---
name: xy-yt-report-v2
description: Analyze one Xiaoyu YouTube channel from authorized API data, paired 28-day and recent 7-day YouTube Studio content-export ZIPs, Studio screenshots, and local channel metadata; then generate the standardized channel analysis documents. Use for channel profiling, audience and CTR diagnosis, or refreshing a channel report and generation specification. Do not use it to generate an individual drama operations package or modify YouTube.
---

# XY YouTube Report V2

## Purpose

Build the complete channel-analysis layer from three fixed input assets:

1. YouTube API data pulled by Codex.
2. Two native Studio content-export ZIPs supplied by the user: recent 28 days and recent 7 days, with the same end date, content filter and metric columns. A preceding 7-day ZIP is optional.
3. The required YouTube Studio screenshots supplied by the user.

This workflow only collects, normalizes, analyzes, and writes channel-analysis documents. It does not generate an individual drama operations package, edit scheduling, or mutate YouTube.

Keep the existing `xy-yt-report` skill unchanged. V2 is an independent workflow with a different input contract and different outputs.

## Required References

Before acting, read these files completely:

- `references/authorization.md`
- `references/asset-contract.md`
- `references/analysis-rules.md`
- `references/output-contract.md`
- `references/generation-spec-contract.md`

## Invocation

Require two positional parameters:

```text
xy-yt-report-v2 <频道名或本地昵称> <素材文件夹>
```

Example:

```text
xy-yt-report-v2 "রাজকীয় প্রেমকথা" "/Users/name/Desktop/频道分析输入"
```

Parameter 1 identifies the channel. Parameter 2 is the user-supplied folder containing the Studio ZIP and screenshots. Both are required. Do not substitute the channel's historical `分析数据/` directory for a missing material-folder parameter.

Resolve names and nicknames through:

```text
运营/工作流运营/公用/频道注册表.json
```

If the target is ambiguous or the material folder does not exist, stop and request the exact missing parameter. Never guess.

## Workflow

1. Parse both required parameters and resolve the registered channel name, channel ID, language, market, channel directory, and canonical OAuth token path.
2. Create the dated history batch path `<频道目录>/分析数据/YYYY-MM-DD_频道分析V2/` only so the authorization evidence has a permanent location. Do not read or copy user assets yet.
3. Validate authorization using `references/authorization.md`. If authorization is absent, expired, invalid, missing required read scopes, or belongs to another channel, complete OAuth authorization and exact channel verification before continuing. This is the first execution gate.
4. Validate that the supplied material folder exists and inventory its Studio ZIP and screenshots. Report only genuinely missing required assets.
5. Preserve supplied assets unchanged in `Studio导出数据/` and `截图/`; extracted CSV copies may live beside the ZIP.
6. Pull the API datasets into `API原始数据/`. Keep Studio CSV windows separate. For API trends use the latest actually returned complete day, record requested and observed ends, and disclose missing days. Pull daily history covering the latest two complete 7-day windows, plus the recent 28-day context and available 90-day history. Use actual returned dates and the Revision 5 rules in analysis-rules.md.
7. If one API dataset fails, retry only that narrow dataset. Do not repeat successful pulls unnecessarily.
8. Do not create a YouTube Reporting Reach job. Studio export is the authoritative source for impressions and CTR in this workflow.
9. Join video IDs to local `剧目/` metadata to recover Chinese drama names, plot, relationship structure, and existing creative context where available.
10. Normalize all sources into `分析产物原始版本/频道Analytics原始快照.json`, preserving source scope and availability states.
11. Analyze audience, traffic, content, packaging/CTR, consumption, concentration, A/B tests, community posts, and channel stage using `analysis-rules.md`.
12. Refresh the three required root documents defined by `output-contract.md`. Build `<频道名>_生成规范.md` from the stable profile and current diagnosis using `generation-spec-contract.md`; its `[GLOBAL]` values come from the channel registry and verified stable channel identity, never from current-period performance. Archive the previous root files before replacement and copy final files into `最终文件快照/`.
13. Validate source coverage, date windows, arithmetic, scope labels, YAML syntax, filenames, output placement, and the generation-spec section contract before completion. Run `python3 scripts/validate_generation_spec.py "<频道目录>/<频道名>_生成规范.md" --expected-channel-name "<注册表正式频道名>" --expected-language "<注册表目标语言>" --expected-market "<注册表目标市场>"`.


## Revision 5 dual-period input

Read references/asset-contract.md for the two required ZIPs and optional preceding week. Identify periods from CSV dates, never filenames or upload order. Preserve each source and total separately. The actual executor input includes studio_short_windows.recent_7d, optional previous_7d, native totals and all exported video rows. Use each window's native total CTR; exported-video weighted CTR has its own scope. Missing prior-week impressions or CTR stays unavailable; never use 28-day CTR or zero as a substitute. Keep 28-day screenshots unchanged and ignore unfinished A/B tests. ZIP files do not encode complete UI filters: user confirmation is a separate source, not machine verification.

## Revision 5 decision requirements

Use the recent complete 7 days versus the preceding complete 7 days as the primary current decision window. Use 28 days for context and available 90-day history for stability. Follow references/analysis-rules.md for date alignment, decline decomposition, microverticals and selection review, and references/output-contract.md for where to put the decisions.

For a launch-stage channel, give one concrete provisional or supported core microvertical, with inclusion/exclusion examples and supply from actual dramas. Broad labels such as female audience, revenge, comeback, billionaire or feel-good fiction cannot serve as launch positioning. Treat editorial choices and measured audience preferences as different evidence states.

Review recent actual selections and any supplied future schedule by video/drama ID. Return retain, improve packaging, inspect opening/language fulfillment, replace, test or defer judgment with reasons. When schedules or candidate inventory are absent, state which review is unavailable and produce the supported vertical selection boundary. Read-only selection guidance belongs in this analysis. Schedule execution belongs to the scheduling workflow.

Completion requires a current decision, supporting and opposing samples, the largest explained changes, concrete priority actions and a test with a decision criterion. A document that only enumerates metrics, source limitations or generic advice is incomplete. When sources are insufficient, narrow the conclusion and give the precise missing comparison while still using available evidence.

## API Pull

Use the project fetcher with the channel-specific token:

```bash
YOUTUBE_TOKEN_FILE="运营/_授权令牌/youtube_accounts/<channel_id>/youtube_oauth_token.json" \
YOUTUBE_ANALYTICS_OUTPUT_ROOT="<history batch>/API原始数据" \
python3 scripts/fetch_youtube_analytics.py \
  --start-date <api-start-date> \
  --end-date <last-complete-date> \
  --max-videos 200
```

Do not expose token contents. Missing or invalid authorization triggers the authorization procedure; do not start formal data extraction or analysis until exact-channel authorization succeeds.

## Completion Boundary

The run is complete only when:

- the API pull has succeeded or is explicitly recorded as unavailable with a concrete reason;
- both Studio ZIP periods and screenshot coverage have been inventoried;
- the normalized JSON has been generated;
- all three root documents have been generated or refreshed;
- the generation specification passes the deterministic seven-section validation;
- historical inputs and final snapshots are stored in the channel's own directory;
- no Reporting Reach task and no YouTube mutation were performed.

In the final response, link the three root documents and report only missing/unavailable data that materially limits the analysis.

## Operational decisions

Preserve all existing inputs, analytical methods, three documents, fact snapshot, exact H2 headings, and the seven-section generation specification. In the diagnosis, start the body of Current content priority with plain-language primary topics, secondary topics, a classification boundary and counterexamples. The distinction is based on the main plot, not the release slot. Review tasks, packaging actions and metric checks belong in their own sections, never in topic lists. Keep the old YAML lists content_priority and content_secondary and make them equal to topics.primary and topics.secondary below.

In the existing channel_strategy YAML add operating_reference with exactly these eight keys: positioning, topics, empathy, reusable_patterns, title, cover, selection_guidance, validation. Each key is an object with status and a nonempty evidence list of strings. Use status data_supported for a conclusion directly supported within its stated sample and window, retest for a hypothesis or next test, and cold_start_hypothesis only for unmeasured cold start. Every object except topics requires conclusion. topics requires primary and secondary lists, a boundary string, and a counterexamples list. title may include examples. Use report/Studio/video references, or state the missing evidence and what would verify it. Platform metadata supplies the applied version and source report IDs.

State who viewers might side with, what conflict they recognize and what change they expect; mark unmeasured empathy as retest. Give concrete target-language title angles and cover scene/action directions with what each would test; respect the registered template and only use facts from the actual story. A winning title-cover combination cannot establish a winning title or cover alone. Separate observed results from editorial choices. In selection_guidance state the plot boundary, why a drama qualifies, and a test direction. Do not recommend playlist names, IDs or routing in analysis outputs. Preserve the required PLAYLIST section of the generation specification as a handoff to the confirmed workflow input. Put specific reproduction steps or the next comparable-sample test in validation. In the seven-section generation specification, carry grounded actionable title and cover guidance into TITLE and COVER; keep channel identity in GLOBAL and do not force any plot onto another drama.
