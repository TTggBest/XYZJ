# Output Contract

## Root documents

Write these three live files directly in the channel directory:

```text
频道用户画像与长期经营档案.md
频道当前运营诊断与运营包指导.md
<频道名>_生成规范.md
```

Their responsibilities are:

| File | Sole responsibility |
|---|---|
| `频道用户画像与长期经营档案.md` | Stable long-term channel knowledge |
| `频道当前运营诊断与运营包指导.md` | Current-period analysis decisions and its machine-readable diagnostic summary |
| `<频道名>_生成规范.md` | The sole downstream channel execution file; channel-specific expression rules derived from the two analysis documents |

Do not write these live files into `output/` or inside the history batch.

`<频道名>_频道分析报告.md` is not a required live output and must not be used as downstream operations-package input. If an older copy exists, preserve it as history; do not refresh it as part of V2.

## History structure

For each analysis run, use:

```text
<频道目录>/分析数据/YYYY-MM-DD_频道分析V2/
├── API原始数据/
├── Studio导出数据/
├── 截图/
│   └── A_B测试/
├── 分析产物原始版本/
│   └── 频道Analytics原始快照.json
├── 更新前文件/
└── 最终文件快照/
```

Store inputs and historical snapshots here. The three live documents remain at channel root.

## Normalized JSON

At minimum include:

```text
schema_version
snapshot_status
generated_at
channel
data_windows
availability_rules
channel_totals_28d
trend
audience_28d
traffic_28d_video_pct
retention_intro_30s_pct
top_videos_28d
low_videos_28d
concentration_28d
community_posts
ab_testing
source_manifest
unmatched_video_ids
```

Every Studio-only field must retain its source and scope. Every missing field must use an explicit availability state.

## Document structure

### Long-term profile

Keep these ten sections:

1. Channel basics
2. Overall performance
3. Audience profile
4. Traffic profile
5. Content profile
6. Packaging profile
7. Consumption profile
8. Stable audience preferences
9. Current channel positioning
10. Long-term strategy

Short-term anomalies must not silently replace stable conclusions.

### Current diagnosis

Keep these seven sections:

1. Current-stage diagnosis
2. What the current audience rewards
3. Current content priority
4. Current title guidance
5. Current cover guidance
6. Current description/community/hashtag guidance
7. Current decision summary

Section 7 must contain valid YAML with this authoritative structure:

```yaml
channel_strategy:
  channel_id: ""
  updated_at: ""
  data_window:
    recent_28d: ""
    recent_90d: ""
  strategy_confidence: ""
  channel_stage: ""
  audience_core: ""
  traffic_type: ""
  content_priority: []
  content_secondary: []
  content_explore: []
  content_avoid: []
  title_priority: []
  title_reduce: []
  cover_priority: []
  cover_reduce: []
  description_focus: []
  community_focus: []
  hashtag_focus: []
  scheduling_notes: []
```

The YAML is authoritative only inside the analysis layer and must agree with the human-readable body. Downstream operations-package production must not read this file; it reads only `<频道名>_生成规范.md`.

### Generation specification

Write the exact seven-section structure defined in `generation-spec-contract.md`. Convert supported channel findings into channel-specific expression guidance for titles, covers, descriptions, hashtags, and community posts. In the required PLAYLIST section only refer to the confirmed workflow input. Do not select the current drama, invent current-drama facts, or turn short-term performance into channel identity.

## Final validation

Before completion verify:

- all three root files exist and have the correct channel name/ID;
- normalized JSON parses;
- the strategy YAML parses and matches the prose;
- date windows and exported-content/video-only scopes are labeled;
- unavailable values are not encoded as zero;
- no per-video returning-viewer sum appears;
- A/B percentages are labeled watch-time shares;
- previous root files and final snapshots were archived;
- no required live file was written to `output/`.
- `<频道名>_生成规范.md` passes `scripts/validate_generation_spec.py`.

### Revision 3 operating reference

Add the eight operating_reference objects inside the existing channel_strategy block in the diagnosis. The operative field definitions and evidence states are in SKILL.md under Operational decisions. Keep the first human-readable priority paragraph and the YAML topic decision consistent. Do not add a fourth Markdown output or alter the fact JSON.


## Revision 5 decisions inside existing sections

Keep the three root documents and existing H2 headings and eight operating_reference keys. Extend the substance inside them.

- Diagnosis section 1 opens with the current verdict, latest complete 7-day versus previous 7-day table, actual dates/cutoff, and priority bottleneck. Show daily turning points and decline contributions here; preserve 28/90-day context after the current result.
- Section 2 compares fitting and opposing concrete drama samples with source, age and duration conditions. State whether covers/openings were actually inspected.
- Section 3 begins with the core launch microvertical and adjacent secondary direction, inclusion/exclusion boundaries and inventory support. Include the recent selection verdict and per-drama retain/change/replace/test reasoning, then review any accessible future plan. Give the exact missing input if a plan cannot be reviewed.
- Sections 4 and 5 each give channel-specific expression guidance, actual supporting examples and prioritized tests. Express the emotional promise at microvertical level and condition it on each drama's true plot.
- Section 7 summarizes immediate decisions, the prior hypothesis review, the next test and its decision condition. In the existing operating_reference, positioning and topics carry the concrete core and adjacent vertical; empathy carries the specific injury and desired payoff; selection_guidance.conclusion carries the selection verdict, inclusion/exclusion and priority batch direction with named targets when known; validation carries windows and test conditions. Keep primary/secondary equal to content_priority/content_secondary.
- The long-term profile separates stable evidence from current launch or recent-week hypotheses. Its positioning section contains a concrete provisional core if the channel is still launching; it labels the evidence state.

Use existing snapshot fields where present. Store added actual-window comparisons and source provenance in the fact snapshot through the collector's supported contract. If runtime has not supplied a new split, mark its absence and analyze what is actually present; do not fabricate source objects. The developer integration requirements are documented alongside the bundle.

Quality acceptance requires answers to why current performance changed, which microvertical is supported/provisional, whether recent selections fit, and what exact next action is justified. Source limitations accompany the affected result and do not replace the decision. A successful schema validator alone does not establish analytical quality.
