# Analysis Rules

## Source precedence and scope

Use sources according to the metric they can actually support:

1. Studio export total row: separate native 28-day and 7-day totals for the exported content scope, returning viewers, revenue, impressions, and CTR. A ZIP does not retain the UI content filter; use studio_exported_content unless all-content coverage is independently verified.
2. Content > Videos screenshot: rounded video-only totals and Studio-only video cards. Keep this scope separate from all-content totals.
3. Analytics API: exact daily trends, per-video performance, country, traffic source, and device splits.
4. Audience screenshot: Studio-only audience segments, gender/age, subscriptions, online time, and adjacent audience interests.
5. A/B screenshots: tested variants and Studio's watch-time-share result.
6. Local drama metadata: Chinese drama identity, plot, relationships, and content DNA.

Do not merge values with different scopes into one unlabeled metric. If the exported-content total and video-only screenshot differ, explain the scope difference instead of calling it a conflict.

## Date and cohort rules

- Derive the Studio window from the CSV contents when the ZIP filename differs.
- Exclude a partial current day from API trends.
- Compare like with like: same duration class, maturity, content type, and comparable traffic conditions.
- Treat a long-form video as mature for performance comparison only after at least 7 complete days unless the report explicitly labels it early performance.
- Do not sum per-video returning viewers: viewers can overlap across videos.
- Do not let one breakout video overwrite the long-term channel identity. Promote a short-term observation to stable knowledge only after repeated-period evidence.

## Derived metrics

Calculate only when inputs are numeric and scopes match:

```text
average_view_duration_minutes = watch_hours * 60 / views
average_percentage_viewed = average_view_duration_seconds / video_duration_seconds * 100
subscriber_gain_per_1000_views = subscribers_gained / views * 1000
RPM = revenue / views * 1000
top_n_view_share = sum(top_n_views) / total_views
browse_suggested_share = browse_share + suggested_share
```

CTR summaries must be impression-weighted, not a simple mean across videos.

## Required analysis domains

Analyze:

- channel stage, latest complete 7 days versus preceding complete 7 days, daily inflection, and 28-day / available 90-day context;
- audience geography, age, gender, device, subscription, and new/returning behavior;
- traffic model and discovery dependence;
- top, middle, and weak content cohorts;
- content DNA: relationships, conflicts, identity, family/children, CEO/revenge, and endings when supported by the dramas;
- packaging and CTR;
- watch time, APV, early retention, and long-tail/first-day behavior;
- traffic and view concentration risk;
- completed A/B tests;
- community-post performance;
- current opportunities, risks, and evidence gaps.

## CTR diagnosis

CTR is never interpreted alone. For each important cohort, jointly inspect:

- impressions and traffic source;
- CTR;
- average view duration/APV;
- video age and sample size.

Use the four quadrants to prioritize investigation. Define high/low relative to comparable channel cohorts and source conditions. They are hypotheses, not causal verdicts:

- high CTR + strong retention: a candidate combination to repeat under comparable source, duration, age and exposure conditions;
- high CTR + weak retention: packaging promise may exceed content delivery;
- low CTR + strong retention: investigate the entry angle and audience/source match; observed viewers staying does not prove broad content appeal;
- low CTR + weak retention: content and packaging both require caution.

Do not call a tiny-impression video a proven high-CTR pattern.

## A/B-test semantics

Studio's A/B percentages are watch-time shares, not variant CTR. Record them exactly as shown and preserve Studio's Winner/Preferred/None decision. Do not convert watch-time share into CTR or claim causality beyond the test result.

## Evidence discipline

- Tie major conclusions to a metric, cohort, screenshot card, or mapped drama set.
- Distinguish fact, calculation, interpretation, and recommendation.
- Use `unavailable` rather than inventing a number or audience trait.
- Do not invent competitor behavior, algorithm penalties, user motives, or title/cover causality that the sources cannot support.

## Confidence

Set descriptive confidence:

- `high`: multiple independent sources or repeated mature cohorts agree;
- `medium`: one strong source or several partially aligned signals;
- `low`: limited samples, early videos, missing audience cards, or a conclusion dominated by one hit.


## Revision 5 recent decisions and decline diagnosis

### Actual data windows

1. Record requested end, actual last returned date, source timezone and collection date separately. A report ends when all its requested metrics are available. Missing a requested last day alone does not invalidate earlier complete observations. Query core trend metrics separately if a slower metric prevents current trend collection.
2. Choose the latest end D with comparable complete daily data for the required trend metrics. Compare D-6 through D with D-13 through D-7, inclusive, nonoverlapping, with explicit dates. Report gaps as unknown, not zero. State the exact day count if either window is shorter. Shorter equal windows may supplement the report but cannot be labeled 7 versus 7.
3. Align each difference to the same scope, video content type and returned date range. Keep older Studio 28-day context alongside fresh API trends under its own dates. Do not ascribe old CTR to fresh API views. A 28-day chart CSV can supply daily CTR or impressions only if those fields and their full scope are present.
4. Show daily turning points within the two windows. Use 48-hour realtime only for present momentum, labeled preliminary, with matching elapsed-hour comparisons. Do not compare a partial final day to a full previous day.
5. A channel with fewer than 14 complete observed days gets the available equal-window comparison and an early-stage decision, not a fabricated prior week.

### Explain the change

Report views, watch time, gained/lost/net subscribers and gain/net per 1,000 views for both windows, with absolute and relative changes. When the baseline is zero, use absolute change and mark the percentage not applicable. Use API-provided average duration/APV where available. Derive an average only when its denominator and content scope are verified.

For declines, break down source views and per-video views in both windows. Rank absolute losses, compute each video's signed contribution to the net channel difference using the same inventory/scope, and show gains from new or recovering videos as offsets. Positive loss contributions may exceed 100% when other videos grow. Reconcile selected contributions and the remaining videos to the total; disclose any source/report discrepancy instead of forcing equality.

Separate existing-video decline from new-upload contribution. Compare new uploads at the same complete elapsed 24h/72h/7d when those observations exist; calendar-day buckets are not exact elapsed-hour windows. If only daily buckets exist, disclose the approximation and use comparable first full-day cohorts. A mature publication date alone does not make period cumulative performance comparable. CTR and APV comparisons must consider duration, source, exposure and audience mix.

Distinguish source views, impressions and CTR. Source-view losses alone identify where views were lost, not whether exposure or clicking caused it. Use source-matched impressions and CTR to estimate the components only when their scope matches. Total views include views outside counted thumbnail impressions, so impressions times CTR is not total views. SUBSCRIBER source includes homepage feeds and subscription features; it is not viewer subscription status.

Inspect per-video retention, opening, target-language audio/subtitles and actual title/thumbnail version for important losses or mismatched promise/fulfillment. Name what was inspected. Thumbnail URLs, plot summaries and model-inferred scenes do not establish that a published cover or opening was visually reviewed. A/B watch-time share and winner remain under the original test's dates and combination.

### Launch-stage microverticals

Define a launch microvertical through a coherent recurring story promise: protagonist's situation, central relationship, specific injury or pressure, agency/response, and expected emotional payoff. Give a natural, specific one-sentence definition. Broad genre names are metadata only and cannot be the launch decision. Do not invent an arbitrary fixed taxonomy or a label quota.

Select one core launch microvertical and justify it using mapped plots, comparable performance and available supply. Identify any adjacent secondary direction and the exact difference from the core. If evidence is weak, choose an explicitly provisional editorial hypothesis with low confidence, not an asserted audience preference. Avoid forcing every successful isolated drama into one vertical. If no coherent core is supported, say so and propose the smallest evidenced test.

For each proposed microvertical, show fitting actual drama IDs and main-plot reasons, opposing/weak samples and sample limitations, plus exclusions such as a story that merely contains divorce, CEO or children. Identify whether the key payoff is actually central to the plot. If available fitting inventory is insufficient for a proposed batch, report the real supply gap. Do not narrow the vertical around one incidental prop or copy one hit's scene into all dramas.

Retain broadening decisions as conditional on repeated adjacent-vertical performance. A single breakout or a number of subscribers does not by itself establish that the channel is ready to broaden.

### Review selections and prescribe the next batch

Use recent published drama mappings and the actual planned list when available. Check scope and date first. Assess each relevant drama as retain, improve packaging, inspect fulfillment, replace, small test, or insufficient evidence. Specify its microvertical fit, supporting/contradicting metrics, recommended action and reason. Low exposure alone cannot establish a weak vertical. Good observed retention alone cannot establish broad demand.

Give a clear overall verdict on recent selections: aligned, partly drifted, or insufficient evidence, with concrete drama IDs. For future plans, recommend replacements only after checking the candidate plot and availability. Honor explicit exclusions including Tempting My Keeper. If the plan or candidate library was not supplied or accessible, state that the future-plan review is unavailable and provide actionable inclusion/exclusion criteria from verified plots. Do not invent planned rows or write the schedule.

Each priority action names the target, current bottleneck or hypothesis, exact variable to change, comparison to retain, signals to observe and condition for continuing or reversing. Set sample/observation conditions using channel exposure and upload cadence, state uncertainty, and avoid universal CTR thresholds or invented numerical success guarantees. Prefer a small controlled change per test. Express recommendations at the strongest level supported by the evidence without turning every result into vague “observe further.”

### Historical decisions

Compare the previous applied diagnosis and its actual windows with current results. Describe which hypothesis is supported, weakened or still untested. Overlapping 28-day reports are not independent periods. Treat a schedule/packaging implementation as verified only if its actual record and version are available. Do not credit or blame this analysis for execution that was not checked.


### Dual-period source handling

Use each Studio export under its own CSV start/end, totals and all video rows. Recent-week videos need their available title, current thumbnail reference and verified plot mapping, even when absent from the 28-day leading cohort. Missing mappings remain gaps; do not infer plots from titles. State when Studio and actually returned API comparison dates differ. A previous-week Studio export is optional and never reconstructed from 28-day per-video totals. Preserve unavailable impressions change and CTR percentage-point change when that export is absent.
