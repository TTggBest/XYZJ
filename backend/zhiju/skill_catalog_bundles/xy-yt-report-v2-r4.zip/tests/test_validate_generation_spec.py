from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


SCRIPT = Path(__file__).parents[1] / "scripts" / "validate_generation_spec.py"
SPEC = importlib.util.spec_from_file_location("validate_generation_spec", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def valid_spec() -> str:
    return f"""## [GLOBAL]

- 正式频道名：Example Channel
- 目标语言：西班牙语
- 目标市场：拉丁美洲
- 频道性别方向：女性向
- 稳定频道类型：情感短剧频道
- 公开内容语言：西班牙语
- 允许的跨语言表达：无
- 频道公共语气：直接、情绪清晰、尊重观众
- GLOBAL权限声明：{MODULE.PERMISSION}

## [TITLE]

使用自然的目标语言。

## [COVER]

画面信息保持清晰。

## [DESCRIPTION]

使用公开内容语言。

## [HASHTAG]

使用目标语言标签。

## [COMMUNITY]

采用自然互动语气。

## [PLAYLIST]

播放列表名称使用目标语言。
"""


class GenerationSpecValidationTests(unittest.TestCase):
    def test_accepts_valid_contract(self) -> None:
        self.assertEqual(MODULE.validate_text(valid_spec()), [])

    def test_rejects_missing_section(self) -> None:
        text = valid_spec().replace("## [PLAYLIST]\n\n播放列表名称使用目标语言。\n", "")
        self.assertTrue(any("章节必须唯一" in error for error in MODULE.validate_text(text)))

    def test_rejects_duplicate_section(self) -> None:
        text = valid_spec() + "\n## [TITLE]\n\n重复。\n"
        self.assertTrue(any("章节必须唯一" in error for error in MODULE.validate_text(text)))

    def test_rejects_wrong_order(self) -> None:
        text = valid_spec().replace("## [TITLE]", "## [TMP]", 1).replace("## [COVER]", "## [TITLE]", 1).replace("## [TMP]", "## [COVER]", 1)
        self.assertTrue(any("固定顺序" in error for error in MODULE.validate_text(text)))

    def test_rejects_extra_h2_section(self) -> None:
        text = valid_spec() + "\n## 其他规则\n\n不应存在。\n"
        self.assertTrue(any("固定标记以外" in error for error in MODULE.validate_text(text)))

    def test_rejects_extra_global_prose(self) -> None:
        text = valid_spec().replace("\n## [TITLE]", "\n这里是额外策略。\n\n## [TITLE]", 1)
        self.assertTrue(any("只能包含九个固定字段" in error for error in MODULE.validate_text(text)))

    def test_rejects_changed_permission_statement(self) -> None:
        text = valid_spec().replace(MODULE.PERMISSION, "GLOBAL可以决定当前剧情。")
        self.assertTrue(any("权限声明" in error for error in MODULE.validate_text(text)))

    def test_rejects_forbidden_global_content(self) -> None:
        text = valid_spec().replace("情感短剧频道", "近期CTR 18%的CEO题材频道")
        errors = MODULE.validate_text(text)
        self.assertTrue(any("禁止内容" in error for error in errors))

    def test_rejects_registry_identity_mismatch(self) -> None:
        errors = MODULE.validate_text(
            valid_spec(),
            expected_channel_name="Another Channel",
            expected_language="西班牙语",
            expected_market="拉丁美洲",
        )
        self.assertTrue(any("与注册表不一致" in error for error in errors))

    def test_rejects_unresolved_global_placeholder(self) -> None:
        text = valid_spec().replace("Example Channel", "<注册表正式频道名>")
        self.assertTrue(any("模板占位符" in error for error in MODULE.validate_text(text)))


if __name__ == "__main__":
    unittest.main()
