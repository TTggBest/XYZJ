#!/usr/bin/env swift

import AppKit
import Foundation
import Vision

struct OCRLine: Codable {
    let text: String
    let confidence: Float
    let x: Double
    let y: Double
    let width: Double
    let height: Double
}

struct OCRFile: Codable {
    let path: String
    let lines: [OCRLine]
    let error: String?
}

func recognize(_ path: String) -> OCRFile {
    guard let image = NSImage(contentsOfFile: path) else {
        return OCRFile(path: path, lines: [], error: "cannot_load_image")
    }
    var rect = NSRect(origin: .zero, size: image.size)
    guard let cgImage = image.cgImage(forProposedRect: &rect, context: nil, hints: nil) else {
        return OCRFile(path: path, lines: [], error: "cannot_create_cgimage")
    }

    let request = VNRecognizeTextRequest()
    request.recognitionLevel = .accurate
    request.usesLanguageCorrection = true
    if let supported = try? request.supportedRecognitionLanguages() {
        let preferred = ["zh-Hans", "hi-Deva", "en-US"].filter { supported.contains($0) }
        if !preferred.isEmpty { request.recognitionLanguages = preferred }
    }

    do {
        try VNImageRequestHandler(cgImage: cgImage, options: [:]).perform([request])
        let observations = (request.results ?? []).sorted {
            let dy = abs($0.boundingBox.midY - $1.boundingBox.midY)
            if dy > 0.01 { return $0.boundingBox.midY > $1.boundingBox.midY }
            return $0.boundingBox.minX < $1.boundingBox.minX
        }
        let lines = observations.compactMap { observation -> OCRLine? in
            guard let candidate = observation.topCandidates(1).first else { return nil }
            let box = observation.boundingBox
            return OCRLine(
                text: candidate.string,
                confidence: candidate.confidence,
                x: box.minX,
                y: box.minY,
                width: box.width,
                height: box.height
            )
        }
        return OCRFile(path: path, lines: lines, error: nil)
    } catch {
        return OCRFile(path: path, lines: [], error: String(describing: error))
    }
}

var arguments = Array(CommandLine.arguments.dropFirst())
var outputPath: String?
if arguments.count >= 2 && arguments[0] == "--output" {
    outputPath = arguments[1]
    arguments.removeFirst(2)
}

let files = arguments.map(recognize)
let encoder = JSONEncoder()
encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
let data = try encoder.encode(files)
if let outputPath {
    try data.write(to: URL(fileURLWithPath: outputPath), options: .atomic)
} else {
    FileHandle.standardOutput.write(data)
    FileHandle.standardOutput.write(Data("\n".utf8))
}
