---
name: xy-yt-report-v2
description: Analyze one Xiaoyu YouTube channel from authorized API data, one recent YouTube Studio content-export ZIP, Studio screenshots, and local channel metadata; then generate the standardized channel analysis documents. Use for channel profiling, audience and CTR diagnosis, or refreshing a channel report and generation specification. Do not use it to generate an individual drama operations package or modify YouTube.
---

# XY YouTube Report V2

## Purpose

Build the complete channel-analysis layer from three fixed input assets:

1. YouTube API data pulled by Codex.
2. One recent 28-day YouTube Studio content-export ZIP supplied by the user.
3. The required YouTube Studio screenshots supplied by the user.

This workflow only collects, normalizes, analyzes, and writes channel-analysis documents. It does not generate an individual drama operations package, edit scheduling, or mutate YouTube.

Keep the existing `xy-yt-report` skill unchanged. V2 is an independent workflow with a different input contract and different outputs.

## Required References

Before acting, read these files completely:

- `references/authorization.md`
- `references/asset-contract.md`
- `references/analysis-rules.md`
- `references/output-contract.md`
- `references/generation-spec-contract.md`

## Invocation

Require two positional parameters:

```text
xy-yt-report-v2 <频道名或本地昵称> <素材文件夹>
```

Example:

```text
xy-yt-report-v2 "রাজকীয় প্রেমকথা" "/Users/name/Desktop/频道分析输入"
```

Parameter 1 identifies the channel. Parameter 2 is the user-supplied folder containing the Studio ZIP and screenshots. Both are required. Do not substitute the channel's historical `分析数据/` directory for a missing material-folder parameter.

Resolve names and nicknames through:

```text
运营/工作流运营/公用/频道注册表.json
```

If the target is ambiguous or the material folder does not exist, stop and request the exact missing parameter. Never guess.

## Workflow

1. Parse both required parameters and resolve the registered channel name, channel ID, language, market, channel directory, and canonical OAuth token path.
2. Create the dated history batch path `<频道目录>/分析数据/YYYY-MM-DD_频道分析V2/` only so the authorization evidence has a permanent location. Do not read or copy user assets yet.
3. Validate authorization using `references/authorization.md`. If authorization is absent, expired, invalid, missing required read scopes, or belongs to another channel, complete OAuth authorization and exact channel verification before continuing. This is the first execution gate.
4. Validate that the supplied material folder exists and inventory its Studio ZIP and screenshots. Report only genuinely missing required assets.
5. Preserve supplied assets unchanged in `Studio导出数据/` and `截图/`; extracted CSV copies may live beside the ZIP.
6. Pull the API datasets into `API原始数据/`. Use the most recent completed day as the end date. Pull a recent 28-day window and, when channel age permits, enough daily history for a 90-day comparison.
7. If one API dataset fails, retry only that narrow dataset. Do not repeat successful pulls unnecessarily.
8. Do not create a YouTube Reporting Reach job. Studio export is the authoritative source for impressions and CTR in this workflow.
9. Join video IDs to local `剧目/` metadata to recover Chinese drama names, plot, relationship structure, and existing creative context where available.
10. Normalize all sources into `分析产物原始版本/频道Analytics原始快照.json`, preserving source scope and availability states.
11. Analyze audience, traffic, content, packaging/CTR, consumption, concentration, A/B tests, community posts, and channel stage using `analysis-rules.md`.
12. Refresh the three required root documents defined by `output-contract.md`. Build `<频道名>_生成规范.md` from the stable profile and current diagnosis using `generation-spec-contract.md`; its `[GLOBAL]` values come from the channel registry and verified stable channel identity, never from current-period performance. Archive the previous root files before replacement and copy final files into `最终文件快照/`.
13. Validate source coverage, date windows, arithmetic, scope labels, YAML syntax, filenames, output placement, and the generation-spec section contract before completion. Run `python3 scripts/validate_generation_spec.py "<频道目录>/<频道名>_生成规范.md" --expected-channel-name "<注册表正式频道名>" --expected-language "<注册表目标语言>" --expected-market "<注册表目标市场>"`.

## API Pull

Use the project fetcher with the channel-specific token:

```bash
YOUTUBE_TOKEN_FILE="运营/_授权令牌/youtube_accounts/<channel_id>/youtube_oauth_token.json" \
YOUTUBE_ANALYTICS_OUTPUT_ROOT="<history batch>/API原始数据" \
python3 scripts/fetch_youtube_analytics.py \
  --start-date <api-start-date> \
  --end-date <last-complete-date> \
  --max-videos 200
```

Do not expose token contents. Missing or invalid authorization triggers the authorization procedure; do not start formal data extraction or analysis until exact-channel authorization succeeds.

## Completion Boundary

The run is complete only when:

- the API pull has succeeded or is explicitly recorded as unavailable with a concrete reason;
- the Studio ZIP and screenshot coverage have been inventoried;
- the normalized JSON has been generated;
- all three root documents have been generated or refreshed;
- the generation specification passes the deterministic seven-section validation;
- historical inputs and final snapshots are stored in the channel's own directory;
- no Reporting Reach task and no YouTube mutation were performed.

In the final response, link the three root documents and report only missing/unavailable data that materially limits the analysis.
