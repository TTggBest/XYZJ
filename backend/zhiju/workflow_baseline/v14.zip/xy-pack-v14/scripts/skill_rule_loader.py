#!/usr/bin/env python3
import json
from pathlib import Path


SKILLS_ROOT = Path(__file__).resolve().parents[2]

# Production channel metadata uses these short labels, while some historical
# rule files use a country-name label.  Resolve the alias before falling back
# to the English default block.
LANGUAGE_RULE_ALIASES = {
    "印地": "印度",
    "印地语": "印度",
    "Hindi": "印度",
    "Bengali": "孟加拉",
    "Indonesian": "印尼",
    "Filipino": "菲律宾",
    "Tagalog": "菲律宾",
    "Filipino / Tagalog": "菲律宾",
    "Spanish": "西班牙",
    "Brazilian Portuguese": "巴葡",
    "Portuguese (Brazil)": "巴葡",
    "Turkish": "土耳其",
    "Arabic": "阿拉伯语",
    "English": "英语",
    "Russian": "俄语",
    "Thai": "泰语",
    "Vietnamese": "越南语",
    "French": "法语",
    "Urdu": "乌尔都语",
    "Malay": "马来语",
    "German": "德语",
    "Italian": "意大利语",
    "Korean": "韩语",
    "Japanese": "日语",
    "Polish": "波兰",
    "Greek": "希腊语",
}


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_skill_rules(skill_name: str, filename: str) -> dict:
    path = SKILLS_ROOT / skill_name / "rules" / filename
    if not path.exists():
        raise FileNotFoundError(f"Skill rule file not found: {path}")
    return load_json(path)


def language_rule_block(mapping: dict, language: str, *, allow_default: bool = True):
    normalized = str(language or "").strip()
    rule_key = LANGUAGE_RULE_ALIASES.get(normalized, normalized)
    if rule_key in mapping:
        return mapping[rule_key]
    if allow_default and "default" in mapping:
        return mapping["default"]
    raise KeyError(f"Missing language rule block for {language}")


def render_template_values(payload, replacements: dict[str, str]):
    if isinstance(payload, str):
        result = payload
        for key, value in replacements.items():
            result = result.replace("{" + key + "}", value)
        return result
    if isinstance(payload, list):
        return [render_template_values(item, replacements) for item in payload]
    if isinstance(payload, dict):
        return {key: render_template_values(value, replacements) for key, value in payload.items()}
    return payload


def load_description_rule_bundle(language: str, channel_name: str) -> dict:
    rules = load_skill_rules("xy-place-v14", "description_rules.json")
    assets = language_rule_block(rules["fixed_assets_defaults"], language)
    rendered_assets = render_template_values(assets, {"channel_name": channel_name})
    return {
        "rules_version": rules.get("version", 1),
        "fixed_assets": rendered_assets,
        "contract": rules.get("description_contract", {}),
    }


def load_community_rule_bundle() -> dict:
    return load_skill_rules("xy-post-v14", "community_copy_rules.json")


def load_title_rule_bundle() -> dict:
    return load_skill_rules("xy-title-v14", "title_rules.json")


def load_cover_rule_bundle() -> dict:
    return load_skill_rules("xy-cover-v14", "cover_rules.json")
