#!/usr/bin/env python3
"""Compatibility reader for canonical workflow JSON.

Markdown is display-only.  This module deliberately contains no Markdown
parsers and can never manufacture or repair JSON from text files.
"""

from __future__ import annotations

import json
from pathlib import Path


CANONICAL_PAIRS = (
    ("04_标题方案.md", "04_标题方案.json"),
    ("04_封面提示词.md", "04_封面提示词.json"),
    ("place_result.md", "place_result.json"),
    ("06_社群方案.md", "06_社群方案.json"),
)


def sync_structured_outputs(package_path: Path) -> dict[str, str]:
    """Verify and return canonical JSON paths without mutating the package."""
    outputs: dict[str, str] = {}
    for markdown_name, json_name in CANONICAL_PAIRS:
        markdown_path = package_path / markdown_name
        json_path = package_path / json_name
        if markdown_path.exists() and not json_path.exists():
            raise RuntimeError(
                f"Canonical JSON missing; Markdown cannot be reverse parsed: {json_name}"
            )
        if json_path.exists():
            payload = json.loads(json_path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise RuntimeError(f"Canonical JSON root must be object: {json_name}")
            outputs[json_name] = str(json_path)
    return outputs
