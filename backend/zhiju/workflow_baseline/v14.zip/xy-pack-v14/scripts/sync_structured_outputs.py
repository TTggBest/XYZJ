#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

from structured_outputs import sync_structured_outputs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("package")
    args = parser.parse_args()

    package_path = Path(args.package).expanduser().resolve()
    outputs = sync_structured_outputs(package_path)
    print(
        json.dumps(
            {
                "package_path": str(package_path),
                "outputs": outputs,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
