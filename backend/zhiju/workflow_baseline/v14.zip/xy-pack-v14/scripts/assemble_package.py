#!/usr/bin/env python3
import argparse
import json
import re
import sys
from pathlib import Path

CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.append(str(CURRENT_DIR))

from skill_rule_loader import load_community_rule_bundle


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def strip_first_heading(text: str) -> str:
    lines = text.splitlines()
    if lines and lines[0].startswith("#"):
        return "\n".join(lines[1:]).strip()
    return text.strip()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def title_direct_list(title_text: str) -> list[str]:
    titles = []
    for key in ("标题1", "标题2", "标题3"):
        m = re.search(rf"^{key}：(.+)$", title_text, flags=re.MULTILINE)
        if m:
            titles.append(m.group(1).strip())
    return titles


def normalize_single_links(text: str) -> str:
    contract = load_community_rule_bundle()
    if not contract.get("normalize_markdown_links_before_validation", True):
        return text
    text = re.sub(
        r"\[(https://youtu\.be/[A-Za-z0-9_-]+)\]\(https://www\.youtube\.com/watch\?v=[A-Za-z0-9_-]+\)",
        r"\1",
        text,
    )
    text = re.sub(
        r"\[(https://youtu\.be/[A-Za-z0-9_-]+)\]\(https://youtu\.be/[A-Za-z0-9_-]+\)",
        r"\1",
        text,
    )
    text = re.sub(
        r"\[[^\]]*?(https://youtu\.be/[A-Za-z0-9_-]+)[^\]]*?\]\(https?://[^)]+\)",
        r"\1",
        text,
    )
    text = re.sub(
        r"\[([^\]]+)\]\((https?://[^)]+)\)",
        r"\2",
        text,
    )
    return text


def infer_output_dir(package_path: Path) -> str:
    parts = package_path.parts
    try:
        idx = parts.index("运营")
        return "/".join(parts[idx:])
    except ValueError:
        return str(package_path)


def build_package(package_path: Path) -> str:
    state_path = package_path / "workflow_state.json"
    meta_path = package_path / "剧目元数据.json"
    title_path = package_path / "04_标题方案.md"
    cover_path = package_path / "04_封面提示词.md"
    post_path = package_path / "06_社群方案.md"
    # Current workflow writes placement to place_result.md.  The historical
    # 07_播放列表建议.md file is optional and must never block assembly.
    place_path = package_path / "place_result.md"

    if not state_path.exists():
        raise SystemExit(f"Missing workflow_state.json: {state_path}")
    state = load_json(state_path)
    meta = load_json(meta_path) if meta_path.exists() else {}

    if not title_path.exists() or not cover_path.exists() or not place_path.exists():
        raise SystemExit("Missing required step files: 04_标题方案.md / 04_封面提示词.md / place_result.md")

    title_text = strip_first_heading(read_text(title_path))
    cover_text = strip_first_heading(read_text(cover_path))
    place_text = strip_first_heading(read_text(place_path))
    post_text = normalize_single_links(strip_first_heading(read_text(post_path))) if post_path.exists() else ""

    direct_titles = title_direct_list(title_text)
    lines = [
        "# 运营包",
        "",
        "## 基础信息",
        "",
        f"剧名：{state.get('drama_name', meta.get('drama_name', package_path.name))}",
        "",
        f"语言：{state.get('language', meta.get('language', ''))}",
        "",
        f"频道：{state.get('channel', meta.get('channel', ''))}",
        "",
        f"本地昵称：{state.get('nickname', meta.get('nickname', ''))}",
        "",
        f"档期：{state.get('slot', meta.get('slot', ''))}",
        "",
        f"输出目录：{infer_output_dir(package_path)}/",
        "",
        "## 标题输出",
        "",
        title_text,
        "",
    ]
    if direct_titles:
        lines.extend(
            [
                "## 标题直列",
                "",
                *direct_titles,
                "",
            ]
        )
    lines.extend(
        [
            "## 封面",
            "",
            cover_text,
            "",
            "## 播放列表",
            "",
            place_text,
            "",
        ]
    )
    if state.get("need_community", True):
        lines.extend(
            [
                "## 社群",
                "",
                post_text or "待补充",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "## 社群",
                "",
                "本剧未要求社区图与社区文案。",
                "",
            ]
        )
    return "\n".join(lines).rstrip() + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("package")
    args = parser.parse_args()

    package_path = Path(args.package).expanduser().resolve()
    output = build_package(package_path)
    output_path = package_path / "运营包.md"
    output_path.write_text(output, encoding="utf-8")

    state_path = package_path / "workflow_state.json"
    state = load_json(state_path)
    state["assembled_package"] = True
    state["assembled_package_path"] = str(output_path)
    state["structured_outputs_source"] = "canonical_json_only"
    write_json(state_path, state)

    print(
        json.dumps(
            {
                "package_path": str(package_path),
                "output_path": str(output_path),
                "direct_titles": title_direct_list(strip_first_heading(read_text(package_path / "04_标题方案.md"))),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
