#!/usr/bin/env python3
raise SystemExit("核心词统计已从当前生产流程移除，禁止更新。")
