---
name: xy-workflow-v14
description: Select the frozen Xiaoyu V14 production workflow from work-order generation through package finalization. Use when the user explicitly says V14 or asks to switch production or testing to V14.
---

# XY Workflow V14

V14 is isolated from the frozen V13 baseline for development and testing. Its Find stage may contain the separately authorized market-packaging evidence upgrade; no other planned V14 change is authorized by that approval. Creating or selecting this Skill does not authorize production. Do not initialize, continue, retry, or write back any V14 production batch unless the user explicitly authorizes V14 production in the current request.

Use only the V14 chain: `xy-generate-tasks-v14`, `xy-batch-v14`, `xy-find-v14`, `xy-title-v14`, `xy-cover-v14`, `xy-place-v14`, `xy-post-v14`, `xy-pack-v14`, `xy-finalize-v14`, `xy-sort-v14`, and `xy-logo-v14`.

Use the shared data root `运营/工作流运营`. Read `运营/工作流实验室/V14/公用/XY生产锁定规范_V14.md` before any production mutation. Freeze the selected V14 skill and rule hashes into each new batch. Do not load any V2 skill or rule in the same frozen batch.
