---
name: xy-post-v14
description: Generate Xiaoyu YouTube community post materials for a short drama. Use after xy-find and xy-title when producing a 1:1 community image prompt, reversal-based community copy, interactive hooks, comments, or high-impact social text for the current channel language.
---

# XY Post

## Inputs

In deterministic batch mode, the controller supplies the normalized contents of:

```text
01_搜索资料.md
04_标题方案.md
频道名_生成规范.md
```

If it exists, also read the channel-level fixed footer CTA file:

```text
频道根目录/community_footer_cta.json
```

Community-copy validation contract:

```text
<xy-post skill dir>/rules/community_copy_rules.json
```

## Rules

- Same-drama `creative_history` is a forbidden-reference list. Do not reuse or translate another channel's post hook, interaction question, selected plot moment, image scene, action, or evidence prop.
- Return `community_hook_type`, concrete Chinese `selected_moment`, and concrete Chinese `interaction_angle` for cross-channel collision validation.

- In a future V2 batch, generate exactly `community_count` independent result blocks. `0` skips; positive `N` produces N. Legacy batches keep their original boolean behavior.
- Each result uses sequential `plan_index` and must differ from every sibling in selected moment, interaction angle, scene family, main action, key prop, composition, palette, copy, and image concept.
- Use the supplied video link exactly once per copy. When the link is unavailable, preserve the exact placeholder `【视频链接待补】`; this placeholder is allowed even though ordinary Chinese text remains forbidden in channel-language copy.
- Community workflow order is fixed: `01_搜索资料.md里的独有冲突/不确定边界 -> 标题方向 -> 当前频道生成规范语气 -> 社群图/文案`. Do not start from a fixed community copy skeleton.
- Community image is 1:1.
- Community image prompt must be in English.
- The community image prompt must use English descriptive words for scene, characters, action, conflict, composition, lighting, style, safety, and visual layout.
- Do not write Chinese scene descriptions inside `社群图 1：1`.
- Only visible overlay text, hook sentence, subscribe CTA, and share CTA may be in the channel language.
- Chinese is allowed only in `社群文案翻译` or review labels outside the actual image prompt text.
- Community copy must be in the channel language.
- Community copy must be pure channel language. Do not leave Chinese names, Chinese labels, copied Chinese note text, or mixed Chinese-channel-language sentences anywhere in the community copy body.
- The scene must be reversal-heavy, emotionally direct, and visually understandable.
- All visible people in the community image must have Chinese facial features and a contemporary Chinese short-drama cast appearance. This is mandatory even for non-Chinese language channels because the content is Chinese short drama. Do not generate South Asian, Bengali, Western, or mixed-ethnicity faces unless the user explicitly overrides this for a specific drama.
- Match the channel language and tone from the report.
- Treat the fixed channel theme as existing context that guides angle selection and expression. Do not force its wording to appear verbatim in the public copy or image hook, and do not create a new planning or output field for this purpose.
- Match not only the language but also the current channel's recognition model when the current report defines one clearly. If the current report locks a stable winning structure for this channel, the community copy and community image must still sound and look like this channel when the current drama supports it. Do not drift into generic copy, and do not import another channel's winner structure into this one.
- Avoid generic slogans and avoid claims unsupported by the story card.
- Community copy and image hook must be drama-specific, not just topic-specific. Same channel and same topic do not justify reusing the same `他们不知道 / 全家震惊 / 订阅分享` body with only nouns swapped.
- The image hook must express only the selected scene's single core conflict, choice, or relationship change. It must not also carry a complete plot summary or the interaction question; keep the full interaction question in the Community copy.
- Build each Community copy around one primary audience decision. Include only the minimum background needed to understand that decision, then stop explaining the plot. Do not introduce a second competing interaction goal.
- The Community body before the formal interaction CTA must establish only scene, conflict, and choice background; it must not ask the audience any question. Put the one audience-facing question only in the formal `🤔` interaction CTA.
- This is a generation priority, not a question-mark count, word limit, character limit, or Validator rule. Natural supporting suspense statements are allowed when they serve the same decision.
- No gore, no sexual content, no unsafe depiction of children or teenagers.
- If the channel report or synced channel fields provide `专属表情`, use that emoji in the final subscribe line instead of substituting another emotional emoji.
- The bottom CTA of the community image is a channel-level fixed asset, not a drama-level variable. For the same channel, the subscribe CTA text, share CTA text, icon order, layout style, and bar style must stay identical across every community image. Do not rewrite the bottom CTA just because the drama is different.
- The first-line full-video CTA in Community copy is also a channel-level fixed asset. The exact format is `🔥 {full_video_cta} 👉 {video_link}`. Only the video link changes by drama; the CTA wording must not be translated or paraphrased again.
- Keep the channel-language hook sentence, both CTA buttons, emoji, and their precise fixed layout inside the generated image prompt. This workflow does not switch Community images to a text-free base image or a later code-overlay step.
- If `community_footer_cta.json` already exists for the channel, reuse its `subscribe_cta`, `share_cta`, and `layout_style` exactly. Do not paraphrase, shorten, decorate, or swap words.
- If `community_footer_cta.json` does not exist yet, create it once for the channel and then reuse it for all later dramas in that channel. Prefer a simple fixed two-pill layout with left `🔔 subscribe` CTA and right `🙏 share` CTA.
- Same language is not enough. The rule is stronger: same channel means same footer CTA copy and same footer CTA layout.
- Same channel means same footer CTA only. It does not mean same main hook sentence, same conflict wording, same reversal paragraph, same interaction question, or same image scene.
- Use one concrete hook from `01_搜索资料.md` that belongs to this drama only, such as `听见孩子心声`, `报恩小福宝`, `功夫双娃`, `救过霍家孩子`, `错认恩人`, `解约协议`, `豪门争宠`, etc. If the community copy could be pasted onto another drama in the same channel with only 1 to 3 nouns changed, rewrite it.
- Same-channel differentiation and same-channel recognition must coexist. For a mature channel, the community body should usually contain:
  - one `channel-level stable anchor` from the current channel report when supported by the plot
  - one `this-drama-only hook`
  Do not let all posts become identical, but do not strip out the current channel's main recognition tags either.
- If `01_搜索资料.md` lists an item under `不可确认/不能当事实`, do not use it in the community image or copy.
- If `01_搜索资料.md` does not provide a confirmed plot and only contains title/alias-derived summary, base the community hook on the Chinese title's literal conflict and the selected title direction. Do not add unconfirmed relationship twists, exact locations, documents, children, weddings, hospitals, or identity props.
- The community image must not simply remake the cover as a square image. It should use the same story hook but can choose a different conflict moment, reaction, or question angle.
- Before generating the community image prompt, compare against this package's canonical `04_封面提示词.json`. The community image must have a different `community concept tuple` from the covers:
  - scene family
  - main visible action
  - proof/object
  - emotional question
  - foreground blocking
  If the square image would look like a cropped version of one cover, rewrite it.
- Community image is the feed hook, not a fourth cover. It should answer a viewer-facing question or emotional reversal that makes people click the linked video. Prefer one of these community-specific angles when supported:
  - before/after recognition moment
  - parent-child warmth after the truth
  - one decisive object on a table while adults react
  - a public misunderstanding frozen at the turning point
  - heroine's emotional choice rather than generic crowd shock
  - villain/fake identity losing control while the real family stands together
- Do not use the same default community template across dramas: `office desk + document/cards + shocked CEO + bottom CTA`, `luxury room + evidence + family stunned`, or `child points at adult + everyone freezes`. These are invalid when reused as the main community image structure.
- For community images with children, apply the same child-safe visual rules as `xy-cover`: no child pointing at adults, no child holding proof as the main reveal, no medical-emergency staging, no rescue/save/weak/pale/clinic/hospital wording, and no negative risk-word lists. The child should be a warm emotional anchor, not a prosecutor.
- For child-led, 萌宝, 双宝, 三宝, 四宝, 五宝, 多宝, twins, triplets, or explicit child-count stories, preserve the visible child count as a first-order story signal whenever the title/search evidence makes that count part of the hook. Control adult count, not child count. Do not collapse `双宝/三宝/四宝/五宝` into `one child + implied others`.
- In child-count stories, visible children must carry the hook directly. Do not replace missing children with indirect hints such as drawings, framed photos, handprints, backpacks, baby shoes, toys, stroller, silhouettes, off-screen references, or dialogue-only implication when those children are supposed to be one of the clickable reasons to stop scrolling.
- For child-led community images, default adult count to `1-2` meaningful adults and then keep the needed children visible. If the scene becomes crowded, reduce adults first, side characters second, and props third. Do not solve crowding by deleting the children that define the title hook.

## Community Image Template

The community image must draw one concise hook sentence, not just a few keywords.

Use this structure for `社群图 1：1：`:

```text
Create a square 1:1 YouTube Community post image for a short drama.

Scene:
[English description of one strong reversal/conflict moment from the drama.]
- This scene must be materially different from the 3 cover scenes unless the source story has only one confirmed location.

Main characters:
[English description of the main people, identity relationship, expressions, and actions.]
- Must explicitly state that all visible people have Chinese facial features and a contemporary Chinese short-drama cast appearance.
- Must explicitly forbid South Asian, Bengali, Western, or mixed-ethnicity faces unless the user overrides it for this drama.

Conflict:
[English description of the visible conflict: humiliation, betrayal, hidden identity reveal, revenge, CEO shock, family shock, comeback, or sweet reversal.]
- For child-led or 萌宝 stories, express the conflict as family recognition, mistaken-parent warmth, reunion, or adult realization. Do not make the child accuse, point, expose, or order adults.
- If the title/search evidence explicitly says `双宝/三宝/四宝/五宝` or another concrete child count, keep that child count visible or as close as composition safely allows. Do not rewrite a multi-child hook into a one-child prompt unless the source evidence itself proves only one child is present in the key scene.

Composition:
- 1:1 square image.
- Medium close-up or half-body characters.
- Main faces must be large, sharp, and unobstructed.
- Strong emotional contrast.
- Clear foreground subject.
- Background supports the story but must not be messy.
- No tiny full-body distant characters.

Hook sentence overlay:
[One concise channel-language hook sentence expressing the scene's core conflict, choice, or relationship change.]
- Big bold readable text.
- High contrast.
- Thick outline.
- Subtle shadow.
- Must be eye-catching on mobile.
- Must not cover the main characters' faces.

Bottom CTA overlay:
🔔 [Channel-language subscribe CTA]   🙏 [Channel-language share CTA]
- Use the exact channel-fixed CTA copy from `community_footer_cta.json` when available.
- Use the same layout style for the same channel every time. Default preferred layout: two separate rounded black pills with yellow outline, left pill for subscribe, right pill for share.
- Place the whole bottom CTA block slightly higher than before. Do not stick it to the very bottom edge.
- Keep the CTA block bottom edge at roughly 6% to 9% above the image bottom edge.
- Keep a visibly larger safe margin from the bottom edge than the previous workflow.
- Must not cover faces or important story objects.
- Must be readable and high contrast.
- Keep the CTA block centered horizontally and visually balanced.

Visual style:
- Natural live-action TV drama still.
- Realistic lens rendering and natural skin texture.
- Ordinary clothing wrinkles and believable location lighting.
- Slightly softer environmental detail while faces remain readable through framing.
- Dramatic but photographic, without plastic beauty-filter rendering.
- Do not request ultra sharp focus, crisp facial details, high/strong micro-contrast, clean edges, sharp facial highlights, or mobile-readability rendering.

Safety:
- No gore.
- No sexual content.
- No unsafe depiction of children or teenagers.
- No real celebrity likeness.
- No graphic violence.

Goal:
Make viewers stop scrolling, click the video link, comment, subscribe, and share.
```

Bottom CTA consistency file:

- Channel root file path:

```text
community_footer_cta.json
```

- Recommended shape:

```json
{
  "full_video_cta": "Obejrzyj całą historię tutaj",
  "subscribe_cta": "Subskrybuj pełne historie",
  "share_cta": "Udostępnij znajomym",
  "layout_style": "dual_pill_black_yellow",
  "updated_at": "YYYY-MM-DD HH:MM:SS"
}
```

- Once created for a channel, future community images in that channel must reuse it exactly.
- When a read-only channel folder has no CTA file, the controller must resolve
  all three CTA strings from the batch-frozen language defaults in
  `rules/community_copy_rules.json`. It must not create or modify a file in the
  historical production root.

## Community Copy Template

Use this flexible structure for `社群文案：`, translated into the channel language. The first link line and final subscribe/share lines are fixed, but the body must be drama-specific and may change order to fit the story:

```text
🔥 [完整故事请看这里] 👉 [视频链接]
[1-2 行：最强冲突/羞辱/误会/背叛]

[转折句：使用本剧自己的反转，不要默认写“但是他们不知道”]

[1-2 行：身份/力量/秘密/反转爆点]

[1-2 行：结果/全家震惊/CEO 沉默/敌人后悔]

🤔 [互动问题：如果是你，你会怎么做？你会相信谁？]
👇 [评论引导：在评论区告诉我们]

[订阅引导] 🔔[频道专属/情绪emoji]
[分享引导] 🙏
```

Copy rules:

- The first line must contain only one visible URL, using the short-link form:
  `https://youtu.be/VIDEO_ID`
- Do not use Markdown links, dual-link format, bracketed links, or `[short-link](long-link)` anywhere in community copy. This is a hard rule; outputs using Markdown links are invalid and must be rewritten.
- This rule applies to every channel and every export target. Never output `[https://youtu.be/VIDEO_ID](https://youtu.be/VIDEO_ID)`, `[https://youtu.be/VIDEO_ID](https://www.youtube.com/watch?v=VIDEO_ID)`, or any other Markdown-wrapped URL. The copy must contain the bare short URL only.
- Script-side validation for fixed emojis, minimum non-empty lines, and link-format rules must read the xy-post skill rule file `rules/community_copy_rules.json` resolved relative to this `SKILL.md`. Do not maintain a second hardcoded community-copy contract in unrelated scripts.
- For Bengali `আমার প্রেমের গল্প`, the first line must use this exact single-link pattern:
  `🔥 সম্পূর্ণ গল্প দেখতে এখানে ক্লিক করুন 👉 https://youtu.be/VIDEO_ID`
- Do not insert a blank line between the video link line and the first conflict line.
- Keep short lines for mobile readability.
- Use `🔥`, `👉`, `🤔`, `👇`, `🔔`, `🙏` as fixed structure emojis.
- Add channel-specific/emotional emoji only where it improves the line.
- The final subscribe line should follow this Bengali pattern when applicable:
  `নতুন সম্পূর্ণ বাংলা ডাব গল্প দেখতে সাবস্ক্রাইব করুন 🔔[频道专属表情]`
- The final share line should follow:
  `বন্ধুদের সাথে শেয়ার করুন 🙏`
- The first visible area must include the video link and the strongest conflict.
- For channels with a locked winner model in the current report, the first 3 to 4 non-empty lines should usually expose at least one stable channel anchor when the current plot supports it. Use the current channel's own anchors only. Do not turn another channel's recurring nouns into the opening pattern for this channel.
- Community copy must create curiosity, argument, empathy, or a choice.
- Keep one primary audience decision throughout the copy. Supply only the minimum background needed to understand that decision instead of retelling the Description, and do not introduce a second competing interaction goal.
- Before the formal `🤔` interaction CTA, write only scene, conflict, reversal, payoff, or choice background; do not ask the audience a preliminary or rhetorical question. The formal `🤔` line owns the only audience-facing question.
- The interaction question must be tied to this drama's unique reversal. Do not repeatedly ask generic questions like `如果是你，你会相信谁` or `你会怎么做` unless they are grounded in this drama's specific conflict.
- Prefer 3-part copy logic:
  - first conflict unique to this drama
  - second reversal unique to this drama
  - third payoff or emotional choice unique to this drama
  Avoid the default generic rhythm `她被羞辱 -> 他们不知道 -> 全家震惊` unless the story card itself is that exact beat.
- Reject and rewrite if two community copies from nearby packages share the same body rhythm, same question, and same image scene with only names/props changed.
- `社群文案翻译` is a review aid only. Provide it when practical, but a blank,
  imperfect, differently worded, or missing Chinese review translation must
  never block, retry, reject, or determine similarity of valid public copy.

## Community Copy Acceptance Tests

Reject and rewrite `社群文案` before writing files if any of these are true:

- The copy contains Markdown link syntax like `[text](https://...)` or `[https://...](https://...)`.
- The copy does not contain exactly one visible `https://youtu.be/VIDEO_ID` URL.
- The first line does not contain `🔥`, `👉`, and the single bare short URL.
- There is a blank line between the first link line and the first conflict/reversal line.
- The copy has fewer than 8 non-empty lines.
- Any Chinese character appears anywhere in the community copy body.
- The copy is only CTA/question text and lacks a 3-part story body: conflict, reversal, payoff/emotional choice.
- It is missing any fixed copy emoji from `🔥`, `👉`, `🤔`, `👇`, `🔔`, `🙏`.
- The final two lines are missing a subscribe line with `🔔` or a share line with `🙏`.
- The body could fit another same-channel drama by changing only the names, child count, or one prop.

## Community Image Acceptance Tests

Reject and rewrite `社群图 1：1` before writing files if any of these are true:

- The actual image prompt contains Chinese descriptive wording instead of English descriptive wording.
- It shares the same scene family and same main action as any of the three cover prompts in `04_封面提示词.json`.
- It uses a generic `office desk + evidence + shocked CEO`, `luxury room + document + family shock`, or `child points at adult` skeleton without a drama-specific reason.
- It uses only a few keywords instead of a full hook sentence overlay.
- A child appears as an accuser, judge, proof-holder, phone-recorder, or finger-pointing prosecutor.
- A child-related community image contains rescue/save/weak/pale/clinic/hospital/doctor-rushing/blood/violence/revenge/panic/frightened wording, even in negative clauses.
- A child-count story such as `双宝/三宝/四宝/五宝/萌宝` is visually reduced to one child without source-based justification.
- A child-count story tries to compensate for missing visible children by using drawings, framed photos, handprints, backpacks, toys, silhouettes, or other symbolic stand-ins as the main child-count cue.
- The bottom CTA covers faces, sits on the bottom edge, or changes the channel-fixed CTA text/layout when `community_footer_cta.json` exists.
- The image style requests ultra-sharp, crisp-face, high/strong-micro-contrast, clean-edge, sharp-highlight, or mobile-readability advertising rendering instead of natural live-action photography.

## Output Contract

Return structured data only. The controller validates it, writes canonical JSON first,
and then renders `06_社群方案.md` for display. The model must not write files,
channel CTA assets, workflow state, or Feishu data.

Rendered Markdown shape:

```text
# 社群

社群图 1：1：
xxxxxx

社群文案：
xxxxxxx
```

If available, also include:

```text
社群文案翻译：
xxxxxxx
```

Also write structured data to:

```text
06_社群方案.json
```

The controller owns `community_footer_cta.json`. If it does not exist, the controller
creates it once; the model only receives and reuses the supplied fixed CTA values.

Canonical JSON shape:

```json
{
  "section": "community",
  "results": [
    {
      "search_result_index": 1,
      "source_block_label": "搜索资料1",
      "result_id": "VIDEO_ID_1",
      "video_id": "...",
      "drama_name": "...",
      "image_prompt_1x1": "...",
      "copy": "...",
      "copy_translation": "..."
    }
  ]
}
```
