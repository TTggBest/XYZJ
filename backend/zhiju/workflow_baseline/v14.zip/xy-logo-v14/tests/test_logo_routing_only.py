import importlib.util
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "apply_logos_from_sort.py"
SPEC = importlib.util.spec_from_file_location("apply_logos_routing_only_test", SCRIPT)
LOGO = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(LOGO)


class LogoRoutingOnlyTests(unittest.TestCase):
    def test_queue_uses_only_standard_16x9_paths_from_sort_report(self):
        with tempfile.TemporaryDirectory() as temp:
            package = Path(temp) / "语言/频道/剧目/剧名_2026081819"
            raw = package / "images/raw"
            raw.mkdir(parents=True)
            cover = raw / "02_标题1_16x9.png"
            portrait = raw / "01_标题1_4x5.png"
            extra = raw / "random.png"
            for image in (cover, portrait, extra):
                image.write_bytes(b"anything")
            report = {"items": [{
                "package_path": str(package),
                "matched": [
                    {"destination": str(cover)},
                    {"destination": str(portrait)},
                    {"destination": str(extra)},
                ],
            }]}

            queue = LOGO.logo_queue_from_sort_report(report)

            self.assertEqual(queue, {str(package.resolve()): [str(cover.resolve())]})

    def test_batch_logo_runner_has_no_contract_or_package_state_gate(self):
        code = SCRIPT.read_text(encoding="utf-8")
        forbidden = (
            "verify_contract_snapshot", "verify_runtime_sources",
            "mark_delivered_packages", "workflow_state.json",
            "record_transition", "accepted_image_task_ids",
        )
        for token in forbidden:
            self.assertNotIn(token, code)

    def test_delivery_candidates_only_changes_output_folder_and_suffix(self):
        package = Path("/tmp/V2/语言/频道/剧目/剧名_2026081819")
        raw = package / "images/raw/02_标题1_16x9.png"
        self.assertEqual(
            LOGO.delivery_candidates({str(package): [str(raw)]}),
            {str(package): [str(package / "images/final/02_标题1_16x9_logo.png")]},
        )


if __name__ == "__main__":
    unittest.main()
