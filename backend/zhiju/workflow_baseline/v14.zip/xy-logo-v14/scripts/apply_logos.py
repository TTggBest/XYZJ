#!/usr/bin/env python3
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def _ensure_runtime(modules: tuple[str, ...]) -> None:
    flag = "XY_LOGO_RUNTIME_READY"
    if os.environ.get(flag) == "1":
        return

    try:
        for module in modules:
            __import__(module)
        os.environ[flag] = "1"
        return
    except ModuleNotFoundError:
        pass

    candidates = []
    seen = set()
    for value in (
        "/Users/ttggmac-mini/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        sys.executable,
        "/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/.venv/bin/python",
        "/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/.venv-youtube/bin/python",
        "python3",
        "python",
    ):
        if value and value not in seen:
            candidates.append(value)
            seen.add(value)

    probe = "; ".join([f"import {module}" for module in modules]) + "; print('OK')"
    for candidate in candidates:
        try:
            proc = subprocess.run([candidate, "-c", probe], capture_output=True, text=True, check=False)
        except FileNotFoundError:
            continue
        if proc.returncode == 0 and proc.stdout.strip() == "OK":
            env = os.environ.copy()
            env[flag] = "1"
            os.execve(candidate, [candidate, __file__, *sys.argv[1:]], env)

    missing = ", ".join(modules)
    raise ModuleNotFoundError(f"No Python runtime with required modules: {missing}")


_ensure_runtime(("PIL",))

from PIL import Image, ImageFilter


IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp")
RAW_TARGETS = (
    "02_标题1_16x9",
    "04_标题2_16x9",
    "06_标题3_16x9",
)
WORKFLOW_ROOT = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/运营/工作流运营")
CHANNEL_HELPER_DIR = Path(__file__).resolve().parents[2] / "xy-channels" / "scripts"
if str(CHANNEL_HELPER_DIR) not in sys.path:
    sys.path.append(str(CHANNEL_HELPER_DIR))

from channel_registry import resolve_channel


def load_rgba(path: Path) -> Image.Image:
    return Image.open(path).convert("RGBA")


def with_opacity(img: Image.Image, opacity: float) -> Image.Image:
    if opacity >= 0.999:
        return img
    alpha = img.getchannel("A").point(lambda a: int(a * opacity))
    out = img.copy()
    out.putalpha(alpha)
    return out


def backup_existing(path: Path) -> Path | None:
    if not path.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d%H%M%S")
    backup = path.with_name(f"{path.stem}.bak_{stamp}{path.suffix}")
    path.rename(backup)
    return backup


def find_raw_images(raw_dir: Path) -> list[Path]:
    found = []
    for stem in RAW_TARGETS:
        candidates = [raw_dir / f"{stem}{ext}" for ext in IMAGE_EXTS]
        match = next((p for p in candidates if p.exists()), None)
        if match:
            found.append(match)
    return found


def resolve_package_raw_images(package_path: Path, explicit_images: list[Path]) -> list[Path]:
    """Validate a controller-provided sort whitelist for one package.

    Batch mode must never rediscover images by scanning ``images/raw`` because
    that directory can contain files rejected by a later sort run.
    """
    raw_dir = (package_path / "images" / "raw").resolve()
    resolved: list[Path] = []
    for image in explicit_images:
        candidate = image.expanduser().resolve()
        if candidate.parent != raw_dir:
            raise ValueError(f"Whitelisted image is outside package raw directory: {candidate}")
        if candidate.suffix.lower() not in IMAGE_EXTS:
            raise ValueError(f"Unsupported whitelisted image type: {candidate}")
        if not any(candidate.stem == stem for stem in RAW_TARGETS):
            raise ValueError(f"Whitelisted image is not a supported 16:9 cover: {candidate}")
        if not candidate.exists():
            raise ValueError(f"Whitelisted image does not exist: {candidate}")
        if candidate not in resolved:
            resolved.append(candidate)
    return resolved


def find_directory_images(image_dir: Path) -> list[Path]:
    found = []
    for path in sorted(image_dir.iterdir()):
        if not path.is_file():
            continue
        if path.suffix.lower() not in IMAGE_EXTS:
            continue
        if path.stem.endswith("_logo"):
            continue
        found.append(path)
    return found


def resize_logo(logo: Image.Image, width: int, height: int) -> Image.Image:
    width = max(1, int(round(width)))
    height = max(1, int(round(height)))
    return logo.resize((width, height), Image.Resampling.LANCZOS)


def composite_one(
    source_path: Path,
    output_path: Path,
    config: dict,
    left_logo: Image.Image,
    right_logo: Image.Image | None,
) -> tuple[Path, Path | None]:
    src = load_rgba(source_path)
    canvas_cfg = config.get("canvas", {})
    out_w = int(canvas_cfg.get("width", src.width))
    out_h = int(canvas_cfg.get("height", src.height))
    normalize = bool(canvas_cfg.get("normalize_output", True))
    if normalize and (src.width != out_w or src.height != out_h):
        src = src.resize((out_w, out_h), Image.Resampling.LANCZOS)
    else:
        out_w, out_h = src.width, src.height

    canvas = Image.new("RGBA", (out_w, out_h))
    canvas.alpha_composite(src)

    opacity = float(config.get("opacity", 1))
    left_cfg = config["left_logo"]
    left = resize_logo(
        left_logo,
        out_w * float(left_cfg["width_pct"]),
        out_h * float(left_cfg["height_pct"]),
    )
    left = with_opacity(left, opacity)
    left_x = int(round(out_w * float(left_cfg["x_pct"])))
    left_y = int(round(out_h * float(left_cfg["y_pct"])))
    canvas.alpha_composite(left, (left_x, left_y))

    right_cfg = config.get("right_logo", {})
    if right_logo is not None and right_cfg.get("enabled"):
        right = resize_logo(
            right_logo,
            out_w * float(right_cfg["width_pct"]),
            out_h * float(right_cfg["height_pct"]),
        )
        right = with_opacity(right, opacity)
        right_x = int(round(out_w * float(right_cfg["x_pct"])))
        right_y = int(round(out_h * float(right_cfg["y_pct"])))
        canvas.alpha_composite(right, (right_x, right_y))

    result = canvas.convert("RGB").filter(
        ImageFilter.UnsharpMask(radius=1.0, percent=100, threshold=3)
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    backup = backup_existing(output_path)
    result.save(output_path, format="PNG", optimize=True)
    return output_path, backup


def write_report(
    report_path: Path,
    target_label: str,
    target_path: Path,
    config_path: Path,
    raw_images: list[Path],
    outputs: list[Path],
    backups: list[Path],
    left_logo_path: Path,
    right_logo_path: Path | None,
) -> None:
    lines = [
        "# Logo 合成报告",
        "",
        f"{target_label}: {target_path}",
        f"Config: {config_path}",
        f"Left logo: {left_logo_path}",
        f"Right logo: {right_logo_path if right_logo_path else '未配置'}",
        "",
        "## Outputs",
        "",
    ]
    for src, out in zip(raw_images, outputs):
        lines.append(f"- {src} -> {out}")
    if backups:
        lines.extend(["", "## Backups", ""])
        for backup in backups:
            lines.append(f"- {backup}")
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--channel-root", default="")
    parser.add_argument("--channel", default="")
    parser.add_argument("--root", default=str(WORKFLOW_ROOT))
    parser.add_argument("--image-dir", default="")
    parser.add_argument("--raw-image", action="append", default=[])
    parser.add_argument("package_paths", nargs="*")
    args = parser.parse_args()

    if args.image_dir and args.package_paths:
        raise SystemExit("Use either --image-dir or package_paths, not both")
    if not args.image_dir and not args.package_paths:
        raise SystemExit("xy-logo-v14 requires either --image-dir or package_paths")

    if args.channel_root:
        channel_root = Path(args.channel_root).expanduser().resolve()
    elif args.channel:
        root = Path(args.root).expanduser().resolve()
        channel_row = resolve_channel(root, args.channel)
        channel_root = Path(channel_row["channel_dir"]).expanduser().resolve()
    else:
        raise SystemExit("xy-logo-v14 requires either --channel-root or --channel")

    logo_root = channel_root / "logo"
    config_path = logo_root / "logo_config.json"
    with config_path.open("r", encoding="utf-8") as f:
        config = json.load(f)

    left_logo_path = logo_root / config["left_logo"]["file"]
    left_logo = load_rgba(left_logo_path)
    right_logo_path = None
    right_logo = None
    right_cfg = config.get("right_logo", {})
    if right_cfg.get("enabled") and right_cfg.get("file"):
        right_logo_path = logo_root / right_cfg["file"]
        right_logo = load_rgba(right_logo_path)

    summary = []

    if args.image_dir:
        image_dir = Path(args.image_dir).expanduser().resolve()
        raw_images = find_directory_images(image_dir)
        outputs = []
        backups = []
        for raw_image in raw_images:
            output_name = raw_image.stem + "_logo.png"
            output_path = raw_image.with_name(output_name)
            output, backup = composite_one(
                raw_image,
                output_path,
                config,
                left_logo,
                right_logo,
            )
            outputs.append(output)
            if backup is not None:
                backups.append(backup)

        write_report(
            image_dir / "logo合成报告.md",
            "Image Dir",
            image_dir,
            config_path,
            raw_images,
            outputs,
            backups,
            left_logo_path,
            right_logo_path,
        )
        summary.append(
            {
                "image_dir": str(image_dir),
                "source_images": [str(p) for p in raw_images],
                "outputs": [str(p) for p in outputs],
                "backups": [str(p) for p in backups],
                "channel_root": str(channel_root),
            }
        )
    else:
        if args.raw_image and len(args.package_paths) != 1:
            raise SystemExit("--raw-image requires exactly one package path")
        for package in args.package_paths:
            package_path = Path(package).expanduser().resolve()
            raw_dir = package_path / "images" / "raw"
            final_dir = package_path / "images" / "final"
            raw_images = (
                resolve_package_raw_images(package_path, [Path(value) for value in args.raw_image])
                if args.raw_image
                else find_raw_images(raw_dir)
            )
            outputs = []
            backups = []
            for raw_image in raw_images:
                output_name = raw_image.stem + "_logo.png"
                output_path = final_dir / output_name
                output, backup = composite_one(
                    raw_image,
                    output_path,
                    config,
                    left_logo,
                    right_logo,
                )
                outputs.append(output)
                if backup is not None:
                    backups.append(backup)

            write_report(
                final_dir / "logo合成报告.md",
                "Package",
                package_path,
                config_path,
                raw_images,
                outputs,
                backups,
                left_logo_path,
                right_logo_path,
            )
            summary.append(
                {
                    "package_path": str(package_path),
                    "raw_images": [str(p) for p in raw_images],
                    "outputs": [str(p) for p in outputs],
                    "backups": [str(p) for p in backups],
                }
            )

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
