#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path


RAW_16X9_STEMS = {"02_标题1_16x9", "04_标题2_16x9", "06_标题3_16x9"}


def logo_queue_from_sort_report(report: dict) -> dict[str, list[str]]:
    """Build the only allowed batch-logo input set from matched destinations."""
    queue: dict[str, list[str]] = {}
    for item in report.get("items", []):
        if not isinstance(item, dict):
            continue
        package_value = str(item.get("package_path") or "").strip()
        if not package_value:
            continue
        package = Path(package_value).expanduser().resolve()
        raw_dir = (package / "images" / "raw").resolve()
        accepted: list[str] = []
        for record in item.get("matched", []):
            if not isinstance(record, dict):
                continue
            destination_value = str(record.get("destination") or "").strip()
            if not destination_value:
                continue
            destination = Path(destination_value).expanduser().resolve()
            if destination.parent != raw_dir or destination.stem not in RAW_16X9_STEMS:
                continue
            if destination.exists() and str(destination) not in accepted:
                accepted.append(str(destination))
        if accepted:
            queue[str(package)] = accepted
    return queue


def delivery_candidates(queue: dict[str, list[str]]) -> dict[str, list[str]]:
    """Map accepted raw images to their exact expected logo outputs."""
    return {
        package: [
            str(Path(package) / "images" / "final" / f"{Path(raw).stem}_logo.png")
            for raw in raw_images
        ]
        for package, raw_images in queue.items()
    }


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def find_pil_python() -> str:
    candidates: list[str] = []
    seen = set()
    for value in (
        sys.executable,
        "/Users/ttggmac-mini/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        "/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/.venv/bin/python",
        "/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/.venv-youtube/bin/python",
        "python3",
        "python",
    ):
        if value and value not in seen:
            candidates.append(value)
            seen.add(value)

    probe = "import PIL; print('OK')"
    for candidate in candidates:
        try:
            proc = subprocess.run(
                [candidate, "-c", probe],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            continue
        if proc.returncode == 0 and proc.stdout.strip() == "OK":
            return candidate
    raise SystemExit("No Python runtime with Pillow (PIL) available for xy-logo-v14")


def load_batch_report(root: Path, batch_id: str = "") -> tuple[str, Path, dict]:
    batch_root = root / "批量任务"
    if batch_id:
        report_path = batch_root / batch_id / "图片分拣报告.json"
        if not report_path.exists():
            raise SystemExit(f"Sort report not found: {report_path}")
        return batch_id, report_path, load_json(report_path)

    current_batch = batch_root / "current_batch.json"
    if not current_batch.exists():
        raise SystemExit(f"Current batch pointer not found: {current_batch}")
    pointer = load_json(current_batch)
    current_batch_id = pointer["batch_id"]
    report_path = batch_root / current_batch_id / "图片分拣报告.json"
    if not report_path.exists():
        raise SystemExit(f"Sort report not found: {report_path}")
    return current_batch_id, report_path, load_json(report_path)


def find_tem(logo_root: Path) -> Path | None:
    for name in ("tem.png", "tem.jpg", "tem.jpeg", "tem.webp", "template.png", "template.jpg", "template.jpeg", "template.webp"):
        path = logo_root / name
        if path.exists():
            return path
    return None


def resolve_logo_channel_root(workflow_root: Path, package_channel_root: Path) -> Path:
    """V2 packages reuse the live channel's calibrated logo assets read-only."""
    if (package_channel_root / "logo").exists():
        return package_channel_root
    try:
        relative = package_channel_root.resolve().relative_to(workflow_root.resolve())
    except ValueError:
        return package_channel_root
    # V2 package channel root is <V2>/<language>/<channel>.
    if len(relative.parts) == 2 and workflow_root.name == "V2":
        production = workflow_root.parents[1] / "工作流运营" / relative
        if (production / "logo").exists():
            return production
    return package_channel_root


def is_calibrated(config_path: Path) -> bool:
    if not config_path.exists():
        return False
    try:
        payload = load_json(config_path)
    except Exception:
        return False
    return payload.get("calibrated") is True


def run_subprocess(cmd: list[str], dry_run: bool) -> dict:
    if dry_run:
        return {"cmd": cmd, "returncode": 0, "stdout": "", "stderr": "", "dry_run": True}
    proc = subprocess.run(cmd, capture_output=True, text=True)
    return {
        "cmd": cmd,
        "returncode": proc.returncode,
        "stdout": proc.stdout.strip(),
        "stderr": proc.stderr.strip(),
        "dry_run": False,
    }


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def delivery_parts(root: Path, package_path: Path) -> tuple[str, str, str]:
    """Return language, channel and a human-sortable drama delivery folder."""
    relative = package_path.resolve().relative_to(root.resolve())
    # Expected: <language>/<channel>/剧目/<drama_slot>
    if len(relative.parts) < 4 or relative.parts[2] != "剧目":
        raise ValueError(f"Unexpected package path: {package_path}")
    return relative.parts[0], relative.parts[1], relative.parts[3]


def export_delivery(
    root: Path,
    batch_id: str,
    package_images: dict[str, list[str]],
    delivery_root: Path,
    dry_run: bool,
) -> dict:
    """Copy final logo images into one handoff folder for the upload machine."""
    batch_root = delivery_root.expanduser().resolve() / batch_id
    rows: list[dict] = []
    copied = skipped = backed_up = 0
    for package_str, image_values in package_images.items():
        package = Path(package_str).resolve()
        language, channel, drama_folder = delivery_parts(root, package)
        destination_dir = batch_root / language / channel / drama_folder
        images = [Path(value).expanduser().resolve() for value in image_values]
        for source in images:
            if not source.exists():
                continue
            destination = destination_dir / source.name
            action = "copy"
            if destination.exists():
                if sha256(source) == sha256(destination):
                    action = "same_skip"
                    skipped += 1
                else:
                    action = "backup_and_copy"
                    backed_up += 1
                    if not dry_run:
                        stamp = datetime.now().strftime("%Y%m%d%H%M%S")
                        destination.rename(destination.with_name(f"{destination.stem}.bak_{stamp}{destination.suffix}"))
            if action != "same_skip":
                copied += 1
                if not dry_run:
                    destination_dir.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, destination)
            rows.append({
                "语言": language,
                "频道": channel,
                "剧目": drama_folder,
                "源文件": str(source),
                "交付文件": str(destination),
                "动作": action,
            })

    manifest_csv = batch_root / "交付清单.csv"
    manifest_md = batch_root / "交付说明.md"
    if not dry_run:
        batch_root.mkdir(parents=True, exist_ok=True)
        with manifest_csv.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=["语言", "频道", "剧目", "源文件", "交付文件", "动作"])
            writer.writeheader()
            writer.writerows(rows)
        manifest_md.write_text(
            "# YouTube 封面交付包\n\n"
            f"批次：{batch_id}\n\n"
            "目录结构：语言 / 频道 / 档期_剧名 / 3 张最终 16:9 封面。\n\n"
            f"图片总数：{len(rows)}\n\n"
            f"新复制：{copied}\n\n"
            f"相同文件跳过：{skipped}\n\n"
            f"已备份后覆盖：{backed_up}\n",
            encoding="utf-8",
        )
    return {
        "root": str(batch_root), "manifest_csv": str(manifest_csv),
        "manifest_md": str(manifest_md), "images": len(rows),
        "copied": copied, "same_skipped": skipped, "backed_up": backed_up,
        "files": [row["交付文件"] for row in rows],
        "rows": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--batch", default="")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--delivery-root", default="~/Desktop/XY最终交付")
    parser.add_argument("--no-delivery-export", action="store_true")
    parser.add_argument("--delivery-only", action="store_true")
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    batch_id, report_path, report = load_batch_report(root, args.batch.strip())
    batch_dir = report_path.parent
    logo_queue = logo_queue_from_sort_report(report)
    if args.delivery_only:
        candidates = delivery_candidates(logo_queue)
        delivery = export_delivery(
            root, batch_id, candidates,
            Path(args.delivery_root), args.dry_run,
        )
        print(json.dumps({
            "batch_id": batch_id,
            "delivery_only": True,
            "matched_packages": len(logo_queue),
            "desktop_delivery": delivery,
        }, ensure_ascii=False, indent=2))
        return
    channel_groups: dict[str, list[Path]] = defaultdict(list)
    for package_value in logo_queue:
        package_path = Path(package_value).resolve()
        if package_path not in channel_groups[str(package_path.parents[1])]:
            channel_groups[str(package_path.parents[1])].append(package_path)

    calibrate_script = Path(__file__).resolve().parent / "calibrate_logo_config.py"
    apply_script = Path(__file__).resolve().parent / "apply_logos.py"
    pil_python = find_pil_python()

    summary = {
        "batch_id": batch_id,
        "sort_report": str(report_path),
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_matched_packages": len(logo_queue),
        "processed_packages": [],
        "skipped_channels": [],
        "channel_runs": [],
        "desktop_delivery": None,
    }

    processed_delivery: dict[str, list[str]] = {}
    for channel_root_str, package_paths in sorted(channel_groups.items()):
        package_channel_root = Path(channel_root_str)
        channel_root = resolve_logo_channel_root(root, package_channel_root)
        logo_root = channel_root / "logo"
        config_path = logo_root / "logo_config.json"
        tem_path = find_tem(logo_root)

        channel_entry = {
            "package_channel_root": str(package_channel_root),
            "channel_root": str(channel_root),
            "packages": [str(p) for p in package_paths],
            "calibration": None,
            "apply": None,
            "status": "pending",
        }

        if not is_calibrated(config_path):
            if tem_path is None:
                channel_entry["status"] = "skipped"
                channel_entry["reason"] = "missing logo/tem.* and no calibrated logo_config.json"
                summary["skipped_channels"].append(channel_entry)
                summary["channel_runs"].append(channel_entry)
                continue
            calibrate_result = run_subprocess(
                [pil_python, str(calibrate_script), "--channel-root", str(channel_root)],
                args.dry_run,
            )
            channel_entry["calibration"] = calibrate_result
            if calibrate_result["returncode"] != 0:
                channel_entry["status"] = "skipped"
                channel_entry["reason"] = "calibration_failed"
                summary["skipped_channels"].append(channel_entry)
                summary["channel_runs"].append(channel_entry)
                continue

        apply_runs = []
        for package_path in package_paths:
            raw_images = logo_queue[str(package_path)]
            apply_runs.append(run_subprocess(
                [
                    pil_python, str(apply_script), "--channel-root", str(channel_root),
                    str(package_path),
                    *[argument for raw in raw_images for argument in ("--raw-image", raw)],
                ],
                args.dry_run,
            ))
        channel_entry["apply"] = apply_runs
        if any(result["returncode"] != 0 for result in apply_runs):
            channel_entry["status"] = "failed"
        else:
            channel_entry["status"] = "done"
            summary["processed_packages"].extend([str(p) for p in package_paths])
            for package_path in package_paths:
                processed_delivery[str(package_path)] = delivery_candidates(
                    {str(package_path): logo_queue[str(package_path)]}
                )[str(package_path)]
        summary["channel_runs"].append(channel_entry)

    report_json = batch_dir / "角标批处理报告.json"
    report_md = batch_dir / "角标批处理报告.md"
    if not args.no_delivery_export:
        summary["desktop_delivery"] = export_delivery(
            root, batch_id, processed_delivery,
            Path(args.delivery_root), args.dry_run,
        )
    write_json(report_json, summary)

    lines = [
        "# 角标批处理报告",
        "",
        f"批次：{batch_id}",
        f"分拣报告：{report_path}",
        f"生成时间：{summary['generated_at']}",
        f"命中包数：{summary['total_matched_packages']}",
        f"成功处理包数：{len(summary['processed_packages'])}",
        f"跳过频道数：{len(summary['skipped_channels'])}",
        f"桌面交付目录：{summary['desktop_delivery']['root'] if summary['desktop_delivery'] else '未导出'}",
        "",
        "## 频道结果",
        "",
    ]
    for row in summary["channel_runs"]:
        lines.append(f"### {row['channel_root']}")
        lines.append("")
        lines.append(f"- 状态：{row['status']}")
        lines.append(f"- 包数：{len(row['packages'])}")
        if row.get("reason"):
            lines.append(f"- 原因：{row['reason']}")
        if row.get("calibration"):
            lines.append(f"- 校准返回码：{row['calibration']['returncode']}")
        if row.get("apply"):
            lines.append(f"- 合成返回码：{', '.join(str(run['returncode']) for run in row['apply'])}")
        lines.append("")

    report_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({
        "batch_id": batch_id,
        "sort_report": str(report_path),
        "batch_logo_report_md": str(report_md),
        "batch_logo_report_json": str(report_json),
        "matched_packages": len(logo_queue),
        "processed_packages": len(summary["processed_packages"]),
        "skipped_channels": len(summary["skipped_channels"]),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
