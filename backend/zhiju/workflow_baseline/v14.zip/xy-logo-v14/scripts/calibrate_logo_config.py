#!/usr/bin/env python3
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def _ensure_runtime(modules: tuple[str, ...]) -> None:
    flag = "XY_LOGO_RUNTIME_READY"
    if os.environ.get(flag) == "1":
        return

    try:
        for module in modules:
            __import__(module)
        os.environ[flag] = "1"
        return
    except ModuleNotFoundError:
        pass

    candidates = []
    seen = set()
    for value in (
        "/Users/ttggmac-mini/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        sys.executable,
        "/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/.venv/bin/python",
        "/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/.venv-youtube/bin/python",
        "python3",
        "python",
    ):
        if value and value not in seen:
            candidates.append(value)
            seen.add(value)

    probe = "; ".join([f"import {module}" for module in modules]) + "; print('OK')"
    for candidate in candidates:
        try:
            proc = subprocess.run([candidate, "-c", probe], capture_output=True, text=True, check=False)
        except FileNotFoundError:
            continue
        if proc.returncode == 0 and proc.stdout.strip() == "OK":
            env = os.environ.copy()
            env[flag] = "1"
            os.execve(candidate, [candidate, __file__, *sys.argv[1:]], env)

    missing = ", ".join(modules)
    raise ModuleNotFoundError(f"No Python runtime with required modules: {missing}")


_ensure_runtime(("numpy", "PIL"))

import numpy as np
from PIL import Image


IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp")


def newest_image(folder: Path) -> Path:
    files = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    if not files:
        raise FileNotFoundError(f"No image files found in {folder}")
    preferred = [p for p in files if any(k in p.stem.lower() for k in ("default", "main"))]
    files = preferred or files
    return max(files, key=lambda p: p.stat().st_mtime)


def optional_newest_image(folder: Path) -> Path | None:
    if not folder.exists():
        return None
    files = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    if not files:
        return None
    preferred = [p for p in files if any(k in p.stem.lower() for k in ("default", "main"))]
    files = preferred or files
    return max(files, key=lambda p: p.stat().st_mtime)


def find_tem(logo_root: Path) -> Path:
    candidates = [
        p
        for p in logo_root.iterdir()
        if p.is_file()
        and p.suffix.lower() in IMAGE_EXTS
        and p.stem.lower() in ("tem", "template")
    ]
    if not candidates:
        raise FileNotFoundError(f"Missing logo/tem image in {logo_root}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def load_rgba(path: Path) -> Image.Image:
    return Image.open(path).convert("RGBA")


def resize_width(img: Image.Image, width: int) -> Image.Image:
    width = max(8, int(width))
    ratio = width / img.width
    height = max(8, int(round(img.height * ratio)))
    return img.resize((width, height), Image.Resampling.LANCZOS)


def masked_mse(patch: np.ndarray, logo: np.ndarray, mask: np.ndarray) -> float:
    diff = (patch[:, :, :3] - logo[:, :, :3]) * mask
    denom = max(float(mask.sum() * 3), 1.0)
    return float((diff * diff).sum() / denom)


def detect_bbox_from_tem(tem: Image.Image, side: str) -> dict | None:
    arr = np.asarray(tem.convert("RGB"))
    # White template backgrounds are used for channel logo calibration.
    mask = np.any(arr < 245, axis=2)
    h, w = mask.shape
    if side == "left":
        mask[:, int(w * 0.5) :] = False
    else:
        mask[:, : int(w * 0.5)] = False

    ys, xs = np.where(mask)
    if xs.size < 50:
        return None

    x0, x1 = int(xs.min()), int(xs.max())
    y0, y1 = int(ys.min()), int(ys.max())
    return {
        "x_pct": round(x0 / w, 6),
        "y_pct": round(y0 / h, 6),
        "width_pct": round((x1 - x0 + 1) / w, 6),
        "height_pct": round((y1 - y0 + 1) / h, 6),
        "match_score": 0.0,
    }


def search_one(tem: Image.Image, logo: Image.Image, side: str) -> dict:
    # Work on a reduced canvas for speed. The result is stored as percentages,
    # so this scale does not affect final placement.
    scale = 0.25
    small_tem = tem.resize(
        (max(1, int(tem.width * scale)), max(1, int(tem.height * scale))),
        Image.Resampling.LANCZOS,
    )
    tem_arr = np.asarray(small_tem).astype(np.float32) / 255.0
    th, tw = tem_arr.shape[:2]

    search_top = int(th * 0.42)
    if side == "left":
        x0, x1 = 0, int(tw * 0.52)
    else:
        x0, x1 = int(tw * 0.48), tw

    best = None
    # Candidate width range: broad enough for channel logo variants, not used as
    # a default placement. It only discovers the actual rendered size in tem.
    for width_pct in np.linspace(0.04, 0.24, 41):
        logo_w = int(round(tw * width_pct))
        candidate = resize_width(logo, logo_w)
        if candidate.width >= (x1 - x0) or candidate.height >= search_top:
            continue
        logo_arr = np.asarray(candidate).astype(np.float32) / 255.0
        alpha = logo_arr[:, :, 3:4]
        mask = (alpha > 0.08).astype(np.float32)
        if mask.sum() < 10:
            mask = np.ones((*logo_arr.shape[:2], 1), dtype=np.float32)

        stride = 2
        y_max = search_top - candidate.height
        x_max = x1 - candidate.width
        for y in range(0, y_max + 1, stride):
            for x in range(x0, x_max + 1, stride):
                patch = tem_arr[y : y + candidate.height, x : x + candidate.width, :]
                score = masked_mse(patch, logo_arr, mask)
                if best is None or score < best["score"]:
                    best = {
                        "score": score,
                        "x": x,
                        "y": y,
                        "w": candidate.width,
                        "h": candidate.height,
                    }

    if best is None:
        raise RuntimeError(f"Could not match {side} logo in tem")

    return {
        "x_pct": round(best["x"] / tw, 6),
        "y_pct": round(best["y"] / th, 6),
        "width_pct": round(best["w"] / tw, 6),
        "height_pct": round(best["h"] / th, 6),
        "match_score": round(best["score"], 6),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--channel-root", required=True)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    channel_root = Path(args.channel_root).expanduser().resolve()
    logo_root = channel_root / "logo"
    config_path = logo_root / "logo_config.json"
    if config_path.exists() and not args.force:
        with config_path.open("r", encoding="utf-8") as f:
            existing = json.load(f)
        if existing.get("calibrated") is True:
            print(json.dumps({"status": "exists", "config": str(config_path)}, ensure_ascii=False))
            return

    tem_path = find_tem(logo_root)
    left_path = newest_image(logo_root / "llogo")
    right_path = optional_newest_image(logo_root / "rlogo")

    tem = load_rgba(tem_path)
    left = load_rgba(left_path)
    right = load_rgba(right_path) if right_path else None

    left_match = detect_bbox_from_tem(tem, "left") or search_one(tem, left, "left")
    right_match = (
        detect_bbox_from_tem(tem, "right") or search_one(tem, right, "right")
        if right is not None
        else None
    )

    config = {
        "version": 2,
        "target": "16x9",
        "calibrated": True,
        "calibration_source": {
            "template_file": tem_path.name,
            "method": "match_logo_from_tem",
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        },
        "canvas": {
            "width": tem.width,
            "height": tem.height,
            "normalize_output": True,
        },
        "left_logo": {
            "file": str(left_path.relative_to(logo_root)),
            "x_pct": left_match["x_pct"],
            "y_pct": left_match["y_pct"],
            "width_pct": left_match["width_pct"],
            "height_pct": left_match["height_pct"],
        },
        "right_logo": {
            "enabled": right_path is not None,
            "file": str(right_path.relative_to(logo_root)) if right_path else "",
            "x_pct": right_match["x_pct"] if right_match else None,
            "y_pct": right_match["y_pct"] if right_match else None,
            "width_pct": right_match["width_pct"] if right_match else None,
            "height_pct": right_match["height_pct"] if right_match else None,
        },
        "opacity": 1,
        "auto_adjust_per_image": False,
        "match_scores": {
            "left": left_match["match_score"],
            "right": right_match["match_score"] if right_match else None,
        },
    }

    config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    report_path = logo_root / "logo校准报告.md"
    report_path.write_text(
        "\n".join(
            [
                "# Logo 校准报告",
                "",
                f"频道目录：{channel_root}",
                f"模板图：{tem_path.name}",
                f"左 logo：{left_path.relative_to(logo_root)}",
                f"右 logo：{right_path.relative_to(logo_root) if right_path else '未配置'}",
                f"画布：{tem.width}x{tem.height}",
                f"左匹配分数：{left_match['match_score']}",
                f"右匹配分数：{right_match['match_score'] if right_match else '未执行'}",
                f"配置：{config_path}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(json.dumps({"status": "calibrated", "config": str(config_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
