---
name: xy-logo-v14
description: Add the configured Xiaoyu channel logo to matched 16:9 images. Supports batch mode from an xy-sort-v14 report and direct channel-plus-folder mode. It only composites logos and never reviews image content.
---

# XY Logo

## Single Responsibility

`xy-logo-v14` only composites the channel's configured left/right logo onto input images and writes new `_logo.png` files.

It must not:

- call an AI/model or review image content;
- judge anatomy, faces, text, scene, safety, similarity or aspect-ratio compliance;
- verify production contracts, runtime hashes, task lineage, title/cover/package state or Feishu writeback;
- reject a source image because of content;
- change `workflow_state.json`, the batch index, package status or Feishu data.

Reading image dimensions to resize the canvas and logo is part of compositing, not a quality gate.

## Modes

Direct channel plus folder:

```text
scripts/apply_logos.py --root "运营/工作流运营" --channel "频道名称" --image-dir /path/to/images
```

This processes supported source images in the folder, skips files already ending in `_logo.png`, preserves originals and writes `<stem>_logo.png` beside them.

Batch mode after `xy-sort-v14`:

```text
scripts/apply_logos_from_sort.py --root "运营/工作流运营" --batch BATCH_ID
```

Batch mode reads only the routing report:

```text
批量任务/BATCH_ID/图片分拣报告.json
```

It selects the three standard 16:9 destinations named:

```text
02_标题1_16x9.*
04_标题2_16x9.*
06_标题3_16x9.*
```

The report is used only to locate files and channels. No contract or content acceptance is inferred from it.

## Logo Configuration

Channel assets remain under:

```text
运营/工作流运营/语言/频道名/logo/llogo/
运营/工作流运营/语言/频道名/logo/rlogo/
运营/工作流运营/语言/频道名/logo/logo_config.json
运营/工作流运营/语言/频道名/logo/tem.*
```

- `llogo` is required.
- `rlogo` is optional.
- Reuse a calibrated `logo_config.json` for stable position and size.
- If a channel has no calibrated config, derive it once from `tem.*`; this only establishes logo coordinates and does not inspect or approve the generated cover.
- Never auto-move a logo per image based on faces or text.

## Output

Package mode writes:

```text
images/final/02_标题1_16x9_logo.png
images/final/04_标题2_16x9_logo.png
images/final/06_标题3_16x9_logo.png
images/final/logo合成报告.md
```

Existing outputs receive timestamped backups before replacement. Raw images remain unchanged.

Batch mode may also copy the completed logo files to the configured desktop delivery folder. That is a file-copy step only; it does not mark the production package `DELIVERED`.

Batch summary:

```text
批量任务/BATCH_ID/角标批处理报告.json
批量任务/BATCH_ID/角标批处理报告.md
```

## Safety Boundary

- Never edit channel analysis reports or core-word statistics.
- Never modify raw source images.
- Never apply another channel's logo.
- Missing logo configuration blocks only that channel's logo composition; it is not an image-content rejection.
