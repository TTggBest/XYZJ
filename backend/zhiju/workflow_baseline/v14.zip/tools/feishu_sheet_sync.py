#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


BASE = "https://open.feishu.cn/open-apis"


def load_config(path: str) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def request_json(method: str, url: str, token: str | None = None, body: dict[str, Any] | None = None) -> dict[str, Any]:
    data = None
    headers = {"Content-Type": "application/json; charset=utf-8"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {raw}") from exc

    result = json.loads(raw)
    if result.get("code") != 0:
        raise RuntimeError(json.dumps(result, ensure_ascii=False))
    return result


def get_token(config: dict[str, Any]) -> str:
    app_id = os.environ.get(config.get("app_id_env", "FEISHU_APP_ID")) or config.get("app_id")
    app_secret = os.environ.get(config.get("app_secret_env", "FEISHU_APP_SECRET")) or config.get("app_secret")
    if not app_id or not app_secret:
        raise SystemExit("Missing FEISHU_APP_ID / FEISHU_APP_SECRET. Put them in env vars or config.")
    result = request_json(
        "POST",
        f"{BASE}/auth/v3/tenant_access_token/internal",
        body={"app_id": app_id, "app_secret": app_secret},
    )
    return result["tenant_access_token"]


def list_sheets(token: str, spreadsheet_token: str) -> list[dict[str, Any]]:
    result = request_json(
        "GET",
        f"{BASE}/sheets/v3/spreadsheets/{spreadsheet_token}/sheets/query",
        token=token,
    )
    return result.get("data", {}).get("sheets", [])


def resolve_sheet_id(token: str, config: dict[str, Any], employee_key: str) -> tuple[str, dict[str, Any]]:
    spreadsheet_token = config["spreadsheet_token"]
    employees = config.get("employees", {})
    if employee_key not in employees:
        raise SystemExit(f"Unknown employee key: {employee_key}. Known: {', '.join(employees)}")

    employee = employees[employee_key]
    if employee.get("sheet_id"):
        return employee["sheet_id"], employee

    sheet_name = employee.get("sheet_name")
    if not sheet_name:
        raise SystemExit(f"{employee_key} needs sheet_id or sheet_name in config.")

    sheets = list_sheets(token, spreadsheet_token)
    for sheet in sheets:
        if sheet.get("title") == sheet_name:
            return sheet["sheet_id"], employee

    known = ", ".join(f"{s.get('title')}({s.get('sheet_id')})" for s in sheets)
    raise SystemExit(f"Sheet name not found: {sheet_name}. Current sheets: {known}")


def read_csv(path: Path) -> list[list[Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [row for row in csv.reader(handle)]


def read_xlsx(path: Path, sheet_name: str | None = None) -> list[list[Any]]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise SystemExit("XLSX input requires openpyxl. Run: pip install openpyxl") from exc

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[sheet_name] if sheet_name else wb.active
    rows: list[list[Any]] = []
    for row in ws.iter_rows(values_only=True):
        values = ["" if value is None else value for value in row]
        while values and values[-1] == "":
            values.pop()
        rows.append(values)
    while rows and not any(str(cell).strip() for cell in rows[-1]):
        rows.pop()
    return rows


def read_input(path: str, sheet_name: str | None = None) -> list[list[Any]]:
    file_path = Path(path)
    suffix = file_path.suffix.lower()
    if suffix == ".csv":
        return read_csv(file_path)
    if suffix in {".xlsx", ".xlsm"}:
        return read_xlsx(file_path, sheet_name)
    raise SystemExit("Only .csv, .xlsx, .xlsm inputs are supported.")


def rect_values(rows: list[list[Any]], width: int | None = None) -> list[list[Any]]:
    if not rows:
        return []
    max_width = width or max(len(row) for row in rows)
    return [(row + [""] * max_width)[:max_width] for row in rows]


def put_values(token: str, spreadsheet_token: str, range_name: str, values: list[list[Any]]) -> dict[str, Any]:
    return request_json(
        "PUT",
        f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/values",
        token=token,
        body={"valueRange": {"range": range_name, "values": values}},
    )


def add_sheet(token: str, spreadsheet_token: str, title: str, row_count: int = 500, column_count: int = 20) -> dict[str, Any]:
    return request_json(
        "POST",
        f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/sheets_batch_update",
        token=token,
        body={
            "requests": [
                {
                    "addSheet": {
                        "properties": {
                            "title": title,
                            "gridProperties": {
                                "rowCount": row_count,
                                "columnCount": column_count,
                            },
                        }
                    }
                }
            ]
        },
    )


def cmd_add_sheets(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    token = get_token(config)
    spreadsheet_token = config["spreadsheet_token"]
    existing = {sheet.get("title"): sheet for sheet in list_sheets(token, spreadsheet_token)}
    created = []
    skipped = []
    for title in args.titles:
        if title in existing:
            skipped.append({"title": title, "sheet_id": existing[title].get("sheet_id")})
            continue
        result = add_sheet(token, spreadsheet_token, title, args.rows, args.cols)
        created.append({"title": title, "result": result.get("data")})
    print(json.dumps({"created": created, "skipped": skipped}, ensure_ascii=False, indent=2))


def cmd_list_sheets(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    token = get_token(config)
    sheets = list_sheets(token, config["spreadsheet_token"])
    for sheet in sheets:
        props = sheet.get("grid_properties") or {}
        print(f"{sheet.get('title')}\t{sheet.get('sheet_id')}\t{props.get('row_count')}x{props.get('column_count')}")


def cmd_upload(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    token = get_token(config)
    spreadsheet_token = config["spreadsheet_token"]
    sheet_id, employee = resolve_sheet_id(token, config, args.employee)

    rows = read_input(args.input, args.input_sheet)
    width = args.columns or employee.get("columns")
    rows = rect_values(rows, width=width)
    if not rows:
        raise SystemExit("Input has no rows.")

    clear_rows = args.clear_rows or employee.get("clear_rows", 500)
    clear_cols = args.clear_cols or employee.get("clear_cols") or len(rows[0])
    clear_values = [["" for _ in range(clear_cols)] for _ in range(clear_rows)]
    clear_range = f"{sheet_id}!A1:{col_name(clear_cols)}{clear_rows}"
    put_values(token, spreadsheet_token, clear_range, clear_values)

    write_range = f"{sheet_id}!A1:{col_name(len(rows[0]))}{len(rows)}"
    result = put_values(token, spreadsheet_token, write_range, rows)
    data = result.get("data", {})
    print(json.dumps({
        "employee": args.employee,
        "sheet_id": sheet_id,
        "input": args.input,
        "clear_range": clear_range,
        "write_range": write_range,
        "updatedRows": data.get("updatedRows"),
        "updatedColumns": data.get("updatedColumns"),
        "updatedCells": data.get("updatedCells"),
    }, ensure_ascii=False, indent=2))


def col_name(index: int) -> str:
    name = ""
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


def main() -> None:
    parser = argparse.ArgumentParser(description="One shared Feishu sheet sync tool. Employees only change config/employee key.")
    parser.add_argument("--config", default="tools/feishu_sync/feishu_sync_config.json")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_list = sub.add_parser("list-sheets")
    p_list.set_defaults(func=cmd_list_sheets)

    p_add = sub.add_parser("add-sheets")
    p_add.add_argument("titles", nargs="+")
    p_add.add_argument("--rows", type=int, default=500)
    p_add.add_argument("--cols", type=int, default=20)
    p_add.set_defaults(func=cmd_add_sheets)

    p_upload = sub.add_parser("upload")
    p_upload.add_argument("--employee", required=True, help="employee key in config, e.g. bengali_revenge")
    p_upload.add_argument("--input", required=True, help="CSV/XLSX file to upload")
    p_upload.add_argument("--input-sheet", help="XLSX sheet name, optional")
    p_upload.add_argument("--columns", type=int, help="force column count")
    p_upload.add_argument("--clear-rows", type=int)
    p_upload.add_argument("--clear-cols", type=int)
    p_upload.set_defaults(func=cmd_upload)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
