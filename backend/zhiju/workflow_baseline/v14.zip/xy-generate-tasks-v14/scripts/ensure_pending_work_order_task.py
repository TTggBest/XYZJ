#!/usr/bin/env python3
"""Safely preview/apply one valid work-order task whose video URL is pending."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from community_counts import assert_complete_date_scope  # noqa: E402
from reconcile_work_order_community_counts import cell_text  # noqa: E402

WORKSPACE = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube")
FEISHU_TOOLS = WORKSPACE / "tools" / "feishu_sync"
if str(FEISHU_TOOLS) not in sys.path:
    sys.path.insert(0, str(FEISHU_TOOLS))
from feishu_sheet_sync import BASE, get_token, load_config, put_values, request_json  # noqa: E402

CHANNEL_HELPERS = Path(__file__).resolve().parents[2] / "xy-channels" / "scripts"
if str(CHANNEL_HELPERS) not in sys.path:
    sys.path.insert(0, str(CHANNEL_HELPERS))
from channel_registry import ensure_registry, resolve_channel  # noqa: E402


WIKI_TOKEN = "MUJ0wBw9yiyeJNkIt0cczSCgn3f"
WORK_ORDER_SHEET_ID = "5EPSHD"
HEADERS = ["剧名", "地址", "频道", "档期", "是否需要社区", "是否有资源"]


def plan_pending_task(
    rows: list[list], task: dict, *, expected_items: int, expected_channels: int,
    expected_single: int, expected_double: int,
) -> dict:
    if not rows:
        raise ValueError("工单表为空")
    header = [cell_text(value).strip() for value in rows[0]]
    columns = {name: index for index, name in enumerate(header)}
    missing_headers = [name for name in HEADERS if name not in columns]
    if missing_headers:
        raise ValueError("工单表缺少列: " + ", ".join(missing_headers))
    date = task["档期"][:8]
    current = []
    blank_row = None
    exact_rows = []
    for row_number, row in enumerate(rows[1:], start=2):
        get = lambda name: cell_text(row[columns[name]]) if columns[name] < len(row) else ""
        values = {name: get(name) for name in HEADERS}
        if not any(values.values()) and blank_row is None:
            blank_row = row_number
        if values["档期"][:8] != date:
            continue
        current.append(values)
        if (values["频道"], values["剧名"], values["档期"]) == (
            task["频道"], task["剧名"], task["档期"]
        ):
            exact_rows.append(row_number)
    if len(exact_rows) > 1:
        raise ValueError(f"目标工单重复: rows={exact_rows}")
    projected = list(current)
    action = "existing"
    target_row = exact_rows[0] if exact_rows else (blank_row or len(rows) + 1)
    if not exact_rows:
        projected.append(task)
        action = "append"
    summary = assert_complete_date_scope(
        projected, projected,
        expected_items=expected_items,
        expected_channels=expected_channels,
        expected_single=expected_single,
        expected_double=expected_double,
    )
    return {"action": action, "row_number": target_row, "task": task, "summary": summary}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--drama", required=True)
    parser.add_argument("--channel", required=True)
    parser.add_argument("--slot", required=True)
    parser.add_argument("--expected-items", type=int, required=True)
    parser.add_argument("--expected-channels", type=int, required=True)
    parser.add_argument("--expected-single", type=int, required=True)
    parser.add_argument("--expected-double", type=int, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--channel-source-root", default=str(WORKSPACE / "运营/工作流运营"))
    parser.add_argument("--config", default=str(WORKSPACE / "tools/feishu_sync/feishu_sync_config.json"))
    args = parser.parse_args()
    if len(args.slot) != 10 or not args.slot.isdigit():
        raise SystemExit("--slot must be YYYYMMDDHH")
    channel_root = Path(args.channel_source_root).expanduser().resolve()
    ensure_registry(channel_root)
    channel = resolve_channel(channel_root, args.channel)
    formal_channel = str(channel["channel_name"])
    task = {
        "剧名": args.drama.strip(), "地址": "", "频道": formal_channel,
        "档期": args.slot, "是否需要社区": "2", "是否有资源": "",
    }
    token = get_token(load_config(args.config))
    node = request_json(
        "GET", f"{BASE}/wiki/v2/spaces/get_node?token={WIKI_TOKEN}", token=token
    ).get("data", {}).get("node", {})
    spreadsheet_token = node.get("obj_token")
    if node.get("obj_type") != "sheet" or not spreadsheet_token:
        raise SystemExit("工单Wiki节点不是电子表格")
    result = request_json(
        "GET",
        f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/values/"
        f"{WORK_ORDER_SHEET_ID}!A1:F500",
        token=token,
    )
    rows = result.get("data", {}).get("valueRange", {}).get("values", [])
    plan = plan_pending_task(
        rows, task,
        expected_items=args.expected_items,
        expected_channels=args.expected_channels,
        expected_single=args.expected_single,
        expected_double=args.expected_double,
    )
    plan.update({"dry_run": not args.apply, "formal_channel": formal_channel})
    if args.apply and plan["action"] == "append":
        row_number = plan["row_number"]
        values = [[task[name] for name in HEADERS]]
        range_name = f"{WORK_ORDER_SHEET_ID}!A{row_number}:F{row_number}"
        put_values(token, spreadsheet_token, range_name, values)
        readback = request_json(
            "GET",
            f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/values/{range_name}",
            token=token,
        ).get("data", {}).get("valueRange", {}).get("values", [])
        actual = [cell_text(value) for value in (readback[0] if readback else [])]
        expected = values[0]
        if actual[: len(expected)] != expected:
            raise RuntimeError(f"待补链接工单写后回读不一致: row={row_number}")
        plan["readback_verified"] = True
    print(json.dumps(plan, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
