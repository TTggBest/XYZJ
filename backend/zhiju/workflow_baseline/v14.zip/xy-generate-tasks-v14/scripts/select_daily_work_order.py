#!/usr/bin/env python3
"""Select and validate one complete production date from a fetched work-order TSV."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from community_counts import assign_community_counts, scope_identity


HEADERS = ["剧名", "剧id", "地址", "频道", "档期", "是否需要社区"]


def select_rows(rows: list[dict], date: str, excluded: set[tuple[str, str, str]] | None = None) -> list[dict]:
    selected = [dict(row) for row in rows if str(row.get("档期") or "")[:8] == date]
    assigned = assign_community_counts(selected)
    for row in assigned:
        actual = str(row.get("是否需要社区") or "").strip()
        expected = str(row["是否需要社区"])
        if actual != expected:
            raise ValueError(
                f"工单社群数量不符: identity={scope_identity(row)}, expected={expected}, actual={actual}"
            )
    if excluded:
        assigned = [row for row in assigned if scope_identity(row) not in excluded]
    return assigned


def index_identities(path: Path) -> set[tuple[str, str, str]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return {
        (str(item.get("channel") or ""), str(item.get("drama_name") or ""), str(item.get("slot") or ""))
        for item in data.get("items", [])
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--date", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--exclude-index", action="append", default=[], type=Path)
    parser.add_argument("--expected-items", type=int)
    parser.add_argument("--expected-channels", type=int)
    args = parser.parse_args()
    with args.input.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    all_selected = select_rows(rows, args.date)
    channels = {row["频道"] for row in all_selected}
    if args.expected_items is not None and len(all_selected) != args.expected_items:
        raise ValueError(f"日期任务数不符: expected={args.expected_items}, actual={len(all_selected)}")
    if args.expected_channels is not None and len(channels) != args.expected_channels:
        raise ValueError(f"日期频道数不符: expected={args.expected_channels}, actual={len(channels)}")
    excluded = set()
    for path in args.exclude_index:
        excluded.update(index_identities(path))
    selected = select_rows(rows, args.date, excluded)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=HEADERS, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(selected)
    print(json.dumps({
        "output": str(args.output.resolve()), "complete_date_items": len(all_selected),
        "complete_date_channels": len(channels), "selected_items": len(selected),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
