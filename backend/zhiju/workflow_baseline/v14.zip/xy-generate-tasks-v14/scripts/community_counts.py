#!/usr/bin/env python3
"""Derive Xiaoyu community output counts from one complete production date scope."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path


def assign_community_counts(rows: list[dict]) -> list[dict]:
    """Return copied rows with single-update=2 and double-update=1.

    The input must represent the complete selected scope for exactly one date.
    More than two rows for one formal channel is rejected instead of guessed.
    """
    normalized = []
    dates = set()
    for position, source in enumerate(rows, start=1):
        row = dict(source)
        channel = str(row.get("频道") or "").strip()
        slot = str(row.get("档期") or "").strip()
        if not channel:
            raise ValueError(f"第{position}条缺少正式频道名")
        if len(slot) < 8 or not slot[:8].isdigit():
            raise ValueError(f"第{position}条档期不是YYYYMMDDHH: {slot}")
        row["频道"] = channel
        row["档期"] = slot
        dates.add(slot[:8])
        normalized.append(row)
    if len(dates) != 1:
        raise ValueError(f"社群数量必须按单个完整日期计算，实际日期={sorted(dates)}")
    frequencies = Counter(row["频道"] for row in normalized)
    overloaded = {channel: count for channel, count in frequencies.items() if count > 2}
    if overloaded:
        raise ValueError(f"同日频道任务超过2条，禁止推断社群数量: {overloaded}")
    for row in normalized:
        row["是否需要社区"] = 2 if frequencies[row["频道"]] == 1 else 1
    return normalized


def scope_identity(row: dict) -> tuple[str, str, str]:
    return (
        str(row.get("频道") or "").strip(),
        str(row.get("剧名") or "").strip(),
        str(row.get("档期") or "").strip(),
    )


def assert_complete_date_scope(
    source_rows: list[dict], written_rows: list[dict], *,
    expected_items: int | None = None,
    expected_channels: int | None = None,
    expected_single: int | None = None,
    expected_double: int | None = None,
) -> dict:
    """Fail closed unless the written work order exactly matches the selected scope."""
    assigned = assign_community_counts(source_rows)
    source_identities = [scope_identity(row) for row in assigned]
    written_identities = [scope_identity(row) for row in written_rows]
    if len(set(source_identities)) != len(source_identities):
        raise ValueError("完整日期源范围存在重复频道+剧名+档期")
    if set(source_identities) != set(written_identities):
        missing = sorted(set(source_identities) - set(written_identities))
        extra = sorted(set(written_identities) - set(source_identities))
        raise ValueError(f"完整日期工单闭环失败: missing={missing}, extra={extra}")
    frequencies = Counter(row["频道"] for row in assigned)
    summary = {
        "item_count": len(assigned),
        "channel_count": len(frequencies),
        "single_update_count": sum(count == 1 for count in frequencies.values()),
        "double_update_count": sum(count == 2 for count in frequencies.values()),
        "channels": sorted(frequencies),
    }
    expectations = {
        "item_count": expected_items,
        "channel_count": expected_channels,
        "single_update_count": expected_single,
        "double_update_count": expected_double,
    }
    mismatches = {
        key: {"expected": expected, "actual": summary[key]}
        for key, expected in expectations.items()
        if expected is not None and summary[key] != expected
    }
    if mismatches:
        raise ValueError(f"完整日期数量门禁失败: {mismatches}")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path, help="UTF-8 TSV with 频道 and 档期 headers")
    args = parser.parse_args()
    with args.input.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    result = assign_community_counts(rows)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
