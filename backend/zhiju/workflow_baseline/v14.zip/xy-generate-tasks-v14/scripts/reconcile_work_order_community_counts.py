#!/usr/bin/env python3
"""Audit or narrowly correct work-order community counts for one production date."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from community_counts import assign_community_counts  # noqa: E402

WORKSPACE = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube")
FEISHU_TOOLS = WORKSPACE / "tools" / "feishu_sync"
if str(FEISHU_TOOLS) not in sys.path:
    sys.path.insert(0, str(FEISHU_TOOLS))
from feishu_sheet_sync import BASE, get_token, load_config, put_values, request_json  # noqa: E402


WIKI_TOKEN = "MUJ0wBw9yiyeJNkIt0cczSCgn3f"
WORK_ORDER_SHEET_ID = "5EPSHD"


def cell_text(value) -> str:
    if isinstance(value, list):
        return "".join(cell_text(part) for part in value)
    if isinstance(value, dict):
        return cell_text(value.get("text") or value.get("link") or "")
    return "" if value is None else str(value).strip()


def plan_reconciliation(rows: list[list], date: str) -> dict:
    if not rows:
        raise ValueError("工单表为空")
    header = [cell_text(value) for value in rows[0]]
    columns = {name.strip(): index for index, name in enumerate(header)}
    required = ["剧名", "频道", "档期", "是否需要社区"]
    missing = [name for name in required if name not in columns]
    if missing:
        raise ValueError("工单表缺少列: " + ", ".join(missing))
    selected = []
    for row_number, row in enumerate(rows[1:], start=2):
        get = lambda name: cell_text(row[columns[name]]) if columns[name] < len(row) else ""
        slot = get("档期")
        if slot[:8] != date:
            continue
        selected.append({
            "row_number": row_number,
            "剧名": get("剧名"),
            "频道": get("频道"),
            "档期": slot,
            "current_count": get("是否需要社区"),
        })
    if not selected:
        raise ValueError(f"工单表没有日期{date}的任务")
    assigned = assign_community_counts(selected)
    changes = []
    for row in assigned:
        expected = str(row["是否需要社区"])
        if row["current_count"] != expected:
            changes.append({
                "row_number": row["row_number"],
                "剧名": row["剧名"],
                "频道": row["频道"],
                "档期": row["档期"],
                "before": row["current_count"],
                "after": expected,
            })
    frequencies = Counter(row["频道"] for row in assigned)
    return {
        "date": date,
        "item_count": len(assigned),
        "channel_count": len(frequencies),
        "single_update_channels": sorted(channel for channel, count in frequencies.items() if count == 1),
        "double_update_channels": sorted(channel for channel, count in frequencies.items() if count == 2),
        "changes": changes,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="YYYYMMDD")
    parser.add_argument("--apply", action="store_true", help="Apply narrow E-cell writes after dry-run review")
    parser.add_argument(
        "--config",
        default=str(WORKSPACE / "tools/feishu_sync/feishu_sync_config.json"),
    )
    args = parser.parse_args()
    if len(args.date) != 8 or not args.date.isdigit():
        raise SystemExit("--date must be YYYYMMDD")
    token = get_token(load_config(args.config))
    node = request_json(
        "GET", f"{BASE}/wiki/v2/spaces/get_node?token={WIKI_TOKEN}", token=token
    ).get("data", {}).get("node", {})
    spreadsheet_token = node.get("obj_token")
    if node.get("obj_type") != "sheet" or not spreadsheet_token:
        raise SystemExit("工单Wiki节点不是电子表格")
    result = request_json(
        "GET",
        f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/values/"
        f"{WORK_ORDER_SHEET_ID}!A1:F500",
        token=token,
    )
    rows = result.get("data", {}).get("valueRange", {}).get("values", [])
    plan = plan_reconciliation(rows, args.date)
    plan["dry_run"] = not args.apply
    plan["applied"] = []
    if args.apply:
        for change in plan["changes"]:
            row_number = change["row_number"]
            range_name = f"{WORK_ORDER_SHEET_ID}!E{row_number}:E{row_number}"
            put_values(token, spreadsheet_token, range_name, [[change["after"]]])
            readback = request_json(
                "GET",
                f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/values/{range_name}",
                token=token,
            ).get("data", {}).get("valueRange", {}).get("values", [])
            actual = cell_text(readback[0][0]) if readback and readback[0] else ""
            if actual != change["after"]:
                raise RuntimeError(f"工单社群数量写后回读不一致: row={row_number}")
            plan["applied"].append({**change, "readback_verified": True})
    print(json.dumps(plan, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
