---
name: xy-generate-tasks-v14
description: Generate Feishu task-table rows from unprocessed channel schedule rows. Use when the user invokes xy-generate-tasks-v14 with an optional date, channel name, or language filter.
---

Feishu account: always use the approved `筱宇` account through `feishu-api-accounts` (`feishu_accounts.py run --account 筱宇 -- ...`) for any script that reads or writes Feishu. Never invoke a legacy local config directly.

# XY Generate Tasks

## Purpose

Create the task list consumed by `xy-batch`. The source of truth is the Feishu channel schedule; only rows whose `是否写入任务` is blank are eligible. A source row is marked `1` only after the corresponding task row has been written and read back successfully.

Before operating, read the locked production specification:

`/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/运营/工作流实验室/V14/公用/XY生产锁定规范_V14.md`

## Fixed Feishu sources

- Schedule directory: wiki `NDyCw5M9iiqTLlkcGGHcbWr1n2c`, sheet `频道目录` (`43e1df`). Match the exact formal `频道名` and follow its `链接` to the actual per-channel schedule; this directory is not the schedule itself. An absent row or link blocks generation before any write.
- Channel registry: wiki `MUJ0wBw9yiyeJNkIt0cczSCgn3f`, sheet `频道信息` (`ccsEjl`).
- Destination: wiki `MUJ0wBw9yiyeJNkIt0cczSCgn3f`, sheet ID `5EPSHD`, displayed as `工单`. This is the input table consumed by `xy-batch`.
- Use the `筱宇` Feishu account. Never print credentials or replace these sources with an unverified URL.

## Accepted command forms

```text
xy-generate-tasks-v14 YYYY-MM-DD
xy-generate-tasks-v14 YYYY-MM-DD 频道名
xy-generate-tasks-v14 YYYY-MM-DD 语言
xy-generate-tasks-v14 频道名
xy-generate-tasks-v14 语言
```

Date, channel, and language filters may be supplied together. Channel and language are mutually exclusive; if both are supplied, use the exact channel filter and ignore the language filter. Without a date, select the next unprocessed schedule rows in schedule order; never invent a date.

## Procedure

1. Read `频道信息` and the local channel registry. Resolve each schedule Sheet title through `channel_name`, current `nickname`, and legacy `aliases`; write the registry's formal `channel_name` into the work-order `频道` column. Never copy a schedule Sheet title or nickname into `频道`.
2. Read only the selected channel schedule sheets. Preserve their existing column names and row order.
3. Apply filters for date, exact channel, or language. Select only rows where `是否写入任务` is blank; a value of `1` means the drama has already generated a task and must be skipped. A selected row is valid when `剧名 + formal channel_name + 档期时间` are present. An empty video URL is not a blocker: write an empty `地址`, and let V2 derive its stable `pending_...` identity from drama/channel/slot and use `【视频链接待补】` in community copy.
4. Preserve schedule order. Do not deduplicate unrelated dramas; the stable source-row identity is `频道 + 剧名 + 档期`.
5. Build work-order rows for the existing `工单` schema: `剧名, 地址, 频道, 档期, 是否需要社区, 是否有资源`. Use the resolved formal channel name (not the nickname), source schedule URL, and convert the source `档期时间` to the required `YYYYMMDDHH` value (for example `2026080510`), not the labels `主档`/`辅档`. Before writing, group the complete selected date scope by formal `频道`: a channel with exactly one selected task that day is single-update and must write `是否需要社区=2`; a channel with exactly two selected tasks that day is double-update and both rows must write `是否需要社区=1`. Any channel with more than two selected tasks is a scheduling error and must stop before writes. Use `scripts/community_counts.py` for this calculation; never default every row to `1`.
6. Before writing, freeze the complete selected-date identities and formal channel set. Resolve every schedule Sheet title/nickname/legacy alias through `频道注册表.json`, and write only the registry `channel_name`; never preserve a stale nickname or alias as `频道`.
7. Write to `工单` while preserving its existing six-column schema and existing rows. Match an existing work order by `频道 + 剧名 + 档期`; do not create a duplicate.
8. Read back the written rows and run the complete-date closure: source and written identities must match exactly; task count, formal channel set, single-update count, and double-update count must all match the pre-write scope. Any missing channel or task stops before source marks are changed.
9. Only after the full closure passes, mark the exact source schedule rows `是否写入任务=1`. If that column does not exist, add it without disturbing other columns.
10. Read back the source marks and report the result.

For an already-written work-order date whose community counts were initialized
incorrectly, the production executor must first run
`scripts/reconcile_work_order_community_counts.py --date YYYYMMDD` as a
read-only preview, then use the same command with `--apply`. The script may
write only the changed `是否需要社区` cells in column E and must read back every
write. It must not rewrite the six-column table or touch schedule source marks.

## Work-order columns

```text
剧名, 地址, 频道, 档期, 是否需要社区, 是否有资源
```

The generation stage fills the work-order fields and the date-scope cadence-derived community count. `xy-batch` reads `工单`, then writes stage results to its configured production output table.

## Safety and reporting

- Preview the matched sheets and row count before writes.
- If no eligible rows exist, perform no writes and report the reason.
- Never clear or overwrite the whole workbook.
- If task write or readback fails, do not mark source rows as written.
- Final output must state: filters used, sheets read, rows selected, task rows written/skipped, source rows marked, and any blocked rows.

## Examples

```text
xy-generate-tasks-v14 2026-08-03 孟加拉
xy-generate-tasks-v14 2026-08-03 दिल की शाही कहानी
xy-generate-tasks-v14 孟加拉
```
