import importlib.util
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "community_counts.py"
SPEC = importlib.util.spec_from_file_location("community_counts_under_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class CommunityCountTests(unittest.TestCase):
    def test_single_update_gets_two_and_double_update_gets_one_each(self):
        rows = [
            {"频道": "单更频道", "档期": "2026081906"},
            {"频道": "双更频道", "档期": "2026081910"},
            {"频道": "双更频道", "档期": "2026081920"},
        ]
        result = MODULE.assign_community_counts(rows)
        self.assertEqual([row["是否需要社区"] for row in result], [2, 1, 1])

    def test_multiple_dates_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "单个完整日期"):
            MODULE.assign_community_counts([
                {"频道": "A", "档期": "2026081906"},
                {"频道": "B", "档期": "2026082006"},
            ])

    def test_more_than_two_tasks_for_one_channel_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "超过2条"):
            MODULE.assign_community_counts([
                {"频道": "A", "档期": "2026081906"},
                {"频道": "A", "档期": "2026081910"},
                {"频道": "A", "档期": "2026081920"},
            ])

    def test_empty_url_remains_a_valid_scope_identity(self):
        source = [{"剧名": "一胎双宝，夫人拒不复婚", "地址": "", "频道": "ছোট্ট পরিবারের গল্প", "档期": "2026081920"}]
        written = [{"剧名": "一胎双宝，夫人拒不复婚", "地址": "", "频道": "ছোট্ট পরিবারের গল্প", "档期": "2026081920"}]
        summary = MODULE.assert_complete_date_scope(
            source, written, expected_items=1, expected_channels=1,
            expected_single=1, expected_double=0,
        )
        self.assertEqual(summary["item_count"], 1)

    def test_complete_scope_rejects_missing_channel_even_when_other_rows_match(self):
        source = [
            {"剧名": "A", "频道": "频道A", "档期": "2026081906"},
            {"剧名": "B", "频道": "频道B", "档期": "2026081920"},
        ]
        with self.assertRaisesRegex(ValueError, "missing"):
            MODULE.assert_complete_date_scope(source, source[:1])


if __name__ == "__main__":
    unittest.main()
