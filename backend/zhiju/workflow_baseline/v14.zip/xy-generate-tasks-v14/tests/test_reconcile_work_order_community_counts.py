import importlib.util
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "reconcile_work_order_community_counts.py"
SPEC = importlib.util.spec_from_file_location("reconcile_community_under_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class ReconcileCommunityCountTests(unittest.TestCase):
    def test_plan_updates_only_single_channel_rows_for_selected_date(self):
        rows = [
            ["剧名", "地址", " 频道", "档期 ", "是否需要社区", "是否有资源"],
            ["剧A", "url", "单更", "2026081906", "1", ""],
            ["剧B", "url", "双更", "2026081910", "1", ""],
            ["剧C", "url", "双更", "2026081920", "1", ""],
            ["剧D", "url", "别日", "2026082006", "1", ""],
        ]
        plan = MODULE.plan_reconciliation(rows, "20260819")
        self.assertEqual(plan["item_count"], 3)
        self.assertEqual(plan["single_update_channels"], ["单更"])
        self.assertEqual(plan["double_update_channels"], ["双更"])
        self.assertEqual(plan["changes"], [{
            "row_number": 2,
            "剧名": "剧A",
            "频道": "单更",
            "档期": "2026081906",
            "before": "1",
            "after": "2",
        }])


if __name__ == "__main__":
    unittest.main()
