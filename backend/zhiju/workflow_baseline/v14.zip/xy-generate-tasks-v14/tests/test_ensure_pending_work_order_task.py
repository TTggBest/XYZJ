import importlib.util
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "ensure_pending_work_order_task.py"
SPEC = importlib.util.spec_from_file_location("ensure_pending_work_order_under_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class EnsurePendingWorkOrderTaskTests(unittest.TestCase):
    def test_empty_url_task_is_appended_and_closes_expected_scope(self):
        rows = [["剧名", "地址", " 频道", "档期 ", "是否需要社区", "是否有资源"]]
        for number in range(20):
            rows.append([f"单{number}", "url", f"单频道{number}", f"20260819{number:02d}", "2", ""])
        for number in range(9):
            rows.append([f"双{number}A", "url", f"双频道{number}", f"20260819{number:02d}", "1", ""])
            rows.append([f"双{number}B", "url", f"双频道{number}", f"20260819{number+10:02d}", "1", ""])
        task = {
            "剧名": "一胎双宝，夫人拒不复婚", "地址": "", "频道": "ছোট্ট পরিবারের গল্প",
            "档期": "2026081920", "是否需要社区": "2", "是否有资源": "",
        }
        plan = MODULE.plan_pending_task(
            rows, task, expected_items=39, expected_channels=30,
            expected_single=21, expected_double=9,
        )
        self.assertEqual(plan["action"], "append")
        self.assertEqual(plan["summary"]["item_count"], 39)
        self.assertEqual(plan["summary"]["channel_count"], 30)


if __name__ == "__main__":
    unittest.main()
