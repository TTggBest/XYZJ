import importlib.util
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "select_daily_work_order.py"
SPEC = importlib.util.spec_from_file_location("select_daily_work_order_under_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class SelectDailyWorkOrderTests(unittest.TestCase):
    def test_empty_url_pending_row_is_selected(self):
        rows = [{
            "剧名": "一胎双宝，夫人拒不复婚", "剧id": "", "地址": "",
            "频道": "ছোট্ট পরিবারের গল্প", "档期": "2026081920", "是否需要社区": "2",
        }]
        selected = MODULE.select_rows(rows, "20260819")
        self.assertEqual(len(selected), 1)
        self.assertEqual(selected[0]["地址"], "")


if __name__ == "__main__":
    unittest.main()
