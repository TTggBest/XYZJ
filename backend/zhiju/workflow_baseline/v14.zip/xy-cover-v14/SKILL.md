---
name: xy-cover-v14
description: Generate 3 cover groups for the current Xiaoyu short-drama package. Use after titles are ready. Each title gets one 4:5 cover prompt first, then one 16:9 expansion prompt.
---

# XY Cover

## Purpose

This step only does one thing:

- generate covers from the 3 titles

It does not search plot, does not generate titles, and does not write community or description content.

## Inputs

In deterministic batch mode, the controller supplies the normalized contents of:

```text
04_标题方案.md
01_搜索资料.md
频道名_生成规范.md
```

## Rules

- Generate 3 cover groups, one for each title.
- V14 cover generation strictly forbids these semantic concepts in `visual_payoff`, `story_hook`, scene/action fields, core words, `scene_prompt_4_5`, and `outpaint_environment`: 强奸/rape、性侵/sexual assault、猥亵/molestation、下药/drugged、迷奸/date rape or drugging、卖掉某人/sold a person、人口贩卖/human trafficking、杀死/kill、谋杀/murder、枪杀/shooting or killing、自杀/suicide、自残/self-harm、尸体/corpse or dead body、血腥/bloody or gory、酷刑/torture、毒杀/poisoning to death、虐杀/brutal killing. Translation, inflection, euphemistic spelling, or visual implication does not make the concept usable.
- Prefer not to use 家暴/domestic violence、虐待/abuse、绑架/kidnapping、死亡威胁/death threat. Create another title-linked conflict expression whenever possible.
- Apply this blacklist while creating the cover plan and prompt. Do not rely on a downstream Validator or cleaning pass.
- For each title, generate the 4:5 cover first, then generate the 16:9 version.
- All cover image prompt descriptions must be written in English.
- Use English descriptive words for scene, characters, action, composition, lighting, style, safety, and 16:9 expansion instructions.
- Do not write Chinese scene descriptions inside `4:5` or `16:9` prompts.
- Only the visible cover text / core cover words may be in the channel language.
- Only the visible core cover words are language-constrained. Incidental Chinese environmental text on signs, documents, boards, buildings, and props is allowed when natural to the Chinese setting.
- Never add blanket restrictions such as `no readable words`, `no new text`, or `no other visible text`. Background Chinese alone is never a rejection reason; reject it only when garbled, illogical, dominant over the core words, or otherwise damaging the image.
- Chinese is allowed only in labels, explanations, or review notes outside the actual image prompt text.
- The model returns `scene_prompt_4_5` without global Style, actor-identity, or Typography boilerplate. It leaves suitable negative space but never describes font, outline, shadow, canvas width, text placement, or core-word rendering. The controller is the sole owner of the final Style and Typography blocks and appends each exactly once.
- Neither `scene_prompt_4_5` nor the controller-built final `prompt_4_5` may contain any `16:9`, outpaint, locked-center, side-band, wide-canvas, pixel-restoration, or other wide-image execution wording. Wide-image instructions belong only to the separate `prompt_16_9` task.
- The controller-owned 4:5 Typography block uses a `typography_salience_rule`, not a fixed size rule. Render the exact core words as visually prominent, highly legible, immediately recognizable mobile editorial typography, but impose no fixed width, height, font size, or canvas ratio. Adapt font size, line breaks, color, outline, compact hard shadow, optional restrained backing shape, and placement to the language, word length, available negative space, local background, and actor placement. Human faces and the dramatic event remain the primary visual storytelling elements; prominent never means largest possible. Keep typography clear of primary faces, critical hands, essential story objects, and channel logos.
- The complete core-word typography must stay inside the original centered 1728x2160 4:5 area. It must never enter the left or right outpaint bands of the final 3840x2160 image.
- The core words must never be printed, painted, written, engraved, projected, reflected, displayed, or attached on a wall, door, paper, document, folder, book, screen, clothing, sign, or physical prop. Natural incidental Chinese environmental text remains allowed, but it must never carry or substitute for the core words.
- The 16:9 image must not change the content of the 4:5 center image. It is only used to expand the left and right sides of the 4:5 image.
- The 16:9 expansion must preserve the non-diegetic core-word typography in exactly the same position, scale, and style.
- A 16:9 task is executable only as real image-to-image outpainting from its approved 4:5 source task. Never run the 16:9 prompt as standalone text-to-image. Use a side-only mask, generate environment only in the left/right bands, and composite the approved 4:5 source pixels back over the full center area after outpainting. The side bands must add no people, body fragments, faces, core words, props, or story information.
- Before writing `scene_prompt_4_5`, commit the generation plan in this order: `visual_payoff`; `required_characters` and adult/child counts; a freely created scene; a freely created action; optional supporting prop; one standard camera angle; core-word category and reason; then the prompt.
- Every 4:5 group must show exactly one continuous moment in one physical location with one coherent lighting environment. Set `single_continuous_moment=true`, `single_physical_location=true`, and `temporal_montage=false` before writing the scene.
- A title may contain A+B, but the cover must choose only the strongest single visible instant. Never draw both beats, two times, or two locations in one image. If upstream `visual_thesis` mentions multiple moments, distill it into one `visual_payoff` instead of reproducing both.
- Forbid split screen, upper/lower stacked scenes, collage, diptych, multi-panel layouts, before/after comparison, present/later comparison, cause/result pairing, temporal montage, and an adjacent second moment.
- For a group without required children, use 2 to 4 visible adults and no unplanned people or readable extra faces.
- Keep every required child. When a child group would become crowded, remove optional adults first: required child anchor > protagonist > primary antagonist/lover > optional adults.
- The final scene may contain only `required_characters`; do not add background crowds, assistants, guards, shareholders, relatives, or decorative extras.
- Never depict Chinese police, public-security, traffic-police, special-police, law-enforcement, or other public-service uniforms in a cover. Police caps, police badges, police emblems, police epaulettes, police shoulder boards, police service numbers, and police-style uniforms are forbidden. If the plot needs an order-maintaining figure, use only a commercial security guard in a plain neutral security uniform with no government or police insignia.
- `scene_family`, `scene`, `main_action`, `composition`, and optional `key_prop` are fresh free creative text for the current title. Never select them from a reusable scene, action, layout, prop, or reaction candidate library.
- `visual_payoff` must express the strongest visible power shift, relationship reversal, or consequence. Do not turn title nouns directly into props; a prop may support the payoff but can never be the whole visual B explosion.
- If a location detail does not improve comprehension, emotional intensity, or realism, omit it. Do not invent decorative architecture, luxury dressing, lighting spectacle, or art-direction detail merely to sound professional.
- Use half-body framing by default so the image reads clearly on mobile.
- Main characters should be as large and readable as possible.
- Every visible person must be depicted as a Chinese person with clearly Chinese facial features and appearance, regardless of the target channel language or market. Do not use Indian, Southeast Asian, Middle Eastern, Western, or ambiguous facial features.
- Put this identity constraint in every actual image prompt in explicit English: `Chinese actors, Chinese facial features, East Asian appearance`.
- Select one provocative unresolved moment promised by the title and stage it as a believable frame from a real Chinese television drama. A minimal plot connection is enough; do not reveal the later explanation or ending.
- Do not use doors or vehicle doors as primary scene devices. Never build the scene, main action, actor interaction, or camera blocking around opening or closing a door, blocking, standing, waiting, or leaning at a doorway, entering or exiting through a vehicle door, gripping a car door, or confronting across a door. Freely create a fresh title-specific non-door scene and action without selecting from a replacement list. A distant closed door may remain incidental background architecture only when nobody interacts with it. This is a hard generation and validation requirement.
- Priority order is: readable faces, character relationship, one physical action, emotion, believable location, then zero or one ordinary plot-supported evidence prop.
- Prefer zero or one story-evidence prop. Two is the hard maximum. Do not stack documents, phones, rings, reports, screens, and symbolic objects to explain the full plot.
- The image must have a clear emotional conflict or reversal, be eye-catching, and improve click-through without turning into an artificial concept poster.
- The image must clearly reflect the title's marketing premise, not restore the literal full-plot outcome.
- The text on the image must be prominent and easy to notice.
- The 3 cover groups must not share the same main action.
- The 3 cover groups must not share the same scene.
- The 3 cover groups must not share the same environment.
- The 3 cover groups must use three mutually distinct `core_words` values. Unicode normalization, capitalization, and repeated whitespace do not make a repeated value different.
- Every `core_words` value must be one idiomatic native-language word or a natural two-word modifier-plus-head phrase. Never compress a natural three-word construction by deleting a required linker, postposition, case marker, or article, and never join two plot nouns mechanically. If the natural expression needs more than two words, choose a different plot-supported one- or two-word hook.
- Select core words by priority: specific relationship > shocking identity > concrete number > concrete consequence > abnormal action > abstract theme. Use an abstract theme only when no concise package-specific phrase is available. Never use a reusable multilingual core-word candidate library.
- Return `story_hook`, `scene_family`, `scene`, `main_action`, `key_prop`, `composition`, `palette`, and `lighting` for every group before the actual prompts.
- Across the three groups, `scene_family`, `main_action`, and natural camera blocking must be different. `key_prop`, `palette`, and `lighting` remain fingerprint metadata, but must follow the real scene and are never novelty quotas.
- When normalized input contains `visual_history`, use it to distinguish channel style from duplicated storytelling. Partial reuse of channel-level visual grammar is allowed across videos: character count, shot size, camera angle, placement logic, typography-layout logic, or scene type may each be similar.
- A single similar visual dimension is not narrative duplication. Do not force a new composition solely because a recent cover looks similar in one or several isolated visual dimensions.
- Do not reproduce the whole visual combination as a template. Rebuild the overall image for the current title instead of repeatedly combining the same character count, shot size, camera angle, placement, scene type, and typography layout.
- Treat a historical cover as a forbidden narrative duplicate only when its character relationship, primary action or reversal, key event or evidence prop, and core cover words form a substantially repeated complete concept. When several key visual dimensions and that narrative concept are both highly similar, actively separate the new design.
- Do not use a numeric similarity ratio or fingerprint-count quota for generation. The governing principle is: same channel style is allowed; the same template or complete visual story is not.
- The model prompt may contain only the highest-priority recent history sample
  for performance.
- When normalized input contains same-drama `creative_history`, a different language alone is not sufficient to make a duplicated complete narrative concept new. Local visual grammar may still be reused; organize the whole image around the current title and avoid copying the prior relationship + action/reversal + key event/prop + core-word combination. Do not invent technology or an implausible setting merely to escape history.
- Base every group on a different plausible title-linked physical event. Marketing amplification is allowed, but the location, bodies, action, and props must remain physically believable. Never default to the repeated `luxury mansion + standing confrontation + document/phone + dark brown/red/gold light` template.
- State clear spatial logic, one decisive physical action, natural body overlap, and enough location evidence to make the moment believable. Avoid motionless glamour-poster staging.
- Do not use named geometric poster formulas such as lightning-bolt, hourglass, crescent, sweeping-anchor, unfolding-fan, rail-switch, crossed-chute, descending-hand-chain, or shield-and-split composition.
- `camera_angle` must be exactly one of `eye-level`, `slightly low-angle`, `slightly high-angle`, `over-the-shoulder`, or `three-quarter view`. These are technical angle values, not reusable composition templates.
- Use natural location color with at most one accent color. Use one plausible primary light source plus only restrained fill or rim light justified by the location.
- The controller is the sole owner of the canonical global Style block in the final 4:5 prompt. `scene_prompt_4_5` describes only the specific scene, people, relationship, physical action, emotion, believable location, camera blocking, and location-specific light/color.
- Do not use `ultra sharp focus`, `crisp facial detail`, `crisp faces`, `strong/high micro-contrast`, `clean edges`, `sharp facial highlights`, or `mobile readability` as image-rendering instructions.
- Allow natural asymmetry, overlapping bodies, age-appropriate wrinkles, flyaway hair, and ordinary environmental texture. Avoid waxy skin, plastic beauty filters, muddy shadows, orange/brown casts, heavy haze, excessive bokeh, artificial glow, and empty luxury decoration.
- Never introduce holograms, futuristic scanners, glowing DNA devices, forensic display walls, transparent evidence machines, memory carousels, or other invented technology unless the source plot explicitly contains science fiction and the channel permits it.
- Keep `scene_prompt_4_5` concise, scene-specific, and free of repeated controller-owned blocks. Word count is audit evidence only: it has no minimum, maximum, target interval, rejection threshold, or retry trigger. Abnormal length must be investigated as duplicate assembly or system contamination, not treated as a creative failure.
- Record `real_drama_score`, prompt verbosity, prop density, lighting-description density, and overly designed staging as audit-only quality observations. They never reject content and never trigger a model retry.
- Hard-reject only explicit invented/futuristic visual technology and named AI-poster geometric compositions, including holograms, futuristic scanners, glowing DNA/tracking devices, and the named geometry patterns listed in the frozen rule source.
- For female-frequency channels, visual special effects are forbidden: no magic, aura, energy, lightning, particles, fire, explosion, holograms, fake glowing props, glowing eyes, lasers, or supernatural glow. Real sunlight, practical lamps, headlights, and real stage lights are allowed.
- For male-frequency dramas, if the drama involves costume, fantasy, cultivation, time-travel, or similar themes, restrained plot-supported visual effects may be shown.
- Resolve child presence independently from each accepted Find/title direction. Channel direction and drama name never force all three groups to add a child. A direction whose only child fact is not yet born is valid without a visible born child; only a direction that actually contains a born minor requires that real Chinese child to appear safely. A photograph, backpack, toy, silhouette, or adult-only implication is not a substitute when a born child is actually required.
- If children are present, never show child humiliation, child abuse, or similar harmful scenes.
- Children must always be shown fully clothed, safe, healthy, and supervised. Never show a child crying in distress, injured, restrained, threatened, kidnapped, sick, unconscious, endangered, isolated, or near weapons, fire, explosions, blood, or adult physical violence.
- A child may safely appear in a hospital, clinic, ward, waiting area, rehabilitation area, or normal examination setting. Never show the child undergoing a painful, invasive, dangerous, or harmful medical procedure.
- `daughter`, `son`, `girl`, or `boy` alone does not prove that a person is a minor. Prefer structured age/role facts; explicitly adult offspring are excluded from child checks. A risk state fails only when it actually applies to a verified minor. Adult fear, humiliation, tears, injury, or conflict in the same sentence/frame must not be attributed to a nearby safe child.
- For every required child group, use upstream `child_role` as a required safety fact and `safe_cover_scene` only as a reference safety implementation. The title's `visual_thesis` remains the scene priority.
- When a required minor is visible, do not combine that minor in the same image prompt with abandonment or humiliation directed at the child, hidden surveillance, coercive parenting, bedroom or bedside intimacy, police restraint/escort/control, paternity-evidence confrontation, or adult physical/coercive conflict. Express the click-driving reversal through adult status, posture, relationship, or consequence while the child stays calm, protected, and clearly supervised. Keep every required child; do not replace the title event with an unrelated peaceful activity.
- The controller must repeat the exact per-group upstream title, title translation,
  visual thesis, and child role at the end of the initial generation prompt and
  every retry prompt. It may include `safe_cover_scene` only as a reference, never
  as a mandatory scene script. Correcting typography,
  typography, realism, collision, or another group must never delete a
  previously required visible child or regress another already-passing hard
  rule.
- Every retry retains a compact all-group checklist: exact upstream mapping,
  concise non-repetitive `scene_prompt_4_5`, no physical or threatened violence,
  no controller-owned Style or Typography text, distinct core words, and—on
  female-frequency tasks—zero visual special effects.
- All covers forbid physical beating and threatened beating: no slap, punch, kick, choke, dragging, pushing someone down, stomping, weapons, blood, wounds, or raised fist about to strike. Freely create a title-specific nonviolent action; do not choose a replacement from a stock action list.
- Covers must not be overly violent or bloody.
- Covers must not contain sexual content.
- Final result must avoid triggering child/youth depiction violations.

## Output Contract

Return structured data only. The controller validates it, writes canonical JSON first,
and then renders Markdown for display. The model must not write files, workflow state,
or Feishu data.

Canonical files owned by the controller:

```text
04_封面提示词.json
04_封面提示词.md
```

For each title the model returns one `scene_prompt_4_5` and one short `outpaint_environment`. The controller creates the final `prompt_4_5` by appending one canonical Style block and one canonical Typography block, and creates the final `prompt_16_9` as the fixed outpaint execution contract plus `outpaint_environment`.
- The controller compiles one compact `generation_constraints` block from this frozen rule source plus title metadata and `visual_thesis`; generation and validation therefore share the same authority. Do not add another AI planning stage.

The controller owns the final audit. Word count, real-drama score, prop density, lighting-description density, and overly designed staging are recorded as audit evidence only and never reject or retry content. Explicit invented/futuristic visual technology and named AI-poster geometric compositions remain hard failures. Historical uniqueness never overrides plot truth or scene plausibility.

The prompt manifest must carry `generation_mode=image_to_image_outpaint`, `depends_on_task_id`, `source_image_task_id`, `mask_policy=side_bands_only`, and `center_restore_required=true` for every 16:9 task. This is a generation prerequisite, not a validation hint.

Reject and rewrite the cover prompt before finalizing if any actual `4:5` or `16:9` image prompt uses Chinese descriptive wording instead of English descriptive wording.

Canonical JSON shape:

```json
{
  "section": "covers",
  "results": [
    {
      "search_result_index": 1,
      "source_block_label": "...",
      "result_id": "...",
      "video_id": "...",
      "drama_name": "...",
      "titles": [
        {
          "title_index": 1,
          "title": "...",
          "title_translation": "...",
          "core_words": "...",
          "core_words_translation": "...",
          "visual_thesis": "...",
          "visual_payoff": "...",
          "single_continuous_moment": true,
          "single_physical_location": true,
          "temporal_montage": false,
          "required_characters": ["..."],
          "visible_adult_count": 2,
          "visible_child_count": 0,
          "removed_optional_characters": "...",
          "scene_choice_reason": "...",
          "action_choice_reason": "...",
          "prop_role": "none",
          "camera_angle": "eye-level",
          "core_words_category": "specific_relationship",
          "core_words_selection_reason": "...",
          "story_hook": "...",
          "scene_family": "...",
          "scene": "...",
          "main_action": "...",
          "key_prop": "...",
          "composition": "...",
          "palette": "...",
          "lighting": "...",
          "scene_prompt_4_5": "...",
          "outpaint_environment": "..."
        }
      ]
    }
  ]
}
```
