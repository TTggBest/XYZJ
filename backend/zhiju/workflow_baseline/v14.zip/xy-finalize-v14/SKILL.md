---
name: xy-finalize-v14
description: Finalize one Xiaoyu drama package after review by rebuilding 运营包.md from the accepted canonical JSON and rendered step files.
---

# XY Finalize

## Purpose

Close one drama package cleanly.

This skill does one fixed action:

1. Rebuild `运营包.md` from the latest step files.

It also marks the package `workflow_state.json` as finalized.

## Command

Preferred:

```text
xy-finalize 剧名 YYYYMMDDHH
```

If the same drama+slot may exist in multiple channels, pass the channel too:

```text
xy-finalize 剧名 YYYYMMDDHH --channel 本地昵称
xy-finalize 剧名 YYYYMMDDHH --channel 频道名
```

## Resolve Rule

Use:

```text
运营/工作流运营/公用/频道注册表.json
```

If `--channel` is given, resolve the package inside that channel's `剧目/`.

If `--channel` is omitted, scan registered channels for exactly one matching:

```text
剧名_YYYYMMDDHH
```

If zero or multiple matches exist, stop and report it.

## Scripts

Prefer the bundled wrapper:

```text
scripts/finalize_package.py "剧名" YYYYMMDDHH --root "运营/工作流运营"
scripts/finalize_package.py "剧名" YYYYMMDDHH --root "运营/工作流运营" --channel "🔥频道名-孟加拉-女频-甜宠"
```

This wrapper calls:

```text
xy-pack/scripts/assemble_package.py
```

核心词统计已从当前生产流程移除，不调用、不更新。

## Safety

- Do not edit `频道名_频道分析报告.md`.
- If required step files are missing, stop and report which ones are missing.
