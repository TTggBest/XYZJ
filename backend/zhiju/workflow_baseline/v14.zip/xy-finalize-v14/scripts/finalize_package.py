#!/usr/bin/env python3
import argparse
import json
import subprocess
import sys
from pathlib import Path


HELPER_DIR = Path(__file__).resolve().parents[2] / "xy-channels" / "scripts"
if str(HELPER_DIR) not in sys.path:
    sys.path.append(str(HELPER_DIR))

from channel_registry import ensure_registry
from channel_registry import resolve_channel


def locate_package(root: Path, drama_name: str, slot: str, channel_query: str = "") -> Path:
    package_name = f"{drama_name}_{slot}"
    if channel_query.strip():
        row = resolve_channel(root, channel_query.strip())
        package_path = Path(row["drama_dir"]) / package_name
        if package_path.exists():
            return package_path
        raise SystemExit(f"Package not found: {package_path}")

    matches = []
    for row in ensure_registry(root):
        package_path = Path(row["drama_dir"]) / package_name
        if package_path.exists():
            matches.append(package_path)
    if not matches:
        raise SystemExit(f"Package not found: {package_name}")
    if len(matches) > 1:
        joined = ", ".join(str(path) for path in matches)
        raise SystemExit(f"Ambiguous package match: {joined}")
    return matches[0]


def run_script(script: Path, package_path: Path) -> dict:
    result = subprocess.run(
        [sys.executable, str(script), str(package_path)],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise SystemExit(result.stderr.strip() or result.stdout.strip())
    return json.loads(result.stdout)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("drama_name")
    parser.add_argument("slot")
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--channel", default="")
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    package_path = locate_package(root, args.drama_name.strip(), args.slot.strip(), args.channel.strip())

    base_dir = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts"
    assemble_payload = run_script(base_dir / "assemble_package.py", package_path)

    print(
        json.dumps(
            {
                "package_path": str(package_path),
                "assemble": assemble_payload,
                "finalize": {"core_word_statistics": "disabled"},
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
