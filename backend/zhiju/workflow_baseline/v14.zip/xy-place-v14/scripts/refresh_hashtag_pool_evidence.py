#!/usr/bin/env python3
"""Build evidence-backed YouTube hashtag pools for active Xiaoyu markets."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import json
import math
from pathlib import Path
import re
import time
import unicodedata
import os
from urllib.parse import quote_plus
from urllib.request import Request, urlopen


WORKSPACE = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube")
DEFAULT_REGISTRY = WORKSPACE / "运营/工作流运营/公用/频道注册表.json"
DEFAULT_OUTPUT = Path(__file__).resolve().parents[1] / "rules" / "hashtag_pool_evidence.json"
USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
MANDATORY = {"#cdrama", "#chinesedrama", "#shortdrama"}
MIN_POOL_VIDEOS = 1_000
MIN_POOL_CHANNELS = 100
MIN_AUDIENCE_MATCH = 0.50
MIN_DRAMA_AUDIENCE_MATCH = 0.50

DRAMA_AUDIENCE_SIGNALS = (
    "chinese drama", "short drama", "mini drama", "minidrama", "cdrama", "full drama",
    "drama china", "drama chino", "drama chinês", "drama chines", "китайская дорама",
    "дорама", "çin dizisi", "kısa dizi", "mini dizi", "aşk dizisi", "مسلسل", "دراما",
    "চাইনিজ ড্রামা", "বাংলা ডাব", "bangla dubbed", "hindi dubbed", "चीनी ड्रामा",
    "tagalog dubbed", "filipino drama", "series china", "series chinas", "doramachinês",
    "ceo", "billionaire", "milliarder", "milyarder", "herdeira", "herdeiro", "cinderela",
    "suaminya", "istrinya", "menikahi", "asawa", "mayaman", "anak ng mayaman",
    "episode", "episodio", "episódio", "bölüm", "серия",
)
NON_DRAMA_AUDIENCE_SIGNALS = (
    "official music video", "official audio", "lyrics", "song", "music", "lagu", "şarkı",
    "klip", "akustik", "vlog", "vlogger", "youtuber", "news", "নিউজ",
    "lecture", "motivational", "podcast", "compilation songs",
)
MISLEADING_POOL_TAG_FRAGMENTS = ("kdrama", "koreandrama", "drakor", "dramakorea")


SEARCH_QUERIES = {
    "俄语": ["китайская короткая дорама русская озвучка полностью", "китайская дорама на русском полный фильм"],
    "印地": ["hindi dubbed chinese short drama full", "chinese drama hindi dubbed full movie"],
    "印尼": ["drama china dubbing indonesia full", "short drama china bahasa indonesia lengkap"],
    "土耳其": ["çin kısa dizisi türkçe dublaj full", "çin dizisi türkçe dublaj tamamı"],
    "孟加拉": ["bangla dubbed chinese short drama full", "chinese drama bangla dubbed full movie"],
    "巴葡": ["drama chinês dublado português completo", "minissérie chinesa dublada completa"],
    "英语": ["chinese short drama english dubbed full", "chinese mini drama english dubbed complete"],
    "菲律宾": ["tagalog dubbed chinese short drama full", "chinese drama tagalog dubbed full movie"],
    "西班牙": ["drama chino doblado español completo", "miniserie china doblada completa"],
    "阿拉伯语": ["مسلسل صيني قصير مدبلج عربي كامل", "دراما صينية مدبلجة بالعربية كاملة"],
}


LANGUAGE_SIGNALS = {
    "俄语": {"ranges": ((0x0400, 0x04FF),), "hints": ("русск", "дорам", "озвуч", "полностью")},
    "印地": {"ranges": ((0x0900, 0x097F),), "hints": ("hindi", "हिंदी", "dubbed in hindi")},
    "印尼": {"ranges": (), "hints": ("bahasa indonesia", "dubbing indonesia", "drama china", "sub indo", "mereka", "ternyata", "kisah", "cinta", "wanita", "pria", "suaminya", "istrinya", "menikahi", "gadis")},
    "土耳其": {"ranges": (), "hints": ("türkçe", "turkce", "dublaj", "çin dizisi", "aşk", "kadın", "adam", "evlilik", "intikam", "zengin")},
    "孟加拉": {"ranges": ((0x0980, 0x09FF),), "hints": ("bangla", "bengali", "বাংলা")},
    "巴葡": {"ranges": (), "hints": ("português", "portugues", "dublado", "drama chinês", "drama chines", "ela", "marido", "filha", "família", "vingança", "casamento")},
    "英语": {"ranges": (), "hints": ("english dubbed", "english sub", "full drama", "complete drama", " she ", " he ", "the ", "love", "family", "marriage", "ceo")},
    "菲律宾": {"ranges": (), "hints": ("tagalog", "filipino", "dubbed tagalog", "buong", "ang ", "siya", "anak", "asawa", "mayaman", "pag-ibig")},
    "西班牙": {"ranges": (), "hints": ("español", "espanol", "doblado", "drama chino", "completo", "ella", "esposo", "hija", "familia", "venganza", "película")},
    "阿拉伯语": {"ranges": ((0x0600, 0x06FF),), "hints": ("عربي", "بالعربية", "مدبلج", "مسلسل صيني")},
}


def parse_count(text: str) -> int:
    match = re.search(r"([0-9][0-9,]*(?:\.[0-9]+)?)\s*([KMB])?", str(text), flags=re.I)
    if not match:
        return 0
    value = float(match.group(1).replace(",", ""))
    multiplier = {"K": 1_000, "M": 1_000_000, "B": 1_000_000_000}.get(
        str(match.group(2) or "").upper(), 1
    )
    return int(value * multiplier)


def _script_ratio(text: str, ranges: tuple[tuple[int, int], ...]) -> float:
    letters = [char for char in text if unicodedata.category(char).startswith("L")]
    if not letters or not ranges:
        return 0.0
    hits = sum(any(start <= ord(char) <= end for start, end in ranges) for char in letters)
    return hits / len(letters)


def text_matches_language(language: str, text: str) -> bool:
    rule = LANGUAGE_SIGNALS.get(language, {})
    normalized = unicodedata.normalize("NFKC", str(text)).casefold()
    if any(hint.casefold() in normalized for hint in rule.get("hints", ())):
        return True
    return _script_ratio(normalized, tuple(rule.get("ranges", ()))) >= 0.18


def audience_match_ratio(language: str, sample_titles: list[str]) -> float:
    titles = [str(value).strip() for value in sample_titles if str(value).strip()]
    if not titles:
        return 0.0
    return sum(text_matches_language(language, title) for title in titles) / len(titles)


def drama_audience_match_ratio(sample_titles: list[str]) -> float:
    titles = [unicodedata.normalize("NFKC", str(value)).casefold() for value in sample_titles if str(value).strip()]
    if not titles:
        return 0.0
    matches = 0
    for title in titles:
        positive = any(signal.casefold() in title for signal in DRAMA_AUDIENCE_SIGNALS)
        negative = any(signal.casefold() in title for signal in NON_DRAMA_AUDIENCE_SIGNALS)
        matches += bool(positive and not negative)
    return matches / len(titles)


def evaluate_candidate(
    language: str,
    hashtag: str,
    pool_video_count: int,
    pool_channel_count: int,
    sample_titles: list[str],
) -> dict:
    ratio = audience_match_ratio(language, sample_titles)
    drama_ratio = drama_audience_match_ratio(sample_titles)
    normalized_tag = unicodedata.normalize("NFKC", hashtag).casefold()
    misleading = any(fragment in normalized_tag for fragment in MISLEADING_POOL_TAG_FRAGMENTS)
    return {
        "hashtag": hashtag,
        "pool_video_count": int(pool_video_count),
        "pool_channel_count": int(pool_channel_count),
        "audience_match_ratio": round(ratio, 4),
        "drama_audience_match_ratio": round(drama_ratio, 4),
        "sample_titles": sample_titles[:8],
        "ineligible_reason": "misleading_non_chinese_drama_pool" if misleading else "",
        "eligible": bool(
            int(pool_video_count) >= MIN_POOL_VIDEOS
            and int(pool_channel_count) >= MIN_POOL_CHANNELS
            and ratio >= MIN_AUDIENCE_MATCH
            and drama_ratio >= MIN_DRAMA_AUDIENCE_MATCH
            and not misleading
        ),
    }


def fetch_html(url: str, timeout: int = 20) -> str:
    last_error: Exception | None = None
    for attempt in range(3):
        request = Request(url, headers={"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.8"})
        try:
            with urlopen(request, timeout=timeout) as response:
                return response.read().decode("utf-8", "replace")
        except Exception as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    assert last_error is not None
    raise last_error


def extract_initial_json(html: str, markers: tuple[str, ...]) -> dict:
    decoder = json.JSONDecoder()
    for marker in markers:
        position = html.find(marker)
        if position < 0:
            continue
        try:
            value, _ = decoder.raw_decode(html[position + len(marker):])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    return {}


def _runs_text(value: dict) -> str:
    if not isinstance(value, dict):
        return ""
    if isinstance(value.get("simpleText"), str):
        return value["simpleText"]
    return "".join(str(run.get("text") or "") for run in value.get("runs", []) if isinstance(run, dict))


def search_videos(query: str, limit: int = 12) -> list[dict[str, str]]:
    html = fetch_html("https://www.youtube.com/results?search_query=" + quote_plus(query))
    data = extract_initial_json(html, ("var ytInitialData = ", "ytInitialData = "))
    rows: list[dict[str, str]] = []

    def walk(value):
        if len(rows) >= limit:
            return
        if isinstance(value, dict):
            renderer = value.get("videoRenderer")
            if isinstance(renderer, dict) and renderer.get("videoId"):
                rows.append({
                    "video_id": str(renderer.get("videoId")),
                    "title": _runs_text(renderer.get("title", {})),
                    "channel": _runs_text(renderer.get("ownerText", {})),
                })
                return
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(data)
    return rows[:limit]


def video_description(video_id: str) -> str:
    html = fetch_html("https://www.youtube.com/watch?v=" + video_id)
    data = extract_initial_json(
        html,
        ("var ytInitialPlayerResponse = ", "ytInitialPlayerResponse = "),
    )
    return str(data.get("videoDetails", {}).get("shortDescription") or "")


def extract_hashtags(text: str) -> list[str]:
    values = []
    for raw in re.findall(r"#[^\s#]+", str(text), flags=re.UNICODE):
        tag = raw.rstrip(".,!?;:，。！？；：、|()[]{}<>\"'“”‘’")
        if len(tag) < 3 or tag.casefold() in MANDATORY:
            continue
        if tag not in values:
            values.append(tag)
    return values


def hashtag_page_evidence(hashtag: str) -> tuple[int, int, list[str]]:
    slug = hashtag.lstrip("#")
    html = fetch_html("https://www.youtube.com/hashtag/" + quote_plus(slug))
    metadata = re.search(r'"content":"([0-9.,KMB]+ videos [^"\\]* [0-9.,KMB]+ channels)"', html, flags=re.I)
    counts = metadata.group(1) if metadata else ""
    parts = re.split(r"\s*[•·]\s*", counts)
    videos = parse_count(parts[0]) if parts else 0
    channels = parse_count(parts[1]) if len(parts) > 1 else 0
    data = extract_initial_json(html, ("var ytInitialData = ", "ytInitialData = "))
    titles: list[str] = []

    def walk(value):
        if len(titles) >= 12:
            return
        if isinstance(value, dict):
            renderer = value.get("videoRenderer")
            if isinstance(renderer, dict):
                title = _runs_text(renderer.get("title", {})).strip()
                if title and title not in titles:
                    titles.append(title)
            lockup = value.get("lockupMetadataViewModel")
            if isinstance(lockup, dict):
                title = str(lockup.get("title", {}).get("content") or "").strip()
                if title and title not in titles:
                    titles.append(title)
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(data)
    return videos, channels, titles[:12]


def build_language_pool(language: str, own_channel_names: set[str]) -> dict:
    queries = SEARCH_QUERIES.get(language, [])
    videos: dict[str, dict[str, str]] = {}
    for query in queries:
        for row in search_videos(query):
            if row.get("channel") in own_channel_names:
                continue
            if not text_matches_language(language, f"{row.get('title', '')} {query}"):
                continue
            videos.setdefault(row["video_id"], row)

    tag_sources: dict[str, set[str]] = {}
    with ThreadPoolExecutor(max_workers=6) as executor:
        futures = {executor.submit(video_description, video_id): video_id for video_id in videos}
        for future in as_completed(futures):
            video_id = futures[future]
            try:
                description = future.result()
            except Exception:
                continue
            row = videos[video_id]
            if not text_matches_language(language, f"{row.get('title', '')} {description}"):
                continue
            for hashtag in extract_hashtags(description):
                tag_sources.setdefault(hashtag, set()).add(row.get("channel") or video_id)

    ranked = sorted(tag_sources, key=lambda tag: (-len(tag_sources[tag]), tag.casefold()))[:30]
    candidates: list[dict] = []
    with ThreadPoolExecutor(max_workers=6) as executor:
        futures = {executor.submit(hashtag_page_evidence, tag): tag for tag in ranked}
        for future in as_completed(futures):
            tag = futures[future]
            try:
                video_count, channel_count, titles = future.result()
            except Exception:
                continue
            candidate = evaluate_candidate(language, tag, video_count, channel_count, titles)
            candidate["matching_search_source_channels"] = len(tag_sources[tag])
            candidate["youtube_hashtag_url"] = "https://www.youtube.com/hashtag/" + quote_plus(tag.lstrip("#"))
            candidate["score"] = round(
                candidate["audience_match_ratio"] * 100
                + math.log10(max(video_count, 1)) * 3
                + math.log10(max(channel_count, 1)) * 2
                + min(len(tag_sources[tag]), 5),
                3,
            )
            candidates.append(candidate)
    candidates.sort(key=lambda row: (-bool(row["eligible"]), -float(row["score"]), row["hashtag"].casefold()))
    return {"queries": queries, "candidates": candidates}


def build_evidence(registry_path: Path) -> dict:
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    active_languages = sorted({str(row.get("language") or "") for row in registry.get("channels", []) if row.get("language")})
    own_channels = {str(row.get("channel_name") or "") for row in registry.get("channels", [])}
    languages = {language: build_language_pool(language, own_channels) for language in active_languages}
    return {
        "version": 1,
        "verified_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "source": "youtube_public_search_and_hashtag_pages",
        "thresholds": {
            "minimum_pool_videos": MIN_POOL_VIDEOS,
            "minimum_pool_channels": MIN_POOL_CHANNELS,
            "minimum_audience_match_ratio": MIN_AUDIENCE_MATCH,
            "minimum_drama_audience_match_ratio": MIN_DRAMA_AUDIENCE_MATCH,
        },
        "languages": languages,
    }


def _eligible_count(language_pool: dict) -> int:
    return sum(
        bool(row.get("eligible"))
        for row in language_pool.get("candidates", [])
        if isinstance(row, dict)
    )


def merge_evidence_payloads(live: dict, fallbacks: list[dict]) -> dict:
    """Keep the newest successful per-language collection window after transient 429s."""
    payloads = [live, *fallbacks]
    all_languages = sorted({
        language
        for payload in payloads
        for language in (payload.get("languages") or {})
    })
    merged = dict(live)
    merged["source"] = "youtube_public_search_and_hashtag_pages_per_language_verified_windows"
    merged["collection_windows"] = sorted({
        str(payload.get("verified_at") or "") for payload in payloads if payload.get("verified_at")
    })
    merged["languages"] = {}
    for language in all_languages:
        choices = []
        for payload in payloads:
            pool = (payload.get("languages") or {}).get(language)
            if isinstance(pool, dict):
                pool = dict(pool)
                reevaluated = [
                    {
                        **row,
                        **evaluate_candidate(
                            language,
                            str(row.get("hashtag") or ""),
                            int(row.get("pool_video_count") or 0),
                            int(row.get("pool_channel_count") or 0),
                            list(row.get("sample_titles") or []),
                        ),
                    }
                    for row in pool.get("candidates", []) if isinstance(row, dict)
                ]
                deduplicated = {}
                for row in reevaluated:
                    key = unicodedata.normalize("NFKC", str(row.get("hashtag") or "")).casefold()
                    existing = deduplicated.get(key)
                    if existing is None or float(row.get("score") or 0) > float(existing.get("score") or 0):
                        deduplicated[key] = row
                pool["candidates"] = list(deduplicated.values())
                choices.append((_eligible_count(pool), str(payload.get("verified_at") or ""), pool))
        _, verified_at, selected = max(choices, key=lambda row: (row[0], row[1]))
        selected = dict(selected)
        selected["evidence_verified_at"] = verified_at
        merged["languages"][language] = selected
    return merged


def write_verified_evidence(payload: dict, output: Path, required_languages: set[str]) -> None:
    languages = payload.get("languages") if isinstance(payload, dict) else None
    insufficient = {
        language: _eligible_count((languages or {}).get(language, {}))
        for language in sorted(required_languages)
        if _eligible_count((languages or {}).get(language, {})) < 1
    }
    if insufficient:
        raise RuntimeError(
            "insufficient_verified_hashtag_evidence:" + json.dumps(insufficient, ensure_ascii=False, sort_keys=True)
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + f".tmp.{os.getpid()}")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(output)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--registry", default=str(DEFAULT_REGISTRY))
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument(
        "--fallback", action="append", default=[],
        help="Previously collected evidence window used only for languages whose live refresh is incomplete",
    )
    parser.add_argument(
        "--reuse-fallback-only", action="store_true",
        help="Rebuild from already verified collection windows without issuing new YouTube requests",
    )
    args = parser.parse_args()
    registry_path = Path(args.registry).expanduser().resolve()
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    required_languages = {
        str(row.get("language") or "") for row in registry.get("channels", []) if row.get("language")
    }
    fallbacks = [
        json.loads(Path(path).expanduser().resolve().read_text(encoding="utf-8"))
        for path in args.fallback
    ]
    if args.reuse_fallback_only:
        if not fallbacks:
            raise RuntimeError("reuse_fallback_only_requires_fallback")
        live = {
            "version": 1,
            "verified_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "source": "no_live_refresh",
            "thresholds": {
                "minimum_pool_videos": MIN_POOL_VIDEOS,
                "minimum_pool_channels": MIN_POOL_CHANNELS,
                "minimum_audience_match_ratio": MIN_AUDIENCE_MATCH,
                "minimum_drama_audience_match_ratio": MIN_DRAMA_AUDIENCE_MATCH,
            },
            "languages": {},
        }
    else:
        live = build_evidence(registry_path)
    payload = merge_evidence_payloads(live, fallbacks)
    output = Path(args.output).expanduser().resolve()
    write_verified_evidence(payload, output, required_languages)
    summary = {
        language: {
            "eligible": sum(bool(row.get("eligible")) for row in value.get("candidates", [])),
            "total": len(value.get("candidates", [])),
        }
        for language, value in payload["languages"].items()
    }
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
