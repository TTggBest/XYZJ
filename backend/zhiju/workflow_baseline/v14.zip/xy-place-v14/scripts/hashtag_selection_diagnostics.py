#!/usr/bin/env python3
"""Report V14 hashtag overlap and explicit drama coverage without gating production."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def _tags(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return list(dict.fromkeys(tag for tag in value if isinstance(tag, str) and tag.startswith("#")))


def analyze_records(records: list[dict[str, Any]]) -> dict[str, Any]:
    history: dict[str, list[set[str]]] = {}
    observations: list[dict[str, Any]] = []

    for record in records:
        channel = str(record.get("channel") or "")
        selected = _tags(record.get("selected_additional_tags"))
        selected_set = set(selected)
        prior = history.get(channel, [])
        overlaps = [len(selected_set & earlier) for earlier in prior]

        explicit_relevance = record.get("drama_relevant_tags")
        if isinstance(explicit_relevance, list):
            relevant = set(_tags(explicit_relevance))
            coverage_tags = [tag for tag in selected if tag in relevant]
            coverage_count: int | None = len(coverage_tags)
            coverage_status = "evaluated_from_explicit_relevance_evidence"
        else:
            coverage_tags = []
            coverage_count = None
            coverage_status = "not_evaluated_without_explicit_relevance_evidence"

        observations.append(
            {
                "channel": channel,
                "video_id": str(record.get("video_id") or ""),
                "selected_additional_tags": selected,
                "prior_same_channel_count": len(prior),
                "mean_exact_overlap_count": round(sum(overlaps) / len(overlaps), 2) if overlaps else None,
                "drama_coverage_count": coverage_count,
                "drama_coverage_tags": coverage_tags,
                "drama_coverage_status": coverage_status,
            }
        )
        history.setdefault(channel, []).append(selected_set)

    return {
        "report_type": "v14_hashtag_selection_observation",
        "blocking": False,
        "records": observations,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="JSON list, or object containing a records list")
    parser.add_argument("--output", type=Path, help="optional report path; stdout when omitted")
    args = parser.parse_args()

    payload = json.loads(args.input.read_text(encoding="utf-8"))
    records = payload.get("records") if isinstance(payload, dict) else payload
    if not isinstance(records, list) or not all(isinstance(row, dict) for row in records):
        raise SystemExit("input must be a JSON list of records or an object with a records list")

    rendered = json.dumps(analyze_records(records), ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
