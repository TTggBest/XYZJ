---
name: xy-place-v14
description: Generate the drama description, Chinese translation, and best matching playlist recommendation for the current Xiaoyu short-drama package. Use after plot summary is available.
---

# XY Place

## Purpose

This step only does these things:

- generate the description
- generate the Chinese translation of the description
- choose the best matching playlist
- provide the playlist URL

It does not search plot, does not generate titles, does not generate covers, and does not generate community image/copy.

## Inputs

In deterministic batch mode, the controller supplies the normalized contents of:

```text
01_搜索资料.md
频道名_生成规范.md
```

If the current channel has playlist information inside its generation brief or synced channel data, use that playlist information.

## Rules

- Same-drama `creative_history` is negative-reference material only. Use a different opening premise, emotional emphasis, reveal order, and payoff framing from every other channel; never translate or paraphrase another package.
- Return `opening_hook_type`, `payoff_hook_type`, and a concrete Chinese `editorial_anchor` so the controller can reject cross-channel direction reuse.

- Generate the description from the plot summary and the current channel generation brief.
- Open with one concrete conflict, abnormal situation, identity mismatch, or relationship anomaly. Use only the strongest click entry and do not summarize the whole drama. Do not stack several betrayals, props, or consequences into the opening sentence; move secondary facts into the minimum background only when needed.
- Continue in two to four natural paragraphs whose length, order, and transitions follow the current plot and target language rather than a fixed template. Include only the relationship and background needed to understand the conflict.
- Use exactly one concrete mid-story event as the escalation. State who acted, what specific anomaly appeared, and whose judgment, relationship, or position changed directly because of it. Do not stack a second independent escalation event.
- Do not use the final identity reveal, final parentage confirmation, villain's final punishment, final reunion, proposal, wedding, inheritance result, or other ending climax as the escalation. Leave at most one plot-specific unresolved question or a non-question suspense statement. Name the relevant character instead of using a vague stranger, woman, man, mother, or person when the verified name is available and clearer.
- Before drafting, choose one precise current-drama `editorial_anchor`. Use `editorial_anchor` as the sole sentence-selection center: every background sentence must be necessary to understand it, and delete a sentence when removing it does not reduce understanding of that anchor. The final suspense must directly close the loop with the opening misunderstanding or follow the immediate unresolved consequence of the selected escalation; it must not open a new abstract question or switch to another plot line.
- Before returning JSON, silently reread and rewrite the body inside this same model call. Keep one spelling for each person, preserve narrator-versus-character knowledge, keep causes before effects, replace translated source-language logic with native target-language collocation, and make the final sentence understandable on its first reading. This is internal single-call editing, not a second model call or a semantic Validator.
- Add SEO information only when the target-language version, Chinese-drama identity, or one or two essential genre terms are not already clear, and integrate it naturally into an existing paragraph. Never place a blunt standalone genre declaration after the suspense, use a fixed "if you like A/B/C, watch to the end" sentence, or output a keyword list.
- Before finalizing, remove generic AI phrases, repeated facts, report-like headings, plot-highlight lists, story-type lists, mechanical timelines, and any sentence whose deletion would not reduce comprehension or suspense. Do not expand the title line by line into a synopsis.
- This remains a free-body generation and self-check preference, not a new Validator rule.
- The description must follow the current channel style and recommendation direction.
- For registered languages that do not use Han characters, the public target-language description must contain no Chinese characters. Japanese keeps its legitimate kanji. Chinese review translation fields remain allowed and non-blocking; a hashtag-only line remains governed by the exact channel whitelist.
- The description must match the drama itself and must not become a generic reusable template.
- If plot summary is available, use plot summary first.
- If plot summary is weak, use the Chinese drama name or alias together with the current channel generation brief.
- Choose the best matching playlist for this drama from the current channel's available playlists.
- Keep that best match in the structured `playlist` and `url` fields, but the public description must list every playlist registered for the current channel. Show the best match first, then every remaining exact playlist name and viewer-facing URL. Never omit a registered playlist.
- Do not invent playlist names.
- Do not invent playlist URLs.
- Playlist links in public descriptions must use viewer-facing `https://www.youtube.com/playlist?list=PLAYLIST_ID` URLs. Never output `studio.youtube.com` management links.
- Translate every structural label into the channel language. Outside an English channel, do not leave English labels such as `Today’s story includes:`, `Story type:`, `For more stories like this, watch this playlist:`, or `More great playlists:`.
- In V14, the compact footer is controller-owned fixed asset data selected by the registered channel language. The public footer contains only the exact combined subscribe-and-share CTA line and disclaimer lines. The combined CTA uses `🔔` for subscription guidance and `🙏` for share guidance. The model must not create, translate, paraphrase, or replace them. Legacy welcome lines, channel introductions, and generic comment questions are not public output.
- If the registered language has no exact fixed asset, fail closed; never fall back to English.
- Hashtags use the exact current channel as the only routing key. Do not route by language and do not borrow from another channel, including another channel in the same language.
- Output exactly 12 hashtags. Place `#cdrama` exactly once at position 3. Select the other exactly 11 tags from `channel_hashtag_whitelist.additional_candidates`; `#ChineseDrama` and `#ShortDrama` are not mandatory.
- Keep the existing public-tag order. Within the exact current-channel whitelist, use target-market audience-entry candidates first, then channel-history candidates, then current-drama-specific candidates, and finally cross-market generic candidates. This is a soft supply and selection priority, not a fixed quota: current-drama relevance still decides which exact 9 tags are selected, and no tier has a required count.
- First remove candidates that do not fit the current drama. At least one of positions 1 and 2 must come from `channel_hashtag_whitelist.target_language_tags`. Target-language qualification is owned only by this pre-registered exact-channel asset; the model must not infer that an unregistered mixed, transliterated, English, or other tag qualifies. Never sacrifice current-drama relevance elsewhere or impose category quotas. This is a generation structure rule and model self-check, not a new Schema field or a general semantic scoring gate.
- Cross-market generic tags are fallback coverage and must not dominate when eligible market-, channel-, or drama-specific candidates fit the current drama.
- Hashtags improve metadata fit; do not treat any single hashtag as an independent cause of recommendation traffic.
- Never invent, translate, concatenate, respell, change case, or otherwise modify a hashtag. A missing channel whitelist or an insufficient whitelist is a system error before the content model; never fall back to a language pool or generated tag.
- The hashtag line is final YouTube plain text, not Markdown source. Copy every selected hashtag character-for-character from the channel whitelist. Never insert a backslash before `_` or any other hashtag character; for example, output `#دراما_صينية`, never `#دراما\_صينية`.
- If the channel has no clear perfect playlist, choose the closest existing playlist.
- Never provide a playlist recommendation reason, plot-match explanation, SEO explanation, playlist summary, or any sentence after a playlist URL. The controller rebuilds the public playlist block deterministically from the selected registered playlist and the registered channel order.
- The Chinese `translation` and `channel_theme_phrase_translation` fields are review aids only. Provide useful Chinese review text when practical, but blank, imperfect, differently worded, or missing theme keywords in those review fields must never block, retry, or reject an otherwise valid target-language description.
- Validate the public description's objective contract: exact playlist assets, hashtags, fixed footer, language, links, and required structure. Channel-theme meaning and the quality of `channel_theme_phrase` remain generation/self-check responsibilities; a deterministic Validator must not accept or reject them by keyword matching. Never use Chinese review translations as semantic proof for production fields.
- Keep the final result focused on:
  - description
  - playlist
  - translation
- When minors appear, keep adult wrongdoing and child-safe facts in separate sentences. Do not describe a minor as the direct target of abandonment, humiliation, hostile surveillance, coercive parenting, police restraint/control, adult confrontation, or bedroom/bedside intimacy. Preserve the adult betrayal, reversal, punishment, and payoff; keep the child as a protected relationship, identity, reunion, or family anchor. Do not omit verified children or soften the main hook.

## Description Template

Use this production structure. The model writes the natural free body and selects hashtags and the primary playlist; the controller owns the playlist block and compact fixed footer:

```text
🔥 [一句具体冲突、反常情境、身份错位或荒诞关系；只选一个最强点击入口]

[2—4个自然段：必要人物关系与背景 → 一个中前段具体升级事件 → 最多一个不剧透的悬念]

[可选：仅在正文尚未自然包含必要搜索信息时，补充一句自然的目标语言版本、Chinese drama识别或1—2个类型词]

[共12个：第3位固定为 #cdrama 且只出现一次；其余11个只能从当前频道 channel_hashtag_whitelist.additional_candidates 中按当前剧情选择；前两位至少1个必须来自预登记的 channel_hashtag_whitelist.target_language_tags；不得跨频道、自造或改写]

👇 更多同类型故事请看这个播放列表：
[播放列表名称，频道语言] 👉
[播放列表链接]

📌 更多精彩播放列表：
1. [播放列表名称，频道语言] 👉
[播放列表链接]

2. [播放列表名称，频道语言] 👉
[播放列表链接]

3. [播放列表名称，频道语言] 👉
[播放列表链接]

[如果还有更多播放列表，继续按 4、5、6... 列出，直到当前频道的剩余播放列表全部列完]

🔔 [Controller原样输出当前语言固定“订阅 + 分享”合并CTA]

⚠️ [Controller原样输出当前语言固定授权、专业翻译配音及虚构声明]
```

The public description ends immediately after the fixed disclaimer. Never output a Chinese drama-name marker, internal ID, review note, score, generation note, or Validator result.

## Output Contract

Return structured data only. The controller validates it, writes canonical
`place_result.json` first, and renders `place_result.md` for display. The model
must not write files, workflow state, or Feishu data.

Rendered Markdown shape:

```text
# 播放列表

播放列表：xxxxx
地址：xxxxx
说明：
xxxxxx
翻译：
xxxxxx
```

Also write structured data to:

```text
place_result.json
```

Canonical JSON shape:

```json
{
  "section": "placement",
  "results": [
    {
      "search_result_index": 1,
      "source_block_label": "搜索资料1",
      "result_id": "VIDEO_ID_1",
      "video_id": "VIDEO_ID",
      "drama_name": "...",
      "playlist": "...",
      "url": "...",
      "description": "...",
      "translation": "..."
    }
  ]
}
```
