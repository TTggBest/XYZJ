import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "refresh_hashtag_pool_evidence.py"
SPEC = importlib.util.spec_from_file_location("refresh_hashtag_pool_evidence_under_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class RefreshHashtagPoolEvidenceTests(unittest.TestCase):
    def test_parse_count_supports_compact_youtube_metadata(self):
        self.assertEqual(MODULE.parse_count("261K videos"), 261000)
        self.assertEqual(MODULE.parse_count("1.2M channels"), 1200000)
        self.assertEqual(MODULE.parse_count("37,402 videos"), 37402)

    def test_audience_match_distinguishes_bengali_pool_from_english_pool(self):
        bengali_titles = [
            "বাংলা ডাবিং চাইনিজ ড্রামা সম্পূর্ণ পর্ব",
            "নতুন বাংলা প্রেমের নাটক",
            "Bangla dubbed Chinese drama full",
        ]
        english_titles = [
            "Best English romance series",
            "Hollywood family drama full movie",
            "English love story",
        ]

        self.assertGreaterEqual(MODULE.audience_match_ratio("孟加拉", bengali_titles), 0.66)
        self.assertLess(MODULE.audience_match_ratio("孟加拉", english_titles), 0.34)

    def test_candidate_requires_real_pool_and_target_audience_match(self):
        good = MODULE.evaluate_candidate(
            "孟加拉", "#bangladrama", 261000, 37000,
            ["বাংলা ডাবিং চাইনিজ ড্রামা", "নতুন বাংলা নাটক", "Bangla full drama"],
        )
        wrong_pool = MODULE.evaluate_candidate(
            "孟加拉", "#romance", 9000000, 500000,
            ["English romance series", "Hollywood love story", "English drama"],
        )

        self.assertTrue(good["eligible"])
        self.assertFalse(wrong_pool["eligible"])
        self.assertGreater(good["audience_match_ratio"], wrong_pool["audience_match_ratio"])

    def test_candidate_rejects_same_language_music_pool(self):
        music_pool = MODULE.evaluate_candidate(
            "印尼", "#cinta", 1_000_000, 100_000,
            [
                "CINTA - official music video",
                "Lagu cinta terbaru official audio",
                "Kumpulan lagu cinta populer",
            ],
        )
        drama_pool = MODULE.evaluate_candidate(
            "印尼", "#filmcina", 24_000, 2_000,
            [
                "Gadis miskin kaget saat tahu suaminya CEO",
                "Drama China: istri kembali untuk balas dendam",
                "CEO menyamar lalu menikahi gadis biasa",
            ],
        )

        self.assertFalse(music_pool["eligible"])
        self.assertTrue(drama_pool["eligible"])
        self.assertLess(music_pool["drama_audience_match_ratio"], drama_pool["drama_audience_match_ratio"])

    def test_candidate_rejects_misleading_korean_drama_pool_for_chinese_drama(self):
        candidate = MODULE.evaluate_candidate(
            "印尼", "#drakor", 204_000, 18_000,
            [
                "Gadis menikahi CEO yang menyamar dan jatuh cinta",
                "Drama China tentang istri yang kembali",
                "CEO melindungi gadis miskin",
            ],
        )

        self.assertFalse(candidate["eligible"])
        self.assertEqual(candidate["ineligible_reason"], "misleading_non_chinese_drama_pool")

    def test_merge_keeps_last_verified_language_pool_when_live_refresh_is_rate_limited(self):
        live = {
            "version": 1, "verified_at": "2026-08-20T15:00:00+08:00",
            "source": "youtube_public_search_and_hashtag_pages",
            "languages": {"孟加拉": {"queries": ["q"], "candidates": []}},
        }
        cached = {
            "version": 1, "verified_at": "2026-08-20T14:00:00+08:00",
            "source": "youtube_public_search_and_hashtag_pages",
            "languages": {"孟加拉": {"queries": ["q"], "candidates": [
                {
                    "hashtag": "#bangladrama", "eligible": True,
                    "pool_video_count": 261000, "pool_channel_count": 37000,
                    "sample_titles": [
                        "বাংলা ডাবিং চাইনিজ ড্রামা সম্পূর্ণ পর্ব",
                        "Bangla dubbed Chinese drama full",
                        "নতুন বাংলা চাইনিজ ড্রামা",
                    ],
                },
            ]}},
        }

        merged = MODULE.merge_evidence_payloads(live, [cached])

        self.assertEqual(
            [row["hashtag"] for row in merged["languages"]["孟加拉"]["candidates"]],
            ["#bangladrama"],
        )
        self.assertEqual(
            merged["languages"]["孟加拉"]["evidence_verified_at"],
            "2026-08-20T14:00:00+08:00",
        )

    def test_atomic_writer_refuses_incomplete_evidence_without_overwriting(self):
        payload = {
            "languages": {"孟加拉": {"candidates": []}}
        }
        with tempfile.TemporaryDirectory() as td:
            output = Path(td) / "asset.json"
            output.write_text('{"known":"good"}\n', encoding="utf-8")

            with self.assertRaisesRegex(RuntimeError, "insufficient_verified_hashtag_evidence"):
                MODULE.write_verified_evidence(payload, output, required_languages={"孟加拉"})

            self.assertEqual(json.loads(output.read_text(encoding="utf-8")), {"known": "good"})


if __name__ == "__main__":
    unittest.main()
