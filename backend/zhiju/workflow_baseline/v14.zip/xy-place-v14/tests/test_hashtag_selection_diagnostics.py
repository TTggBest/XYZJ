import importlib.util
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "hashtag_selection_diagnostics.py"


class HashtagSelectionDiagnosticsTests(unittest.TestCase):
    def module(self):
        if not SCRIPT.exists():
            self.fail("hashtag selection diagnostics script does not exist")
        spec = importlib.util.spec_from_file_location("v14_hashtag_diagnostics_test", SCRIPT)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module

    def test_reports_overlap_and_explicit_drama_coverage_without_gating(self):
        module = self.module()
        report = module.analyze_records([
            {
                "channel": "频道A",
                "video_id": "v1",
                "selected_additional_tags": ["#a", "#b", "#c"],
                "drama_relevant_tags": ["#a", "#c"],
            },
            {
                "channel": "频道A",
                "video_id": "v2",
                "selected_additional_tags": ["#b", "#c", "#d"],
                "drama_relevant_tags": ["#d"],
            },
        ])

        current = report["records"][1]
        self.assertEqual(current["prior_same_channel_count"], 1)
        self.assertEqual(current["mean_exact_overlap_count"], 2.0)
        self.assertEqual(current["drama_coverage_count"], 1)
        self.assertEqual(current["drama_coverage_tags"], ["#d"])
        self.assertNotIn("passed", current)
        self.assertNotIn("failed", current)
        self.assertFalse(report["blocking"])

    def test_does_not_guess_drama_coverage_without_explicit_evidence(self):
        module = self.module()
        report = module.analyze_records([
            {
                "channel": "频道A",
                "video_id": "v1",
                "selected_additional_tags": ["#a", "#b"],
            }
        ])
        current = report["records"][0]
        self.assertIsNone(current["drama_coverage_count"])
        self.assertEqual(current["drama_coverage_status"], "not_evaluated_without_explicit_relevance_evidence")


if __name__ == "__main__":
    unittest.main()
