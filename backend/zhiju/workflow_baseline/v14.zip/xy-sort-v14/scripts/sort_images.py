#!/usr/bin/env python3
"""Route generated image files into their Xiaoyu drama package folders.

This command deliberately does no image/content/contract validation. Its only
job is deterministic filename-to-task matching followed by copy (default) or
move (explicit).
"""

import argparse
import json
import re
import shutil
from datetime import datetime
from pathlib import Path


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
VIDEO_SEQUENCE_TO_SLUG = {
    "1": "title1", "01": "title1",
    "2": "title2", "02": "title2",
    "3": "title3", "03": "title3",
}
SHORT_SUFFIX_TO_TASK = {
    "": ("community1", "1x1"),
    "_2": ("community2", "1x1"),
    "1_4_5": ("title1", "4x5"),
    "2_4_5": ("title2", "4x5"),
    "3_4_5": ("title3", "4x5"),
}
SIMPLE_VIDEO_SUFFIX_RE = re.compile(
    r"^[ _.-]*(0?[123])(?:[ _.-]*(?:16x9|16-9|landscape|wide))?$", re.I
)


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def resolve_batch(root: Path, batch_id: str) -> tuple[str, Path, Path]:
    batch_root = root / "批量任务"
    if not batch_id:
        pointer = batch_root / "current_batch.json"
        if not pointer.is_file():
            raise SystemExit(f"Current batch pointer not found: {pointer}")
        batch_id = str(load_json(pointer).get("batch_id") or "").strip()
    if not batch_id:
        raise SystemExit("Batch ID is empty")
    batch_dir = batch_root / batch_id
    index_path = batch_dir / "今日任务索引.json"
    if not index_path.is_file():
        raise SystemExit(f"Batch index not found: {index_path}")
    return batch_id, batch_dir, index_path


def hydrate_image_tasks(item: dict) -> list[dict]:
    """Read routing metadata only; contract fields are intentionally ignored."""
    manifest_value = str(item.get("prompt_manifest") or "").strip()
    manifest_path = Path(manifest_value).expanduser() if manifest_value else None
    if manifest_path and manifest_path.is_file():
        try:
            tasks = load_json(manifest_path).get("tasks", [])
            if isinstance(tasks, list) and tasks:
                return [dict(task) for task in tasks if isinstance(task, dict)]
        except (OSError, ValueError, json.JSONDecodeError):
            pass
    return [dict(task) for task in item.get("image_tasks", []) if isinstance(task, dict)]


def build_bindings(index: dict) -> tuple[dict[str, dict], dict[str, list[dict]]]:
    task_map: dict[str, dict] = {}
    video_map: dict[str, list[dict]] = {}
    for item in index.get("items", []):
        if not isinstance(item, dict):
            continue
        for task in hydrate_image_tasks(item):
            task_id = str(task.get("task_id") or "").strip()
            if not task_id:
                continue
            binding = {"item": item, "task": task}
            task_map[task_id] = binding
            video_id = str(item.get("video_id") or "").strip()
            if video_id:
                video_map.setdefault(video_id, []).append(binding)
    return task_map, video_map


def match_simple_video_sequence(image: Path, video_map: dict[str, list[dict]]) -> dict | None:
    hits = []
    for video_id, bindings in video_map.items():
        if not image.stem.startswith(video_id):
            continue
        suffix = image.stem[len(video_id):]
        short_task = SHORT_SUFFIX_TO_TASK.get(suffix.lower())
        if short_task:
            slug, ratio = short_task
            sequence = suffix
        else:
            match = SIMPLE_VIDEO_SUFFIX_RE.fullmatch(suffix)
            if not match:
                continue
            sequence = match.group(1)
            slug = VIDEO_SEQUENCE_TO_SLUG[sequence]
            ratio = "16x9"
        candidates = [
            binding for binding in bindings
            if str(binding["task"].get("slug") or "") == slug
            and str(binding["task"].get("ratio") or "") == ratio
        ]
        for binding in candidates:
            hits.append({"video_id": video_id, "sequence": sequence, "binding": binding})
    if not hits:
        return None
    if len(hits) > 1:
        return {"ambiguous": True, "hits": hits}
    return {"ambiguous": False, **hits[0]}


def backup_path(destination: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
    return destination.with_name(f"{destination.stem}.bak_{stamp}{destination.suffix}")


def safe_copy_or_move(source: Path, destination: Path, *, move: bool, dry_run: bool) -> dict:
    if source.resolve() == destination.resolve():
        return {"action": "same_path_skip", "backup": ""}
    backup = ""
    action = "move" if move else "copy"
    if destination.exists():
        backup_file = backup_path(destination)
        backup = str(backup_file)
        action = f"backup_and_{action}"
        if not dry_run:
            destination.rename(backup_file)
    if not dry_run:
        destination.parent.mkdir(parents=True, exist_ok=True)
        if move:
            shutil.move(str(source), str(destination))
        else:
            shutil.copy2(source, destination)
    return {"action": action, "backup": backup}


def target_path_for(item: dict, task: dict) -> Path:
    value = str(task.get("target_path") or "").strip()
    if value:
        return Path(value).expanduser().resolve()
    filename = str(task.get("target_filename") or "").strip()
    if not filename:
        raise ValueError(f"task_target_missing:{task.get('task_id', '')}")
    return Path(str(item["package_path"])).expanduser().resolve() / "images" / "raw" / filename


def route_images(source: Path, index: dict, *, move: bool, dry_run: bool) -> dict:
    task_map, video_map = build_bindings(index)
    source_images = sorted(
        path for path in source.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_EXTS
    )
    matched: list[dict] = []
    unmatched: list[str] = []
    ambiguous: list[dict] = []
    item_records: dict[str, dict] = {}

    for item in index.get("items", []):
        if not isinstance(item, dict) or not item.get("package_path"):
            continue
        package = str(Path(str(item["package_path"])).expanduser().resolve())
        item_records[package] = {
            "row_number": item.get("row_number"),
            "output_row_number": item.get("output_row_number"),
            "video_id": str(item.get("video_id") or ""),
            "drama_name": str(item.get("drama_name") or ""),
            "package_path": package,
            "matched": [],
        }

    for image in source_images:
        exact = [task_id for task_id in task_map if task_id in image.stem]
        binding = None
        match_mode = ""
        extra: dict = {}
        if len(exact) == 1:
            binding = task_map[exact[0]]
            match_mode = "task_id"
        elif len(exact) > 1:
            ambiguous.append({"source": str(image), "task_ids": exact})
            continue
        else:
            simple = match_simple_video_sequence(image, video_map)
            if simple and simple.get("ambiguous"):
                ambiguous.append({
                    "source": str(image),
                    "task_ids": [row["binding"]["task"]["task_id"] for row in simple["hits"]],
                    "match_mode": "video_id_sequence",
                })
                continue
            if simple:
                binding = simple["binding"]
                match_mode = "video_id_sequence"
                extra = {"video_id": simple["video_id"], "sequence": simple["sequence"]}

        if binding is None:
            unmatched.append(str(image))
            continue

        item = binding["item"]
        task = binding["task"]
        destination = target_path_for(item, task)
        operation = safe_copy_or_move(image, destination, move=move, dry_run=dry_run)
        record = {
            "task_id": str(task.get("task_id") or ""),
            "source": str(image),
            "destination": str(destination),
            "match_mode": match_mode,
            **operation,
            **extra,
        }
        matched.append(record)
        package = str(Path(str(item["package_path"])).expanduser().resolve())
        item_records.setdefault(package, {"package_path": package, "matched": []})["matched"].append(record)

    return {
        "total_source_images": len(source_images),
        "matched_count": len(matched),
        "unmatched_count": len(unmatched),
        "ambiguous_count": len(ambiguous),
        "matched": matched,
        "unmatched": unmatched,
        "ambiguous": ambiguous,
        "items": list(item_records.values()),
    }


def report_markdown(payload: dict) -> str:
    lines = [
        "# 图片分拣报告", "",
        f"批次：{payload['batch_id']}",
        f"来源：{payload['source_folder']}",
        f"模式：{payload['mode']}",
        f"源图片数：{payload['total_source_images']}",
        f"已放入：{payload['matched_count']}",
        f"未匹配：{payload['unmatched_count']}",
        f"歧义：{payload['ambiguous_count']}", "",
        "说明：本命令只按文件名放图，不读取或检测图片内容、尺寸、比例、提示词、合同、历史相似度。", "",
        "## 每剧结果", "",
    ]
    for item in payload["items"]:
        if item.get("matched"):
            lines.extend([
                f"### {item.get('drama_name') or item.get('video_id') or item['package_path']}", "",
                f"- 已放入：{len(item['matched'])}", "",
            ])
    if payload["unmatched"]:
        lines.extend(["## 未匹配", "", *[f"- {path}" for path in payload["unmatched"]], ""])
    if payload["ambiguous"]:
        lines.extend(["## 歧义", ""])
        for row in payload["ambiguous"]:
            lines.append(f"- {row['source']} -> {', '.join(row['task_ids'])}")
        lines.append("")
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Route generated images into Xiaoyu drama folders")
    parser.add_argument("source_folder")
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--batch", default="")
    parser.add_argument("--move", action="store_true", help="Move files; default is copy")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    source = Path(args.source_folder).expanduser().resolve()
    if not source.is_dir():
        raise SystemExit(f"Source folder not found: {source}")
    root = Path(args.root).expanduser().resolve()
    batch_id, batch_dir, index_path = resolve_batch(root, args.batch.strip())
    payload = route_images(source, load_json(index_path), move=args.move, dry_run=args.dry_run)
    payload.update({
        "version": 1,
        "responsibility": "filename_routing_and_copy_or_move_only",
        "batch_id": batch_id,
        "source_folder": str(source),
        "mode": "move" if args.move else "copy",
        "dry_run": bool(args.dry_run),
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    })

    suffix = ".dry_run" if args.dry_run else ""
    report_json = batch_dir / f"图片分拣报告{suffix}.json"
    report_md = batch_dir / f"图片分拣报告{suffix}.md"
    write_json(report_json, payload)
    report_md.write_text(report_markdown(payload), encoding="utf-8")
    if not args.dry_run:
        for item in payload["items"]:
            if not item.get("matched"):
                continue
            raw_dir = Path(item["package_path"]) / "images" / "raw"
            raw_dir.mkdir(parents=True, exist_ok=True)
            (raw_dir / "分拣报告.md").write_text(
                f"# 分拣报告\n\n批次：{batch_id}\n\n已放入：{len(item['matched'])}\n",
                encoding="utf-8",
            )
    print(json.dumps({
        "batch_id": batch_id,
        "report_json": str(report_json),
        "report_md": str(report_md),
        "matched_count": payload["matched_count"],
        "unmatched_count": payload["unmatched_count"],
        "ambiguous_count": payload["ambiguous_count"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
