import importlib.util
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "sort_images.py"
SPEC = importlib.util.spec_from_file_location("sort_images_routing_only_test", SCRIPT)
SORT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SORT)


class SortRoutingOnlyTests(unittest.TestCase):
    def item(self, package: Path, video_id: str = "video_X-1") -> dict:
        raw = package / "images" / "raw"
        return {
            "row_number": 2,
            "output_row_number": 12,
            "video_id": video_id,
            "drama_name": "测试剧",
            "package_path": str(package),
            "image_tasks": [
                {
                    "task_id": f"{video_id}_01_title1_4x5",
                    "slug": "title1", "ratio": "4x5",
                    "target_filename": "01_标题1_4x5.png",
                    "target_path": str(raw / "01_标题1_4x5.png"),
                },
                {
                    "task_id": f"{video_id}_02_title1_16x9",
                    "slug": "title1", "ratio": "16x9",
                    "target_filename": "02_标题1_16x9.png",
                    "target_path": str(raw / "02_标题1_16x9.png"),
                },
                {
                    "task_id": f"{video_id}_03_title2_4x5",
                    "slug": "title2", "ratio": "4x5",
                    "target_filename": "03_标题2_4x5.png",
                    "target_path": str(raw / "03_标题2_4x5.png"),
                },
                {
                    "task_id": f"{video_id}_04_title2_16x9",
                    "slug": "title2", "ratio": "16x9",
                    "target_filename": "04_标题2_16x9.png",
                    "target_path": str(raw / "04_标题2_16x9.png"),
                },
                {
                    "task_id": f"{video_id}_05_title3_4x5",
                    "slug": "title3", "ratio": "4x5",
                    "target_filename": "05_标题3_4x5.png",
                    "target_path": str(raw / "05_标题3_4x5.png"),
                },
                {
                    "task_id": f"{video_id}_06_title3_16x9",
                    "slug": "title3", "ratio": "16x9",
                    "target_filename": "06_标题3_16x9.png",
                    "target_path": str(raw / "06_标题3_16x9.png"),
                },
                {
                    "task_id": f"{video_id}_07_community1_1x1",
                    "slug": "community1", "ratio": "1x1",
                    "target_filename": "07_社群1_1x1.png",
                    "target_path": str(raw / "07_社群1_1x1.png"),
                },
                {
                    "task_id": f"{video_id}_08_community2_1x1",
                    "slug": "community2", "ratio": "1x1",
                    "target_filename": "08_社群2_1x1.png",
                    "target_path": str(raw / "08_社群2_1x1.png"),
                },
            ],
        }

    def test_eight_short_names_route_to_distinct_cover_and_community_tasks(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source"
            package = root / "package"
            source.mkdir()
            fixtures = {
                "video_X-11_4_5.png": ("01_标题1_4x5.png", b"title1-4x5"),
                "video_X-12_4_5.png": ("03_标题2_4x5.png", b"title2-4x5"),
                "video_X-13_4_5.png": ("05_标题3_4x5.png", b"title3-4x5"),
                "video_X-11.png": ("02_标题1_16x9.png", b"title1-16x9"),
                "video_X-12.png": ("04_标题2_16x9.png", b"title2-16x9"),
                "video_X-13.png": ("06_标题3_16x9.png", b"title3-16x9"),
                "video_X-1.png": ("07_社群1_1x1.png", b"community1"),
                "video_X-1_2.png": ("08_社群2_1x1.png", b"community2"),
            }
            for filename, (_, payload) in fixtures.items():
                (source / filename).write_bytes(payload)

            result = SORT.route_images(source, {"items": [self.item(package)]}, move=False, dry_run=False)

            self.assertEqual(result["matched_count"], 8)
            self.assertEqual(result["unmatched_count"], 0)
            self.assertEqual(result["ambiguous_count"], 0)
            for target_filename, payload in fixtures.values():
                self.assertEqual((package / "images/raw" / target_filename).read_bytes(), payload)

    def test_video_id_1_2_3_routes_and_default_copies(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source"
            package = root / "V2" / "语言" / "频道" / "剧目" / "测试剧_2026081819"
            source.mkdir()
            for seq in (1, 2, 3):
                (source / f"video_X-1{seq}.png").write_bytes(f"image-{seq}".encode())

            result = SORT.route_images(source, {"items": [self.item(package)]}, move=False, dry_run=False)

            self.assertEqual(result["matched_count"], 3)
            self.assertEqual(result["unmatched_count"], 0)
            self.assertTrue((source / "video_X-11.png").exists())
            self.assertEqual((package / "images/raw/02_标题1_16x9.png").read_bytes(), b"image-1")
            self.assertEqual((package / "images/raw/04_标题2_16x9.png").read_bytes(), b"image-2")
            self.assertEqual((package / "images/raw/06_标题3_16x9.png").read_bytes(), b"image-3")

    def test_full_task_id_routes(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source"
            package = root / "package"
            source.mkdir()
            image = source / "download_video_X-1_04_title2_16x9_final.webp"
            image.write_bytes(b"pixels")

            result = SORT.route_images(source, {"items": [self.item(package)]}, move=False, dry_run=False)

            self.assertEqual(result["matched"][0]["match_mode"], "task_id")
            self.assertTrue((package / "images/raw/04_标题2_16x9.png").exists())

    def test_file_content_and_dimensions_are_never_read(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source"
            package = root / "package"
            source.mkdir()
            # Deliberately not an image payload. Filename routing must still copy it.
            image = source / "video_X-11.png"
            image.write_bytes(b"not-a-real-image-and-could-be-square")

            result = SORT.route_images(source, {"items": [self.item(package)]}, move=False, dry_run=False)

            self.assertEqual(result["matched_count"], 1)
            self.assertEqual((package / "images/raw/02_标题1_16x9.png").read_bytes(), image.read_bytes())

    def test_existing_destination_is_backed_up(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source"
            package = root / "package"
            destination = package / "images/raw/02_标题1_16x9.png"
            source.mkdir()
            destination.parent.mkdir(parents=True)
            destination.write_bytes(b"old")
            (source / "video_X-11.png").write_bytes(b"new")

            result = SORT.route_images(source, {"items": [self.item(package)]}, move=False, dry_run=False)

            backup = Path(result["matched"][0]["backup"])
            self.assertEqual(backup.read_bytes(), b"old")
            self.assertEqual(destination.read_bytes(), b"new")

    def test_unmatched_is_left_untouched(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "source"
            source.mkdir()
            unknown = source / "unknown1.png"
            unknown.write_bytes(b"image")

            result = SORT.route_images(source, {"items": []}, move=True, dry_run=False)

            self.assertEqual(result["unmatched"], [str(unknown)])
            self.assertTrue(unknown.exists())

    def test_sort_source_has_no_review_or_contract_runtime(self):
        code = SCRIPT.read_text(encoding="utf-8")
        forbidden = (
            "review_image", "SimilarityGate", "verify_contract_snapshot",
            "verify_runtime_sources", "regeneration_queue", "codex exec",
            "ffmpeg", "PIL", "cv2",
        )
        for token in forbidden:
            self.assertNotIn(token, code)


if __name__ == "__main__":
    unittest.main()
