---
name: xy-sort-v14
description: Put generated Xiaoyu images into the matching V2 drama package folders by filename or task ID. This command only routes and copies/moves files; it never reviews image content.
---

# XY Sort

## Single Responsibility

`xy-sort-v14` only does two things:

1. Match an image filename to one image task in the selected V2 batch.
2. Copy the image into that drama's `images/raw/` folder, or move it only when the user explicitly supplies `--move`.

It must not:

- call an AI/model;
- inspect pixels, dimensions, aspect ratio, anatomy, text, faces, children, scenes or safety;
- compare historical images or run similarity scoring;
- read or verify prompt content, production contracts, runtime hashes or task lineage;
- reject images because of visual/content quality;
- create regeneration tasks;
- change `workflow_state.json`, task status, package status or Feishu data.

An unmatched or ambiguous filename is a routing failure, not an image-quality failure. Leave that source file untouched and list it in the report.

## Production Root

Use only:

```text
运营/工作流运营
```

All versions route images into this one shared production tree. Do not create a second V14 data tree under `运营/工作流实验室/V14`.

## Commands

Current batch, default copy:

```text
scripts/sort_images.py /path/to/generated-images --root "运营/工作流运营"
```

Specific batch:

```text
scripts/sort_images.py /path/to/generated-images --root "运营/工作流运营" --batch BATCH_ID
```

Read-only destination preview:

```text
scripts/sort_images.py /path/to/generated-images --root "运营/工作流运营" --batch BATCH_ID --dry-run
```

Move source files only when explicitly requested:

```text
scripts/sort_images.py /path/to/generated-images --root "运营/工作流运营" --batch BATCH_ID --move
```

## Filename Matching

Full task IDs are accepted:

```text
<video_id>_01_title1_4x5
<video_id>_02_title1_16x9
<video_id>_03_title2_4x5
<video_id>_04_title2_16x9
<video_id>_05_title3_4x5
<video_id>_06_title3_16x9
<video_id>_07_community1_1x1
<video_id>_08_community2_1x1
```

The compact eight-image names are also accepted:

```text
<video_id>1_4_5.png -> 01_标题1_4x5.png
<video_id>2_4_5.png -> 03_标题2_4x5.png
<video_id>3_4_5.png -> 05_标题3_4x5.png
<video_id>1.png -> 02_标题1_16x9.png
<video_id>2.png -> 04_标题2_16x9.png
<video_id>3.png -> 06_标题3_16x9.png
<video_id>.png -> 07_社群1_1x1.png
<video_id>_2.png -> 08_社群2_1x1.png
```

For covers, `_4_5` selects the 4:5 task and the bare `1/2/3` suffix selects the corresponding 16:9 task. A bare video ID selects community image 1; `_2` selects community image 2 and must not be interpreted as title 2. Matching is based only on filename. A square file with a matching name is still routed; `xy-sort-v14` does not inspect or reject its ratio.

## Destination and Replacement

Use each matched task's declared `target_path`. If the destination already exists, rename the existing file to a timestamped `.bak_...` backup, then copy or move the new file. Default operation is copy so the source folder remains recoverable.

## Reports

Write only routing evidence:

```text
批量任务/BATCH_ID/图片分拣报告.json
批量任务/BATCH_ID/图片分拣报告.md
每个命中包/images/raw/分拣报告.md
```

The report contains matched source/destination paths, unmatched files and ambiguous matches. It contains no quality verdict, similarity score, rejection record or regeneration queue.
