---
name: xy-title-v14
description: Generate 3 titles for the current Xiaoyu short-drama package. Use after plot summary is available. Read the current channel generation brief and create 3 first-person titles that fit the channel format and stay within 100 characters.
---

# XY Title

## Purpose

This step only does one thing:

- generate 3 titles for the current drama package

Goal of this skill:

- make downstream title generation default to short, hard, direct, click-driven wording
- avoid soft,绕, abstract, over-explained, or literary titles
- make the first beat establish immediate emotional debt through a concrete event, and make the second beat directly repay it through a perceptible position change

It does not search plot, does not decide covers, and does not do community or description work.

## Inputs

In deterministic batch mode, the controller supplies the normalized contents of:

```text
01_搜索资料.md
01_市场包装证据.json 的 final_angles
频道名_生成规范.md
```

Use the complete authoritative plot fields in the normalized `plot_payload`. Do not title from a compressed synopsis when the four fields are available.

Use `market_packaging.final_angles` as the three A/B/C packaging directions in order. Do not inspect or reconstruct raw market videos. Market evidence ranks plot-supported angles; it never overrides plot truth. A `story_derived` direction is a normal fallback and must be treated as a plot-derived angle without a market-performance claim.

If `01_搜索资料.md` does not contain usable plot summary, generate titles from:

- Chinese drama name
- alias, when available

In both cases, titles must still be packaged according to the current channel `频道名_生成规范.md`.

New V2.1 batches also supply `channel_theme_contract` and a controller-owned
`creative_slot`. Treat the slot as a preference only where verified plot facts
support it. Return one shared `packaging_brief`; copy its `creative_slot_id` and
`channel_direction` exactly so cover, description, and community inherit the
same click promise.

## Rules

- Generate exactly 3 titles.
- Generate direction 1 from market angle A, direction 2 from B, and direction 3 from C before recommendation sorting. Preserve each angle's factual A/B core while realizing it in the current channel language and title shell. Do not merge the three directions into one title or replace them with three wording variants of one angle.
- V14 title generation strictly forbids these semantic concepts in every target language, Chinese review translation, direction, hook fact, payoff anchor, and downstream visual field: 强奸/rape、性侵/sexual assault、猥亵/molestation、下药/drugged、迷奸/date rape or drugging、卖掉某人/sold a person、人口贩卖/human trafficking、杀死/kill、谋杀/murder、枪杀/shooting or killing、自杀/suicide、自残/self-harm、尸体/corpse or dead body、血腥/bloody or gory、酷刑/torture、毒杀/poisoning to death、虐杀/brutal killing. This is semantic, so translation, inflection, or euphemistic spelling does not make the concept usable.
- Prefer not to use 家暴/domestic violence、虐待/abuse、绑架/kidnapping、死亡威胁/death threat. Freely choose another hard, clickable expression whenever possible without weakening the A+B structure.
- Apply this blacklist during generation before returning JSON. Do not rely on a downstream Validator or text-cleaning pass.
- Treat the current channel's controller-supplied `recent_channel_title_usage_7d` as soft wording guidance, not a gate. It counts accepted generated title candidates scheduled in the prior rolling seven days. At or above a numeric preference, freely choose another equally hard expression when possible: 复仇/背叛最多2次；报复、羞辱、抛弃、赶出家门、被赶走、毁掉、摧毁、骗局、出轨、情人/小三、偷走、夺走、陷害、诬陷、赶出公司、开除、破产最多1次；欺骗最多2次。
- 尽量少用绝望、憎恨、恨我；不建议使用“毁了我的人生”；对“让他付出代价”“我要让他们后悔”主动限频。历史缺失或已经超出偏好时都不得阻塞、拒收或单独触发重试，A+B爆点强度仍优先。
- When `channel_theme_contract.plot_supported=true`, make the current channel
  direction prominent in all three directions. Keep the topic consistent while
  varying the factual moment, hook pair, and downstream visual role.
- V14 has no fixed localized title-theme candidate library. Never copy a reusable
  direction slogan merely to satisfy channel fit. Build each title from this
  drama's current evidence and channel direction; generic direction labels are
  not mandatory title text.
- Titles must strictly follow the current channel title format.
- Generate every final title at no more than 95 Unicode code points, including emoji, brackets, spaces, and punctuation, so it stays safely within the validator's hard 100-code-point limit.
- Recount the actual final title string; never trust or merely copy the model's own `char_count` field.
- Titles must be written in first person.
- Use the plot as marketing raw material and keep only a minimum relationship or conflict connection; B does not need to reproduce a literal plot event or ending.
- If plot summary is unavailable, use the Chinese drama name or alias.
- Titles must be direct and explosive. Do not write them in a绕/铺垫/含蓄 way.
- Prefer concrete conflict nouns and verbs over abstract emotion words.
- The title is aggressive marketing packaging, not a literal translation of plot facts. Deliberately amplify the most clickable conflict, result, reversal, and payoff.
- The first half of each title must immediately expose the strongest clickable stimulus.
- The second half must immediately deliver a concrete position change that answers the first half's emotional debt.
- Prefer short impact words over soft summary words.
- Whether based on plot or name, every title must:
  - have a hook
  - have reversal
  - have melodrama / dramatic conflict
  - have a clear explosive point
  - be packaged according to the current channel
  - clearly follow the current channel generation brief
- If the story can reasonably lean on child-related elements, highlight the child angle.
- Use an optional amplifier only when current task evidence, channel-permitted marketing extrapolation, or the frozen contract supports it. Never invent a new identity, amount, asset, power, or relationship merely to intensify a title.
- The 3 titles must not be similar.
- Same-drama `creative_history` is a forbidden-reference list. Across channels, do not translate, paraphrase, or reuse its A/B hook pair, specificity anchor, or editorial direction; only objective plot facts may be shared.
- The strongest and most recommended title must be placed first.
- Give every direction a unique integer `recommendation_score` from 1 to 100. Score click strength, emotional shock, open-loop curiosity, channel fit, and downstream visual potential. When exactly one or two final angles are market-backed, the controller places those market-backed directions first and sorts within the market-backed and story-derived groups by score. When all three or none are market-backed, the controller sorts all three by score. It then rewrites indexes so final title 1/2/3 are the final A/B/C delivery order.
- `child_angle` is a downstream cover-execution flag, not a keyword detector. Set it to `true` only when the selected title direction has a born minor who can truthfully appear, safe and supervised, in the same single continuous moment and physical location as the chosen cover event. A title may mention a child while using `child_angle=false` when its strongest visible payoff is an adult-only later consequence and the child cannot truthfully share that moment.
- Channel type, drama name, or the mere presence of child words must never force all 3 directions to set `child_angle=true`.
- Every direction must provide a short `visual_thesis`: the title's main visible conflict, discovery, reveal, reunion, or emotional reversal. It states what the cover should make understandable, not a fixed composition, camera, prop, or blocking template.
- Resolve child presence independently from each supplied Find final angle. Channel direction and drama name cannot force a child into an angle. An angle whose only child fact is not yet born uses `child_angle=false` unless that same angle also contains a born minor. A deceased, absent, or earlier-life child does not require `child_angle=true` for a later adult-only consequence. When `child_angle=true`, `safe_cover_scene` must be one executable single moment in one physical location; never satisfy it with a split screen, inset memory, separate memory region, collage, or temporal montage. Every such direction must provide `safe_cover_scene` and `child_role` before the cover stage. `safe_cover_scene` is a reference safety implementation, not a mandatory replacement for the title event.
- Keep the public A+B title explosive. In the downstream visual fields `visual_thesis`, `child_role`, and `safe_cover_scene`, never make a minor the visible target of abandonment, humiliation, hostile surveillance, coercive parenting, police restraint/control, adult confrontation, or bedroom/bedside intimacy. Put the visible wrongdoing, confrontation, or consequence on adults and keep the required child as a calm, protected, supervised relationship, identity, reunion, or family anchor. Do not delete the child and do not weaken the public title.
- A child may safely appear in a hospital, clinic, ward, waiting area, rehabilitation area, or normal examination setting. Reject only painful, invasive, dangerous, or harmful medical procedures involving the child. Do not replace the title's main conflict, discovery, reveal, reunion, or emotional reversal with an unrelated peaceful activity.
- Different titles may use related explosive points, but the wording and angle must not feel repetitive.
- The 3 directions must use different emotional debts and position changes, not merely different isolated nouns.
- Do not merely translate the Chinese drama name.
- Keep the output format unchanged.
- `translation` is a Chinese review aid only, not production truth and not an
  input to acceptance, retry, child-safety, format, theme, or collision gates.
- When provided, it should explain the same two title beats rather than invent
  a second title. A blank, imperfect, differently punctuated, or differently
  formatted Chinese review translation must never block an otherwise valid
  target-language title.
- Translate the localized completion marker inside `【】` to `【完结】` for the
  Chinese review title; do not replace the channel emoji with a global emoji.
- The controller owns the final translation shell. AI only translates the A
  and B content beats.
- The exact channel title shell and every applicable child-safe staging
  requirement remain binding on the initial generation and every retry. A
  retry for length, collision, format, or another field must not regress a
  requirement that passed on the previous attempt.
- A `format_mismatch` retry must receive the exact frozen channel shell and may
  replace only A and B. A cross-channel-collision retry must change the actual
  hook pair, specificity anchor, and editorial moment, not merely wording.

## Direct Title Formula

Every title must use one declarative A+B causal chain.

Core definition:

> A creates immediate emotional debt through a concrete, perceptible event. B directly repays that debt through a clear position change.

Generate in this exact order:

```text
strongest immediate emotion
-> concrete perceptible event
-> relationship inside that event
-> protagonist's response, choice, or gain
-> clear position change
-> optional amplifier
-> single A-to-B causal chain
```

Prioritize events that directly change the position between people. An event's type does not determine its priority; priority depends on whether it directly causes selection, exclusion, recognition, replacement, protection, or a change in status between people. A procedural fact receives high priority only when it carries such a position change.

Position change is an abstract result dimension. It may concern relationship, identity, power, interests, resources, social position, relationship commitment, or fate. These dimensions are not a candidate library, and no one dimension is mandatory.

Do not explain the full story, write a synopsis, or delay the concrete event behind setup.

Production-facing rules must remain abstract. Do not inject prebuilt story examples, fixed action combinations, fixed identity combinations, fixed result combinations, or fixed reversal templates. Actual plot evidence, channel context, and negative creative history remain valid dynamic inputs.

Finalize the marketing semantics, A-to-B emotional debt, and position change before wording the title. Then realize that unchanged meaning naturally in the current target language and market. The goal is to reduce first-read comprehension cost, not to make the title more literary, complete, or narrative. Keep this priority: relationship clarity, action clarity, result clarity, natural word order, then conciseness. This language realization may reorganize grammar, clause order, pronouns, punctuation, time placement, locally natural forms of address, and accepted loanwords when the current channel context supports them. It must not weaken the conflict, reversal, payoff, or position change, must not change facts or invent identities, amounts, assets, power, or relationships, and must not add explanatory background. Do not create or use a fixed sentence-pattern library for any language.

Before returning the localized title, perform a model-only native-language self-check: a local cold viewer should immediately understand who did what to whom; the wording should not preserve unnatural Chinese source order; it should sound locally natural rather than merely grammatical; it should be shortened or smoothed only when the original click strength remains intact; and the relationship, action, and result should remain immediately clear. This is generation and internal ranking guidance only, not a new Schema field, mechanical Validator, or Controller semantic detector.

Before returning candidates, perform a model-only self-check:

1. Does A create immediate emotion for a cold viewer?
2. Does A contain a concrete, perceptible event?
3. Does B directly repay the emotional debt created by A?
4. Is A-to-B understandable without the full plot background?
5. Is there only one main emotional causal line?

Use this self-check only for candidate generation, ranking, and internal rewrite. It must not become a mechanical Validator or an independent Controller semantic detector.

## Minimum Plot Anchor Ledger

For each title return `hook_a_type`, `hook_a_fact`, `hook_a_evidence`, `hook_b_type`, `hook_b_fact`, `hook_b_evidence`, and `specificity_anchor`.

- `hook_a_evidence` must copy one short minimum anchor verbatim from the Chinese authoritative plot fields.
- `hook_b_evidence` may contain a short Chinese marketing-amplification rationale; it does not need to be another plot quote.
- `public_payoff_anchor` is one short Chinese internal position-change note that directly answers A. It is evaluated on its own meaning and must not be required to appear verbatim inside the Chinese review translation.
- Preserve numeric facts and convert units correctly: `1亿 = 100 million = 0.1 billion`; `20亿 = 2 billion`, not 20 billion.
- Evidence fields are internal source or amplification notes, not a verbatim-proof gate.
- Use three different specificity anchors across the title set.
- Use at least two different A types and at least two different B types.
- Treat the drama's people, relationships, and conflicts as the minimum connection. B may use a concrete marketed result without matching a literal event or ending, but any amplifier must remain grounded in current task evidence or permitted extrapolation.
- Reject a B beat whose whole result is an abstract story summary rather than a perceptible position change that answers A.
- Apply the cold-viewer test: replace bare story-internal proper nouns with a universally understandable description of the current relationship, event, or position change. Internal names may remain only in evidence notes.
- Never sexualize minors and never use explicit incest wording. Adult relationship ambiguity may be used only as a click gap, not as an explicit incest claim.

Protocol-only allowed `hook_a_type` values: `betrayal`, `humiliation`, `abandonment`, `theft`, `forced_choice`, `life_crisis`, `child_separation`, `identity_suppression`, `public_attack`, `marriage_trap`, `money_power_attack`, `shocking_discovery`.

Protocol-only allowed `hook_b_type` values: `identity_reveal`, `public_slapback`, `revenge`, `power_reversal`, `villain_cost`, `family_collapse`, `regret_chase`, `child_recognition`, `marriage_reveal`, `life_or_death_payoff`, `wealth_reveal`, `alliance_victory`, `arrival_mystery`, `relationship_mystery`, `secret_object`, `public_shock`, `forced_choice_escalation`, `countdown_crisis`, `unseen_consequence`.

These type values only encode the already chosen current-task result in the unchanged output protocol. They must not be used as a creative candidate list.

## Direction Split Rule

The 3 directions must come from 3 different primary click points whenever the plot supports them.

Generic outcome labels alone are not enough directions.

## Hard Style Constraints

- Favor shorter clauses over long explanatory clauses.
- Favor impact words over logic words.
- Do not explain the whole setup inside the title.
- Do not use elegant summary wording when a harsher concrete wording exists.
- Do not use soft filler or generic summary wording unless the plot truly has no stronger direct hook.
- Avoid titles that read like a synopsis sentence.
- Avoid titles that sound like emotional review copy rather than thumbnail click copy.

## Reject And Rewrite

Reject the title set and rewrite before finalizing if any of these are true:

- the first half is not an immediate clickable stimulus
- the second half does not intensify curiosity
- B starts a second unrelated plot line instead of answering A
- the title explains background instead of showing the strongest hook
- the title hides the concrete爆点 behind vague words
- the title sounds polite, elegant, literary, or explanatory
- the title could be reused on 20 other dramas with only one noun changed
- all 3 titles use the same emotional debt and position change
- the title requires reading twice to understand
- the title includes too many plot points and feels crowded

## Preferred Thinking Order

Before writing each title, decide in this order:

1. What is the strongest immediate emotion?
2. Which concrete, perceptible event creates it?
3. Does that event directly change the position between people, regardless of event type?
4. Which relationship makes that event instantly understandable?
5. What response, choice, or gain changes the protagonist's position?
6. What is the resulting position change?
7. Is an evidence-grounded optional amplifier useful?
8. How can this become one short A-to-B causal chain distinct from the other two?

## Output Contract

Return structured data only. The controller validates it, writes canonical
`04_标题方案.json` first, and renders `04_标题方案.md` for display. The model
must not write files, workflow state, or Feishu data.

Rendered Markdown shape:

```text
# 标题方案

方向1：xxxx
标题1：xxxx
翻译：xxxxx
字符数：xx

方向2：xxxx
标题2：xxxx
翻译：xxxxx
字符数：xx

方向3：xxxx
标题3：xxxx
翻译：xxxxx
字符数：xx
```

Also write structured data to:

```text
04_标题方案.json
```

Return JSON that matches the controller-supplied response Schema exactly. The
Schema, not a story-filled example, defines every required field and nesting
level. Do not add fields outside that unchanged Schema.
