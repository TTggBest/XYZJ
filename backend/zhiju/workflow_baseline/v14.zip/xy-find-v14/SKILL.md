---
name: xy-find-v14
description: Build V14 short-drama plot truth from the authoritative Feishu drama library, then independently search YouTube for verified market-packaging evidence and select three channel-fit packaging angles.
---

# XY Find V14

## Purpose

V14 Find has two strictly separated outputs:

```text
01_搜索资料.json / md
= Plot Truth

01_市场包装证据.json / md
= Market Packaging Intelligence
```

Plot truth answers what happens in the drama. Market evidence answers which verified parts of that drama are currently being used as clickable YouTube packaging.

## Plot truth

The deterministic controller reads the authoritative Feishu `剧库表`, matches the exact Chinese drama name, and keeps these four fields as the only story authority:

- `内容概述`
- `剧情档案`
- `剧情套路`
- `核心人设`

YouTube findings must never add, replace, or override a story fact. Preserve the existing `01_搜索资料` JSON and Markdown contract.

## Market search

After plot truth is written, use the Chinese title plus verified characters, relationships, and plot terms to search YouTube.

The controller first retrieves YouTube metadata through Agent-Reach's documented
`yt-dlp` backend installed in `/Users/ttggmac-mini/.agent-reach/venv`.
It passes these records as `agent_reach_search` into the existing market-model
call. Missing metadata remains null; the existing web search may supplement it.
Agent-Reach is only an external retrieval component. It does not change plot
truth, output schemas, final-angle selection, downstream stages or model calls.
Do not download video/audio or invoke transcription for this retrieval.

Search priority:

```text
recent 180 days
-> extended 365 days when insufficient
-> older historical evidence when still insufficient
-> story-derived fallback
```

Prefer same-drama or demonstrably same-source videos with strong absolute views or clear performance above the source channel's normal level. Record only metadata actually visible in search results or video pages. Never invent a URL, publication date, view count, title, channel, or performance claim.

For each market video, extract its packaging angle and visual thesis, then verify the claimed event against `01_搜索资料`. Failed matches remain auditable but cannot enter the candidate pool.

Cluster videos selling the same underlying angle before counting verified market angles. Several uploads of one angle count as one market angle.

## Final angles

Select exactly three distinct channel-fit packaging directions as A, B, and C. The current channel language and type may rank verified story angles, but cannot change plot truth.

Use the following fallback:

- 3 or more verified market angles: select three verified directions.
- 2 verified angles: use two verified directions plus one story-derived direction.
- 1 verified angle: use one verified direction plus two story-derived directions.
- 0 verified angles, or search unavailable: derive all three directions from plot truth.

The three directions must compete as materially different packaging propositions, not as wording variants of the same event. Find supplies facts, angle, and visual moment; it does not write final localized titles or final cover prompts.

## Downstream boundary

- Title reads `01_搜索资料` and only `final_angles` from `01_市场包装证据`.
- Title must not rescan `market_videos` or `angle_candidates`.
- Cover, Place, and Post do not read market evidence. They inherit the accepted Title and `packaging_brief`.
- Market search failure must fall back to story-derived angles instead of fabricating evidence.

The machine contract and renderer live in the V14 batch runtime. No V13 file, contract, package, or production batch may be modified by this skill.
