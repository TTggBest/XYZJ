#!/usr/bin/env python3
"""Recoverably delete selected old packages and recreate clean packages.

Dry-run is the default. Apply moves each complete old package into the new
batch archive, then creates a fresh package at the original path. No old
workflow state or creative output is copied into the fresh package.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from deterministic_batch import ContractBundle, load_json, timestamp, write_json  # noqa: E402
from init_batch import (  # noqa: E402
    COMMUNITY_OUTPUT_VERSION,
    build_image_tasks,
    ensure_dirs,
    ensure_prompt_manifest,
    ensure_workflow_state,
    validate_v2_package_path,
    write_channel_asset_snapshot,
    write_channel_snapshot,
    write_package_metadata,
)


# Kept only for compatibility with older callers/tests that imported it.
V7_CONTRACT_ID = "xy-v2-e35930be947c85a9188c"
SCOPE_VERSION = 1
SAFE_BATCH_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,95}$")
SAFE_CONTRACT_ID = re.compile(r"^xy-v14-[0-9a-f]{20}$")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha256_json(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def is_within(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def resolve_under_root(root: Path, raw: str) -> Path:
    path = Path(str(raw or "")).expanduser()
    path = path.resolve() if path.is_absolute() else (root / path).resolve()
    if not is_within(path, root):
        raise ValueError(f"路径越出V2根目录: {path}")
    return path


def load_scope(scope_path: Path) -> dict[str, Any]:
    scope = load_json(scope_path, {})
    if int(scope.get("scope_version") or 0) != SCOPE_VERSION:
        raise ValueError(f"重建范围版本必须为 {SCOPE_VERSION}")
    if str(scope.get("mode") or "") != "clean_recreate":
        raise ValueError("重建范围 mode 必须为 clean_recreate")
    target_contract_id = str(scope.get("target_contract_id") or "")
    if not SAFE_CONTRACT_ID.fullmatch(target_contract_id):
        raise ValueError("目标契约必须是完整的 xy-v14-<20位十六进制> 契约ID")
    batch_id = str(scope.get("batch_id") or "").strip()
    if not SAFE_BATCH_ID.fullmatch(batch_id):
        raise ValueError("batch_id 只能使用3-96位字母、数字、点、下划线或短横线")
    rows = scope.get("items")
    if not isinstance(rows, list) or not rows:
        raise ValueError("重建范围 items 不能为空")
    return scope


def resolve_source_item(root: Path, row: dict[str, Any]) -> dict[str, Any]:
    video_id = str(row.get("video_id") or "").strip()
    output_row = int(row.get("output_row_number") or 0)
    source_output_row = int(row.get("source_output_row_number") or output_row)
    source_row = int(row.get("source_row_number") or 0)
    expected_contract = str(row.get("expected_source_contract_id") or "").strip()
    expected_status = str(row.get("expected_source_status") or "").strip().upper()
    reason = str(row.get("reason") or "").strip()
    if not video_id or output_row < 2:
        raise ValueError(f"重建项缺少有效 video_id/output_row_number: {row}")
    if "expected_source_contract_id" not in row:
        raise ValueError(f"{video_id} 必须声明 expected_source_contract_id；无契约源包显式写空字符串")
    if not expected_contract and expected_status not in {"INITIALIZED", "WRITEBACK_PENDING"}:
        raise ValueError(
            f"{video_id} 无契约源包必须声明 "
            "expected_source_status=INITIALIZED或WRITEBACK_PENDING"
        )
    if not reason:
        raise ValueError(f"{video_id} 必须声明重建原因")

    index_path = resolve_under_root(root, str(row.get("source_index") or ""))
    if index_path.name != "今日任务索引.json" or not index_path.is_file():
        raise ValueError(f"{video_id} source_index 无效: {index_path}")
    source_index = load_json(index_path, {})
    matches = []
    for item in source_index.get("items", []):
        if str(item.get("video_id") or "") != video_id:
            continue
        item_output_row = int(item.get("output_row_number") or 0)
        item_source_row = int(item.get("row_number") or 0)
        if source_row:
            if item_source_row != source_row:
                continue
                if item_output_row and item_output_row != source_output_row:
                    continue
        elif item_output_row != source_output_row:
            continue
        matches.append(item)
    if len(matches) != 1:
        raise ValueError(
            f"{video_id} 无法按剧id+任务表行唯一定位: "
            f"output_row={source_output_row}, source_row={source_row or '-'}, matches={len(matches)}"
        )
    source_item = copy.deepcopy(matches[0])
    source_drama_name = str(source_item.get("drama_name") or "").strip()
    expected_source_drama_name = str(row.get("expected_source_drama_name") or "").strip()
    target_drama_name = str(row.get("target_drama_name") or "").strip()
    identity_correction_requested = (
        "expected_source_drama_name" in row or "target_drama_name" in row
    )
    if identity_correction_requested:
        if not expected_source_drama_name or not target_drama_name:
            raise ValueError(
                f"{video_id} 剧名纠正必须同时声明 "
                "expected_source_drama_name 和 target_drama_name"
            )
        if source_drama_name != expected_source_drama_name:
            raise ValueError(
                f"{video_id} 源剧名不符: expected={expected_source_drama_name}, "
                f"actual={source_drama_name}"
            )
        if target_drama_name == source_drama_name:
            raise ValueError(f"{video_id} 目标剧名与源剧名相同，无需纠正")
    else:
        target_drama_name = source_drama_name
    source_community_count = int(
        source_item.get("community_count") or (1 if source_item.get("need_community") else 0)
    )
    target_community_count = source_community_count
    if "target_community_count" in row:
        if "expected_source_community_count" not in row:
            raise ValueError(
                f"{video_id} 修改社群数量时必须声明 expected_source_community_count"
            )
        expected_source_count = int(row.get("expected_source_community_count"))
        if expected_source_count != source_community_count:
            raise ValueError(
                f"{video_id} 源社群数量不符: expected={expected_source_count}, "
                f"actual={source_community_count}"
            )
        target_community_count = int(row.get("target_community_count"))
        if target_community_count not in {1, 2}:
            raise ValueError(f"{video_id} 目标社群数量只能为1或2")
    package = resolve_under_root(root, str(source_item.get("package_path") or ""))
    validate_v2_package_path(root, package)
    target_package = package.parent / f"{target_drama_name}_{source_item.get('slot') or ''}"
    target_package = target_package.resolve()
    validate_v2_package_path(root, target_package)
    if target_package != package and target_package.exists():
        raise ValueError(f"{video_id} 目标剧目包已存在，禁止覆盖: {target_package}")
    state_path = package / "workflow_state.json"
    if not package.is_dir() or not state_path.is_file():
        raise ValueError(f"{video_id} 源剧目包或 workflow_state.json 不存在: {package}")
    state = load_json(state_path, {})
    actual_contract = str(state.get("contract_id") or "")
    if expected_contract and actual_contract != expected_contract:
        raise ValueError(
            f"{video_id} 源契约不符: expected={expected_contract}, actual={actual_contract}"
        )
    if not expected_contract:
        steps = state.get("steps")
        source_status = str(source_item.get("status") or "").upper()
        claim_only_writeback_failure = (
            expected_status == "WRITEBACK_PENDING"
            and source_status == "WRITEBACK_PENDING"
            and not int(source_item.get("output_row_number") or 0)
            and str(source_item.get("current_stage") or "") == "claim"
            and "Feishu基础字段回写失败" in str(source_item.get("error") or "")
        )
        forbidden_outputs = (
            "01_搜索资料.json", "01_搜索资料.md", "01_市场包装证据.json", "01_市场包装证据.md",
            "04_标题方案.json", "04_标题方案.md",
            "04_封面提示词.json", "04_封面提示词.md", "place_result.json", "place_result.md",
            "06_社群方案.json", "06_社群方案.md", "运营包.md",
        )
        pristine = (
            not actual_contract
            and (
                (expected_status == "INITIALIZED" and source_status == "INITIALIZED")
                or claim_only_writeback_failure
            )
            and str(state.get("status") or "").upper() == "INITIALIZED"
            and str(state.get("package_status") or "").upper() == "INITIALIZED"
            and isinstance(steps, dict)
            and bool(steps)
            and all(value == "pending" for value in steps.values())
            and not any((package / name).exists() for name in forbidden_outputs)
        )
        if not pristine:
            raise ValueError(
                f"{video_id} 无契约源包不是全新 INITIALIZED，"
                "且不是经证明的仅领取回写失败状态，禁止按空契约重建"
            )
    channel_dir = Path(str(source_item.get("channel_dir") or "")).expanduser().resolve()
    if not channel_dir.is_dir():
        raise ValueError(f"{video_id} 频道目录不存在: {channel_dir}")
    return {
        "scope": copy.deepcopy(row),
        "source_index_path": index_path,
        "source_item": source_item,
        "source_package": package,
        "target_package": target_package,
        "source_state": state,
        "source_drama_name": source_drama_name,
        "target_drama_name": target_drama_name,
        "video_id": video_id,
        "output_row_number": output_row,
        "source_output_row_number": source_output_row,
        "source_row_number": int(source_item.get("row_number") or 0),
        "source_status": str(source_item.get("status") or ""),
        "reason": reason,
        "expected_source_contract_id": expected_contract,
        "source_community_count": source_community_count,
        "target_community_count": target_community_count,
        "channel_dir": channel_dir,
    }


def validate_scope(root: Path, scope: dict[str, Any]) -> list[dict[str, Any]]:
    resolved = [resolve_source_item(root, row) for row in scope["items"]]
    identities = [(row["video_id"], row["output_row_number"]) for row in resolved]
    if len(set(identities)) != len(identities):
        raise ValueError("重建范围存在重复的 video_id/output_row_number")
    if len({row["output_row_number"] for row in resolved}) != len(resolved):
        raise ValueError("重建范围存在重复任务表行，禁止多项写入同一行")
    if len({row["source_package"] for row in resolved}) != len(resolved):
        raise ValueError("重建范围存在重复剧目包路径")
    expected_count = int(scope.get("expected_item_count") or len(resolved))
    if expected_count != len(resolved):
        raise ValueError(f"重建项数量不符: expected={expected_count}, actual={len(resolved)}")
    expected_ids = [str(value) for value in scope.get("expected_video_ids", [])]
    if expected_ids and set(expected_ids) != {row["video_id"] for row in resolved}:
        raise ValueError("重建剧id集合与 expected_video_ids 不一致")
    return resolved


def tree_manifest(package: Path) -> dict[str, Any]:
    files = []
    for path in sorted(value for value in package.rglob("*") if value.is_file()):
        files.append(
            {
                "path": path.relative_to(package).as_posix(),
                "size": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return {
        "file_count": len(files),
        "total_bytes": sum(item["size"] for item in files),
        "files": files,
        "manifest_sha256": sha256_json(files),
    }


def clean_recreate_plan(root: Path, scope: dict[str, Any], rows: list[dict[str, Any]]) -> dict[str, Any]:
    batch_id = str(scope["batch_id"])
    batch_dir = root / "批量任务" / batch_id
    items = []
    for row in rows:
        archive = batch_dir / "已删除旧数据" / f"row{row['output_row_number']}_{row['video_id']}" / "package"
        items.append(
            {
                "video_id": row["video_id"],
                "output_row_number": row["output_row_number"],
                "source_output_row_number": row["source_output_row_number"],
                "source_row_number": row["source_row_number"],
                "source_status": row["source_status"],
                "source_contract_id": row["expected_source_contract_id"],
                "source_community_count": row["source_community_count"],
                "target_community_count": row["target_community_count"],
                "source_index": str(row["source_index_path"]),
                "package_path": str(row["source_package"]),
                "target_package_path": str(row["target_package"]),
                "source_drama_name": row["source_drama_name"],
                "target_drama_name": row["target_drama_name"],
                "archive_path": str(archive),
                "fresh_start_stage": "xy-find",
                "reason": row["reason"],
            }
        )
    return {
        "ok": True,
        "dry_run": True,
        "mode": "clean_recreate",
        "scope_version": SCOPE_VERSION,
        "scope_sha256": sha256_json(scope),
        "target_contract_id": str(scope["target_contract_id"]),
        "batch_id": batch_id,
        "batch_dir": str(batch_dir),
        "index_path": str(batch_dir / "今日任务索引.json"),
        "item_count": len(items),
        "items": items,
    }


def channel_row_from_item(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "language": item.get("language", ""),
        "channel_name": item.get("channel", ""),
        "nickname": item.get("nickname", ""),
        "gender": item.get("gender", ""),
        "direction": item.get("direction", ""),
        "channel_dir": item.get("channel_dir", ""),
    }


def build_fresh_package(staged: Path, final_path: Path, row: dict[str, Any], batch_id: str) -> dict[str, Any]:
    source = row["source_item"]
    channel_row = channel_row_from_item(source)
    community_count = int(row["target_community_count"])
    ensure_dirs(staged)
    image_tasks = build_image_tasks(row["video_id"], community_count, final_path)
    item = {
        "row_number": int(source.get("row_number") or 0),
        "output_row_number": row["output_row_number"],
        "drama_name": row["target_drama_name"],
        "video_id": row["video_id"],
        "url": str(source.get("url") or ""),
        "language": str(source.get("language") or ""),
        "channel": str(source.get("channel") or ""),
        "nickname": str(source.get("nickname") or ""),
        "gender": str(source.get("gender") or ""),
        "direction": str(source.get("direction") or ""),
        "channel_input": str(source.get("channel_input") or source.get("channel") or ""),
        "channel_dir": str(row["channel_dir"]),
        "slot": str(source.get("slot") or ""),
        "slot_label": str(source.get("slot_label") or source.get("slot") or ""),
        "need_community": 1 if community_count > 0 else 0,
        "community_output_version": COMMUNITY_OUTPUT_VERSION,
        "community_count": community_count,
        "workflow_contract_version": 2,
        "package_path": str(final_path),
        "prompt_manifest": str(final_path / "images/prompts/出图任务清单.json"),
        "images_raw_dir": str(final_path / "images/raw"),
        "images_final_dir": str(final_path / "images/final"),
        "expected_images": len(image_tasks),
        "status": "INITIALIZED",
        "error": "",
        "image_tasks": image_tasks,
        "writeback_readback_stages": [],
        "clean_recreate": {
            "batch_id": batch_id,
            "source_contract_id": row["expected_source_contract_id"],
            "source_community_count": row["source_community_count"],
            "target_community_count": row["target_community_count"],
            "reason": row["reason"],
            "source_drama_name": row["source_drama_name"],
            "target_drama_name": row["target_drama_name"],
        },
    }
    if isinstance(source.get("creative_slot"), dict):
        item["creative_slot"] = copy.deepcopy(source["creative_slot"])

    source_row = {"剧id": row["video_id"], "地址": item["url"]}
    ensure_workflow_state(
        staged / "workflow_state.json",
        item["drama_name"], item["slot"], item["slot_label"], source_row,
        channel_row, final_path, batch_id, community_count, 2,
    )
    write_channel_snapshot(staged, channel_row)
    write_channel_asset_snapshot(staged, row["channel_dir"])
    write_package_metadata(
        staged,
        {
            "batch_id": batch_id,
            "drama_name": item["drama_name"],
            "video_id": item["video_id"],
            "url": item["url"],
            "slot": item["slot"],
            "slot_label": item["slot_label"],
            "channel": item["channel"],
            "nickname": item["nickname"],
            "language": item["language"],
            "gender": item["gender"],
            "direction": item["direction"],
            "workflow_contract_version": 2,
            "need_community": community_count > 0,
            "community_output_version": COMMUNITY_OUTPUT_VERSION,
            "community_count": community_count,
            "package_path": str(final_path),
            "clean_recreated_from_contract": row["expected_source_contract_id"],
        },
    )
    ensure_prompt_manifest(staged, item, image_tasks)
    return item


def create_migration_batch(root: Path, scope_path: Path, *, apply: bool) -> dict[str, Any]:
    """Compatibility function name; this now performs clean recreation only."""
    root = root.expanduser().resolve()
    scope_path = scope_path.expanduser().resolve()
    if not scope_path.is_file():
        raise ValueError(f"重建范围文件不存在: {scope_path}")
    scope = load_scope(scope_path)
    rows = validate_scope(root, scope)
    plan = clean_recreate_plan(root, scope, rows)
    if not apply:
        return plan

    batch_dir = Path(plan["batch_dir"])
    if batch_dir.exists():
        raise ValueError(f"目标重建批次已存在，禁止覆盖: {batch_dir}")
    token = uuid.uuid4().hex[:12]
    staged_batch = batch_dir.parent / f".{batch_dir.name}.clean-recreate-{token}"
    staged_packages = [
        row["target_package"].parent / f".{row['target_package'].name}.clean-recreate-{token}"
        for row in rows
    ]
    if any(path.exists() for path in staged_packages):
        raise ValueError("发现重建暂存目录冲突，禁止覆盖")

    current_pointer = root / "批量任务/current_batch.json"
    pointer_before = current_pointer.read_bytes() if current_pointer.is_file() else None
    source_index_hashes = {
        str(row["source_index_path"]): sha256_file(row["source_index_path"])
        for row in rows
    }
    manifests = {str(row["source_package"]): tree_manifest(row["source_package"]) for row in rows}
    swaps: list[tuple[Path, Path, Path]] = []
    committed_batch = False
    try:
        staged_batch.mkdir(parents=True, exist_ok=False)
        contracts = ContractBundle(staged_batch)
        contracts.assert_runtime_compatible()
        target_contract_id = str(scope["target_contract_id"])
        if contracts.contract_id != target_contract_id:
            raise ValueError(
                f"当前运行环境与目标冻结契约不符: expected={target_contract_id}, actual={contracts.contract_id}"
            )

        new_items = [
            build_fresh_package(staged, row["target_package"], row, scope["batch_id"])
            for row, staged in zip(rows, staged_packages)
        ]
        records = []
        for row in rows:
            folder = f"row{row['output_row_number']}_{row['video_id']}"
            final_archive = batch_dir / "已删除旧数据" / folder / "package"
            staged_archive = staged_batch / "已删除旧数据" / folder / "package"
            staged_archive.parent.mkdir(parents=True, exist_ok=False)
            record = {
                "video_id": row["video_id"],
                "output_row_number": row["output_row_number"],
                "source_output_row_number": row["source_output_row_number"],
                "source_row_number": row["source_row_number"],
                "source_status": row["source_status"],
                "source_contract_id": row["expected_source_contract_id"],
                "source_community_count": row["source_community_count"],
                "target_community_count": row["target_community_count"],
                "source_index": str(row["source_index_path"]),
                "source_index_sha256": source_index_hashes[str(row["source_index_path"])],
                "original_package_path": str(row["source_package"]),
                "target_package_path": str(row["target_package"]),
                "source_drama_name": row["source_drama_name"],
                "target_drama_name": row["target_drama_name"],
                "archive_path": str(final_archive),
                "archived_tree": manifests[str(row["source_package"])],
                "fresh_start_stage": "xy-find",
                "reason": row["reason"],
            }
            write_json(staged_archive.parent / "归档记录.json", record)
            records.append(record)

        index = {
            "batch_id": scope["batch_id"],
            "created_at": timestamp(),
            "updated_at": timestamp(),
            "status": "active",
            "community_output_version": COMMUNITY_OUTPUT_VERSION,
            "clean_recreate": {
                "scope_version": SCOPE_VERSION,
                "scope_path": str(scope_path),
                "scope_sha256": plan["scope_sha256"],
                "target_contract_id": target_contract_id,
                "source_index_hashes": source_index_hashes,
                "records": records,
            },
            "items": new_items,
        }
        write_json(staged_batch / "今日任务索引.json", index)
        write_json(staged_batch / "全新重建范围.json", scope)
        write_json(staged_batch / "全新重建清单.json", {**plan, "dry_run": False, "records": records})
        lines = [
            "# 删除旧数据后全新创建清单", "",
            f"- 契约：`{target_contract_id}`", f"- 数量：{len(new_items)}",
            f"- Scope SHA-256：`{plan['scope_sha256']}`", "",
        ]
        for item in new_items:
            lines.append(
                f"- 任务表{item['output_row_number']}｜{item['video_id']}｜从 `xy-find` 全新创建｜"
                f"{item['clean_recreate']['reason']}"
            )
        (staged_batch / "全新重建清单.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
        if pointer_before is not None:
            (staged_batch / "重建前_current_batch.json").write_bytes(pointer_before)

        for row, staged in zip(rows, staged_packages):
            archive = staged_batch / "已删除旧数据" / f"row{row['output_row_number']}_{row['video_id']}" / "package"
            os.replace(row["source_package"], archive)
            swaps.append((row["target_package"], archive, row["source_package"]))
            os.replace(staged, row["target_package"])

        for row in rows:
            if sha256_file(row["source_index_path"]) != source_index_hashes[str(row["source_index_path"])]:
                raise RuntimeError(f"源索引在重建中发生变化: {row['source_index_path']}")
            fresh_state = load_json(row["target_package"] / "workflow_state.json", {})
            if fresh_state.get("contract_id") or fresh_state.get("attempts"):
                raise RuntimeError(f"{row['video_id']} 新包仍携带旧契约或尝试次数")
            if any(isinstance(value, dict) for value in fresh_state.get("steps", {}).values()):
                raise RuntimeError(f"{row['video_id']} 新包步骤不是全新pending状态")

        os.replace(staged_batch, batch_dir)
        committed_batch = True
        write_json(
            current_pointer,
            {
                "batch_id": scope["batch_id"],
                "index_path": str(batch_dir / "今日任务索引.json"),
                "contract_id": target_contract_id,
                "clean_recreate_scope_sha256": plan["scope_sha256"],
            },
        )
        return {
            **plan,
            "dry_run": False,
            "created": True,
            "recoverable": True,
            "archive_root": str(batch_dir / "已删除旧数据"),
            "index_path": str(batch_dir / "今日任务索引.json"),
            "contract_snapshot": str(batch_dir / "生产契约快照.json"),
        }
    except Exception:
        archive_root = batch_dir if committed_batch else staged_batch
        for fresh, old_staged_archive, source_package in reversed(swaps):
            archive = archive_root / old_staged_archive.relative_to(staged_batch)
            if fresh.exists():
                shutil.rmtree(fresh)
            if archive.exists():
                os.replace(archive, source_package)
        for path in staged_packages:
            if path.exists():
                shutil.rmtree(path)
        if staged_batch.exists():
            shutil.rmtree(staged_batch)
        if committed_batch and batch_dir.exists():
            shutil.rmtree(batch_dir)
        if pointer_before is None:
            if current_pointer.exists():
                current_pointer.unlink()
        else:
            current_pointer.parent.mkdir(parents=True, exist_ok=True)
            current_pointer.write_bytes(pointer_before)
        raise


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--scope", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    result = create_migration_batch(
        Path(args.root).expanduser().resolve(), Path(args.scope), apply=args.apply
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
