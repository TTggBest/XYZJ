#!/usr/bin/env python3
"""Reconcile audited retry-collision evidence without regenerating content."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from deterministic_batch import append_workflow_event, load_json, timestamp, write_json  # noqa: E402


SAFE_CONTRACT_ID = re.compile(r"^xy-v14-[0-9a-f]{20}$")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha256_json(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def under(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def resolve(root: Path, raw: str) -> Path:
    path = Path(raw).expanduser()
    path = path.resolve() if path.is_absolute() else (root / path).resolve()
    if not under(path, root):
        raise ValueError(f"路径越出V2根目录: {path}")
    return path


def collision_list(values: Any, label: str) -> list[str]:
    if not isinstance(values, list):
        raise ValueError(f"{label} 必须是数组")
    result = [str(value) for value in values]
    if not result or not all("visual_collision_with_history" in value for value in result):
        raise ValueError(f"{label} 只能包含非空历史视觉碰撞错误")
    if len(result) != len(set(result)):
        raise ValueError(f"{label} 存在重复错误")
    return result


def prepare(root: Path, scope_path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    scope = load_json(scope_path, {})
    if int(scope.get("scope_version") or 0) != 1 or scope.get("mode") != "retry_feedback_evidence":
        raise ValueError("证据协调范围必须为 scope_version=1/mode=retry_feedback_evidence")
    contract = str(scope.get("expected_contract_id") or "")
    if not SAFE_CONTRACT_ID.fullmatch(contract):
        raise ValueError("必须固定完整 expected_contract_id")
    index_path = resolve(root, str(scope.get("source_index") or ""))
    expected_index_sha = str(scope.get("expected_source_index_sha256") or "")
    if sha256_file(index_path) != expected_index_sha:
        raise ValueError("源索引SHA不符")
    index = load_json(index_path, {})
    row_number = int(scope.get("output_row_number") or 0)
    video_id = str(scope.get("video_id") or "")
    matches = [
        item for item in index.get("items", [])
        if int(item.get("output_row_number") or 0) == row_number
        and str(item.get("video_id") or "") == video_id
    ]
    if len(matches) != 1:
        raise ValueError("无法按剧id+任务表行唯一定位")
    item = matches[0]
    if str(item.get("status") or "").upper() != "TEXT_READY":
        raise ValueError("只允许协调已TEXT_READY项的证据")
    package = resolve(root, str(item.get("package_path") or ""))
    state_path = package / "workflow_state.json"
    expected_state_sha = str(scope.get("expected_workflow_state_sha256") or "")
    if sha256_file(state_path) != expected_state_sha:
        raise ValueError("workflow_state SHA不符")
    state = load_json(state_path, {})
    if str(state.get("contract_id") or "") != contract:
        raise ValueError("包内契约不符")
    stage = str(scope.get("stage") or "")
    step = state.get("steps", {}).get(stage)
    if not isinstance(step, dict) or step.get("status") != "done":
        raise ValueError("目标节点尚未完成")
    current_history = collision_list(scope.get("current_collision_feedback_history"), "current_collision_feedback_history")
    if set(item.get("retry_feedback_seed") or []) != set(current_history):
        raise ValueError("当前累计账本必须与冻结索引retry_feedback_seed一致")
    raw_cycles = scope.get("cycle_feedback_history")
    if not isinstance(raw_cycles, dict) or not raw_cycles:
        raise ValueError("cycle_feedback_history不能为空")
    cycles = {int(key): collision_list(value, f"cycle_feedback_history.{key}") for key, value in raw_cycles.items()}
    existing_cycles = {
        int(row.get("retry_cycle") or 0)
        for row in step.get("retry_history", []) if isinstance(row, dict)
    }
    if set(cycles) != existing_cycles:
        raise ValueError(f"周期集合不符: expected={sorted(existing_cycles)}, actual={sorted(cycles)}")
    return scope, {
        "scope_sha256": sha256_json(scope),
        "index_path": index_path,
        "item": item,
        "package": package,
        "state_path": state_path,
        "state": state,
        "stage": stage,
        "current_history": current_history,
        "cycles": cycles,
    }


def reconcile(root: Path, scope_path: Path, *, apply: bool) -> dict[str, Any]:
    root = root.expanduser().resolve()
    scope_path = scope_path.expanduser().resolve()
    scope, data = prepare(root, scope_path)
    result = {
        "ok": True,
        "dry_run": not apply,
        "mode": "retry_feedback_evidence",
        "scope_sha256": data["scope_sha256"],
        "video_id": str(data["item"].get("video_id") or ""),
        "output_row_number": int(data["item"].get("output_row_number") or 0),
        "stage": data["stage"],
        "package_path": str(data["package"]),
        "workflow_state_sha256_before": sha256_file(data["state_path"]),
        "current_collision_count": len(data["current_history"]),
        "cycles": {str(key): len(value) for key, value in data["cycles"].items()},
        "content_generation_calls": 0,
        "feishu_writes": 0,
    }
    if not apply:
        return result

    state = copy.deepcopy(data["state"])
    step = state["steps"][data["stage"]]
    step["collision_feedback_history"] = list(data["current_history"])
    for cycle in step.get("retry_history", []):
        number = int(cycle.get("retry_cycle") or 0)
        cycle["collision_feedback_history"] = list(data["cycles"][number])
    step["retry_feedback_evidence_reconciled"] = {
        "scope_sha256": data["scope_sha256"],
        "reconciled_at": timestamp(),
    }
    write_json(data["state_path"], state)
    append_workflow_event(
        data["package"],
        {
            "event": "retry_feedback_evidence_reconciled",
            "actor": "xy-batch-v14",
            "stage": data["stage"],
            "contract_id": str(scope["expected_contract_id"]),
            "scope_sha256": data["scope_sha256"],
            "content_generation_calls": 0,
            "feishu_writes": 0,
        },
    )
    result.update({
        "dry_run": False,
        "applied": True,
        "workflow_state_sha256_after": sha256_file(data["state_path"]),
    })
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--scope", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    result = reconcile(Path(args.root), Path(args.scope), apply=args.apply)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
