#!/usr/bin/env python3
"""Deterministic xy-batch execution engine.

Ten ordinary Python workers own one drama each.  The controller owns Feishu,
state and files.  The model is a JSON-only content function and never receives
filesystem paths or credentials.
"""

from __future__ import annotations

import argparse
import copy
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


WORKSPACE = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube")
SKILLS_ROOT = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
PACK_SCRIPT_DIR = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts"
CANONICAL_OUTPUTS_PATH = PACK_SCRIPT_DIR / "canonical_outputs.py"
if str(PACK_SCRIPT_DIR) not in sys.path:
    sys.path.append(str(PACK_SCRIPT_DIR))

from assemble_package import build_package
from canonical_outputs import STAGE_FILES, cover_rows, first_result, schema_for
from canonical_outputs import normalize_identity, playlists_from_snapshot, public_playlist_urls_in_text, title_rows
from canonical_outputs import normalize_cover_prompt_contract, normalize_place_fixed_footer, normalize_title_recommendation_order, normalize_title_translation_format
from canonical_outputs import cover_group_child_requirements, cover_prompt_quality_observations, title_format_from_snapshot, title_row_requires_minor_child
from canonical_outputs import validate_model_output_schema, validate_payload, visual_history_collision_issues, write_stage_outputs
from drama_library import DramaLibraryClient
from export_daily_tasks import ensure_output_base_row, rewrite_output_base_row, write_stage_back
from market_packaging import (
    MARKET_PACKAGING_SCHEMA,
    build_market_packaging_prompt,
    collect_agent_reach_evidence,
    market_context_for_title,
    validate_market_packaging_evidence,
    write_market_packaging_outputs,
)
from skill_rule_loader import load_community_rule_bundle
from skill_rule_loader import load_cover_rule_bundle
from skill_rule_loader import LANGUAGE_RULE_ALIASES, load_description_rule_bundle
from workflow_contract import (
    CONTRACT_VERSION,
    normalize_status,
    seal_contract_snapshot,
    task_lineage,
    verify_contract_snapshot,
    verify_runtime_sources,
)


SIMULATED_SKILLS = {
    "xy-find": SKILLS_ROOT / "xy-find-v14/references/model_prompt.md",
    "xy-title": SKILLS_ROOT / "xy-title-v14/references/model_prompt.md",
    "xy-cover": SKILLS_ROOT / "xy-cover-v14/references/model_prompt.md",
    "xy-place": SKILLS_ROOT / "xy-place-v14/references/model_prompt.md",
    "xy-post": SKILLS_ROOT / "xy-post-v14/references/model_prompt.md",
}
MACHINE_RULE_PATHS = {
    "xy-title": Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills/xy-title-v14/rules/title_rules.json"),
    "xy-cover": Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills/xy-cover-v14/rules/cover_rules.json"),
    "xy-place": Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills/xy-place-v14/rules/description_rules.json"),
    "xy-post": Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills/xy-post-v14/rules/community_copy_rules.json"),
}
CHANNEL_HASHTAG_WHITELISTS_PATH = Path(
    "/Volumes/TTggg_mini01_2T/CodexData/.codex/skills/xy-place-v14/rules/channel_hashtag_whitelists.json"
)
CONTENT_STAGES = ("xy-title", "xy-cover", "xy-place", "xy-post")
ALL_STAGES = ("xy-find", *CONTENT_STAGES)
MAX_STAGE_ATTEMPTS = 3
MODEL_VISUAL_HISTORY_LIMIT = 32
_CREATIVE_ACCEPT_LOCK = threading.RLock()


def runtime_source_paths() -> dict[str, Path]:
    return {
        "deterministic_batch": Path(__file__).resolve(),
        "init_batch": Path(__file__).resolve().parent / "init_batch.py",
        "export_daily_tasks": Path(__file__).resolve().parent / "export_daily_tasks.py",
        "prepare_controlled_retry": Path(__file__).resolve().parent / "prepare_controlled_retry.py",
        "workflow_contract": Path(__file__).resolve().parent / "workflow_contract.py",
        "market_packaging": Path(__file__).resolve().parent / "market_packaging.py",
        "canonical_outputs": CANONICAL_OUTPUTS_PATH.resolve(),
    }


class WritebackPendingError(RuntimeError):
    """Accepted content is safe; only its external stage write remains pending."""


class SystemStageError(RuntimeError):
    """Deterministic contract/runtime failure that must not spend creative retries."""


CHANNEL_GENERATION_SPEC_SECTION_ORDER = (
    "GLOBAL",
    "TITLE",
    "COVER",
    "DESCRIPTION",
    "HASHTAG",
    "COMMUNITY",
    "PLAYLIST",
)
CHANNEL_GENERATION_SPEC_SECTION_PATTERN = re.compile(
    r"^## \[(GLOBAL|TITLE|COVER|DESCRIPTION|HASHTAG|COMMUNITY|PLAYLIST)\][ \t]*$",
    re.MULTILINE,
)
CHANNEL_SNAPSHOT_SOURCE_PATTERN = re.compile(r"^## 来源：", re.MULTILINE)


def channel_generation_spec_sections(snapshot: str) -> dict[str, str]:
    """Parse the one channel execution spec embedded in a frozen snapshot."""
    matches = list(CHANNEL_GENERATION_SPEC_SECTION_PATTERN.finditer(snapshot))
    names = [match.group(1) for match in matches]
    for name in CHANNEL_GENERATION_SPEC_SECTION_ORDER:
        count = names.count(name)
        if count == 0:
            raise SystemStageError(f"preflight_channel_generation_spec_section_missing:{name}")
        if count > 1:
            raise SystemStageError(f"preflight_channel_generation_spec_section_duplicate:{name}")
    if tuple(names) != CHANNEL_GENERATION_SPEC_SECTION_ORDER:
        raise SystemStageError("preflight_channel_generation_spec_section_order_invalid")

    sections: dict[str, str] = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(snapshot)
        if index + 1 == len(matches):
            next_source = CHANNEL_SNAPSHOT_SOURCE_PATTERN.search(snapshot, match.end())
            if next_source:
                end = next_source.start()
        sections[match.group(1)] = snapshot[match.start():end].rstrip() + "\n"
    return sections


def title_channel_context(snapshot: str) -> str:
    if not CHANNEL_GENERATION_SPEC_SECTION_PATTERN.search(snapshot):
        # Current production channel specs use numbered headings. Extract only
        # identity and Title rules; never substitute the whole snapshot.
        source = re.search(r"^## 来源：[^\n]*_生成规范\.md[ \t]*$", snapshot, re.MULTILINE)
        spec = snapshot[source.end():] if source else snapshot
        next_source = CHANNEL_SNAPSHOT_SOURCE_PATTERN.search(spec)
        if next_source:
            spec = spec[:next_source.start()]
        headings = list(re.finditer(r"^## [^\n]+$", spec, re.MULTILINE))
        selected = []
        for label in ("频道生成定位", "标题生成规则"):
            found = [i for i, h in enumerate(headings)
                     if re.fullmatch(r"## \d+\. " + label + r"[ \t]*", h.group())]
            if len(found) != 1:
                raise SystemStageError(f"preflight_channel_generation_spec_numbered_section_invalid:{label}")
            i = found[0]
            end = headings[i + 1].start() if i + 1 < len(headings) else len(spec)
            selected.append(spec[headings[i].start():end].rstrip())
        return "\n\n".join(selected) + "\n"
    sections = channel_generation_spec_sections(snapshot)
    return sections["GLOBAL"].rstrip() + "\n\n" + sections["TITLE"].rstrip() + "\n"


def failure_result_for_exception(exc: Exception) -> dict[str, str]:
    if isinstance(exc, WritebackPendingError):
        status = "WRITEBACK_PENDING"
        error_type = "SYSTEM_ERROR"
    elif isinstance(exc, SystemStageError):
        status = "SYSTEM_ERROR"
        error_type = "SYSTEM_ERROR"
    else:
        status = "NEEDS_USER_REVIEW"
        error_type = "CONTENT_ERROR"
    return {"status": status, "error_type": error_type, "error": str(exc)}


def system_validation_issues(issues: list[str]) -> list[str]:
    """Select schema/controller faults that must never be repaired by creative AI."""
    markers = (
        "_unexpected",
        "_required",
        "_must_be_",
        "_final_prompt_",
        "_16_9_execution_contract_missing",
        "_prompt_4_5_missing_Chinese_actors",
        "_prompt_4_5_missing_Chinese_facial_features",
        "_prompt_4_5_missing_East_Asian_appearance",
        "_prompt_4_5_core_words_not_non_diegetic_typography",
        "_prompt_4_5_core_words_not_visually_salient",
    )
    issue_texts = [str(issue) for issue in issues]
    model_owned_scene_blocks = {
        match.groups()
        for issue in issue_texts
        if (match := re.fullmatch(
            r"cover_(\d+)_scene_prompt_contains_controller_owned_(identity|style|typography|salience)",
            issue,
        ))
    }
    system_issues: list[str] = []
    for issue in issue_texts:
        block_count = re.fullmatch(
            r"cover_(\d+)_final_prompt_(identity|style|typography|salience)_block_count_\d+",
            issue,
        )
        if block_count and block_count.groups() in model_owned_scene_blocks:
            continue
        if any(marker in issue for marker in markers):
            system_issues.append(issue)
    return system_issues

THEME_PROFILES = {
    "萌宝家庭": {
        "audience_promise": "children, parent-child identity, family recognition, protection, warmth, and reunion",
        "required_plot_signals": ("孩子", "萌宝", "宝宝", "双宝", "双胞胎", "儿童", "小孩", "男孩", "女孩", "幼儿", "亲子"),
        "required_output_signals": ("孩子", "萌宝", "宝宝", "双宝", "双胞胎", "儿童", "小孩", "男孩", "女孩", "幼儿", "亲子"),
    },
    "豪门婚恋": {
        "audience_promise": "wealthy-family romance, marriage pressure, heir identity, relationship choice, and emotional reversal",
        "required_plot_signals": ("豪门", "总裁", "继承", "财阀", "集团", "董事长", "少爷", "千金", "婚姻", "结婚", "离婚", "复婚"),
        "required_output_signals": ("豪门", "总裁", "继承", "财阀", "集团", "董事长", "少爷", "千金", "婚姻", "结婚", "离婚", "复婚"),
    },
    "复仇逆袭": {
        "audience_promise": "betrayal, humiliation, comeback, counterattack, exposed lies, and regained agency",
        "required_plot_signals": ("复仇", "逆袭", "背叛", "陷害", "羞辱", "反击", "重生", "报复", "翻身"),
        "required_output_signals": ("复仇", "逆袭", "背叛", "陷害", "羞辱", "反击", "重生", "报复", "翻身"),
    },
    "甜宠": {
        "audience_promise": "mutual attraction, affectionate protection, romantic trust, and a warm relationship payoff",
        "required_plot_signals": ("甜宠", "心动", "恋爱", "相爱", "告白", "暗恋", "宠爱", "情侣"),
        "required_output_signals": ("甜宠", "心动", "恋爱", "相爱", "告白", "暗恋", "宠爱", "情侣"),
    },
}

def timestamp() -> str:
    return datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %z")


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def append_workflow_event(package: Path, event: dict[str, Any]) -> None:
    """Append an immutable workflow transition without rewriting prior evidence."""
    payload = {"created_at": timestamp(), **event}
    path = package / "workflow_events.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")


def resolve_index(root: Path, index_arg: str) -> Path:
    if index_arg:
        return Path(index_arg).expanduser().resolve()
    pointer = root / "批量任务/current_batch.json"
    data = load_json(pointer, {})
    index_path = str(data.get("index_path") or "").strip()
    if not index_path:
        raise SystemExit(f"缺少当前批次指针: {pointer}")
    path = Path(index_path).expanduser()
    return path.resolve() if path.is_absolute() else (WORKSPACE / path).resolve()


class ContractBundle:
    """Load once per batch so an in-flight batch cannot drift with file edits."""

    def __init__(self, batch_dir: Path, *, persist_if_missing: bool = True) -> None:
        self.path = batch_dir / "生产契约快照.json"
        if self.path.exists():
            snapshot = load_json(self.path, {})
        else:
            rules = {}
            machine_contracts = {}
            schema_contracts = {}
            stage_directives = {}
            for stage, path in MACHINE_RULE_PATHS.items():
                raw = path.read_text(encoding="utf-8")
                content = json.loads(raw)
                source_paths = [str(path)]
                hash_material = raw
                if stage == "xy-place":
                    whitelist_raw = CHANNEL_HASHTAG_WHITELISTS_PATH.read_text(encoding="utf-8")
                    content["channel_hashtag_whitelists"] = json.loads(whitelist_raw)
                    source_paths.append(str(CHANNEL_HASHTAG_WHITELISTS_PATH))
                    hash_material = raw + "\n" + whitelist_raw
                machine_contracts[stage] = {
                    "source_path": str(path),
                    "source_paths": source_paths,
                    "sha256": hashlib.sha256(hash_material.encode("utf-8")).hexdigest(),
                    "content": content,
                }
            for stage, path in SIMULATED_SKILLS.items():
                content = path.read_text(encoding="utf-8")
                machine_sha = str(machine_contracts.get(stage, {}).get("sha256") or "")
                rules[stage] = {
                    "source_path": str(path),
                    "sha256": hashlib.sha256((content + "\n" + machine_sha).encode("utf-8")).hexdigest(),
                    "content": content,
                }
            for stage in CONTENT_STAGES:
                schema = schema_for(stage, {
                    "workflow_contract_version": 2,
                    "community_output_version": 2,
                    "community_count": 1,
                    "need_community": 1,
                })
                raw_schema = json.dumps(schema, ensure_ascii=False, sort_keys=True)
                schema_contracts[stage] = {
                    "sha256": hashlib.sha256(raw_schema.encode("utf-8")).hexdigest(),
                    "content": schema,
                }
            for stage, directive in STAGE_DIRECTIVES.items():
                stage_directives[stage] = {
                    "sha256": hashlib.sha256(directive.encode("utf-8")).hexdigest(),
                    "content": directive,
                }
            runtime_sources = {}
            for name, path in runtime_source_paths().items():
                raw = path.read_bytes()
                runtime_sources[name] = {"source_path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}
            snapshot = {
                "version": CONTRACT_VERSION,
                "created_at": timestamp(),
                "rules": rules,
                "machine_contracts": machine_contracts,
                "schema_contracts": schema_contracts,
                "stage_directives": stage_directives,
                "semantic_contract": {
                    "version": CONTRACT_VERSION,
                    "dynamic_channel_theme_grounding_required": True,
                    "fixed_localized_title_candidates": False,
                },
                "visual_review_contract": {
                    "version": 2,
                    "enabled": False,
                    "xy_sort_behavior": "filename_routing_only_no_image_review",
                },
                "regeneration_contract": {
                    "version": 2,
                    "enabled": False,
                    "xy_sort_behavior": "no_rejection_and_no_auxiliary_retry_queue",
                },
                "state_machine_contract": {
                    "version": 1,
                    "package_ready_requires_all_declared_assets": True,
                    "delivered_requires": ["logos", "delivery_manifest", "writeback_readback"],
                    "legacy_done_maps_to": "TEXT_READY",
                },
                "runtime_sources": runtime_sources,
            }
            snapshot = seal_contract_snapshot(snapshot)
            if persist_if_missing:
                write_json(self.path, snapshot)
        if not snapshot.get("contract_id"):
            digest_input = json.dumps(
                {
                    "rules": {key: value.get("sha256", "") for key, value in snapshot.get("rules", {}).items()},
                    "machine": {key: value.get("sha256", "") for key, value in snapshot.get("machine_contracts", {}).items()},
                },
                sort_keys=True,
                ensure_ascii=False,
            )
            snapshot["contract_id"] = "xy-v14-legacy-" + hashlib.sha256(digest_input.encode("utf-8")).hexdigest()[:16]
        self.snapshot = snapshot
        try:
            verify_contract_snapshot(snapshot)
        except ValueError as exc:
            raise RuntimeError(f"生产契约快照完整性失败: {exc}") from exc
        self.rules = {stage: str(row.get("content") or "") for stage, row in snapshot.get("rules", {}).items()}
        missing = [stage for stage in ALL_STAGES if not self.rules.get(stage)]
        if missing:
            raise RuntimeError("生产契约快照缺少: " + ", ".join(missing))

    def sha(self, stage: str) -> str:
        return str(self.snapshot.get("rules", {}).get(stage, {}).get("sha256") or "")

    def machine(self, stage: str) -> dict[str, Any]:
        row = self.snapshot.get("machine_contracts", {}).get(stage, {})
        content = row.get("content") if isinstance(row, dict) else None
        return content if isinstance(content, dict) else {}

    def schema(self, stage: str, item: dict[str, Any]) -> dict[str, Any]:
        row = self.snapshot.get("schema_contracts", {}).get(stage, {})
        content = row.get("content") if isinstance(row, dict) else None
        if not isinstance(content, dict):
            return schema_for(stage, item)
        schema = copy.deepcopy(content)
        if stage == "xy-post":
            count = int(item.get("community_count", 1 if item.get("need_community") else 0) or 0)
            schema["properties"]["results"]["minItems"] = count
            schema["properties"]["results"]["maxItems"] = count
        return schema

    def directive(self, stage: str) -> str:
        row = self.snapshot.get("stage_directives", {}).get(stage, {})
        content = row.get("content") if isinstance(row, dict) else None
        return str(content) if content else STAGE_DIRECTIVES[stage]

    def semantic(self) -> dict[str, Any]:
        value = self.snapshot.get("semantic_contract")
        return dict(value) if isinstance(value, dict) else {}

    def assert_runtime_compatible(self) -> None:
        """Fail closed instead of silently changing semantics inside a batch."""
        try:
            verify_contract_snapshot(self.snapshot)
        except ValueError as exc:
            raise RuntimeError(f"生产契约快照完整性失败: {exc}") from exc
        try:
            verify_runtime_sources(self.snapshot)
        except (OSError, ValueError) as exc:
            raise RuntimeError(f"批次运行代码已变化，禁止漂移续跑: {exc}") from exc
        if int(self.snapshot.get("version") or 0) >= CONTRACT_VERSION:
            return
        frozen = self.snapshot.get("runtime_sources")
        if not isinstance(frozen, dict) or not frozen:
            return
        current_paths = runtime_source_paths()
        mismatches = []
        for name, path in current_paths.items():
            expected = str((frozen.get(name) or {}).get("sha256") or "")
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if not expected or actual != expected:
                mismatches.append(name)
        if mismatches:
            raise RuntimeError("批次运行代码已变化，禁止用漂移后的生成/验证器续跑: " + ", ".join(mismatches))

    @property
    def contract_id(self) -> str:
        return str(self.snapshot.get("contract_id") or "")


def channel_theme_contract(item: dict[str, Any], plot_payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build the shared channel-semantic contract used by every creative stage."""
    nickname = str(item.get("nickname") or "").strip()
    parts = [part.strip() for part in nickname.split("-") if part.strip()]
    direction = str(item.get("direction") or (parts[-1] if parts else "")).strip()
    gender = str(item.get("gender") or (parts[-2] if len(parts) >= 2 else "")).strip()
    profile = THEME_PROFILES.get(direction, {})
    plot_result = first_result(plot_payload or {})
    plot_fields = plot_result.get("plot_fields") if isinstance(plot_result.get("plot_fields"), dict) else {}
    plot_text = "\n".join(
        str(plot_fields.get(key) or "")
        for key in ("内容概述", "剧情档案", "剧情套路", "核心人设")
    )
    def positively_present(term: str) -> bool:
        start = 0
        while True:
            index = plot_text.find(term, start)
            if index < 0:
                return False
            prefix = plot_text[max(0, index - 10):index]
            if not re.search(r"(?:没有|并无|不存在|未出现|不是|不含|无)[^，。；：]{0,6}$", prefix):
                return True
            start = index + len(term)

    found = [term for term in profile.get("required_plot_signals", ()) if positively_present(term)]
    return {
        "channel_direction": direction,
        "channel_gender": gender,
        "audience_promise": str(profile.get("audience_promise") or direction),
        "plot_supported": bool(found),
        "plot_support_signals": found[:12],
        "required_output_signals": list(profile.get("required_output_signals", ())),
        "truth_rule": "use_only_verified_plot_facts_and_never_invent_theme_evidence",
        "same_channel_rule": "theme_consistent_creative_distinct",
        "cross_channel_rule": "channel_direction_must_change_packaging_angle",
    }


def allocate_creative_slots(
    index: dict[str, Any],
    historical_indices: list[dict[str, Any]] | None = None,
) -> None:
    """Assign stable identities without prescribing any creative answer.

    An accepted historical slot is preserved byte-for-byte for resumability.
    New work receives only an identity and a generation policy; scene, action,
    composition, prop, reaction, and wording remain model-owned free creation.
    """
    rows = [
        item for item in index.get("items", [])
        if int(item.get("workflow_contract_version") or 1) >= 2
    ]
    ordered = sorted(rows, key=lambda row: (
        str(row.get("channel") or ""), str(row.get("drama_name") or ""),
        str(row.get("language") or ""), str(row.get("slot") or ""),
    ))
    # A continuation of the exact same channel × drama × slot is the same
    # creative unit. Preserve its frozen slot so accepted upstream artifacts
    # remain valid under a new batch contract; only genuinely new tasks are
    # allocated away from history.
    prior_slots: dict[tuple[str, str, str], dict[str, Any]] = {}
    for prior_index in historical_indices or []:
        for prior in prior_index.get("items", []):
            slot = prior.get("creative_slot") if isinstance(prior.get("creative_slot"), dict) else {}
            if not slot.get("creative_slot_id"):
                continue
            identity = (
                str(prior.get("drama_name") or ""),
                str(prior.get("channel") or ""),
                str(prior.get("slot") or ""),
            )
            prior_slots.setdefault(identity, copy.deepcopy(slot))
    for item in ordered:
        if isinstance(item.get("creative_slot"), dict) and item["creative_slot"].get("creative_slot_id"):
            continue
        identity = (
            str(item.get("drama_name") or ""),
            str(item.get("channel") or ""),
            str(item.get("slot") or ""),
        )
        if identity in prior_slots:
            item["creative_slot"] = copy.deepcopy(prior_slots[identity])
    for ordinal, item in enumerate(ordered, 1):
        if isinstance(item.get("creative_slot"), dict) and item["creative_slot"].get("creative_slot_id"):
            continue
        direction = str(item.get("direction") or channel_theme_contract(item).get("channel_direction") or "")
        raw = f"{item.get('drama_name', '')}|{item.get('channel', '')}|{item.get('language', '')}|{ordinal}"
        item["creative_slot"] = {
            "creative_slot_id": "slot-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12],
            "allocation_ordinal": ordinal,
            "channel_direction": direction,
            "creative_answer_policy": "fresh_model_creation_no_candidate_library",
            "truth_rule": "fresh_title_specific_creation_with_no_reusable_candidate_answers",
        }


def historical_creative_slot_indices(index_path: Path) -> list[dict[str, Any]]:
    """Read prior batch indexes as negative allocation history; never mutate them."""
    batch_root = index_path.parent.parent
    rows = []
    for candidate in sorted(batch_root.glob("*/今日任务索引.json")):
        if candidate.resolve() == index_path.resolve():
            continue
        payload = load_json(candidate, {})
        if isinstance(payload, dict) and isinstance(payload.get("items"), list):
            rows.append(payload)
    return rows


def resolved_community_footer_cta(
    context: dict[str, Any], machine_contract: dict[str, Any]
) -> dict[str, Any]:
    task = context.get("task") if isinstance(context.get("task"), dict) else {}
    language = str(task.get("language") or "").strip()
    defaults = machine_contract.get("channel_cta_defaults_by_language", {}).get(language, {})
    current = context.get("community_footer_cta")
    current = dict(current) if isinstance(current, dict) else {}
    resolved = {**defaults, **current}
    resolved.setdefault("layout_style", str(machine_contract.get("default_cta_layout_style") or "dual_pill_black_yellow"))
    resolved["language"] = language
    resolved["source"] = "batch_frozen_community_contract"
    return resolved


def _render_frozen_values(value: Any, channel_name: str) -> Any:
    if isinstance(value, str):
        return value.replace("{channel_name}", channel_name)
    if isinstance(value, list):
        return [_render_frozen_values(item, channel_name) for item in value]
    if isinstance(value, dict):
        return {key: _render_frozen_values(item, channel_name) for key, item in value.items()}
    return value


def resolved_description_assets(context: dict[str, Any], machine_contract: dict[str, Any]) -> dict[str, Any]:
    task = context.get("task") if isinstance(context.get("task"), dict) else {}
    language = str(task.get("language") or "").strip()
    channel = str(task.get("channel") or "").strip()
    alias = LANGUAGE_RULE_ALIASES.get(language, language)
    asset_defaults = machine_contract.get("fixed_assets_defaults", {})
    if alias not in asset_defaults:
        raise RuntimeError(f"description_fixed_assets_language_missing:{language}")
    defaults = asset_defaults[alias]
    defaults = _render_frozen_values(defaults, channel)
    resolved = {
        "version": int(machine_contract.get("version") or 1),
        "source": "batch_frozen_description_contract",
        "language": language,
        "channel_name": channel,
        **defaults,
    }
    return resolved


def resolved_channel_hashtag_whitelist(
    context: dict[str, Any], machine_contract: dict[str, Any]
) -> dict[str, Any]:
    task = context.get("task") if isinstance(context.get("task"), dict) else {}
    channel = str(task.get("channel") or "").strip()
    asset = machine_contract.get("channel_hashtag_whitelists")
    channels = asset.get("channels") if isinstance(asset, dict) else None
    if not isinstance(channels, dict) or channel not in channels:
        raise SystemStageError(f"channel_hashtag_whitelist_missing:{channel}")
    row = channels.get(channel)
    candidates = row.get("additional_whitelist") if isinstance(row, dict) else None
    target_language_tags = row.get("target_language_tags") if isinstance(row, dict) else None
    mandatory = list(asset.get("mandatory_hashtags") or [])
    selection_count = int(asset.get("selection_count") or 12)
    additional_count = int(asset.get("additional_selection_count") or 11)
    if len(mandatory) != selection_count - additional_count:
        raise SystemStageError(f"channel_hashtag_contract_count_invalid:{channel}")
    if not isinstance(candidates, list) or len(candidates) < additional_count:
        actual = len(candidates) if isinstance(candidates, list) else 0
        raise SystemStageError(
            f"channel_hashtag_whitelist_insufficient:{channel}:{actual}<{additional_count}"
        )
    if (
        not isinstance(target_language_tags, list)
        or not target_language_tags
        or any(tag not in candidates for tag in target_language_tags)
    ):
        raise SystemStageError(f"channel_target_language_hashtag_asset_invalid:{channel}")
    return {
        "version": int(asset.get("version") or 1),
        "source": str(asset.get("source") or ""),
        "channel_name": channel,
        "mandatory_hashtags": mandatory,
        "selection_count": selection_count,
        "additional_selection_count": additional_count,
        "additional_candidates": list(candidates),
        "target_language_tags": list(target_language_tags),
        "selection_contract": {
            "exact_channel_match_required": True,
            "additional_hashtags_must_come_from_current_channel_whitelist": True,
            "cross_channel_borrowing_forbidden": True,
            "invent_translate_concatenate_respell_forbidden": True,
            "require_channel_theme_and_drama_content_relevance": True,
            "cdrama_position": 3,
            "target_language_tag_required_within_positions": [1, 2],
            "target_language_qualification_is_asset_owned": True,
        },
    }


def completion_status_for_images(image_status: str) -> str:
    # Text production never owns image acceptance. Only xy-sort-v14 may advance
    # TEXT_READY to IMAGE_PARTIAL or PACKAGE_READY from verified real assets.
    return "TEXT_READY"


def load_contract_bundle(batch_dir: Path, *, persist_if_missing: bool = True) -> ContractBundle:
    return ContractBundle(batch_dir, persist_if_missing=persist_if_missing)


def stage_preflight_issues(
    stage: str,
    context: dict[str, Any],
    machine_contract: dict[str, Any],
) -> list[str]:
    """Reject deterministic contract/context faults before spending a model call."""
    issues: list[str] = []
    task = context.get("task") if isinstance(context.get("task"), dict) else {}
    if int(task.get("workflow_contract_version") or 1) < 2:
        return []
    if stage in CONTENT_STAGES and not machine_contract:
        issues.append(f"preflight_{stage}_frozen_machine_contract_missing")
    if stage == "xy-title":
        try:
            title_channel_context(str(context.get("channel_snapshot") or ""))
        except SystemStageError as exc:
            issues.append(str(exc))
        market = context.get("market_packaging") if isinstance(context.get("market_packaging"), dict) else {}
        final_angles = market.get("final_angles") if isinstance(market.get("final_angles"), list) else []
        if [str(row.get("angle_id") or "") for row in final_angles if isinstance(row, dict)] != ["A", "B", "C"]:
            issues.append("preflight_market_packaging_final_angles_missing")
    theme = context.get("channel_theme_contract") if isinstance(context.get("channel_theme_contract"), dict) else {}
    if not str(theme.get("channel_direction") or "").strip():
        issues.append("preflight_channel_direction_missing")
    plot = context.get("plot_payload") if isinstance(context.get("plot_payload"), dict) else {}
    if not plot.get("results"):
        issues.append("preflight_plot_payload_missing")
    if stage in {"xy-cover", "xy-place", "xy-post"}:
        title = first_result(context.get("title_payload") if isinstance(context.get("title_payload"), dict) else {})
        if not isinstance(title.get("packaging_brief"), dict):
            issues.append("preflight_packaging_brief_missing")
    if stage == "xy-post":
        footer = context.get("community_footer_cta") if isinstance(context.get("community_footer_cta"), dict) else {}
        if not all(str(footer.get(key) or "").strip() for key in (
            "full_video_cta", "subscribe_cta", "share_cta", "layout_style"
        )):
            issues.append("preflight_community_fixed_cta_incomplete")
    if stage == "xy-place":
        description_contract = machine_contract.get("description_contract")
        description_contract = description_contract if isinstance(description_contract, dict) else {}
        playlists = context.get("playlists")
        if not isinstance(playlists, list) or not playlists:
            issues.append("preflight_channel_registered_playlist_missing")
        if description_contract.get("channel_hashtag_whitelist_required"):
            evidence = context.get("channel_hashtag_whitelist")
            candidates = evidence.get("additional_candidates") if isinstance(evidence, dict) else None
            if not candidates:
                issues.append("preflight_channel_hashtag_whitelist_missing")
    return issues


def with_frozen_machine_contract(
    context: dict[str, Any], contracts: ContractBundle, stage: str
) -> dict[str, Any]:
    machine = contracts.machine(stage)
    context["output_schema"] = contracts.schema(stage, context.get("task") or {})
    context["semantic_contract"] = contracts.semantic()
    if not machine:
        if stage == "xy-title":
            context["title_rule_contract"] = {}
        elif stage == "xy-cover":
            context["cover_rule_contract"] = {}
        elif stage == "xy-post":
            context["community_rule_contract"] = {}
        elif stage == "xy-place":
            context["description_rule_contract"] = {}
        return context
    if stage == "xy-title":
        context["title_rule_contract"] = machine.get("title_contract", {})
    elif stage == "xy-cover":
        context["cover_rule_contract"] = machine
    elif stage == "xy-post":
        context["community_rule_contract"] = machine
        context["community_footer_cta"] = resolved_community_footer_cta(context, machine)
    elif stage == "xy-place":
        context["description_rule_contract"] = machine.get("description_contract", {})
        context["description_fixed_assets"] = resolved_description_assets(context, machine)
        context["description_assets_frozen"] = True
        if context["description_rule_contract"].get("channel_hashtag_whitelist_required"):
            context["channel_hashtag_whitelist"] = resolved_channel_hashtag_whitelist(context, machine)
    return context


class JsonModelClient:
    def __init__(self, codex_bin: str, model: str, timeout: int, logs_dir: Path) -> None:
        self.codex_bin = codex_bin
        self.model = model
        self.timeout = timeout
        self.logs_dir = logs_dir
        self.logs_dir.mkdir(parents=True, exist_ok=True)

    def generate(
        self,
        stage: str,
        prompt: str,
        item: dict[str, Any],
        attempt: int,
        output_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        retry_cycle = max(1, int(item.get("current_retry_cycle") or 1))
        stem = (
            f"row{item.get('row_number', 'x')}_{item.get('video_id', 'unknown')}_"
            f"{stage}_cycle{retry_cycle}_attempt{attempt}"
        )
        prompt_log = self.logs_dir / f"{stem}.prompt.txt"
        result_log = self.logs_dir / f"{stem}.result.json"
        prompt_log.write_text(prompt, encoding="utf-8")
        with tempfile.TemporaryDirectory(prefix="xy-content-") as temp_name:
            temp_dir = Path(temp_name)
            schema_path = temp_dir / "schema.json"
            output_path = temp_dir / "result.json"
            schema_path.write_text(
                json.dumps(output_schema or schema_for(stage, item), ensure_ascii=False),
                encoding="utf-8",
            )
            command = [
                self.codex_bin,
                "--ask-for-approval",
                "never",
                "exec",
                "--ignore-user-config",
                "--ignore-rules",
                "--sandbox",
                "read-only",
                "--cd",
                str(temp_dir),
                "--ephemeral",
                "--skip-git-repo-check",
                "--output-schema",
                str(schema_path),
                "--output-last-message",
                str(output_path),
            ]
            if self.model:
                command.extend(["--model", self.model])
            if stage == "xy-find-market":
                command.extend(["--enable", "standalone_web_search"])
            command.extend(["--", prompt])
            completed = subprocess.run(
                command,
                text=True,
                capture_output=True,
                timeout=self.timeout,
                cwd=str(temp_dir),
            )
            if completed.returncode != 0:
                detail = (completed.stderr or completed.stdout or "").strip()
                raise RuntimeError(f"内容模型退出 {completed.returncode}: {detail[-1200:]}")
            if not output_path.exists():
                raise RuntimeError("内容模型没有返回JSON")
            raw = output_path.read_text(encoding="utf-8", errors="ignore").strip()
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"内容模型返回的不是有效JSON: {exc}") from exc
        write_json(result_log, payload)
        return payload


def item_identity(item: dict[str, Any]) -> dict[str, Any]:
    video_id = str(item.get("video_id") or "")
    return {
        "search_result_index": 1,
        "source_block_label": "搜索资料1",
        "result_id": f"{video_id}_1" if video_id else f"{item.get('slot', '')}_1",
        "video_id": video_id,
        "drama_name": str(item.get("drama_name") or ""),
    }


def read_optional_json(path: Path) -> dict[str, Any]:
    return load_json(path, {}) if path.exists() else {}


VISUAL_FINGERPRINT_KEYS = (
    "scene_family",
    "main_action",
    "key_prop",
    "composition",
    "palette",
    "lighting",
)


def _v2_root(package: Path) -> Path:
    for parent in (package, *package.parents):
        if parent.name == "V2" and parent.parent.name == "工作流实验室":
            return parent
    return package.parents[4]


def visual_history_for(
    package: Path, item: dict[str, Any], limit: int | None = None
) -> list[dict[str, str]]:
    """Return the shared semantic-history contract for generation and validation.

    This is prompt/JSON history only.  It deliberately excludes image files and
    It prioritizes the same drama, then same channel, then recency and never
    mutates historical packages. Actual-image similarity still scans the full
    accepted image registry later in xy-sort-v14.
    """
    root = _v2_root(package)
    candidates: list[tuple[int, float, dict[str, str]]] = []
    current_channel = str(item.get("channel") or "")
    current_drama = str(item.get("drama_name") or "")
    for path in root.glob("*/*/剧目/*/04_封面提示词.json"):
        try:
            if path.parent.resolve() == package.resolve():
                continue
            payload = load_json(path, {})
            result = first_result(payload)
            prior_channel = path.parents[2].name
            for source_group_index, row in enumerate(cover_rows(payload), 1):
                fingerprint = {key: str(row.get(key) or "").strip() for key in VISUAL_FINGERPRINT_KEYS}
                if not all(fingerprint.values()):
                    continue
                fingerprint.update(
                    {
                        "channel": prior_channel,
                        "drama_name": str(result.get("drama_name") or path.parent.name),
                        "video_id": str(result.get("video_id") or ""),
                        "source_group_index": str(source_group_index),
                    }
                )
                prior_drama = str(result.get("drama_name") or path.parent.name)
                priority = 0 if prior_drama == current_drama else (1 if prior_channel == current_channel else 2)
                candidates.append((priority, path.stat().st_mtime, fingerprint))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
    candidates.sort(key=lambda row: (row[0], -row[1]))
    rows = [row[2] for row in candidates]
    return rows[:limit] if limit is not None else rows


def creative_history_for(package: Path, item: dict[str, Any]) -> list[dict[str, Any]]:
    """Load accepted marketing outputs for this drama from every other package.

    Objective plot facts are intentionally excluded.  The returned material is
    used only as a negative creative reference, so a channel cannot receive a
    translated or lightly reworded version of another channel's operating pack.
    """
    root = _v2_root(package)
    wanted = str(item.get("drama_name") or "").strip()
    rows: list[tuple[float, dict[str, Any]]] = []
    stage_files = {
        "title_payload": "04_标题方案.json",
        "cover_payload": "04_封面提示词.json",
        "place_payload": "place_result.json",
        "post_payload": "06_社群方案.json",
    }
    for candidate in root.glob("*/*/剧目/*"):
        try:
            if not candidate.is_dir() or candidate.resolve() == package.resolve():
                continue
            payloads = {
                key: load_json(candidate / filename, {})
                for key, filename in stage_files.items()
                if (candidate / filename).exists()
            }
            if not payloads:
                continue
            result_names = {
                str(first_result(payload).get("drama_name") or "").strip()
                for payload in payloads.values()
                if first_result(payload)
            }
            metadata = read_optional_json(candidate / "剧目元数据.json")
            candidate_name = str(metadata.get("drama_name") or "").strip()
            if not candidate_name:
                candidate_name = next((name for name in result_names if name), candidate.name.rsplit("_", 1)[0])
            if candidate_name != wanted:
                continue
            row: dict[str, Any] = {
                "channel": candidate.parents[1].name,
                "language": candidate.parents[2].name,
                "drama_name": candidate_name,
                "video_id": str(metadata.get("video_id") or ""),
                "package_path": str(candidate),
                **payloads,
            }
            newest = max((candidate / filename).stat().st_mtime for filename in stage_files.values() if (candidate / filename).exists())
            rows.append((newest, row))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
    rows.sort(key=lambda value: -value[0])
    return [row for _, row in rows]


def recent_channel_title_term_usage_7d(
    package: Path,
    item: dict[str, Any],
    policy: dict[str, Any],
) -> dict[str, Any]:
    """Count prior accepted title candidates in this channel's rolling 7-day window.

    This is compact generation context only. Missing or malformed history never
    blocks production and the counts are never used by Validator.
    """
    slot = str(item.get("slot") or "").strip()
    try:
        window_end = datetime.strptime(slot, "%Y%m%d%H")
    except ValueError:
        return {
            "available": False,
            "reason": "task_slot_not_YYYYMMDDHH",
            "count_basis": "accepted_generated_title_candidates",
            "counts": {},
            "limits": {},
        }
    terms = policy.get("terms") if isinstance(policy, dict) else None
    if not isinstance(terms, dict) or not terms:
        return {
            "available": False,
            "reason": "frequency_policy_missing",
            "count_basis": "accepted_generated_title_candidates",
            "counts": {},
            "limits": {},
        }
    window_start = window_end - timedelta(days=7)
    counts = {str(term): 0 for term in terms}
    channel_packages = package.parent
    for candidate in channel_packages.glob("*"):
        try:
            if not candidate.is_dir() or candidate.resolve() == package.resolve():
                continue
            match = re.search(r"_(\d{10})$", candidate.name)
            if not match:
                continue
            candidate_slot = datetime.strptime(match.group(1), "%Y%m%d%H")
            if not (window_start <= candidate_slot < window_end):
                continue
            payload = load_json(candidate / "04_标题方案.json", {})
            for row in title_rows(payload):
                review_text = str(row.get("translation") or row.get("title_translation") or "")
                for term, rule in terms.items():
                    aliases = rule.get("aliases") if isinstance(rule, dict) else None
                    aliases = aliases if isinstance(aliases, list) and aliases else [str(term)]
                    if any(str(alias) and str(alias) in review_text for alias in aliases):
                        counts[str(term)] += 1
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            continue
    limits = {
        str(term): int(rule["max_uses_7d"])
        for term, rule in terms.items()
        if isinstance(rule, dict) and isinstance(rule.get("max_uses_7d"), int)
    }
    guidance = {
        str(term): str(rule.get("guidance") or "")
        for term, rule in terms.items()
        if isinstance(rule, dict) and rule.get("guidance")
    }
    return {
        "available": True,
        "window_start": window_start.strftime("%Y%m%d%H"),
        "window_end": window_end.strftime("%Y%m%d%H"),
        "count_basis": "accepted_generated_title_candidates",
        "counts": counts,
        "limits": limits,
        "guidance": guidance,
    }


def attach_recent_title_frequency_guidance(
    context: dict[str, Any], package: Path, item: dict[str, Any], stage: str
) -> dict[str, Any]:
    if stage != "xy-title":
        return context
    contract = context.get("title_rule_contract")
    contract = contract if isinstance(contract, dict) else {}
    policy = contract.get("negative_term_frequency_guidance")
    if isinstance(policy, dict):
        context["recent_channel_title_usage_7d"] = recent_channel_title_term_usage_7d(
            package, item, policy
        )
    return context


def history_requirements_for_stage(stage: str) -> tuple[bool, bool]:
    return stage == "xy-cover", stage in CONTENT_STAGES


def select_model_visual_history(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Use one bounded history set for both generation and semantic validation."""
    return list(rows[:MODEL_VISUAL_HISTORY_LIMIT])


def package_context(package: Path, item: dict[str, Any], stage: str = "") -> dict[str, Any]:
    snapshot_path = package / "01_频道数据.md"
    if not snapshot_path.exists():
        raise RuntimeError("缺少01_频道数据.md")
    snapshot = snapshot_path.read_text(encoding="utf-8")
    channel_root = package.parent.parent
    workflow_version = int(item.get("workflow_contract_version") or 1)
    description_bundle = (
        load_description_rule_bundle(str(item.get("language") or ""), str(item.get("channel") or ""))
        if workflow_version < 2 else {"fixed_assets": {}, "contract": {}}
    )
    frozen_assets = read_optional_json(package / "02_频道固定资产.json") if workflow_version >= 2 else {}
    needs_visual_history, needs_creative_history = history_requirements_for_stage(stage)
    context = {
        "task": {
            "drama_name": item.get("drama_name", ""),
            "video_id": item.get("video_id", ""),
            "url": item.get("url", ""),
            "channel": item.get("channel", ""),
            "nickname": item.get("nickname", ""),
            "language": item.get("language", ""),
            "gender": item.get("gender", ""),
            "direction": item.get("direction", ""),
            "slot": item.get("slot", ""),
            "workflow_contract_version": int(item.get("workflow_contract_version") or 1),
            "need_community": bool(item.get("need_community")),
            "community_output_version": int(item.get("community_output_version") or 1),
            "community_count": int(item.get("community_count", 1 if item.get("need_community") else 0) or 0),
            "video_link": item.get("url", ""),
        },
        "identity": item_identity(item),
        "channel_snapshot": snapshot,
        "playlists": playlists_from_snapshot(snapshot),
        "description_fixed_assets": (
            frozen_assets.get("description_fixed_assets", {})
            if workflow_version >= 2 else read_optional_json(channel_root / "description_fixed_assets.json")
        ),
        "community_footer_cta": (
            frozen_assets.get("community_footer_cta", {})
            if workflow_version >= 2 else read_optional_json(channel_root / "community_footer_cta.json")
        ),
        "plot_payload": load_json(package / "01_搜索资料.json", {}),
        "market_packaging": market_context_for_title(
            load_json(package / "01_市场包装证据.json", {})
        ) if stage == "xy-title" else {},
        "title_payload": load_json(package / "04_标题方案.json", {}),
        "cover_payload": load_json(package / "04_封面提示词.json", {}),
        "place_payload": load_json(package / "place_result.json", {}),
        "visual_history": select_model_visual_history(visual_history_for(package, item, limit=None)) if needs_visual_history else [],
        "creative_history": creative_history_for(package, item) if needs_creative_history else [],
        "creative_slot": item.get("creative_slot") if isinstance(item.get("creative_slot"), dict) else {},
        "cover_rule_contract": load_cover_rule_bundle(),
        "community_rule_contract": load_community_rule_bundle(),
        "description_rule_contract": description_bundle.get("contract", {}),
    }
    context["channel_theme_contract"] = channel_theme_contract(item, context["plot_payload"])
    if workflow_version < 2:
        context["description_fixed_assets"] = normalized_description_fixed_assets(context)
    return context


def normalized_description_fixed_assets(context: dict[str, Any]) -> dict[str, Any]:
    """Return the authoritative localized footer for the current channel.

    Historical channel snapshots can contain an auto-seeded English footer
    even when the production language is Hindi.  Rule defaults are the source
    of truth for auto-seeded assets; explicitly maintained localized assets are
    preserved when they already match the expected rule language.
    """
    if context.get("description_assets_frozen") and isinstance(context.get("description_fixed_assets"), dict):
        return dict(context["description_fixed_assets"])
    task = context.get("task") if isinstance(context.get("task"), dict) else {}
    language = str(task.get("language") or "").strip()
    channel = str(task.get("channel") or "").strip()
    bundle = load_description_rule_bundle(language, channel)
    defaults = dict(bundle.get("fixed_assets") or {})
    current = context.get("description_fixed_assets")
    if not isinstance(current, dict) or not current:
        current = {}

    # Auto-seeded assets must track the current rule bundle.  This prevents a
    # stale English seed from becoming a permanent channel-specific override.
    source = str(current.get("source") or "").strip()
    if not current or source in {
        "xy-place/rules/description_rules.json",
        "xy-place-v14/rules/description_rules.json",
    }:
        resolved = defaults
    else:
        resolved = {**defaults, **current}

    return {
        "version": int(current.get("version") or bundle.get("rules_version") or 1),
        "source": "xy-place-v14/rules/description_rules.json",
        "language": language,
        "channel_name": channel,
        **resolved,
    }


TITLE_COVER_GENERATION_BLACKLIST_DIRECTIVE = (
    "Strictly forbidden semantic concepts in every newly generated title-owned or cover-owned field, regardless of target language, translation, inflection, or euphemistic spelling: "
    "rape; sexual assault; molestation; drugged; date rape or drugging; sold a person; human trafficking; kill; murder; shooting or killing; suicide; self-harm; corpse or dead body; bloody or gory; torture; poisoning to death; brutal killing. "
    "Prefer not to use these semantic concepts and freely choose another hard, clickable expression whenever possible: domestic violence; abuse; kidnapping; death threat. "
    "This is a generation instruction: choose compliant wording and visual ownership before returning JSON; do not rely on a downstream validator or cleaning pass. "
)

TITLE_GENERATION_STRATEGY_DIRECTIVE = (
    "Build every title in this exact reasoning order: strongest immediate emotion -> concrete perceptible event -> "
    "whether the event directly changes the position between people regardless of event type -> relationship inside that event -> "
    "protagonist's response, choice, or gain -> clear position change -> optional amplifier -> "
    "single A-to-B causal chain. A creates an immediate emotional debt through a concrete event that a cold viewer can understand. "
    "Prioritize events that directly change the position between people. An event's type does not determine its priority; priority "
    "depends on whether it directly causes selection, exclusion, recognition, replacement, protection, or a change in status between people. "
    "A procedural fact receives high priority only when it carries such a position change. "
    "B directly repays the emotional debt created by A through a clear change in relationship, identity, power, interests, resources, "
    "social position, relationship commitment, or fate. These are abstract result dimensions, not a candidate library, and no one "
    "dimension is mandatory. An optional amplifier is allowed only when supported by current plot evidence, the channel's permitted "
    "marketing extrapolation, or the frozen contract; never invent a new identity, amount, asset, power, or relationship merely to intensify a title. "
    "Before returning candidates, perform a model-only self-check: A must create immediate emotion for a cold viewer; A must contain a "
    "concrete perceptible event; B must directly answer A's emotional debt; A-to-B must remain understandable without full plot context; "
    "and the title must contain one main emotional causal line. Use this self-check only for candidate generation, ranking, and internal rewrite. "
    "It must not become a mechanical Validator or an independent Controller semantic detector. "
)

TITLE_HOOK_TYPE_PROTOCOL_DIRECTIVE = (
    "Protocol-only allowed hook_a_type values: betrayal, humiliation, abandonment, theft, forced_choice, life_crisis, "
    "child_separation, identity_suppression, public_attack, marriage_trap, money_power_attack, shocking_discovery. "
    "Protocol-only allowed hook_b_type values: identity_reveal, public_slapback, revenge, power_reversal, villain_cost, "
    "family_collapse, regret_chase, child_recognition, marriage_reveal, life_or_death_payoff, wealth_reveal, alliance_victory, "
    "arrival_mystery, relationship_mystery, secret_object, public_shock, forced_choice_escalation, countdown_crisis, unseen_consequence. "
    "These values exist only to encode the chosen current-task result in the unchanged output protocol and must not be used as a creative candidate list. "
)


STAGE_DIRECTIVES = {
    "xy-title": (
        TITLE_COVER_GENERATION_BLACKLIST_DIRECTIVE
        +
        TITLE_GENERATION_STRATEGY_DIRECTIVE
        +
        TITLE_HOOK_TYPE_PROTOCOL_DIRECTIVE
        +
        "Generate exactly three genuinely first-person titles in the channel language. The narrator must be directly involved in the explosive event as its participant, target, relationship party, or counterattacker. "
        "Do not enforce a fixed first-person vocabulary, starter list, exact pronoun position, or reusable sentence pattern; use natural first-person grammar for the current channel language and reject detached third-person narration. "
        "Read channel_theme_contract first. When plot_supported=true, make the channel direction unmistakable in all three "
        "directions while using different explosive moments and hooks. When plot_supported=false, choose the closest compelling "
        "angle from the drama and do not force a generic channel-theme slogan. "
        "Use creative_slot only as a stable package identity and fresh-creation policy; it contains no hook, scene, action, or layout answer. "
        "Use market_packaging.final_angles as the three packaging propositions before recommendation sorting: direction 1 follows A, direction 2 follows B, and direction 3 follows C. Preserve each supplied angle's factual conflict/payoff core while expressing it naturally in the target language. Do not scan or reconstruct raw market videos, and do not claim that a story_derived angle has market validation. "
        "Create one packaging_brief shared by title, cover, description, and community. Its creative_slot_id and "
        "channel_direction must exactly match creative_slot.creative_slot_id and channel_theme_contract.channel_direction; "
        "when the plot supports the channel direction, core_story_promise must explicitly name at least one verified Chinese channel-theme signal instead of using generic conflict language. "
        "title_role and thumbnail_role must complement rather than repeat each other. "
        "Respect the exact fixed title formula from channel_snapshot. The three directions must be materially different. "
        "Never select, copy, or translate a fixed channel-theme candidate phrase. Build each A/B title from the strongest drama-specific marketing mechanism and the current channel direction; do not use a generic direction label as a reusable title suffix. When plot_supported=false, do not force a channel-theme phrase that makes the title generic. "
        "Keep every final localized title at or below 95 Unicode code points, including emoji, brackets, spaces, and punctuation, "
        "leaving margin under the validator's hard 100-code-point limit. Count the actual final title string yourself. "
        "Do not trust or merely copy your own char_count. "
        "Assign each direction a unique integer recommendation_score from 1 to 100 based on A explosion strength, B escalation or payoff, "
        "instant clarity, emotional shock, channel fit, and downstream visual potential. When exactly one or two final angles are market-backed, the controller places those directions first and sorts within each source group by this score; when all three or none are market-backed, it sorts all three by score. Score honestly. "
        "Treat child_angle as a downstream cover-execution flag, not a keyword detector. Set child_angle=true only when the selected direction has a born minor who can truthfully appear, safe and supervised, in the same single continuous moment and physical location as the chosen cover event. A title may mention a child while using child_angle=false when its strongest visible payoff is an adult-only later consequence and the child cannot truthfully share that moment. "
        "An explicitly adult or grown daughter, son, or offspring is not a child angle: set child_angle=false and do not create child-safety staging for adult offspring. "
        "A direction whose only child fact is not yet born is valid and does not require a visible born child: set child_angle=false unless that same Find direction also contains a born child. Never add a later baby scene merely because the channel or drama is child/cute-child themed. "
        "For every direction, provide one short visual_thesis stating the title's main visible conflict, discovery, reveal, reunion, or emotional reversal. "
        "A deceased, absent, or earlier-life child does not require child_angle=true for a later adult-only consequence. Channel type, drama name, and child wording must never force all three directions to add children. For every child-angle direction, provide safe_cover_scene and child_role before cover generation. safe_cover_scene must be one executable single moment in one physical location; never use a split screen, inset memory, separate memory region, collage, or temporal montage. It is a reference safety implementation, not a mandatory replacement for the title event. Visibly include the relevant Chinese "
        "child or children, fully clothed, healthy, safe, and supervised. A child may appear safely in a hospital, clinic, ward, waiting area, rehabilitation area, or normal examination setting, but must not undergo a painful, invasive, dangerous, or harmful medical procedure. "
        "Keep the public A+B title explosive, but make visual_thesis, child_role, and safe_cover_scene image-provider-safe. These downstream visual fields must not make a minor the visible target of abandonment, humiliation, hostile surveillance, coercive parenting, police restraint or control, adult confrontation, or bedroom/bedside intimacy. Move the visible wrongdoing, confrontation, or consequence onto adults, and keep the required child as a calm, protected relationship, identity, reunion, or family anchor. Do not delete the child and do not weaken the public title. "
        "Use the complete plot_payload.results[0].plot_fields as marketing raw material, not as a synopsis to translate and not as a verbatim-evidence gate. "
        "Keep only a minimum relationship or conflict connection to this drama; the marketed escalation does not need to be a literal plot event or ending. Build a hard declarative two-explosion A!B! structure. "
        "Both A and B must be declarative. Never use questions, rhetorical questions, Why/What/Who/How hooks, or question marks in any channel language. "
        "Evidence fields are brief internal source or amplification notes and are not required to be verbatim plot spans. For every direction return one concrete public_payoff_anchor in Chinese. It must express a directly perceptible position change that answers A and must appear verbatim inside the Chinese B beat. A generic summary cannot be the whole anchor. "
        "Apply a cold viewer test to the public title: never make a bare story-internal proper noun carry the hook. Replace it with a universally understandable description of the current relationship, event, or position change. Internal names may remain only in evidence notes. "
        "The title content hard gate applies only to actual minors: never humiliate, insult, bully, abuse, sexualize, or assign age-inappropriate "
        "conduct to a minor. The same harsh conflict words are allowed for adults, including explicitly adult or grown daughters and sons. "
        "Translate only the two title beats into Chinese; the controller owns and normalizes the Chinese translation shell "
        "from the real channel formula, including its punctuation and channel-specific emoji. "
        "creative_history contains same-drama packages from other channels: use it only as a negative reference. "
        "Choose different hook pairs, specificity anchors, and editorial angles; never translate, paraphrase, or reuse them."
    ),
    "xy-cover": (
        TITLE_COVER_GENERATION_BLACKLIST_DIRECTIVE
        +
        "Generate description prompts only, never images. Produce exactly three title-linked groups. "
        "Treat title_payload.results[0].packaging_brief and channel_theme_contract as binding upstream inputs. "
        "Copy packaging_brief.creative_slot_id into packaging_brief_id, and copy channel_direction and core_story_promise exactly. "
        "Before writing any scene_prompt_4_5, commit in this order for each group: visual_payoff; single_continuous_moment=true, single_physical_location=true, and temporal_montage=false; required_characters and visible adult/child counts; a fresh scene; a fresh main action; prop_role; camera_angle; core_words category and selection reason; then the concise scene prompt. "
        "Each 4:5 group must show exactly one continuous moment in one physical location. Choose only one strongest visible instant from the A+B title; do not illustrate both beats. Do not combine before/after, accusation/consequence, present/later, or cause/result in one image. No split screen, stacked scenes, collage, diptych, multi-panel, temporal montage, or adjacent second moment. Use one coherent lighting environment for that single location. The upstream visual_thesis is a marketing promise: if it mentions more than one time or place, distill it into one visual_payoff instead of reproducing both. "
        "visual_payoff must state the strongest emotional power shift, relationship reversal, or visible consequence promised by the title. Do not convert title nouns directly into props. key_prop is optional supporting evidence, never the sole visual B explosion. "
        "For a group with no required child, plan 2 to 4 visible adults and no extra people. Keep every required child and remove optional adults first. The final scene may contain only required_characters: no background crowd, assistants, guards, shareholders, relatives, or readable extra faces. "
        "Never depict Chinese police, public-security, traffic-police, special-police, or other public-service uniforms in any cover. Do not describe police caps, police badges, police emblems, police epaulettes, police shoulder boards, police service numbers, or police-style uniforms. If the plot needs an order-maintaining figure, replace that visual role with a commercial security guard in a plain neutral security uniform with no government or police insignia. "
        "scene_family, scene, and main_action are fresh free creative text derived specifically from this title and package. Do not choose a scene, action, composition, prop, or reaction from any reusable candidate list; fixed creative answers are forbidden. Explain scene_choice_reason and action_choice_reason before composing the prompt. "
        "If a location detail does not improve story comprehension, emotional intensity, or visual realism, omit it during generation. Do not invent decorative architecture, luxury dressing, lighting spectacle, or art-direction detail merely to sound professional. "
        "Use camera_angle only from: eye-level, slightly low-angle, slightly high-angle, over-the-shoulder, three-quarter view. These are technical vocabulary, not composition templates. "
        "Choose core_words by this priority: specific relationship > shocking identity > concrete number > concrete consequence > abnormal action > abstract theme. Use abstract_theme only when no concise package-specific phrase is available. Never select core words from a reusable multilingual candidate library. "
        "The three scenes must visibly express the current channel direction when supported by plot facts, while remaining distinct from one another. Return the full pre-generation plan plus story_hook, scene_family, scene, main_action, key_prop, composition, palette, and lighting. Design one believable high-emotion frame from a real Chinese television drama. "
        "Stage the provocative unresolved moment promised by each title, not the later explanation or ending. One minimum plot anchor is enough. Do not use doors or vehicle doors as primary scene devices. Never build the scene, main action, actor interaction, or camera blocking around opening or closing a door, blocking, standing, waiting, or leaning at a doorway, entering or exiting through a vehicle door, gripping a car door, or confronting across a door. Create a fresh title-specific non-door scene and action rather than selecting a replacement from a location or action list. A distant closed door may remain incidental background architecture only when nobody interacts with it. This is a hard generation and validation requirement. "
        "The three groups inside this package must use different scene moments, main actions, and camera blocking. Palette, lighting, and props "
        "must follow the chosen real location and must never be varied merely to look novel. Across videos, partial reuse of "
        "channel-level visual grammar is allowed: character count, shot size, camera angle, placement logic, typography-layout logic, "
        "or scene type may each be similar. A single similar visual dimension is not narrative duplication, so do not force a new "
        "composition solely to avoid resemblance. Do not reproduce the whole visual combination as a template. Reject only a substantially "
        "duplicated complete narrative concept: a highly similar combination of character relationship, primary action or reversal, key event "
        "or evidence prop, and core cover words. When several key visual dimensions and that narrative concept are both highly similar, actively "
        "separate the design. Do not use a numeric similarity ratio or fingerprint-count quota for generation. Same channel style is allowed; "
        "the same template or complete visual story is not. Never invent technology, gadgets, forensic displays, or implausible locations to "
        "escape history. Do not use named geometric poster formulas. "
        "Return scene_prompt_4_5 as a concise English scene description containing only the title-linked people, relationship, physical action, emotion, believable location, camera blocking, and location-specific light/color. Do not include global style boilerplate, actor-ethnicity boilerplate, core-word rendering, typography, canvas-width, font, outline, or shadow instructions; the controller owns and appends those exactly once. "
        "For female-frequency channels, ban all visual special effects: no magic, aura, energy, lightning, particles, fire, explosion, "
        "holograms, fake glowing props, glowing eyes, lasers, or supernatural glow; natural sun, practical lights, headlights, and stage lights are allowed. "
        "If the channel/title uses a child or cute-child angle, visibly include the relevant Chinese child or children, safe, healthy, "
        "fully clothed, supervised, and never distressed, harmed, kidnapped, restrained, sick, bullied, humiliated, or surrounded by hostile adults. "
        "For each title, copy visual_thesis exactly and make scene_prompt_4_5 visibly express it. For each title row with child_angle=true, use child_role and safe_cover_scene as safety references, not as a mandatory scene script. When a required minor is visible, do not combine that minor in the same image prompt with abandonment or humiliation directed at the child, hidden surveillance, coercive parenting, bedroom or bedside intimacy, police restraint, escort, or control, paternity-evidence confrontation, or adult physical/coercive conflict. Keep the click-driving reversal visible through adult status, posture, relationship, or consequence while the child remains calm, protected, and clearly supervised. Do not remove a required child and do not replace the title event with unrelated peaceful activity. "
        "All covers forbid hitting and threatened hitting: no slap, punch, kick, choke, drag, push-down, stomp, raised fist about to strike, weapons, blood, or wounds. Create a fresh nonviolent title-specific action without selecting from a stock alternative-action list. "
        "Each core_words value is exactly one or two independent natural words forming an idiomatic native-language hook. Prefer one strong native word; if using two, use a natural modifier-plus-head phrase or an established native compound. Never mechanically concatenate two plot nouns, never omit a required linker or case marker, and if the idiomatic expression needs three or more words, choose a different natural one- or two-word hook. The three core_words values must be mutually distinct after Unicode, case, and whitespace normalization; never reuse one group's core words in another group. Each 4:5 and 16:9 prompt is English; "
        "The core_words_translation must explicitly express the supported channel theme, and the exact localized core_words must remain prominent in both final prompts. "
        "Only core_words use the channel language. Leave suitable negative space without describing the text itself; the controller is the sole owner of the final adaptive core-word typography salience block. Do not impose any fixed typography width, height, or canvas ratio. "
        "Incidental Chinese environmental text on signs, documents, boards, buildings, or props is allowed, but it must never carry or substitute for the core words. Never add a blanket ban such as no readable words, no new text, or no other visible text. "
        "Return outpaint_environment as one short English description of only the left/right environment continuation. Do not repeat center people, identity, typography, style, action, emotion, or story information; the controller owns the complete 16:9 execution prompt. "
        "Same-drama creative_history forbids translating or cosmetically restyling a duplicated complete narrative concept. "
        "Local visual grammar may still be reused; organize the whole image for the current title and do not copy the prior "
        "relationship + primary action or reversal + key event or evidence prop + core cover words combination."
    ),
    "xy-place": (
        "Generate the dynamic channel-language description body and Chinese review translation. "
        "Inherit the exact channel direction and core story promise from title_payload.results[0].packaging_brief. "
        "Copy packaging_brief.creative_slot_id into packaging_brief_id, and copy channel_direction and core_story_promise exactly. "
        "Open with one concrete conflict, abnormal situation, identity mismatch, or relationship anomaly. Use only the strongest click entry and never summarize the whole drama or preview several hooks. Do not stack several betrayals, props, or consequences into the opening sentence; move secondary facts into the minimum background only when needed. Continue in two to four natural paragraphs whose length, order, and transitions follow the current plot and target language rather than a fixed rhythm. Include only the relationship and background needed to understand the conflict. "
        "Use exactly one concrete mid-story event as the escalation: state who acted, what specific anomaly appeared, and whose judgment, relationship, or position changed directly because of it. Do not stack a second independent event, turn the source into a timeline, or use the final identity reveal, final parentage confirmation, villain's final punishment, final reunion, proposal, wedding, inheritance result, or another ending climax. Leave at most one plot-specific unresolved question or a non-question suspense statement. Name the relevant character instead of using a vague stranger, woman, man, mother, or person when the verified name is available and clearer. "
        "Before drafting, choose one precise current-drama editorial_anchor. Use editorial_anchor as the sole sentence-selection center: every background sentence must be necessary to understand that anchor, and delete it when removing it does not reduce understanding of that anchor. The final suspense must directly close the loop with the opening misunderstanding or follow the immediate unresolved consequence of the selected escalation; never open a new abstract question or switch to another plot line. Before returning JSON, silently reread and rewrite the body inside this same model call. Ensure each person keeps one spelling throughout, narrator knowledge is not assigned to a character who does not yet know it, causes precede effects, every target-language phrase uses native collocation rather than translated source-language logic, and the final sentence reads naturally on its first pass. This is internal single-call editing, not a second model call or a semantic Validator. "
        "Add SEO information only when the target-language version, Chinese-drama identity, or one or two essential genre terms are not already clear, and integrate it naturally into an existing paragraph. Never place a blunt standalone genre declaration after the suspense. Do not use report-like headings, plot-highlight lists, story-type lists, a fixed if-you-like-A/B/C sentence, generic AI suspense phrases, repeated facts, or any sentence whose removal would not reduce comprehension or suspense. Write like a local YouTube drama editor, not an AI report, plot encyclopedia, SEO article, or recap. "
        "description_fixed_assets is controller-owned localized compact-footer data. Do not invent, translate, paraphrase, or replace it; "
        "the controller deterministically removes any model-written footer and appends only the exact subscription and disclaimer values after generation. Legacy welcome copy, channel introductions, and generic comment questions are not public output. "
        "Ignore any conflicting legacy footer text embedded inside channel_snapshot. "
        "Return opening_hook_type, payoff_hook_type, and a concrete Chinese editorial_anchor. "
        "Only when channel_theme_contract.plot_supported=true, return one short channel_theme_phrase in the channel language plus its accurate Chinese channel_theme_phrase_translation and include it naturally in the public description. When plot_supported=false, use only a truthful plot phrase and never invent theme evidence. "
        "Generate exactly 12 hashtags for this exact channel and drama. Place #cdrama exactly once at position 3. Select the other exactly 11 hashtags only from channel_hashtag_whitelist.additional_candidates. At least one of positions 1 and 2 must be selected from channel_hashtag_whitelist.target_language_tags. Target-language qualification belongs only to that pre-registered channel asset; never infer that another tag qualifies. #ChineseDrama and #ShortDrama are optional only when they are present in the exact current-channel candidate list and relevant to this drama. Choose a drama-specific combination by considering target-language audience entry, current channel vertical theme, and verified current-drama relevance together. Hashtags improve metadata fit; never treat one hashtag as an independent cause of recommendation traffic. The channel name must match channel_hashtag_whitelist.channel_name exactly. These hashtags are final YouTube plain text, not Markdown source: copy every selected hashtag character-for-character from the whitelist. Never insert a backslash before an underscore or any other hashtag character. Never borrow from another channel, and never invent, translate, concatenate, respell, change case, or otherwise modify a hashtag. "
        "Use the best matching registered playlist in the playlist and url fields. In the public description, include every registered playlist exactly as supplied: show the primary playlist first, then every remaining playlist with its exact name and viewer-facing URL. Do not explain why a playlist matches, summarize its content, add SEO commentary, or write any sentence after a playlist URL. The controller deterministically rebuilds this block. End the public description after the fixed disclaimer and never output a ==Chinese drama name== marker or another internal production marker. "
        "Use only viewer-facing www.youtube.com/playlist?list= URLs and never studio.youtube.com. Translate every structural label into the channel language; outside English channels, English template labels are invalid. "
        "When a story includes minors, keep adult wrongdoing and child-safe facts in separate sentences. Do not describe a minor as the direct target of abandonment, humiliation, hostile surveillance, coercive parenting, police restraint or control, adult confrontation, or bedroom/bedside intimacy. Preserve the dramatic adult betrayal, reversal, punishment, and payoff; keep the child as a protected relationship, identity, reunion, or family anchor. This is wording ownership for future generation, not permission to omit verified children or soften the main hook. "
        "Use a different editorial premise and emotional entry point from every same-drama item in creative_history."
    ),
    "xy-post": (
        "Generate exactly task.community_count independent community plans. Each result must use its sequential plan_index. "
        "Inherit the channel direction and core story promise from title_payload.results[0].packaging_brief, but choose a distinct drama-specific interaction moment for each plan. "
        "In every result copy packaging_brief.creative_slot_id into packaging_brief_id, and copy channel_direction and core_story_promise exactly. "
        "Use task.video_link exactly once in each copy; when it is 【视频链接待补】, preserve that exact placeholder. "
        "Return community_hook_type plus concrete Chinese selected_moment and interaction_angle fields. "
        "Treat the channel theme as existing context for angle selection, not as a fixed sentence that must be exposed publicly. When channel_theme_contract.plot_supported=true, return channel_theme_phrase in the channel language with its accurate Chinese channel_theme_phrase_translation for review, but write the public copy and image hook naturally for this drama without copying that phrase verbatim. When plot_supported=false, use only a truthful plot phrase and never invent theme evidence. "
        "The image hook expresses one core conflict, choice, or relationship change from the selected scene. It must not also carry a full plot summary or the interaction question; keep the full interaction question in the public copy. "
        "Return scene_family, main_action, key_prop, composition, and palette for every plan. "
        "Reuse every community_footer_cta field exactly. The first copy line must be exactly `🔥 {full_video_cta} 👉 {task.video_link}`; "
        "do not translate, paraphrase, decorate, or reorder that fixed line. The community image must not be a square remake of any cover. "
        "Keep the hook sentence, both CTA buttons, emoji, and their exact channel-fixed layout inside the generated image prompt. "
        "Render the scene as a natural live-action TV drama still with realistic lens rendering, natural skin texture, ordinary clothing wrinkles, believable location lighting, and slightly softer environmental detail. Never request ultra sharp focus, crisp facial details, crisp faces, strong or high micro-contrast, clean edges, sharp facial highlights, or mobile-readability rendering. "
        "Every plan must use a materially different moment, interaction premise, visual scene, action, prop, composition, and palette. "
        "Do not translate, paraphrase, or reuse any same-drama community copy or image concept from creative_history."
    ),
}


STAGE_CONTEXT_KEYS = {
    "xy-find": ("task", "identity"),
    "xy-title": ("task", "identity", "channel_snapshot", "channel_theme_contract", "semantic_contract", "creative_slot", "title_rule_contract", "plot_payload", "market_packaging", "creative_history", "recent_channel_title_usage_7d"),
    "xy-cover": ("task", "identity", "channel_snapshot", "channel_theme_contract", "semantic_contract", "creative_slot", "cover_rule_contract", "plot_payload", "title_payload", "visual_history", "creative_history"),
    "xy-place": (
        "task",
        "identity",
        "channel_snapshot",
        "channel_theme_contract",
        "semantic_contract",
        "creative_slot",
        "playlists",
        "description_fixed_assets",
        "channel_hashtag_whitelist",
        "plot_payload",
        "title_payload",
        "creative_history",
    ),
    "xy-post": (
        "task",
        "identity",
        "channel_snapshot",
        "channel_theme_contract",
        "semantic_contract",
        "creative_slot",
        "community_footer_cta",
        "community_rule_contract",
        "plot_payload",
        "title_payload",
        "place_payload",
        "creative_history",
    ),
}


def stage_context(stage: str, context: dict[str, Any]) -> dict[str, Any]:
    """Expose only the immutable inputs owned by the current stage.

    Passing every prior artifact to every model call increased latency and let
    stale downstream prose influence unrelated generation.  The controller,
    not the model, owns dependency selection.
    """
    scoped = {key: context[key] for key in STAGE_CONTEXT_KEYS.get(stage, ()) if key in context}
    if stage == "xy-title" and isinstance(scoped.get("channel_snapshot"), str):
        scoped["channel_snapshot"] = title_channel_context(scoped["channel_snapshot"])
    elif stage == "xy-place":
        scoped["description_fixed_assets"] = normalized_description_fixed_assets(context)
        publication_contract = context.get("description_rule_contract", {})
        if publication_contract and isinstance(scoped.get("channel_snapshot"), str):
            scoped["channel_snapshot"] = public_playlist_urls_in_text(scoped["channel_snapshot"])
        scoped["publication_contract"] = publication_contract
    elif stage == "xy-cover":
        if isinstance(scoped.get("cover_rule_contract"), dict):
            scoped["cover_rule_contract"] = copy.deepcopy(scoped["cover_rule_contract"])
            prompt_audit = scoped["cover_rule_contract"].get("prompt_audit")
            if isinstance(prompt_audit, dict):
                for validator_only_key in (
                    "max_historical_matching_dimensions",
                    "forbid_historical_scene_action_pair",
                    "actual_image_similarity_threshold",
                ):
                    prompt_audit.pop(validator_only_key, None)
        if isinstance(scoped.get("title_payload"), dict):
            scoped["title_payload"] = copy.deepcopy(scoped["title_payload"])
            for row in title_rows(scoped["title_payload"]):
                row["child_angle"] = title_row_requires_minor_child(row, False)
    elif stage == "xy-post":
        scoped["image_style_contract"] = context.get("community_rule_contract", {}).get("image_style", {})
    # Generation and semantic validation consume the exact same selected
    # history contract. Full real-image history remains the separate P0 gate
    # in xy-sort-v14, where actual pixels are available.
    history_key = {
        "xy-title": "title_payload",
        "xy-cover": "cover_payload",
        "xy-place": "place_payload",
        "xy-post": "post_payload",
    }.get(stage)
    if history_key and isinstance(scoped.get("creative_history"), list):
        metadata = ("channel", "language", "drama_name", "video_id")
        def compact(payload: dict[str, Any]) -> dict[str, Any]:
            result = first_result(payload)
            identity = {
                key: result.get(key, "")
                for key in ("drama_name", "video_id", "result_id", "source_block_label")
            }
            if stage == "xy-title":
                fields = (
                    "hook_a_type", "hook_a_fact", "hook_b_type", "hook_b_fact",
                    "specificity_anchor", "translation",
                )
                identity["directions"] = [
                    {key: row.get(key, "") for key in fields}
                    for row in title_rows(payload)
                ]
            elif stage == "xy-cover":
                fields = (
                    "story_hook", "scene_family", "main_action", "key_prop",
                    "composition", "palette", "lighting",
                )
                identity["titles"] = [
                    {key: row.get(key, "") for key in fields}
                    for row in cover_rows(payload)
                ]
            elif stage == "xy-place":
                for key in ("opening_hook_type", "payoff_hook_type", "editorial_anchor"):
                    identity[key] = str(result.get(key) or "")
                identity["translation"] = str(result.get("translation") or "")[:1600]
            elif stage == "xy-post":
                plans = [
                    {
                        key: (str(row.get(key) or "")[:1600] if key in {"copy_translation", "image_prompt_1x1"} else str(row.get(key) or ""))
                        for key in (
                            "plan_index", "community_hook_type", "selected_moment", "interaction_angle",
                            "scene_family", "main_action", "key_prop", "composition", "palette",
                            "copy_translation", "image_prompt_1x1",
                        )
                    }
                    for row in (payload.get("results") or [])
                    if isinstance(row, dict)
                ]
                identity["plans"] = plans
                if plans:
                    # Retain the legacy compact keys so old batches and their
                    # regression contract remain readable without migration.
                    identity.update({key: plans[0].get(key, "") for key in (
                        "community_hook_type", "selected_moment", "interaction_angle",
                        "copy_translation", "image_prompt_1x1",
                    )})
            return {"results": [identity]}
        scoped["creative_history"] = [
            {
                **{key: row.get(key, "") for key in metadata},
                history_key: compact(row.get(history_key, {})),
            }
            for row in scoped["creative_history"]
            if isinstance(row, dict) and row.get(history_key)
        ]
    return scoped


def build_prompt(
    stage: str,
    rules: str,
    context: dict[str, Any],
    previous_issues: list[str],
    stage_directive: str | None = None,
) -> str:
    scoped_context = stage_context(stage, context)
    acceptance_spec: dict[str, Any] = {
        "stage": stage,
        "must_pass_before_acceptance": True,
    }
    if stage == "xy-title":
        theme = context.get("channel_theme_contract") if isinstance(context.get("channel_theme_contract"), dict) else {}
        acceptance_spec.update(
            {
                "channel_direction": str(theme.get("channel_direction") or ""),
                "plot_supported": bool(theme.get("plot_supported")),
                "accepted_theme_signals": list(dict.fromkeys([
                    *(str(value) for value in theme.get("required_output_signals", [])),
                ])),
                "per_direction_requirement": "Each Chinese audit direction and the packaging promise must contain at least one accepted_theme_signal.",
            }
        )
    elif stage == "xy-cover":
        audit = context.get("cover_rule_contract", {}).get("prompt_audit", {}) if isinstance(context.get("cover_rule_contract"), dict) else {}
        acceptance_spec.update(
            {
                "generation_constraints": {
                    "required_event_source": "upstream visual_thesis and verified plot facts",
                    "child_policy": "use structured per-group child requirement; required minors must be visible, safe, healthy, supervised, and outside actual danger",
                    "adult_conflict_near_safe_child": "express through adult status, posture, relationship, or consequence; do not stack provider-sensitive minor contexts in the same image prompt",
                    "physical_violence": "forbidden",
                    "female_frequency_visual_effects": "forbidden",
                    "ordinary_story_evidence_props": "prefer zero or one; avoid stacking explanatory props",
                    "invented_futuristic_technology": "hard forbidden",
                    "named_ai_poster_geometry": "hard forbidden",
                    "three_group_diversity": ["scene_family", "main_action", "composition"],
                    "controller_owned_blocks": ["identity", "style", "typography", "salience", "16:9 execution"],
                    "generation_plan": copy.deepcopy(audit.get("generation_plan", {})),
                    "single_moment_scene": copy.deepcopy(audit.get("single_moment_scene", {})),
                    "door_and_vehicle_door_negative_constraints": copy.deepcopy(audit.get("scene_selection_preferences", {})),
                    "cross_video_visual_grammar_generation": copy.deepcopy(audit.get("cross_video_visual_grammar_generation", {})),
                    "official_uniform_policy": copy.deepcopy(audit.get("official_uniform_policy", {})),
                },
                "audit_only": {
                    "prompt_word_count": True,
                    "real_drama_score": True,
                    "prop_density": True,
                    "lighting_description_density": True,
                    "natural_live_action_style_signals": True,
                },
                "hard_forbidden_ai_poster_terms": list(audit.get("hard_forbidden_ai_poster_terms", [])),
            }
        )
    correction_lines: list[str] = []
    if stage == "xy-title":
        exact_title_format = title_format_from_snapshot(str(scoped_context.get("channel_snapshot") or ""))
        if any("format_mismatch" in issue for issue in previous_issues) and exact_title_format:
            correction_lines.append(
                "Rewrite every failed title with the exact shell `" + exact_title_format
                + "`. Replace only A and B; preserve every fixed marker, bracket, emoji, separator, punctuation mark, and position exactly."
            )
        if any("cross_channel_package_collision" in issue for issue in previous_issues):
            correction_lines.append(
                "Choose three new hook pairs, specificity anchors, and editorial directions that do not translate, paraphrase, or reuse any title direction in creative_history. Change the underlying click moment, not only the wording."
            )
        if any("recommendation" in issue for issue in previous_issues):
            correction_lines.append(
                "Give three unique recommendation_score values from 1 to 100. Score honestly. The controller applies the frozen market-backed-first rule for partial market coverage, then sorts within each source group by score."
            )
        if any("question_not_allowed" in issue for issue in previous_issues):
            correction_lines.append(
                "Rewrite A and B as direct declarative statements. Remove every question, rhetorical question, Why/What/Who/How hook, and question mark. Keep one causal line and make B directly respond to the emotional debt established by A."
            )
        if any(
            marker in issue
            for issue in previous_issues
            for marker in (
                "public_payoff_anchor_abstract",
                "public_payoff_anchor_missing",
                "public_payoff_anchor_not_in_B",
            )
        ):
            correction_lines.append(
                "Rewrite the failed B so it directly responds to the preceding conflict and completes one causal line. State a concrete, perceptible position change rather than an abstract story summary. Put the exact Chinese public_payoff_anchor inside the Chinese B beat. The result may use contract-permitted marketing amplification and does not need to be a literal plot ending, but any amplifier must be grounded in current task evidence or permitted extrapolation."
            )
        if any("cold_viewer_internal_term" in issue for issue in previous_issues):
            correction_lines.append(
                "Replace the internal proper noun in the public title with a cold-viewer-readable description of the current relationship, event, or position change. Do not ask the viewer to know the plot first. Keep internal names only in evidence notes."
            )
        if any("minor_humiliation_or_age_inappropriate" in issue for issue in previous_issues):
            correction_lines.append(
                "The rejected wording targets an actual minor with humiliation, bullying, abuse, sexualization, or age-inappropriate conduct. Choose a different child hook or move the harsh conflict onto an adult. Do not soften adult conflict. Explicitly adult daughters and sons are adults."
            )
        child_plan_failed = any(
            "child_angle" in issue or "child_safe_cover_scene" in issue or "child_role" in issue
            for issue in previous_issues
        )
        if child_plan_failed:
            correction_lines.append(
                "Re-read each supplied Find final angle independently. An angle whose only child fact is not yet born is valid and must use child_angle=false unless that same angle also contains a born minor; do not add a later baby scene because of the channel direction or drama name. Every direction still needs visual_thesis. Only directions that actually contain a born minor use child_angle=true and require child_role plus a safe_cover_scene with that child visibly safe and supervised."
            )
        theme_failures = [
            int(match.group(1))
            for issue in previous_issues
            if (match := re.search(r"title_(\d+)_channel_theme_not_prominent", issue))
        ]
        if theme_failures:
            theme = context.get("channel_theme_contract") if isinstance(context.get("channel_theme_contract"), dict) else {}
            signals = list(theme.get("required_output_signals") or [])
            correction_lines.append(
                "Rewrite failed title direction " + ", ".join(str(value) for value in theme_failures)
                + " so its Chinese hook facts, specificity anchor, or translation explicitly contains at least one "
                + "authoritative channel-theme signal: " + ", ".join(dict.fromkeys(signals)) + "."
            )
    if stage == "xy-cover":
        if any(
            marker in issue
            for issue in previous_issues
            for marker in (
                "single_continuous_moment_required",
                "single_physical_location_required",
                "temporal_montage_forbidden",
                "explicit_multi_moment_staging_forbidden",
            )
        ):
            correction_lines.append(
                "Rebuild every failed group as one continuous instant in one physical location with one coherent lighting environment. Choose only the strongest visible instant from the title. Remove every before/after, present/later, cause/result, split-screen, stacked-scene, collage, diptych, multi-panel, temporal-montage, or adjacent-second-moment construction."
            )
        if any("generation_plan" in issue or "visible_adult_count_over_4" in issue for issue in previous_issues):
            correction_lines.append(
                "Rebuild the failed group from its pre-generation plan before rewriting scene_prompt_4_5. State the title-specific visual_payoff, keep only required_characters, use 2 to 4 adults when no child is required, retain every required child, and remove optional adults first. Then freely create a new title-specific scene and action; do not pick from a candidate list."
            )
        unexpected_final_prompt_fields = any(
            "unexpected" in issue
            and any(field in issue for field in ("prompt_4_5", "prompt_16_9"))
            for issue in previous_issues
        )
        if unexpected_final_prompt_fields:
            correction_lines.append(
                "Remove the unexpected fields prompt_4_5 and prompt_16_9. Return only fields allowed by the current "
                "response schema. For each title use scene_prompt_4_5 and outpaint_environment. Do not construct or "
                "return the final prompt_4_5 or prompt_16_9; the controller constructs them downstream."
            )
        child_missing = any("child_angle_missing_visible_child" in issue for issue in previous_issues)
        child_unsafe = any("child_safety_violation" in issue for issue in previous_issues)
        if child_missing or child_unsafe:
            correction_lines.append(
                "Correct only the failed cover groups whose accepted upstream Find/title direction actually contains a born minor. "
                "Do not use the channel direction or drama name to add children to groups whose only child fact is not yet born, or to adult-only groups. "
                "For a genuine child-angle group, visibly show the relevant safe Chinese child or children; keep them fully clothed, healthy, safe, and supervised without replacing visual_thesis with an unrelated peaceful activity."
            )
        if any("core_words_diegetic_placement" in issue for issue in previous_issues):
            correction_lines.append(
                "Remove every core-word placement or Typography instruction from scene_prompt_4_5. The controller alone adds the non-diegetic editorial Typography block after the scene is accepted."
            )
        if any("scene_prompt_contains_controller_owned" in issue for issue in previous_issues):
            correction_lines.append(
                "Remove all global Style, actor-identity, and Typography boilerplate from every failed scene_prompt_4_5. Keep only the title-linked scene, people, relationship, action, emotion, camera blocking, location, and location-specific light/color."
            )
        if any("contains_wide_generation_instruction" in issue for issue in previous_issues):
            correction_lines.append(
                "Remove every 16:9 or wide-generation execution instruction from scene_prompt_4_5, including outpaint, locked-center, side-band, wide-canvas, and pixel-preservation wording. The 4:5 prompt must describe only the portrait cover. Put only a short environment continuation in outpaint_environment; the controller owns the separate wide-image execution contract."
            )
        if any("core_words_not_distinct" in issue for issue in previous_issues):
            correction_lines.append(
                "Rewrite the duplicated core_words values so all three groups use different localized one- or two-word hooks. Do not change spelling, case, or spacing merely to disguise a duplicate."
            )
        if any("core_words_unidiomatic" in issue for issue in previous_issues):
            correction_lines.append(
                "Rewrite every failed core_words value as one idiomatic native word or a natural two-word modifier-plus-head phrase. Never join two plot nouns mechanically and do not omit a required linker, postposition, case marker, or article. If the natural expression needs three or more words, choose a different plot-supported one- or two-word hook instead of compressing it into broken grammar."
            )
        if any("title_translation_mismatch" in issue for issue in previous_issues):
            correction_lines.append(
                "Copy title and title_translation for every failed group exactly from the matching upstream title row. Do not retranslate, summarize, normalize, or alter punctuation."
            )
        if any("physical_violence_forbidden" in issue for issue in previous_issues):
            correction_lines.append(
                "Remove all physical or threatened violence from every failed scene and prompt: no hitting, slap, punch, kick, choke, dragging, pushing down, stomping, raised fist, weapons, blood, or wounds. Freely create a different title-specific nonviolent action; do not select a replacement from a stock action list."
            )
        if any("door_or_vehicle_door_primary_staging_forbidden" in issue for issue in previous_issues):
            correction_lines.append(
                "Replace the failed group's entire scene, main action, actor interaction, and camera blocking with an equally truthful non-door alternative. Do not merely close or rename the door. Do not stage opening, closing, blocking, standing, waiting, leaning, entering, exiting, gripping, or confrontation at a door, doorway, car door, or vehicle door. A distant closed door is allowed only as incidental background architecture with no human interaction."
            )
        if any("official_police_or_public_service_uniform_forbidden" in issue for issue in previous_issues):
            correction_lines.append(
                "Remove every Chinese police, public-security, traffic-police, special-police, law-enforcement, or other public-service uniform and every police cap, badge, emblem, epaulette, shoulder board, or service number from the failed group. When an order-maintaining person is needed, use only a commercial security guard in a plain neutral security uniform with no government or police insignia."
            )
        if any("female_frequency_special_effects_forbidden" in issue for issue in previous_issues):
            correction_lines.append(
                "Remove every visual special effect from the failed female-frequency cover: no magic, aura, energy, lightning, particles, fire, explosion, hologram, fake glow, glowing eyes, laser, scanner beam, or supernatural light. Use only natural daylight or ordinary practical lamps."
            )
        collision_fields = ("scene_family", "main_action", "key_prop", "composition", "palette", "lighting")
        history = context.get("visual_history") if isinstance(context.get("visual_history"), list) else []
        for issue in previous_issues:
            match = re.match(r"cover_(\d+)_visual_collision_with_history_(\d+)(.*)", issue)
            if not match:
                continue
            group_index = int(match.group(1))
            history_index = int(match.group(2))
            suffix = match.group(3)
            fields = [field for field in collision_fields if re.search(rf"(?:_|^){re.escape(field)}(?:_|$)", suffix)]
            source = suffix.split("_source_", 1)[1] if "_source_" in suffix else ""
            # History can grow between attempts, so the numeric ordinal encoded
            # by the validator is only a diagnostic hint. Resolve the forbidden
            # fingerprint by its stable channel:drama:video identity first.
            ordinal_row = (
                history[history_index - 1]
                if 0 < history_index <= len(history) and isinstance(history[history_index - 1], dict)
                else {}
            )

            def source_id(row: dict[str, Any], include_group: bool) -> str:
                base = ":".join(filter(None, [
                    str(row.get("channel") or ""),
                    str(row.get("drama_name") or ""),
                    str(row.get("video_id") or ""),
                ]))
                group = str(row.get("source_group_index") or "")
                return f"{base}:group{group}" if include_group and base and group else base

            previous = ordinal_row if source in {
                source_id(ordinal_row, False), source_id(ordinal_row, True)
            } else next(
                (
                    row for row in history
                    if isinstance(row, dict)
                    and source in {source_id(row, False), source_id(row, True)}
                ),
                {},
            )
            if not source:
                source = source_id(previous, True)
            fingerprint = "; ".join(
                f"{field}={json.dumps(str(previous.get(field) or ''), ensure_ascii=False)}"
                for field in fields
                if str(previous.get(field) or "").strip()
            )
            correction_lines.append(
                f"GROUP {group_index} collides with accepted history source {source or history_index} on "
                f"{', '.join(fields) or 'its visual fingerprint'}. Redesign GROUP {group_index} around a different "
                "plot-supported story moment. Change scene_family, main_action, and composition together; do not "
                "paraphrase the same event or keep the same actor blocking. Let palette and lighting follow the new "
                "real location naturally rather than swapping colors decoratively. Preserve the exact upstream title "
                "promise and use this prior fingerprint only as forbidden reference"
                + (f": {fingerprint}." if fingerprint else ".")
            )
    if stage == "xy-place":
        if "description_contains_chinese" in previous_issues:
            correction_lines.append(
                "Rewrite every Chinese character in the public description into the registered channel language. "
                "Keep Chinese only in the separate review translation fields; do not output a final drama-name marker."
            )
        if any("hashtag_markdown_escape_forbidden" in issue for issue in previous_issues):
            correction_lines.append(
                "Rewrite the hashtag line as final YouTube plain text. Copy every hashtag character-for-character from channel_hashtag_whitelist; remove every Markdown backslash escape and never place a backslash before an underscore or any other hashtag character."
            )
        missing_playlist_indices = [
            int(match.group(1))
            for issue in previous_issues
            if (match := re.fullmatch(r"description_missing_registered_playlist_(\d+)", issue))
        ]
        playlists = context.get("playlists") if isinstance(context.get("playlists"), list) else []
        missing_playlists = [
            playlists[index - 1]
            for index in missing_playlist_indices
            if 0 < index <= len(playlists) and isinstance(playlists[index - 1], dict)
        ]
        if missing_playlists:
            correction_lines.append(
                "Rewrite the playlist section to include every registered playlist. Keep the best matching pair in the playlist and url fields, show it first in the public description, then include these missing exact name+URL pairs: "
                + "; ".join(
                    f"{str(row.get('name') or '').strip()} | {str(row.get('url') or '').strip()}"
                    for row in missing_playlists
                )
                + ". Do not invent, translate, rename, omit, or replace any registered playlist."
            )
    persistent_lines: list[str] = []
    if stage == "xy-title":
        exact_title_format = title_format_from_snapshot(str(scoped_context.get("channel_snapshot") or ""))
        if exact_title_format:
            persistent_lines.append(
                "Every localized title must use this exact shell: `" + exact_title_format
                + "`. Replace only A and B; preserve all fixed characters and their positions."
            )
        persistent_lines.append(
            "All three titles must use first-person POV and declarative A+B double explosions. "
            + TITLE_GENERATION_STRATEGY_DIRECTIVE
            + "Never use questions or question marks."
        )
        persistent_lines.append(TITLE_HOOK_TYPE_PROTOCOL_DIRECTIVE)
        persistent_lines.append(TITLE_COVER_GENERATION_BLACKLIST_DIRECTIVE)
        recent_usage = scoped_context.get("recent_channel_title_usage_7d")
        if isinstance(recent_usage, dict) and recent_usage.get("counts"):
            persistent_lines.append(
                "Seven-day negative-term usage is soft generation guidance, based on accepted generated title candidates in the current channel: "
                + json.dumps(recent_usage, ensure_ascii=False)
                + ". At or above a numeric preference, choose another hard expression whenever possible. For minimize/not-recommended/rate-limit entries, diversify wording without weakening A+B. Never fail, retry, or block production solely for this frequency guidance."
            )
        persistent_lines.append(
            "Keep only a minimum relationship or conflict connection to this drama; the marketed B does not need to be a literal plot event or ending. Every direction must return a concrete Chinese public_payoff_anchor that appears verbatim inside the Chinese B beat and expresses the perceptible position change that answers A."
        )
        persistent_lines.append(
            "Apply the cold viewer test: public titles must not rely on bare story-internal proper nouns. Replace them with a universally understandable description of the current relationship, event, or position change; internal names belong only in evidence notes."
        )
        persistent_lines.append(
            "The title content hard gate applies only to actual minors: do not humiliate, insult, bully, abuse, sexualize, or assign age-inappropriate conduct to a minor. Explicitly adult or grown daughters and sons are adults and may use the same harsh conflict wording as other adults."
        )
        persistent_lines.append(
            "Keep the public A+B title explosive, but make visual_thesis, child_role, and safe_cover_scene image-provider-safe. They must not make a minor the visible target of abandonment, humiliation, hostile surveillance, coercive parenting, police restraint or control, adult confrontation, or bedroom/bedside intimacy. Move the visible wrongdoing, confrontation, or consequence onto adults; keep the child calm, protected, and supervised. Do not delete the child or weaken the title."
        )
        persistent_lines.append(
            "Resolve child presence independently for each supplied Find final angle. child_angle is a cover-execution flag, not a keyword detector. An angle whose only child fact is not yet born is valid and uses child_angle=false unless that same angle also contains a born minor. A deceased, absent, or earlier-life child does not require child_angle=true for a later adult-only consequence. Channel direction, drama name, and child wording must never force all three directions to add children. Set child_angle=true only when the child can truthfully appear in the selected cover event's one continuous moment and physical location. In that case provide visual_thesis, child_role, and a safe_cover_scene with the relevant Chinese child visibly safe, healthy, fully clothed, and supervised; never use split screen, inset memory, separate memory regions, collage, or temporal montage."
        )
    elif stage == "xy-cover":
        persistent_lines.append(TITLE_COVER_GENERATION_BLACKLIST_DIRECTIVE)
        task = scoped_context.get("task") if isinstance(scoped_context.get("task"), dict) else {}
        rows = title_rows(scoped_context.get("title_payload") or {})
        child_requirements = cover_group_child_requirements(task, scoped_context, rows)
        for position, row in enumerate(rows, start=1):
            title_index = int(row.get("index") or row.get("title_index") or position)
            title = str(row.get("title") or "")
            translation = str(row.get("translation") or row.get("title_translation") or "")
            persistent_lines.append(
                f"GROUP {title_index}: Copy title and title_translation exactly from upstream: "
                + json.dumps(title, ensure_ascii=False) + " / " + json.dumps(translation, ensure_ascii=False) + "."
            )
            persistent_lines.append(
                f"GROUP {title_index}: Copy visual_thesis exactly from upstream and make the scene directly visualize it: "
                + json.dumps(str(row.get("visual_thesis") or ""), ensure_ascii=False) + "."
            )
            if len(child_requirements) >= position and child_requirements[position - 1]:
                persistent_lines.append(
                    f"GROUP {title_index}: a real visible safe Chinese child or children are mandatory in scene_prompt_4_5. "
                    f"Required child_role={json.dumps(str(row.get('child_role') or ''), ensure_ascii=False)}; "
                    f"reference-only safe_cover_scene={json.dumps(str(row.get('safe_cover_scene') or ''), ensure_ascii=False)}. "
                    "Keep them fully clothed, healthy, safe, and supervised; a photo, toy, bag, silhouette, or adult-only implication does not count. "
                    "When a required minor is visible, do not combine that minor in the same image prompt with abandonment or humiliation directed at the child, hidden surveillance, coercive parenting, bedroom or bedside intimacy, police restraint, escort, or control, paternity-evidence confrontation, or adult physical/coercive conflict. Express the strong adult reversal through status, posture, relationship, or consequence while the child remains calm and protected. Do not remove a required child."
                )
        persistent_lines.append(
            "For all three groups, keep scene_prompt_4_5 concise and non-repetitive. It must contain the title-linked relationship, action, emotion, believable location, natural/practical light, and camera blocking, but no controller-owned global Style or Typography wording."
        )
        persistent_lines.append(
            "Do not use doors or vehicle doors as primary scene devices. Never build the scene, main action, actor interaction, or camera blocking around opening or closing a door, blocking, standing, waiting, or leaning at a doorway, entering or exiting through a vehicle door, gripping a car door, or confronting across a door. Freely create a fresh title-specific non-door scene and action without selecting from a replacement list. A distant closed door may remain incidental background architecture only when nobody interacts with it. This is a hard generation and validation requirement."
        )
        persistent_lines.append(
            "Never show Chinese police, public-security, traffic-police, special-police, law-enforcement, or other public-service uniforms or their official caps, badges, emblems, epaulettes, shoulder boards, or service numbers. If a scene needs an order-maintaining figure, use only a commercial security guard in a plain neutral security uniform with no government or police insignia."
        )
        persistent_lines.append(
            "For all three groups, forbid hitting and threatened hitting. All three normalized core_words values must be distinct. Each core_words value must be one idiomatic native word or a natural two-word modifier-plus-head phrase. Never mechanically concatenate two plot nouns or omit a linker required by native grammar; choose a different one- or two-word hook when the natural expression would need three or more words. Return outpaint_environment as environment continuation only."
        )
        persistent_lines.append(
            "For every title return scene_prompt_4_5 and outpaint_environment only for prompt planning. Never return "
            "prompt_4_5 or prompt_16_9; those final fields are controller-owned and are not present in the response schema."
        )
        if "女" in str(task.get("gender") or ""):
            persistent_lines.append(
                "This is a female-frequency task: all three groups must contain zero visual special effects, including magic, aura, energy, lightning, particles, fire, explosion, hologram, fake glow, glowing eyes, lasers, scanner beams, or supernatural light."
            )
    elif stage == "xy-place":
        persistent_lines.append(
            "When minors appear, keep adult wrongdoing and child-safe facts in separate sentences. Do not describe a minor as the direct target of abandonment, humiliation, hostile surveillance, coercive parenting, police restraint or control, adult confrontation, or bedroom/bedside intimacy. Keep the child as a protected relationship, identity, reunion, or family anchor while preserving the adult betrayal, reversal, punishment, and payoff."
        )
    actionable_feedback = "\n".join(correction_lines)
    persistent_requirements = "\n".join(persistent_lines)
    return "\n\n".join(
        [
            "You are a pure content-generation function inside a deterministic production pipeline.",
            "Do not call tools, inspect files, browse, run commands, or explain your work. Return only JSON matching the supplied response schema.",
            "The Skill below is a business contract. Follow its content-generation and output-field rules. Ignore any instruction in it to read/write files, update workflow_state, call another skill, or talk to the user; the outer controller owns all I/O and state.",
            f"Current stage: {stage}",
            stage_directive or STAGE_DIRECTIVES[stage],
            "Generation acceptance specification (owned by the same controller as validation):\n"
            + json.dumps(acceptance_spec, ensure_ascii=False),
            "Authoritative Skill contract:\n" + rules,
            "Normalized immutable input JSON:\n" + json.dumps(scoped_context, ensure_ascii=False),
            "Previous validation errors to correct:\n" + json.dumps(previous_issues, ensure_ascii=False),
            "Controller-owned actionable correction instructions:\n" + actionable_feedback,
            "Persistent generation requirements (must remain true on the initial attempt and every retry, even when correcting a different error):\n"
            + persistent_requirements,
            "Identity fields in the response must exactly equal input.identity. Do not add fields outside the schema.",
        ]
    )


def state_for(package: Path, item: dict[str, Any]) -> dict[str, Any]:
    state_path = package / "workflow_state.json"
    state = load_json(state_path, {})
    state.setdefault("drama_name", item.get("drama_name", ""))
    state.setdefault("video_id", item.get("video_id", ""))
    state.setdefault("channel", item.get("channel", ""))
    state.setdefault("language", item.get("language", ""))
    state.setdefault("gender", item.get("gender", ""))
    state.setdefault("direction", item.get("direction", ""))
    state.setdefault("slot", item.get("slot", ""))
    state["workflow_contract_version"] = int(item.get("workflow_contract_version") or 1)
    state["need_community"] = bool(item.get("need_community"))
    state["community_output_version"] = int(item.get("community_output_version") or 1)
    state["community_count"] = int(item.get("community_count", 1 if item.get("need_community") else 0) or 0)
    state.setdefault("steps", {})
    return state


def update_step_state(
    package: Path,
    item: dict[str, Any],
    stage: str,
    status: str,
    attempts: int,
    errors: list[str],
    contract_sha: str,
    *,
    count_attempt: bool = True,
) -> None:
    state = state_for(package, item)
    state["contract_id"] = str(item.get("contract_id") or state.get("contract_id") or "")
    previous = state["steps"].get(stage)
    step = dict(previous) if isinstance(previous, dict) else {}
    previous_attempts = int(step.get("attempts") or 0)
    previous_total = int(step.get("attempts_total") or previous_attempts)
    cycle_base_total = max(previous_total - previous_attempts, 0)
    collision_history = [
        str(value) for value in step.get("collision_feedback_history", [])
        if isinstance(value, str) and "visual_collision_with_history" in value
    ]
    seed = item.get("retry_feedback_seed")
    if isinstance(seed, list):
        for error in seed:
            value = str(error)
            if "visual_collision_with_history" in value and value not in collision_history:
                collision_history.append(value)
    for error in errors:
        value = str(error)
        if "visual_collision_with_history" in value and value not in collision_history:
            collision_history.append(value)
    step.update(
        {
            "status": status,
            "attempts": attempts,
            "attempts_total": (
                max(previous_total, cycle_base_total + attempts)
                if count_attempt
                else cycle_base_total + attempts
            ),
            "retry_cycle": int(step.get("retry_cycle") or 1),
            "errors": errors,
            "contract_sha256": contract_sha,
            "updated_at": timestamp(),
        }
    )
    if collision_history:
        step["collision_feedback_history"] = collision_history
    state["steps"][stage] = step
    state[stage] = "done" if status in {"done", "skipped"} else status
    state["updated_at"] = timestamp()
    write_json(package / "workflow_state.json", state)
    append_workflow_event(
        package,
        {
            "event": "stage_state_changed",
            "actor": "xy-batch-v14",
            "contract_id": state["contract_id"],
            "stage": stage,
            "status": status,
            "attempt": attempts,
            "errors": errors,
            "contract_sha256": contract_sha,
        },
    )


def stage_step(package: Path, item: dict[str, Any], stage: str) -> dict[str, Any]:
    value = state_for(package, item).get("steps", {}).get(stage)
    return dict(value) if isinstance(value, dict) else {}


def stage_attempts(package: Path, item: dict[str, Any], stage: str) -> int:
    try:
        return max(0, int(stage_step(package, item, stage).get("attempts") or 0))
    except (TypeError, ValueError):
        return 0


def stage_errors(package: Path, item: dict[str, Any], stage: str) -> list[str]:
    errors = stage_step(package, item, stage).get("errors")
    return [str(value) for value in errors] if isinstance(errors, list) else []


def merge_retry_feedback(*groups: list[str]) -> list[str]:
    merged: list[str] = []
    for group in groups:
        for issue in group:
            value = str(issue)
            if value and value not in merged:
                merged.append(value)
    return merged


def stage_retry_feedback(package: Path, item: dict[str, Any], stage: str) -> list[str]:
    """Return current issues plus every visual collision forbidden so far."""
    step = stage_step(package, item, stage)
    groups: list[list[str]] = [stage_errors(package, item, stage)]
    history = step.get("collision_feedback_history")
    if isinstance(history, list):
        groups.append([str(value) for value in history])
    retry_history = step.get("retry_history")
    if isinstance(retry_history, list):
        for cycle in retry_history:
            if isinstance(cycle, dict) and isinstance(cycle.get("errors"), list):
                groups.append([
                    str(value) for value in cycle["errors"]
                    if "visual_collision_with_history" in str(value)
                ])
    seed = item.get("retry_feedback_seed")
    if isinstance(seed, list):
        groups.append([str(value) for value in seed])
    return merge_retry_feedback(*groups)


def retry_stage_for_item(item: dict[str, Any]) -> str:
    """Resolve the real exhausted stage from package state, never stale index state."""
    package = Path(str(item.get("package_path") or "")).resolve()
    if not package.exists():
        return ""
    state = state_for(package, item)
    steps = state.get("steps", {}) if isinstance(state.get("steps"), dict) else {}
    stage = str(item.get("current_stage") or "")
    previous = steps.get(stage) if stage in ALL_STAGES else None
    if (
        isinstance(previous, dict)
        and previous.get("status") not in {"done", "skipped"}
        and (
            int(previous.get("attempts") or 0) >= 3
            or previous.get("status") in {"needs_user_review", "failed", "retrying"}
        )
    ):
        return stage
    return next(
        (
            candidate for candidate in ALL_STAGES
            if isinstance(steps.get(candidate), dict)
            and steps[candidate].get("status") not in {"done", "skipped"}
            and (
                int(steps[candidate].get("attempts") or 0) >= 3
                or steps[candidate].get("status") in {"needs_user_review", "failed", "retrying"}
            )
        ),
        "",
    )


def approve_retry_cycle(item: dict[str, Any]) -> bool:
    """Open a fresh three-attempt cycle only after explicit user approval."""
    stage = retry_stage_for_item(item)
    if not stage:
        return False
    package = Path(str(item.get("package_path") or "")).resolve()
    state = state_for(package, item)
    previous = state.get("steps", {}).get(stage)
    item["current_stage"] = stage
    step = dict(previous)
    attempts = int(step.get("attempts") or 0)
    attempts_total = int(step.get("attempts_total") or attempts)
    previous_errors = list(step.get("errors") or [])
    history = step.get("retry_history")
    retry_history = list(history) if isinstance(history, list) else []
    retry_history.append(
        {
            "retry_cycle": int(step.get("retry_cycle") or 1),
            "attempts": attempts,
            "attempts_total": attempts_total,
            "errors": list(step.get("errors") or []),
            "collision_feedback_history": list(step.get("collision_feedback_history") or []),
            "closed_at": timestamp(),
            "reason": "explicit --retry-failed approval",
        }
    )
    step.update(
        {
            "status": "approved_retry",
            "attempts": 0,
            "attempts_total": attempts_total,
            "retry_cycle": int(step.get("retry_cycle") or 1) + 1,
            "errors": previous_errors,
            "retry_history": retry_history,
            "approved_at": timestamp(),
        }
    )
    state["steps"][stage] = step
    state[stage] = "approved_retry"
    state["updated_at"] = timestamp()
    write_json(package / "workflow_state.json", state)
    # A formally approved retry resumes at the exhausted stage.  Without this
    # marker run_drama starts at xy-find and revisits already accepted upstream
    # stages, which violates the narrow-retry contract and can rewrite fields
    # that the operator explicitly asked us to preserve.
    item["resume_from_stage"] = stage
    item["retry_approved_at"] = timestamp()
    item["error"] = ""
    return True


def needs_retry_approval(item: dict[str, Any]) -> bool:
    """Return true for failed items and interrupted in-flight exhausted stages."""
    status = normalize_status(str(item.get("status") or ""))
    if status in {"SKIPPED", "TEXT_READY", "IMAGE_PARTIAL", "PACKAGE_READY", "DELIVERED"}:
        return False
    return bool(retry_stage_for_item(item))


def should_refill_worker(_status: str) -> bool:
    """A task outcome must never permanently reduce configured concurrency."""
    return True


def normalize_interrupted_items(index: dict[str, Any]) -> int:
    """Recover without ever creating a second Feishu row for the same package."""
    changed = 0
    for item in index.get("items", []):
        if normalize_status(str(item.get("status") or "")) == "GENERATING":
            if int(item.get("output_row_number") or 0) > 0:
                item["status"] = "WRITEBACK_PENDING"
                item["resume_from_stage"] = str(item.get("current_stage") or "")
            else:
                item["status"] = "INTERRUPTED"
            changed += 1
    return changed


def restore_clean_recreate_output_rows(index: dict[str, Any]) -> int:
    """Restore explicitly pinned result rows from the immutable rebuild records."""
    records = index.get("clean_recreate", {}).get("records", [])
    intended = {
        str(record.get("video_id") or ""): int(record.get("output_row_number") or 0)
        for record in records
        if str(record.get("video_id") or "") and int(record.get("output_row_number") or 0) >= 2
    }
    changed = 0
    for item in index.get("items", []):
        row_number = intended.get(str(item.get("video_id") or ""), 0)
        if row_number and int(item.get("output_row_number") or 0) != row_number:
            item["output_row_number"] = row_number
            changed += 1
    return changed


def accepted_existing(stage: str, package: Path, item: dict[str, Any], context: dict[str, Any]) -> bool:
    json_name, _ = STAGE_FILES[stage]
    path = package / json_name
    if not path.exists():
        return False
    payload = load_json(path, {})
    if stage == "xy-find":
        result = first_result(payload)
        market_payload = load_json(package / "01_市场包装证据.json", {})
        expected_market_identity = {
            "drama_id": str(item.get("video_id") or item.get("slot") or ""),
            "drama_title": str(item.get("drama_name") or ""),
            "channel_name": str(item.get("channel") or ""),
            "channel_language": str(item.get("language") or ""),
            "channel_type": str(item.get("direction") or ""),
        }
        return bool(
            result
            and result.get("drama_name") == item.get("drama_name")
            and result.get("plot_fields")
            and not validate_market_packaging_evidence(market_payload, expected_market_identity)
        )
    return not validate_payload(stage, payload, item, context)


def resume_stage_after_find_validation(
    resume_stage: str,
    package: Path,
    item: dict[str, Any],
    base_context: dict[str, Any],
) -> str:
    """Never resume downstream from an incomplete plot/market handoff."""
    if resume_stage and not accepted_existing("xy-find", package, item, base_context):
        return ""
    return resume_stage


def execute_find_stage(
    package: Path,
    item: dict[str, Any],
    market_rules: str,
    library: DramaLibraryClient,
    model_client: JsonModelClient,
    attempt: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Write immutable plot truth, then independently derive market packaging."""
    plot_payload = library.exact_match(
        str(item.get("drama_name") or ""),
        str(item.get("video_id") or ""),
        str(item.get("slot") or ""),
    )
    write_stage_outputs(package, "xy-find", plot_payload)
    external_evidence = collect_agent_reach_evidence(item)
    market_prompt = build_market_packaging_prompt(item, plot_payload, market_rules, external_evidence)
    try:
        market_payload = model_client.generate(
            "xy-find-market",
            market_prompt,
            item,
            attempt,
            output_schema=MARKET_PACKAGING_SCHEMA,
        )
    except RuntimeError as exc:
        fallback_prompt = "\n\n".join(
            [
                market_prompt,
                "External YouTube search could not be executed in this run.",
                "Set search_status to failed, verified_market_angle_count to 0, and fallback.used to true.",
                "Return exactly three distinct story_derived final angles A/B/C using plot_truth only.",
                "All market_videos and market_evidence_refs must be empty. Do not claim external market evidence.",
                "不得声称已获得外部市场证据。联网失败原因仅写入 fallback.reason。",
                f"Search execution error: {str(exc)[-300:]}",
            ]
        )
        market_payload = model_client.generate(
            "xy-find-story-fallback",
            fallback_prompt,
            item,
            attempt,
            output_schema=MARKET_PACKAGING_SCHEMA,
        )
    expected_market_identity = {
        "drama_id": str(item.get("video_id") or item.get("slot") or ""),
        "drama_title": str(item.get("drama_name") or ""),
        "channel_name": str(item.get("channel") or ""),
        "channel_language": str(item.get("language") or ""),
        "channel_type": str(item.get("direction") or ""),
    }
    issues = validate_market_packaging_evidence(market_payload, expected_market_identity)
    if issues:
        raise RuntimeError("01_市场包装证据验收失败: " + "; ".join(issues))
    write_market_packaging_outputs(package, market_payload)
    return plot_payload, market_payload


def build_prompt_manifest(
    package: Path,
    item: dict[str, Any],
    cover_rule_contract: dict[str, Any] | None = None,
    contract_id: str = "",
) -> None:
    cover_payload = load_json(package / "04_封面提示词.json", {})
    community_payload = load_json(package / "06_社群方案.json", {})
    active_cover_contract = cover_rule_contract or load_cover_rule_bundle()
    wide_execution = (
        active_cover_contract
        .get("prompt_audit", {})
        .get("wide_generation_execution", {})
    )
    wide_mode = str(wide_execution.get("mode") or "image_to_image_outpaint")
    wide_mask_policy = str(wide_execution.get("mask_policy") or "side_bands_only")
    wide_center_restore = bool(wide_execution.get("center_restore_required", True))
    prompt_dir = package / "images/prompts"
    raw_dir = package / "images/raw"
    final_dir = package / "images/final"
    for path in (prompt_dir, raw_dir, final_dir):
        path.mkdir(parents=True, exist_ok=True)
    tasks = []
    video_id = str(item.get("video_id") or "")
    order = 0
    for row in cover_rows(cover_payload):
        index = int(row.get("title_index") or 0)
        source_task_id = ""
        source_target_path = ""
        for ratio, key in (("4x5", "prompt_4_5"), ("16x9", "prompt_16_9")):
            order += 1
            task_id = f"{video_id}_{order:02d}_title{index}_{ratio}"
            target_filename = f"{order:02d}_标题{index}_{ratio}.png"
            prompt_file = prompt_dir / f"{task_id}.md"
            prompt = str(row.get(key) or "")
            generation_contract = {}
            if ratio == "4x5":
                source_task_id = task_id
                source_target_path = str(raw_dir / target_filename)
                generation_contract = {"generation_mode": "text_to_image"}
            else:
                generation_contract = {
                    "generation_mode": wide_mode,
                    "depends_on_task_id": source_task_id,
                    "source_image_task_id": source_task_id,
                    "source_image_target_path": source_target_path,
                    "mask_policy": wide_mask_policy,
                    "center_restore_required": wide_center_restore,
                }
            prompt_file.write_text(prompt + "\n", encoding="utf-8")
            tasks.append(
                task_lineage({
                    "task_id": task_id,
                    "order": order,
                    "slug": f"title{index}",
                    "ratio": ratio,
                    "target_filename": target_filename,
                    "target_path": str(raw_dir / target_filename),
                    "prompt_file": str(prompt_file),
                    "status": "prompt_ready",
                    "prompt": prompt,
                    **generation_contract,
                }, contract_id=contract_id, prompt_version=1, attempt=1)
            )
    community_count = int(item.get("community_count", 1 if item.get("need_community") else 0) or 0)
    community_results = community_payload.get("results") if isinstance(community_payload, dict) else []
    for plan_index, result in enumerate(community_results[:community_count], 1):
        order += 1
        task_id = f"{video_id}_{order:02d}_community{plan_index}_1x1"
        target_filename = f"{order:02d}_社群图{plan_index}_1x1.png"
        prompt = str(result.get("image_prompt_1x1") or "")
        prompt_file = prompt_dir / f"{task_id}.md"
        prompt_file.write_text(prompt + "\n", encoding="utf-8")
        tasks.append(
            task_lineage({
                "task_id": task_id,
                "order": order,
                "slug": f"community{plan_index}",
                "ratio": "1x1",
                "target_filename": target_filename,
                "target_path": str(raw_dir / target_filename),
                "prompt_file": str(prompt_file),
                "status": "prompt_ready",
                "prompt": prompt,
            }, contract_id=contract_id, prompt_version=1, attempt=1)
        )
    manifest = {
        "drama_name": item.get("drama_name", ""),
        "video_id": video_id,
        "channel": item.get("channel", ""),
        "nickname": item.get("nickname", ""),
        "language": item.get("language", ""),
        "slot": item.get("slot", ""),
        "need_community": int(bool(item.get("need_community"))),
        "community_output_version": int(item.get("community_output_version") or 1),
        "community_count": community_count,
        "prompt_status": "prompt_ready",
        "contract_id": contract_id,
        "manifest_version": 2,
        "required_asset_manifest": {
            "scope": "all_declared_tasks",
            "required_count": len(tasks),
            "required_task_ids": [task["task_id"] for task in tasks],
        },
        "tasks": tasks,
    }
    write_json(prompt_dir / "出图任务清单.json", manifest)
    lines = ["# 出图任务清单", ""]
    for task in tasks:
        lines.extend([f"## {task['task_id']}", "", task["prompt"], ""])
    (prompt_dir / "出图任务清单.md").write_text("\n".join(lines), encoding="utf-8")


class BatchController:
    def __init__(self, index_path: Path, index: dict[str, Any], skip_export: bool) -> None:
        self.index_path = index_path
        self.index = index
        self.skip_export = skip_export
        self.lock = threading.RLock()

    def persist_index(self) -> None:
        with self.lock:
            write_json(self.index_path, self.index)

    def claim(self, item: dict[str, Any]) -> None:
        if self.skip_export:
            item["status"] = "CLAIMED"
            item["claimed_at"] = timestamp()
            self.persist_index()
            return
        clean_recreate = item.get("clean_recreate")
        if (
            isinstance(clean_recreate, dict)
            and clean_recreate.get("source_drama_name")
            and clean_recreate.get("target_drama_name")
            and int(item.get("output_row_number") or 0) > 0
        ):
            row_number = int(item["output_row_number"])
            try:
                result = rewrite_output_base_row(
                    item, row_number, str(clean_recreate["source_drama_name"])
                )
            except Exception as exc:
                raise WritebackPendingError(f"Feishu身份纠正基础字段回写失败: {exc}") from exc
            if int(result.get("row_number") or 0) != row_number:
                raise WritebackPendingError(
                    f"Feishu身份纠正返回了错误行号: expected={row_number}, "
                    f"actual={result.get('row_number')}"
                )
            item["status"] = "CLAIMED"
            item["claimed_at"] = timestamp()
            item["claim_message"] = "已在原任务行纠正A:H身份字段"
            self.persist_index()
            return
        if (
            normalize_status(str(item.get("status") or "")) in {"SYSTEM_ERROR", "WRITEBACK_PENDING"}
            and int(item.get("output_row_number") or 0) > 0
        ):
            item["resume_from_stage"] = str(item.get("current_stage") or "")
            item["status"] = "CLAIMED"
            item["claimed_at"] = timestamp()
            item["claim_message"] = "沿用既有任务行，仅续传失败阶段"
            self.persist_index()
            return
        try:
            result = ensure_output_base_row(item)
        except Exception as exc:
            raise WritebackPendingError(f"Feishu基础字段回写失败: {exc}") from exc
        item["output_row_number"] = result.get("row_number")
        item["status"] = "CLAIMED"
        item["claimed_at"] = timestamp()
        item["claim_message"] = "已回写A:H基础字段"
        self.persist_index()

    def checkpoint(self, item: dict[str, Any], package: Path, stage: str) -> None:
        with self.lock:
            item["current_stage"] = stage
            item["current_stage_started_at"] = timestamp()
            self.persist_index()
        if stage != "xy-find" and not self.skip_export:
            last_error = ""
            for attempt in range(1, 4):
                try:
                    # Header expansion for numbered community columns and the
                    # matching row write must be serialized across workers.
                    with self.lock:
                        writeback = write_stage_back(item, package, stage)
                        if writeback.get("updated") and not writeback.get("readback_verified"):
                            raise RuntimeError(f"{stage} 飞书写后回读未确认")
                        verified = item.setdefault("writeback_readback_stages", [])
                        if stage not in verified:
                            verified.append(stage)
                        self.persist_index()
                    last_error = ""
                    break
                except Exception as exc:
                    last_error = str(exc)
                    if attempt < 3:
                        time.sleep(attempt)
            if last_error:
                raise WritebackPendingError(f"Feishu阶段回写连续失败3次: {last_error}")
        with self.lock:
            item["last_completed_stage"] = stage
            item["last_stage_event_at"] = timestamp()
            self.persist_index()

    def finish(self, item: dict[str, Any], status: str, error: str = "") -> None:
        with self.lock:
            item["status"] = status
            item["error"] = error
            item["error_type"] = (
                "SYSTEM_ERROR"
                if normalize_status(status) in {"SYSTEM_ERROR", "WRITEBACK_PENDING"}
                else "CONTENT_ERROR"
                if normalize_status(status) == "NEEDS_USER_REVIEW"
                else ""
            )
            item["auto_finished_at"] = timestamp()
            if normalize_status(status) == "NEEDS_USER_REVIEW":
                review_path = self.index_path.parent / "待用户确认.json"
                review = load_json(review_path, {"items": []})
                review.setdefault("items", []).append(
                    {
                        "row_number": item.get("row_number"),
                        "drama_name": item.get("drama_name", ""),
                        "video_id": item.get("video_id", ""),
                        "stage": item.get("current_stage", "claim"),
                        "error": error,
                        "created_at": timestamp(),
                    }
                )
                write_json(review_path, review)
            self.persist_index()


def content_stages_for_resume(resume_stage: str) -> tuple[str, ...]:
    if resume_stage not in CONTENT_STAGES:
        return CONTENT_STAGES
    return CONTENT_STAGES[CONTENT_STAGES.index(resume_stage):]


def run_drama(
    item: dict[str, Any],
    controller: BatchController,
    contracts: ContractBundle,
    library: DramaLibraryClient,
    model_client: JsonModelClient,
) -> dict[str, Any]:
    package = Path(str(item.get("package_path") or "")).resolve()
    if not package.exists():
        return failure_result_for_exception(SystemStageError(f"剧目包不存在: {package}"))
    item["auto_started_at"] = timestamp()
    item["contract_id"] = contracts.contract_id
    item["contract_version"] = int(contracts.snapshot.get("version") or 0)
    item["status"] = "GENERATING"
    initial_state = state_for(package, item)
    initial_state["contract_id"] = contracts.contract_id
    initial_state["contract_version"] = item["contract_version"]
    initial_state["status"] = "GENERATING"
    initial_state["package_status"] = "GENERATING"
    write_json(package / "workflow_state.json", initial_state)
    controller.persist_index()
    try:
        resume_stage = str(item.pop("resume_from_stage", "") or "")
        base_context = package_context(package, item, "xy-find")
        resume_stage = resume_stage_after_find_validation(
            resume_stage,
            package,
            item,
            base_context,
        )
        if not resume_stage:
            item["current_stage"] = "xy-find"
            controller.persist_index()
        if not resume_stage and not accepted_existing("xy-find", package, item, base_context):
            used_attempts = stage_attempts(package, item, "xy-find")
            previous_errors = stage_errors(package, item, "xy-find")
            if used_attempts >= MAX_STAGE_ATTEMPTS:
                raise RuntimeError("xy-find 当前重试周期已用尽3次；需要显式 --retry-failed 才能开启新周期")
            last_error = previous_errors[-1] if previous_errors else ""
            for attempt in range(used_attempts + 1, MAX_STAGE_ATTEMPTS + 1):
                update_step_state(package, item, "xy-find", "running", attempt, previous_errors, contracts.sha("xy-find"))
                try:
                    item["current_retry_cycle"] = int(
                        stage_step(package, item, "xy-find").get("retry_cycle") or 1
                    )
                    controller.persist_index()
                    execute_find_stage(
                        package,
                        item,
                        contracts.rules["xy-find"],
                        library,
                        model_client,
                        attempt,
                    )
                    update_step_state(package, item, "xy-find", "done", attempt, [], contracts.sha("xy-find"))
                    controller.checkpoint(item, package, "xy-find")
                    last_error = ""
                    break
                except Exception as exc:
                    last_error = str(exc)
                    previous_errors = [last_error]
                    update_step_state(package, item, "xy-find", "retrying", attempt, previous_errors, contracts.sha("xy-find"))
                    if attempt < MAX_STAGE_ATTEMPTS:
                        time.sleep(attempt)
            if last_error:
                raise RuntimeError(last_error)
        elif not resume_stage:
            controller.checkpoint(item, package, "xy-find")
            update_step_state(
                package,
                item,
                "xy-find",
                "done",
                stage_attempts(package, item, "xy-find"),
                [],
                contracts.sha("xy-find"),
            )

        for stage in content_stages_for_resume(resume_stage):
            item["current_stage"] = stage
            controller.persist_index()
            if stage == "xy-post" and not item.get("need_community"):
                update_step_state(package, item, stage, "skipped", stage_attempts(package, item, stage), [], contracts.sha(stage))
                continue
            context = attach_recent_title_frequency_guidance(
                with_frozen_machine_contract(package_context(package, item, stage), contracts, stage),
                package,
                item,
                stage,
            )
            preflight_issues = stage_preflight_issues(stage, context, contracts.machine(stage))
            if preflight_issues:
                raise SystemStageError(f"{stage} preflight failed: " + "; ".join(preflight_issues))
            if accepted_existing(stage, package, item, context):
                payload = load_json(package / STAGE_FILES[stage][0], {})
                write_stage_outputs(package, stage, payload)
                controller.checkpoint(item, package, stage)
                update_step_state(package, item, stage, "done", stage_attempts(package, item, stage), [], contracts.sha(stage))
                continue
            used_attempts = stage_attempts(package, item, stage)
            current_issues = stage_errors(package, item, stage)
            previous_issues = stage_retry_feedback(package, item, stage)
            if used_attempts >= MAX_STAGE_ATTEMPTS:
                raise RuntimeError(f"{stage} 当前重试周期已用尽3次；需要显式 --retry-failed 才能开启新周期")
            accepted = False
            for attempt in range(used_attempts + 1, MAX_STAGE_ATTEMPTS + 1):
                if stage in CONTENT_STAGES:
                    # Refresh before every creative attempt so the prompt sees
                    # packages accepted by other workers instead of stale history.
                    context = attach_recent_title_frequency_guidance(
                        with_frozen_machine_contract(package_context(package, item, stage), contracts, stage),
                        package,
                        item,
                        stage,
                    )
                prompt = build_prompt(
                    stage,
                    contracts.rules[stage],
                    context,
                    previous_issues,
                    stage_directive=contracts.directive(stage),
                )
                # Persist before the external model call.  A process death in
                # the middle of the call must still consume this attempt.
                update_step_state(package, item, stage, "running", attempt, current_issues, contracts.sha(stage))
                item["current_retry_cycle"] = int(stage_step(package, item, stage).get("retry_cycle") or 1)
                controller.persist_index()
                try:
                    payload = model_client.generate(
                        stage, prompt, item, attempt, output_schema=contracts.schema(stage, item)
                    )
                    model_schema_issues: list[str] = []
                    if stage == "xy-title":
                        normalize_title_translation_format(payload, context)
                        normalize_title_recommendation_order(payload, context)
                    elif stage == "xy-cover":
                        # The response schema describes only model-owned planning
                        # fields.  Validate that boundary before the controller
                        # adds its canonical final prompt fields; never feed the
                        # assembled object back through the model schema.
                        model_schema_issues = validate_model_output_schema(
                            stage, payload, item, context
                        )
                        if not model_schema_issues:
                            normalize_cover_prompt_contract(payload, contracts.machine("xy-cover"))
                    elif stage == "xy-place":
                        normalize_place_fixed_footer(payload, context, item)
                    # Validation plus acceptance is atomic for every creative
                    # stage. Without this lock, two workers processing the same
                    # drama in different channels can both validate against the
                    # same stale history and accept translated/reworded copies.
                    with _CREATIVE_ACCEPT_LOCK:
                        context = with_frozen_machine_contract(package_context(package, item, stage), contracts, stage)
                        issues = model_schema_issues or validate_payload(
                            stage,
                            payload,
                            item,
                            context,
                            validate_schema=(stage != "xy-cover"),
                        )
                        if not issues:
                            normalize_identity(payload, item)
                            write_stage_outputs(package, stage, payload)
                            if stage == "xy-cover":
                                audit_evidence = {
                                    "version": 1,
                                    "mode": "audit_only_except_hard_forbidden",
                                    "contract_id": contracts.contract_id,
                                    "generated_at": timestamp(),
                                    "groups": [
                                        cover_prompt_quality_observations(
                                            str(row.get("prompt_4_5") or ""),
                                            position,
                                            contracts.machine("xy-cover"),
                                        )
                                        for position, row in enumerate(cover_rows(payload), 1)
                                    ],
                                }
                                write_json(package / "04_封面审计.json", audit_evidence)
                    if issues:
                        system_issues = system_validation_issues(issues)
                        if system_issues:
                            tagged = [f"SYSTEM_ERROR:{value}" for value in system_issues]
                            update_step_state(
                                package,
                                item,
                                stage,
                                "system_error",
                                used_attempts,
                                tagged,
                                contracts.sha(stage),
                                count_attempt=False,
                            )
                            raise SystemStageError(f"{stage} 系统契约错误: " + "; ".join(system_issues))
                        update_step_state(package, item, stage, "retrying", attempt, issues, contracts.sha(stage))
                        current_issues = issues
                        previous_issues = merge_retry_feedback(
                            issues, stage_retry_feedback(package, item, stage)
                        )
                        continue
                    accepted = True
                    break
                except SystemStageError:
                    raise
                except Exception as exc:
                    current_issues = [f"SYSTEM_ERROR:{exc}"]
                    update_step_state(
                        package,
                        item,
                        stage,
                        "system_error",
                        used_attempts,
                        current_issues,
                        contracts.sha(stage),
                        count_attempt=False,
                    )
                    raise SystemStageError(f"{stage} 系统/调用错误: {exc}") from exc
            if not accepted:
                raise RuntimeError(f"{stage} 三次尝试仍未通过: " + "; ".join(current_issues))
            # Writeback has its own retry loop. Never regenerate accepted
            # content merely because Feishu is temporarily unavailable.
            controller.checkpoint(item, package, stage)
            update_step_state(package, item, stage, "done", attempt, [], contracts.sha(stage))

        build_prompt_manifest(
            package,
            item,
            cover_rule_contract=contracts.machine("xy-cover"),
            contract_id=contracts.contract_id,
        )
        (package / "运营包.md").write_text(build_package(package), encoding="utf-8")
        state = state_for(package, item)
        image_status = str(item.get("image_status") or "pending")
        final_status = completion_status_for_images(image_status)
        state["status"] = final_status
        state["package_status"] = final_status
        state["image_status"] = image_status
        state["contract_id"] = contracts.contract_id
        state["contract_version"] = int(contracts.snapshot.get("version") or 0)
        state["assembled_package"] = True
        state["updated_at"] = timestamp()
        write_json(package / "workflow_state.json", state)
        append_workflow_event(
            package,
            {
                "event": "text_pipeline_finished",
                "status": final_status,
                "image_status": image_status,
                "contract_id": contracts.contract_id,
            },
        )
        return {"status": final_status, "error": ""}
    except Exception as exc:
        return failure_result_for_exception(exc)


def runnable_items(index: dict[str, Any], retry_failed: bool, max_output_row: int) -> list[dict[str, Any]]:
    rows = []
    for item in index.get("items", []):
        status = normalize_status(str(item.get("status") or ""))
        if status in {"SKIPPED", "TEXT_READY", "IMAGE_PARTIAL", "PACKAGE_READY", "DELIVERED"}:
            continue
        if status == "NEEDS_USER_REVIEW" and not retry_failed:
            continue
        if max_output_row and int(item.get("output_row_number") or 0) > max_output_row:
            continue
        rows.append(item)
    return rows


def claim_next_item(
    queue: list[dict[str, Any]],
    start_index: int,
    controller: Any,
    results: list[dict[str, Any]],
) -> tuple[dict[str, Any] | None, int]:
    """Skip failed claims and keep filling the worker slot from later rows."""
    next_index = start_index
    while next_index < len(queue):
        item = queue[next_index]
        next_index += 1
        try:
            controller.claim(item)
            return item, next_index
        except Exception as exc:
            error = f"领取任务失败: {exc}"
            item["current_stage"] = "claim"
            failure = failure_result_for_exception(exc)
            controller.finish(item, failure["status"], error)
            results.append(
                {
                    "row_number": item.get("row_number"),
                    "drama_name": item.get("drama_name", ""),
                    "video_id": item.get("video_id", ""),
                    "status": failure["status"],
                    "error": error,
                }
            )
    return None, next_index


def write_report(index_path: Path, results: list[dict[str, Any]], elapsed: float) -> None:
    payload = {"generated_at": timestamp(), "elapsed_seconds": round(elapsed, 2), "results": results}
    write_json(index_path.parent / "批量自动执行报告.json", payload)
    lines = ["# 批量自动执行报告", "", f"耗时：{elapsed:.1f} 秒", ""]
    for row in results:
        lines.append(f"- 第{row.get('row_number')}行｜{row.get('drama_name')}｜{row.get('status')}｜{row.get('error', '')}")
    (index_path.parent / "批量自动执行报告.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--index", default="")
    parser.add_argument("--max-output-row", type=int, default=0)
    parser.add_argument("--codex", default="")
    parser.add_argument("--model", default="")
    parser.add_argument("--timeout", type=int, default=900)
    parser.add_argument("--workers", type=int, default=10)
    parser.add_argument("--chunk-size", type=int, default=1)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--skip-export", action="store_true")
    parser.add_argument(
        "--enable-live-writeback",
        action="store_true",
        help="Explicitly allow V2 to write the live Feishu task output sheet",
    )
    parser.add_argument("--retry-failed", action="store_true")
    parser.add_argument("--preflight", action="store_true", help="Read-only Feishu and contract check; run no production")
    args = parser.parse_args()
    if args.chunk_size != 1:
        raise SystemExit("确定性流程要求 --chunk-size 固定为1")

    root = Path(args.root).expanduser().resolve()
    index_path = resolve_index(root, args.index)
    index = load_json(index_path, {})
    restore_clean_recreate_output_rows(index)
    normalize_interrupted_items(index)
    allocate_creative_slots(index, historical_indices=historical_creative_slot_indices(index_path))
    contracts = load_contract_bundle(
        index_path.parent,
        persist_if_missing=not (args.preflight or args.dry_run),
    )
    contracts.assert_runtime_compatible()
    library = DramaLibraryClient()
    preflight = library.preflight()
    if args.preflight:
        print(json.dumps({"ok": True, "index": str(index_path), "drama_library": preflight, "contract": str(contracts.path)}, ensure_ascii=False, indent=2))
        return
    if args.dry_run:
        print(json.dumps({"ok": True, "dry_run": True, "runnable": len(runnable_items(index, args.retry_failed, args.max_output_row)), "drama_library": preflight}, ensure_ascii=False, indent=2))
        return

    write_json(index_path, index)

    if args.retry_failed:
        for item in index.get("items", []):
            if needs_retry_approval(item):
                approve_retry_cycle(item)
        write_json(index_path, index)

    codex_bin = args.codex or shutil.which("codex") or "/Applications/ChatGPT.app/Contents/Resources/codex"
    if not Path(codex_bin).exists():
        raise SystemExit(f"找不到Codex内容生成接口: {codex_bin}")
    logs_dir = index_path.parent / "自动执行日志"
    model_client = JsonModelClient(codex_bin, args.model, args.timeout, logs_dir)
    controller = BatchController(
        index_path,
        index,
        args.skip_export or not args.enable_live_writeback,
    )
    queue = runnable_items(index, args.retry_failed, args.max_output_row)
    results: list[dict[str, Any]] = []
    started = time.monotonic()
    worker_count = max(1, min(args.workers, len(queue) or 1))
    next_index = 0

    def claim_next() -> dict[str, Any] | None:
        nonlocal next_index
        item, next_index = claim_next_item(queue, next_index, controller, results)
        return item

    with ThreadPoolExecutor(max_workers=worker_count, thread_name_prefix="xy-worker") as pool:
        futures: dict[Future, dict[str, Any]] = {}
        for _ in range(worker_count):
            item = claim_next()
            if item:
                futures[pool.submit(run_drama, item, controller, contracts, library, model_client)] = item
        pending = set(futures)
        while pending:
            done, pending = wait(pending, return_when=FIRST_COMPLETED)
            for future in done:
                item = futures[future]
                try:
                    result = future.result()
                except Exception as exc:
                    result = failure_result_for_exception(
                        SystemStageError(f"Worker未捕获异常: {exc}")
                    )
                controller.finish(item, result["status"], result.get("error", ""))
                results.append(
                    {
                        "row_number": item.get("row_number"),
                        "drama_name": item.get("drama_name", ""),
                        "video_id": item.get("video_id", ""),
                        **result,
                    }
                )
                if should_refill_worker(result["status"]):
                    next_item = claim_next()
                    if next_item:
                        new_future = pool.submit(run_drama, next_item, controller, contracts, library, model_client)
                        futures[new_future] = next_item
                        pending.add(new_future)

    statuses = {normalize_status(str(item.get("status") or "")) for item in index.get("items", [])}
    if statuses.issubset({"PACKAGE_READY", "DELIVERED", "SKIPPED"}):
        index["status"] = "PACKAGE_READY"
    elif statuses.issubset({"TEXT_READY", "IMAGE_PARTIAL", "PACKAGE_READY", "DELIVERED", "SKIPPED"}):
        index["status"] = "TEXT_READY"
    elif "SYSTEM_ERROR" in statuses or "WRITEBACK_PENDING" in statuses:
        index["status"] = "SYSTEM_ERROR"
    else:
        index["status"] = "NEEDS_USER_REVIEW"
    index["updated_at"] = timestamp()
    controller.persist_index()
    write_report(index_path, results, time.monotonic() - started)
    print(json.dumps({"index": str(index_path), "status": index["status"], "results": results}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
