#!/usr/bin/env python3
"""Prepare an exact clean-recreate scope for claim-only writeback failures."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from deterministic_batch import load_json, write_json  # noqa: E402

COMMUNITY_SCRIPT_DIR = SCRIPT_DIR.parents[1] / "xy-generate-tasks-v14" / "scripts"
if str(COMMUNITY_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(COMMUNITY_SCRIPT_DIR))
from community_counts import assign_community_counts  # noqa: E402


SAFE_BATCH_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,95}$")
SAFE_CONTRACT_ID = re.compile(r"^xy-v14-[0-9a-f]{20}$")


def build_claim_recovery_scope(
    source_index_path: Path, *, batch_id: str, target_contract_id: str
) -> dict:
    source_index_path = source_index_path.expanduser().resolve()
    if not source_index_path.is_file() or source_index_path.name != "今日任务索引.json":
        raise ValueError(f"源索引无效: {source_index_path}")
    if not SAFE_BATCH_ID.fullmatch(batch_id):
        raise ValueError("batch_id格式无效")
    if not SAFE_CONTRACT_ID.fullmatch(target_contract_id):
        raise ValueError("target_contract_id格式无效")
    source = load_json(source_index_path, {})
    items = source.get("items")
    if not isinstance(items, list) or not items:
        raise ValueError("源索引没有任务")
    cadence_rows = []
    for item in items:
        source_row = int(item.get("row_number") or 0)
        if source_row < 2:
            raise ValueError(f"源任务缺少有效row_number: {item.get('video_id')}")
        if str(item.get("status") or "").upper() != "WRITEBACK_PENDING":
            raise ValueError(f"{item.get('video_id')} 不是WRITEBACK_PENDING")
        if int(item.get("output_row_number") or 0):
            raise ValueError(f"{item.get('video_id')} 已有output_row_number，不能走领取失败重建")
        if str(item.get("current_stage") or "") != "claim":
            raise ValueError(f"{item.get('video_id')} current_stage不是claim")
        if "Feishu基础字段回写失败" not in str(item.get("error") or ""):
            raise ValueError(f"{item.get('video_id')} 不是Feishu基础字段回写失败")
        cadence_rows.append({
            "频道": str(item.get("channel") or ""),
            "档期": str(item.get("slot") or ""),
            "video_id": str(item.get("video_id") or ""),
            "source_row_number": source_row,
            "source_community_count": int(
                item.get("community_count") or (1 if item.get("need_community") else 0)
            ),
        })
    assigned = assign_community_counts(cadence_rows)
    output_rows = [row["source_row_number"] for row in assigned]
    if len(set(output_rows)) != len(output_rows):
        raise ValueError("源索引row_number重复")
    scope_items = []
    for row in assigned:
        scope_items.append({
            "source_index": str(source_index_path),
            "source_row_number": row["source_row_number"],
            "output_row_number": row["source_row_number"],
            "video_id": row["video_id"],
            "expected_source_contract_id": "",
            "expected_source_status": "WRITEBACK_PENDING",
            "expected_source_community_count": row["source_community_count"],
            "target_community_count": int(row["是否需要社区"]),
            "reason": "领取阶段飞书基础字段回写失败且社群数量需按同日频道频次重新冻结",
        })
    return {
        "scope_version": 1,
        "mode": "clean_recreate",
        "batch_id": batch_id,
        "target_contract_id": target_contract_id,
        "expected_item_count": len(scope_items),
        "expected_video_ids": [row["video_id"] for row in scope_items],
        "items": scope_items,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-index", required=True, type=Path)
    parser.add_argument("--batch-id", required=True)
    parser.add_argument("--target-contract-id", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    scope = build_claim_recovery_scope(
        args.source_index,
        batch_id=args.batch_id,
        target_contract_id=args.target_contract_id,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(args.output, scope)
    print(json.dumps({
        "scope_path": str(args.output.resolve()),
        "item_count": len(scope["items"]),
        "community_count_2": sum(row["target_community_count"] == 2 for row in scope["items"]),
        "community_count_1": sum(row["target_community_count"] == 1 for row in scope["items"]),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
