#!/usr/bin/env python3
"""Single V14 authority for frozen contracts, assets, states and event lineage."""

from __future__ import annotations

import copy
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any


CONTRACT_VERSION = 11
# V7 introduced the sealed integrity/runtime-source contract used by the
# current single-AI baseline.  Raising the current version must not make V7 or
# V10 historical evidence bypass verification.
SEALED_CONTRACT_MIN_VERSION = 7
STATE_MACHINE_VERSION = 1

STATUS_INITIALIZED = "INITIALIZED"
STATUS_CLAIMED = "CLAIMED"
STATUS_GENERATING = "GENERATING"
STATUS_TEXT_READY = "TEXT_READY"
STATUS_IMAGE_PARTIAL = "IMAGE_PARTIAL"
STATUS_PACKAGE_READY = "PACKAGE_READY"
STATUS_DELIVERED = "DELIVERED"
STATUS_WRITEBACK_PENDING = "WRITEBACK_PENDING"
STATUS_SYSTEM_ERROR = "SYSTEM_ERROR"
STATUS_NEEDS_USER_REVIEW = "NEEDS_USER_REVIEW"
STATUS_INTERRUPTED = "INTERRUPTED"
STATUS_SKIPPED = "SKIPPED"

TERMINAL_SUCCESS_STATUSES = frozenset({STATUS_DELIVERED, STATUS_SKIPPED})
EXPORTABLE_STATUSES = frozenset({STATUS_PACKAGE_READY, STATUS_DELIVERED})

EFFECTIVE_CONTRACT_SECTIONS = (
    "version",
    "rules",
    "machine_contracts",
    "schema_contracts",
    "stage_directives",
    "semantic_contract",
    "visual_review_contract",
    "regeneration_contract",
    "state_machine_contract",
    "runtime_sources",
)

# Version 10 briefly sealed three additional content contracts.  Those snapshots
# remain immutable production evidence after the runtime was rolled back to V7.
# Verification must therefore use one of the exact historically issued section
# profiles instead of silently projecting every snapshot onto today's profile.
V10_EFFECTIVE_CONTRACT_SECTIONS = (
    "version",
    "rules",
    "machine_contracts",
    "schema_contracts",
    "stage_directives",
    "semantic_contract",
    "description_acceptance_contract",
    "community_plan_contract",
    "visual_review_contract",
    "community_visual_review_contract",
    "regeneration_contract",
    "state_machine_contract",
    "runtime_sources",
)

KNOWN_CONTRACT_SECTION_PROFILES = (
    EFFECTIVE_CONTRACT_SECTIONS,
    V10_EFFECTIVE_CONTRACT_SECTIONS,
)

LEGACY_STATUS_MAP = {
    "created": STATUS_INITIALIZED,
    "initialized": STATUS_INITIALIZED,
    "resumed": STATUS_INITIALIZED,
    "claimed": STATUS_CLAIMED,
    "running": STATUS_GENERATING,
    "done": STATUS_TEXT_READY,
    "text_ready": STATUS_TEXT_READY,
    "image_partial": STATUS_IMAGE_PARTIAL,
    "package_ready": STATUS_PACKAGE_READY,
    "delivered": STATUS_DELIVERED,
    "writeback_pending": STATUS_WRITEBACK_PENDING,
    "needs_user_review": STATUS_NEEDS_USER_REVIEW,
    "interrupted": STATUS_INTERRUPTED,
    "skipped": STATUS_SKIPPED,
    "dry_run": STATUS_SKIPPED,
}


def timestamp() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def contract_sections_for_snapshot(snapshot: dict[str, Any]) -> tuple[str, ...]:
    """Return the exact issued section profile declared by a sealed snapshot."""
    integrity = snapshot.get("integrity")
    if not isinstance(integrity, dict):
        raise ValueError("contract_integrity_missing")
    declared = frozenset(str(key) for key in integrity)
    for profile in KNOWN_CONTRACT_SECTION_PROFILES:
        if declared == frozenset(profile):
            return profile
    raise ValueError("contract_integrity_profile_unknown:" + ",".join(sorted(declared)))


def effective_contract(
    snapshot: dict[str, Any],
    sections: tuple[str, ...] = EFFECTIVE_CONTRACT_SECTIONS,
) -> dict[str, Any]:
    return {key: snapshot.get(key) for key in sections}


def contract_id_for(
    snapshot: dict[str, Any],
    sections: tuple[str, ...] = EFFECTIVE_CONTRACT_SECTIONS,
) -> str:
    return "xy-v14-" + sha256_json(effective_contract(snapshot, sections))[:20]


def seal_contract_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    sealed = copy.deepcopy(snapshot)
    sealed["version"] = int(sealed.get("version") or CONTRACT_VERSION)
    integrity = {
        key: sha256_json(sealed.get(key))
        for key in EFFECTIVE_CONTRACT_SECTIONS
    }
    sealed["integrity"] = integrity
    sealed["contract_id"] = contract_id_for(sealed)
    return sealed


def verify_contract_snapshot(snapshot: dict[str, Any]) -> None:
    if int(snapshot.get("version") or 0) < SEALED_CONTRACT_MIN_VERSION:
        return
    expected_integrity = snapshot.get("integrity")
    sections = contract_sections_for_snapshot(snapshot)
    mismatches = [
        key for key in sections
        if str(expected_integrity.get(key) or "") != sha256_json(snapshot.get(key))
    ]
    if mismatches:
        raise ValueError("contract_content_tampered:" + ",".join(mismatches))
    expected_id = contract_id_for(snapshot, sections)
    if str(snapshot.get("contract_id") or "") != expected_id:
        raise ValueError("contract_id_mismatch")


def verify_runtime_sources(snapshot: dict[str, Any]) -> None:
    if int(snapshot.get("version") or 0) < SEALED_CONTRACT_MIN_VERSION:
        return
    mismatches = []
    for name, row in snapshot.get("runtime_sources", {}).items():
        if not isinstance(row, dict):
            mismatches.append(str(name))
            continue
        path = Path(str(row.get("source_path") or "")).expanduser()
        expected = str(row.get("sha256") or "")
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else ""
        if not expected or actual != expected:
            mismatches.append(str(name))
    if mismatches:
        raise ValueError("runtime_sources_changed:" + ",".join(sorted(mismatches)))


def normalize_status(status: str) -> str:
    value = str(status or "").strip()
    if value in {
        STATUS_INITIALIZED, STATUS_CLAIMED, STATUS_GENERATING, STATUS_TEXT_READY,
        STATUS_IMAGE_PARTIAL, STATUS_PACKAGE_READY, STATUS_DELIVERED,
        STATUS_WRITEBACK_PENDING, STATUS_SYSTEM_ERROR, STATUS_NEEDS_USER_REVIEW, STATUS_INTERRUPTED,
        STATUS_SKIPPED,
    }:
        return value
    return LEGACY_STATUS_MAP.get(value.lower(), STATUS_INITIALIZED)


def evaluate_asset_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    tasks = {
        str(task.get("task_id") or ""): task
        for task in manifest.get("tasks", [])
        if isinstance(task, dict) and str(task.get("task_id") or "")
    }
    required = [
        str(task_id) for task_id in manifest.get("required_task_ids", [])
        if str(task_id)
    ]
    if not required:
        nested = manifest.get("required_asset_manifest")
        if isinstance(nested, dict):
            required = [str(value) for value in nested.get("required_task_ids", []) if str(value)]
    missing: list[str] = []
    invalid: list[str] = []
    accepted: list[str] = []
    for task_id in required:
        task = tasks.get(task_id)
        if not task:
            missing.append(task_id)
            continue
        target = Path(str(task.get("target_path") or "")).expanduser()
        if not str(task.get("target_path") or "") or not target.is_file():
            missing.append(task_id)
            continue
        validation = str(task.get("validation_status") or task.get("status") or "").lower()
        if validation not in {"accepted", "validated", "sorted"}:
            invalid.append(task_id)
            continue
        accepted.append(task_id)
    return {
        "complete": bool(required) and not missing and not invalid and len(accepted) == len(required),
        "required_task_ids": required,
        "accepted_task_ids": accepted,
        "missing_task_ids": missing,
        "invalid_task_ids": invalid,
    }


def derive_package_status(evidence: dict[str, Any]) -> str:
    text_complete = bool(evidence.get("text_complete"))
    assets_complete = bool(evidence.get("assets_complete"))
    if text_complete and assets_complete:
        if all(bool(evidence.get(key)) for key in (
            "logo_complete", "delivery_complete", "writeback_complete"
        )):
            return STATUS_DELIVERED
        return STATUS_PACKAGE_READY
    if bool(evidence.get("accepted_asset_count")):
        return STATUS_IMAGE_PARTIAL
    if text_complete:
        return STATUS_TEXT_READY
    return STATUS_INITIALIZED


def append_event(package: Path, payload: dict[str, Any]) -> None:
    package.mkdir(parents=True, exist_ok=True)
    event_path = package / "workflow_events.jsonl"
    event = {"created_at": timestamp(), **payload}
    with event_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")


def record_transition(
    package: Path,
    *,
    old_status: str,
    new_status: str,
    event: str,
    actor: str,
    contract_id: str,
    asset_id: str = "",
    prompt_version: int = 0,
    attempt: int = 0,
    details: dict[str, Any] | None = None,
) -> None:
    append_event(package, {
        "event": event,
        "actor": actor,
        "old_status": normalize_status(old_status),
        "new_status": normalize_status(new_status),
        "contract_id": contract_id,
        "asset_id": asset_id,
        "prompt_version": int(prompt_version or 0),
        "attempt": int(attempt or 0),
        "details": details or {},
    })


def task_lineage(
    task: dict[str, Any], *, contract_id: str, attempt: int = 1,
    parent_task_id: str = "", prompt_version: int = 1,
) -> dict[str, Any]:
    result = dict(task)
    result.update({
        "contract_id": contract_id,
        "prompt_version": int(prompt_version),
        "attempt": int(attempt),
        "parent_task_id": parent_task_id,
    })
    return result
