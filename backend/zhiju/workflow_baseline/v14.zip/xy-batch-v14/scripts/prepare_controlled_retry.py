#!/usr/bin/env python3
"""Prepare an exact, non-destructive retry batch for exhausted V2 stages.

The source index and package remain untouched while preparing the batch.  By
default the new index points at the existing package so workflow evidence,
accepted upstream outputs, retry history, and Feishu row identity are retained.
For immutable test baselines, a scope may explicitly request an isolated
package copy; the controller then clones the accepted upstream package into a
new exact path before opening the retry cycle.
The production runner must still be invoked with ``--retry-failed``; that
explicit action opens the next three-attempt cycle at the pinned failed stage.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from deterministic_batch import (  # noqa: E402
    ALL_STAGES,
    ContractBundle,
    load_json,
    normalize_status,
    retry_stage_for_item,
    timestamp,
    write_json,
)


SCOPE_VERSION = 1
SAFE_BATCH_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,95}$")
SAFE_CONTRACT_ID = re.compile(r"^xy-v14-[0-9a-f]{20}$")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha256_json(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def is_within(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def resolve_under_root(root: Path, raw: str) -> Path:
    path = Path(str(raw or "")).expanduser()
    path = path.resolve() if path.is_absolute() else (root / path).resolve()
    if not is_within(path, root):
        raise ValueError(f"路径越出V2根目录: {path}")
    return path


def load_scope(scope_path: Path) -> dict[str, Any]:
    scope = load_json(scope_path, {})
    if int(scope.get("scope_version") or 0) != SCOPE_VERSION:
        raise ValueError(f"受控重试范围版本必须为 {SCOPE_VERSION}")
    if str(scope.get("mode") or "") != "controlled_retry":
        raise ValueError("受控重试范围 mode 必须为 controlled_retry")
    batch_id = str(scope.get("batch_id") or "").strip()
    if not SAFE_BATCH_ID.fullmatch(batch_id):
        raise ValueError("batch_id 只能使用3-96位字母、数字、点、下划线或短横线")
    contract_id = str(scope.get("target_contract_id") or "").strip()
    if not SAFE_CONTRACT_ID.fullmatch(contract_id):
        raise ValueError("目标契约必须是完整的 xy-v14-<20位十六进制> 契约ID")
    items = scope.get("items")
    if not isinstance(items, list) or not items:
        raise ValueError("受控重试 items 不能为空")
    return scope


def resolve_retry_item(root: Path, scope: dict[str, Any], row: dict[str, Any]) -> dict[str, Any]:
    video_id = str(row.get("video_id") or "").strip()
    output_row = int(row.get("output_row_number") or 0)
    stage = str(row.get("retry_stage") or "").strip()
    expected_contract = str(row.get("expected_source_contract_id") or "").strip()
    reason = str(row.get("reason") or "").strip()
    if not video_id or output_row < 2 or stage not in ALL_STAGES:
        raise ValueError(f"受控重试项身份或节点无效: {row}")
    if not SAFE_CONTRACT_ID.fullmatch(expected_contract):
        raise ValueError(f"{video_id} 必须固定完整的源契约ID")
    if not reason:
        raise ValueError(f"{video_id} 必须声明重试原因")

    index_path = resolve_under_root(root, str(row.get("source_index") or ""))
    if index_path.name != "今日任务索引.json" or not index_path.is_file():
        raise ValueError(f"{video_id} source_index 无效: {index_path}")
    expected_index_sha = str(row.get("expected_source_index_sha256") or "").strip()
    actual_index_sha = sha256_file(index_path)
    if not expected_index_sha or expected_index_sha != actual_index_sha:
        raise ValueError(
            f"{video_id} 源索引SHA不符: expected={expected_index_sha or '-'}, actual={actual_index_sha}"
        )
    source_index = load_json(index_path, {})
    matches = [
        item for item in source_index.get("items", [])
        if str(item.get("video_id") or "") == video_id
        and int(item.get("output_row_number") or 0) == output_row
    ]
    if len(matches) != 1:
        raise ValueError(f"{video_id} 无法按剧id+任务表行唯一定位: matches={len(matches)}")
    item = copy.deepcopy(matches[0])
    if str(item.get("contract_id") or "") != expected_contract:
        raise ValueError(f"{video_id} 源索引项契约不符")
    if normalize_status(str(item.get("status") or "")) != "NEEDS_USER_REVIEW":
        raise ValueError(f"{video_id} 不是 NEEDS_USER_REVIEW，禁止开启失败周期")

    package = resolve_under_root(root, str(item.get("package_path") or ""))
    state_path = package / "workflow_state.json"
    if not state_path.is_file():
        raise ValueError(f"{video_id} workflow_state.json 不存在: {state_path}")
    state = load_json(state_path, {})
    if str(state.get("contract_id") or "") != expected_contract:
        raise ValueError(f"{video_id} 包内契约不符")
    actual_stage = retry_stage_for_item(item)
    if actual_stage != stage:
        raise ValueError(f"{video_id} 实际失败节点不符: expected={stage}, actual={actual_stage or '-'}")
    step = state.get("steps", {}).get(stage)
    if not isinstance(step, dict) or int(step.get("attempts") or 0) < 3:
        raise ValueError(f"{video_id} {stage} 尚未耗尽当前三次周期")
    stage_index = ALL_STAGES.index(stage)
    for upstream in ALL_STAGES[:stage_index]:
        upstream_step = state.get("steps", {}).get(upstream)
        if not isinstance(upstream_step, dict) or upstream_step.get("status") not in {"done", "skipped"}:
            raise ValueError(f"{video_id} 上游节点 {upstream} 未验收，禁止从 {stage} 重试")

    expected_errors = [str(value) for value in row.get("expected_errors", [])]
    actual_errors = [str(value) for value in step.get("errors", [])]
    if expected_errors and expected_errors != actual_errors:
        raise ValueError(f"{video_id} 失败反馈已变化，拒绝使用过期重试范围")
    isolated_copy = bool(scope.get("isolated_package_copy"))
    target_package = package
    if isolated_copy:
        if stage != "xy-cover":
            raise ValueError(f"{video_id} 隔离包受控重试当前只支持从 xy-cover 开始")
        target_raw = str(row.get("target_package_path") or "").strip()
        if not target_raw:
            raise ValueError(f"{video_id} 隔离包重试必须固定 target_package_path")
        target_package = resolve_under_root(root, target_raw)
        if target_package == package or is_within(target_package, package) or is_within(package, target_package):
            raise ValueError(f"{video_id} target_package_path 必须与源包完全隔离")
        if target_package.exists():
            raise ValueError(f"{video_id} 隔离目标包已存在，禁止覆盖: {target_package}")
    feedback_seed = [str(value) for value in row.get("retry_feedback_seed", [])]
    if feedback_seed:
        if not all("visual_collision_with_history" in value for value in feedback_seed):
            raise ValueError(f"{video_id} retry_feedback_seed 只允许历史视觉碰撞错误")
        if not set(actual_errors).issubset(set(feedback_seed)):
            raise ValueError(f"{video_id} retry_feedback_seed 必须包含当前完整错误")
    return {
        "item": item,
        "source_index_path": index_path,
        "source_index_sha256": actual_index_sha,
        "package": package,
        "target_package": target_package,
        "isolated_package_copy": isolated_copy,
        "state_path": state_path,
        "state_sha256": sha256_file(state_path),
        "stage": stage,
        "errors": actual_errors,
        "feedback_seed": feedback_seed,
        "reason": reason,
    }


def validate_scope(root: Path, scope: dict[str, Any]) -> list[dict[str, Any]]:
    rows = [resolve_retry_item(root, scope, row) for row in scope["items"]]
    identities = [
        (str(row["item"].get("video_id") or ""), int(row["item"].get("output_row_number") or 0))
        for row in rows
    ]
    if len(set(identities)) != len(identities):
        raise ValueError("受控重试范围存在重复剧id/任务表行")
    expected_count = int(scope.get("expected_item_count") or len(rows))
    if expected_count != len(rows):
        raise ValueError(f"受控重试数量不符: expected={expected_count}, actual={len(rows)}")
    expected_ids = [str(value) for value in scope.get("expected_video_ids", [])]
    if expected_ids and set(expected_ids) != {identity[0] for identity in identities}:
        raise ValueError("受控重试剧id集合与 expected_video_ids 不一致")
    return rows


def retry_plan(root: Path, scope: dict[str, Any], rows: list[dict[str, Any]]) -> dict[str, Any]:
    batch_dir = root / "批量任务" / str(scope["batch_id"])
    return {
        "ok": True,
        "dry_run": True,
        "mode": "controlled_retry",
        "scope_version": SCOPE_VERSION,
        "scope_sha256": sha256_json(scope),
        "target_contract_id": str(scope["target_contract_id"]),
        "batch_id": str(scope["batch_id"]),
        "batch_dir": str(batch_dir),
        "index_path": str(batch_dir / "今日任务索引.json"),
        "item_count": len(rows),
        "items": [
            {
                "video_id": row["item"].get("video_id"),
                "output_row_number": row["item"].get("output_row_number"),
                "retry_stage": row["stage"],
                "preserved_upstream": list(ALL_STAGES[:ALL_STAGES.index(row["stage"])]),
                "source_index": str(row["source_index_path"]),
                "source_index_sha256": row["source_index_sha256"],
                "package_path": str(row["package"]),
                "target_package_path": str(row["target_package"]),
                "isolated_package_copy": row["isolated_package_copy"],
                "workflow_state_sha256": row["state_sha256"],
                "carried_errors": row["errors"],
                "retry_feedback_seed": row["feedback_seed"],
                "reason": row["reason"],
            }
            for row in rows
        ],
    }


def create_controlled_retry_batch(root: Path, scope_path: Path, *, apply: bool) -> dict[str, Any]:
    root = root.expanduser().resolve()
    scope_path = scope_path.expanduser().resolve()
    if not scope_path.is_file():
        raise ValueError(f"受控重试范围文件不存在: {scope_path}")
    scope = load_scope(scope_path)
    rows = validate_scope(root, scope)
    plan = retry_plan(root, scope, rows)
    if not apply:
        return plan

    batch_dir = Path(plan["batch_dir"])
    if batch_dir.exists():
        raise ValueError(f"目标受控重试批次已存在，禁止覆盖: {batch_dir}")
    token = uuid.uuid4().hex[:12]
    staged = batch_dir.parent / f".{batch_dir.name}.controlled-retry-{token}"
    staged_packages: list[tuple[Path, Path]] = []
    created_packages: list[Path] = []
    try:
        staged.mkdir(parents=True, exist_ok=False)
        contracts = ContractBundle(staged)
        contracts.assert_runtime_compatible()
        if contracts.contract_id != str(scope["target_contract_id"]):
            raise ValueError(
                "当前运行环境与目标冻结契约不符: "
                f"expected={scope['target_contract_id']}, actual={contracts.contract_id}"
            )

        # A control-only release may rotate the aggregate contract ID while
        # leaving every affected content-stage contract byte-identical.  We may
        # preserve accepted upstream output only when those stage hashes prove
        # compatibility with the newly frozen runtime.  The exhausted stage
        # must also match so its carried validation feedback remains valid.
        for row in rows:
            state = load_json(row["state_path"], {})
            checked_stages = ALL_STAGES[:ALL_STAGES.index(row["stage"])]
            for checked_stage in checked_stages:
                step = state.get("steps", {}).get(checked_stage)
                actual_sha = str(step.get("contract_sha256") or "") if isinstance(step, dict) else ""
                expected_sha = contracts.sha(checked_stage)
                if actual_sha != expected_sha:
                    raise ValueError(
                        f"{row['item'].get('video_id')} {checked_stage} 节点契约不兼容: "
                        f"expected={expected_sha}, actual={actual_sha or '-'}"
                    )

        new_items = []
        records = []
        for row in rows:
            target_package = row["target_package"]
            if row["isolated_package_copy"]:
                target_package.parent.mkdir(parents=True, exist_ok=True)
                staged_package = target_package.parent / f".{target_package.name}.controlled-retry-{token}"
                if staged_package.exists():
                    raise ValueError(f"隔离包暂存路径已存在: {staged_package}")
                shutil.copytree(row["package"], staged_package)
                metadata_path = staged_package / "剧目元数据.json"
                metadata = load_json(metadata_path, {})
                metadata["batch_id"] = str(scope["batch_id"])
                metadata["package_path"] = str(target_package)
                write_json(metadata_path, metadata)
                cloned_state_path = staged_package / "workflow_state.json"
                cloned_state = load_json(cloned_state_path, {})
                cloned_state["package_path"] = str(target_package)
                history = list(cloned_state.get("batch_history") or [])
                if str(scope["batch_id"]) not in history:
                    history.append(str(scope["batch_id"]))
                cloned_state["batch_history"] = history
                cloned_state["isolated_retry_source"] = {
                    "package_path": str(row["package"]),
                    "workflow_state_sha256": row["state_sha256"],
                    "source_index": str(row["source_index_path"]),
                    "source_index_sha256": row["source_index_sha256"],
                }
                write_json(cloned_state_path, cloned_state)
                staged_packages.append((staged_package, target_package))
            item = copy.deepcopy(row["item"])
            item["package_path"] = str(target_package)
            item["prompt_manifest"] = str(target_package / "images/prompts/出图任务清单.json")
            item["status"] = "NEEDS_USER_REVIEW"
            item["current_stage"] = row["stage"]
            item.pop("resume_from_stage", None)
            item["error"] = (
                f"{row['stage']} 当前周期已耗尽；受控新周期将携带: " + "; ".join(row["errors"])
            )
            item["controlled_retry"] = {
                "batch_id": str(scope["batch_id"]),
                "scope_sha256": plan["scope_sha256"],
                "retry_stage": row["stage"],
                "source_index": str(row["source_index_path"]),
                "source_index_sha256": row["source_index_sha256"],
                "workflow_state_sha256_before_prepare": row["state_sha256"],
                "source_package_path": str(row["package"]),
                "target_package_path": str(target_package),
                "isolated_package_copy": row["isolated_package_copy"],
                "carried_errors": row["errors"],
                "retry_feedback_seed": row["feedback_seed"],
                "reason": row["reason"],
            }
            if row["feedback_seed"]:
                item["retry_feedback_seed"] = list(row["feedback_seed"])
            new_items.append(item)
            records.append(copy.deepcopy(item["controlled_retry"]))

        index = {
            "batch_id": str(scope["batch_id"]),
            "created_at": timestamp(),
            "updated_at": timestamp(),
            "status": "NEEDS_USER_REVIEW",
            "community_output_version": max(
                int(item.get("community_output_version") or 1) for item in new_items
            ),
            "controlled_retry": {
                "scope_version": SCOPE_VERSION,
                "scope_path": str(scope_path),
                "scope_sha256": plan["scope_sha256"],
                "target_contract_id": str(scope["target_contract_id"]),
                "records": records,
            },
            "items": new_items,
        }
        write_json(staged / "今日任务索引.json", index)
        write_json(staged / "受控重试范围.json", scope)
        write_json(staged / "受控重试清单.json", {**plan, "dry_run": False})
        lines = [
            "# V2受控重试清单", "",
            f"- 契约：`{scope['target_contract_id']}`",
            f"- 数量：{len(new_items)}",
            f"- Scope SHA-256：`{plan['scope_sha256']}`", "",
        ]
        for record in plan["items"]:
            lines.append(
                f"- 任务表{record['output_row_number']}｜{record['video_id']}｜"
                f"从 `{record['retry_stage']}` 开启新周期｜保留上游："
                + ", ".join(record["preserved_upstream"])
            )
            for error in record["carried_errors"]:
                lines.append(f"  - 携带反馈：`{error}`")
        (staged / "受控重试清单.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

        for row in rows:
            if sha256_file(row["source_index_path"]) != row["source_index_sha256"]:
                raise RuntimeError(f"源索引在准备期间发生变化: {row['source_index_path']}")
            if sha256_file(row["state_path"]) != row["state_sha256"]:
                raise RuntimeError(f"workflow_state在准备期间发生变化: {row['state_path']}")
        for staged_package, target_package in staged_packages:
            if target_package.exists():
                raise RuntimeError(f"隔离目标包在准备期间被创建: {target_package}")
            os.replace(staged_package, target_package)
            created_packages.append(target_package)
        os.replace(staged, batch_dir)
        return {
            **plan,
            "dry_run": False,
            "created": True,
            "index_path": str(batch_dir / "今日任务索引.json"),
            "contract_snapshot": str(batch_dir / "生产契约快照.json"),
        }
    except Exception:
        for staged_package, _ in staged_packages:
            if staged_package.exists():
                shutil.rmtree(staged_package)
        for target_package in created_packages:
            if target_package.exists():
                shutil.rmtree(target_package)
        if staged.exists():
            shutil.rmtree(staged)
        raise


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--scope", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    result = create_controlled_retry_batch(
        Path(args.root).expanduser().resolve(), Path(args.scope), apply=args.apply
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
