#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import parse_qs, urlparse


HELPER_DIR = Path(__file__).resolve().parents[2] / "xy-channels" / "scripts"
if str(HELPER_DIR) not in sys.path:
    sys.path.append(str(HELPER_DIR))

from channel_registry import ensure_registry
from channel_registry import resolve_channel


HEADERS = ["剧名", "剧id", "地址", "频道", "档期", "是否需要社区"]
HEADERS_NO_VIDEO_ID = ["剧名", "地址", "频道", "档期", "是否需要社区"]
IMAGE_TASK_BLUEPRINTS = [
    ("01", "title1", "4x5", "01_标题1_4x5.png"),
    ("02", "title1", "16x9", "02_标题1_16x9.png"),
    ("03", "title2", "4x5", "03_标题2_4x5.png"),
    ("04", "title2", "16x9", "04_标题2_16x9.png"),
    ("05", "title3", "4x5", "05_标题3_4x5.png"),
    ("06", "title3", "16x9", "06_标题3_16x9.png"),
    ("07", "community", "1x1", "07_社群图_1x1.png"),
]
STEP_NAMES = ["xy-find", "xy-title", "xy-cover", "xy-post", "xy-place"]
TRUE_VALUES = {"1", "true", "yes", "y", "是", "需要"}
PENDING_VIDEO_LINK = "【视频链接待补】"
COMMUNITY_OUTPUT_VERSION = 2


def split_row(line: str) -> list[str]:
    if "\t" in line:
        return [cell.strip() for cell in line.rstrip("\n").split("\t")]
    return [cell.strip() for cell in re.split(r"\s{2,}", line.strip())]


def detect_header_variant(header: list[str]) -> str:
    normalized = [cell.strip() for cell in header]
    if normalized[: len(HEADERS)] == HEADERS:
        return "with_video_id"
    if normalized[: len(HEADERS_NO_VIDEO_ID)] == HEADERS_NO_VIDEO_ID:
        return "without_video_id"
    raise SystemExit("Task table header must be: 剧名 剧id 地址 频道 档期 是否需要社区  或  剧名 地址 频道 档期 是否需要社区")


def row_to_dict(row: list[str], header_variant: str, row_number: int) -> dict:
    if header_variant == "with_video_id":
        padded = row + [""] * max(0, len(HEADERS) - len(row))
        cells = padded[: len(HEADERS)]
        payload = dict(zip(HEADERS, cells))
    else:
        padded = row + [""] * max(0, len(HEADERS_NO_VIDEO_ID) - len(row))
        cells = padded[: len(HEADERS_NO_VIDEO_ID)]
        payload = {
            "剧名": cells[0],
            "剧id": "",
            "地址": cells[1],
            "频道": cells[2],
            "档期": cells[3],
            "是否需要社区": cells[4],
        }
    payload["_row_number"] = row_number
    return payload


def load_table_from_text(text: str) -> tuple[list[str], list[list[str]], str]:
    lines = [line for line in text.splitlines() if line.strip()]
    if not lines:
        raise SystemExit("Empty task table")
    rows = [split_row(line) for line in lines]
    header = rows[0]
    header_variant = detect_header_variant(header)
    return header, rows[1:], header_variant


def load_table_from_csv(path: Path) -> tuple[list[str], list[list[str]], str]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        rows = [[cell.strip() for cell in row] for row in reader if any(cell.strip() for cell in row)]
    if not rows:
        raise SystemExit("Empty CSV task table")
    header = rows[0]
    header_variant = detect_header_variant(header)
    return header, rows[1:], header_variant


def load_table_from_xlsx(path: Path) -> tuple[list[str], list[list[str]], str]:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise SystemExit("Reading .xlsx requires openpyxl") from exc
    wb = load_workbook(path, data_only=True)
    ws = wb.active
    rows = []
    for row in ws.iter_rows(values_only=True):
        values = ["" if cell is None else str(cell).strip() for cell in row]
        if any(values):
            rows.append(values)
    if not rows:
        raise SystemExit("Empty XLSX task table")
    header = rows[0]
    header_variant = detect_header_variant(header)
    return header, rows[1:], header_variant


def load_input(args) -> tuple[str | None, list[dict], str]:
    if args.input:
        path = Path(args.input).expanduser().resolve()
        suffix = path.suffix.lower()
        if suffix == ".csv":
            _, rows, header_variant = load_table_from_csv(path)
        elif suffix in {".xlsx", ".xlsm"}:
            _, rows, header_variant = load_table_from_xlsx(path)
        else:
            text = path.read_text(encoding="utf-8")
            _, table_rows, header_variant = load_table_from_text(text)
            rows = table_rows
        parsed = []
        for idx, row in enumerate(rows, start=2):
            parsed.append(row_to_dict(row, header_variant, idx))
        if not parsed:
            raise SystemExit("Task table has no data rows")
        return str(path), parsed, path.read_text(encoding="utf-8", errors="ignore") if suffix not in {".xlsx", ".xlsm"} else ""
    if args.stdin:
        text = sys.stdin.read()
        _, rows, header_variant = load_table_from_text(text)
        parsed = []
        for idx, row in enumerate(rows, start=2):
            parsed.append(row_to_dict(row, header_variant, idx))
        if not parsed:
            raise SystemExit("Task table has no data rows")
        return None, parsed, text
    fetch_script = Path(__file__).resolve().parent / "fetch_feishu_tasks.py"
    result = subprocess.run(
        [sys.executable, str(fetch_script), "--root", str(Path(args.root).expanduser().resolve())],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if result.returncode != 0:
        raise SystemExit(result.stdout.strip() or "Failed to fetch Feishu task table")
    payload = json.loads(result.stdout)
    path = Path(payload["tsv_path"])
    text = path.read_text(encoding="utf-8")
    _, table_rows, header_variant = load_table_from_text(text)
    parsed = []
    for idx, row in enumerate(table_rows, start=2):
        parsed.append(row_to_dict(row, header_variant, idx))
    if not parsed:
        raise SystemExit(f"Feishu task table has no data rows: {path}")
    return str(path), parsed, text


def extract_video_id(value: str) -> str:
    link = value.strip()
    if not link:
        return ""
    parsed = urlparse(link)
    if parsed.netloc.endswith("youtu.be"):
        return parsed.path.strip("/").split("/")[0]
    qs = parse_qs(parsed.query)
    if "v" in qs and qs["v"]:
        return qs["v"][0]
    if "/shorts/" in parsed.path:
        return parsed.path.split("/shorts/")[-1].split("/")[0]
    if re.fullmatch(r"[A-Za-z0-9_-]{6,}", link):
        return link
    return ""


def normalize_video_id(
    video_id: str,
    url: str,
    drama_name: str = "",
    channel: str = "",
    slot: str = "",
) -> str:
    direct_video_id = extract_video_id(video_id)
    url_video_id = extract_video_id(url)
    if direct_video_id and url_video_id and direct_video_id != url_video_id:
        raise ValueError(f"剧id 与 地址中的视频ID不一致: 剧id={direct_video_id}, 地址ID={url_video_id}")
    resolved = direct_video_id or url_video_id
    if not resolved:
        identity = "\x00".join(part.strip() for part in (drama_name, channel, slot))
        if not all(part.strip() for part in (drama_name, channel, slot)):
            raise ValueError("缺少有效视频ID：空地址任务必须同时提供剧名、频道和档期")
        resolved = "pending_" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:16]
    return resolved


def normalize_url(video_id: str, url: str) -> str:
    link = url.strip()
    if link:
        return link
    if video_id.startswith("pending_"):
        return PENDING_VIDEO_LINK
    if video_id:
        return f"https://youtu.be/{video_id}"
    return ""


def parse_need_community(value: str) -> bool:
    return value.strip().lower() in TRUE_VALUES


def parse_community_count(value: str) -> int:
    """Normalize new-batch community count without changing legacy batches.

    Blank and numeric zero mean no community output.  A positive integer is
    the exact requested plan count.  Every other non-empty value deliberately
    falls back to one plan for backwards compatibility.
    """
    text = str(value or "").strip()
    if not text:
        return 0
    if re.fullmatch(r"\+?\d+", text):
        return max(0, int(text))
    return 1


def is_placeholder_row(row: dict) -> bool:
    drama_name = (row.get("剧名") or "").strip()
    video_id = (row.get("剧id") or "").strip()
    url = (row.get("地址") or "").strip()
    channel = (row.get("频道") or "").strip()
    slot = (row.get("档期") or "").strip()
    return not (drama_name or video_id or url) and bool(channel or slot)


def sanitize_drama_name(name: str) -> str:
    cleaned = name.strip()
    cleaned = cleaned.replace("/", "／")
    cleaned = cleaned.replace("\x00", "")
    return cleaned


def normalize_slot(raw: str, now: datetime) -> tuple[str, str]:
    text = raw.strip()
    if not text:
        raise SystemExit("档期不能为空")
    # Feishu Sheets may expose a date-time cell as an Excel serial number
    # instead of its formatted display value.  Excel's serial epoch is
    # 1899-12-30; preserve the original text as slot_label while normalizing
    # the production slot to YYYYMMDDHH.
    if re.fullmatch(r"\d{4,5}(?:\.\d+)?", text):
        serial = float(text)
        if 20000 <= serial <= 80000:
            dt = datetime(1899, 12, 30) + timedelta(seconds=round(serial * 86400))
            return dt.strftime("%Y%m%d%H"), text
    if re.fullmatch(r"\d{10}", text):
        return text, text
    if re.fullmatch(r"\d{12}", text):
        return text[:10], text
    for fmt in ("%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M", "%Y-%m-%d %H", "%Y/%m/%d %H"):
        try:
            dt = datetime.strptime(text, fmt)
            return dt.strftime("%Y%m%d%H"), text
        except ValueError:
            pass
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", text)
    if m:
        hour = int(m.group(1))
        dt = now.replace(hour=hour, minute=0, second=0, microsecond=0)
        return dt.strftime("%Y%m%d%H"), text
    if re.fullmatch(r"\d{1,2}", text):
        hour = int(text)
        dt = now.replace(hour=hour, minute=0, second=0, microsecond=0)
        return dt.strftime("%Y%m%d%H"), text
    raise SystemExit(f"Unsupported 档期 format: {text}")


def unique_batch_id(batch_root: Path, base: str) -> str:
    if not (batch_root / base).exists():
        return base
    index = 2
    while True:
        candidate = f"{base}_{index:02d}"
        if not (batch_root / candidate).exists():
            return candidate
        index += 1


TERMINAL_ITEM_STATUSES = {"DELIVERED", "SKIPPED", "delivered", "skipped", "dry_run"}


def load_existing_current_batch(batch_root: Path) -> tuple[Path | None, dict]:
    current_batch_path = batch_root / "current_batch.json"
    if not current_batch_path.exists():
        return None, {}
    current = load_json(current_batch_path, {})
    index_path = Path(current.get("index_path", "")).expanduser()
    if not index_path:
        return None, {}
    if not index_path.is_absolute():
        index_path = (batch_root.parent.parent / index_path).resolve()
    if not index_path.exists():
        return None, {}
    return index_path.resolve(), load_json(index_path, {})


def has_unfinished_items(index_payload: dict) -> bool:
    items = index_payload.get("items", [])
    if not items:
        return False
    for item in items:
        if item.get("status") not in TERMINAL_ITEM_STATUSES:
            return True
    return False


def workflow_contract_version_for_batch(batch_dir: Path, use_existing_batch: bool) -> int:
    """Keep appended rows on the contract generation frozen by their batch."""
    if not use_existing_batch:
        return 2
    snapshot_path = batch_dir / "生产契约快照.json"
    if not snapshot_path.exists():
        return 2
    try:
        snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return 1
    return 2 if int(snapshot.get("version", 0) or 0) >= 4 else 1


def normalize_stale_running_items(index_payload: dict) -> None:
    for item in index_payload.get("items", []):
        if str(item.get("status") or "") in {"running", "GENERATING"}:
            item["status"] = "INITIALIZED"
            item["error"] = ""


def row_signature(row: dict, now: datetime) -> str | None:
    if is_placeholder_row(row):
        return None
    try:
        video_id = normalize_video_id(
            row.get("剧id", ""),
            row.get("地址", ""),
            row.get("剧名", ""),
            row.get("频道", ""),
            row.get("档期", ""),
        )
    except Exception:
        video_id = (row.get("剧id") or "").strip()
    drama_name = sanitize_drama_name(row.get("剧名", ""))
    channel_input = (row.get("频道") or "").strip()
    slot_code, _ = normalize_slot(row.get("档期", ""), now)
    return "||".join([drama_name, video_id, channel_input, slot_code])


def item_signature(item: dict) -> str:
    return "||".join(
        [
            sanitize_drama_name(item.get("drama_name", "")),
            (item.get("video_id") or "").strip(),
            (item.get("channel_input") or item.get("channel") or "").strip(),
            (item.get("slot") or "").strip(),
        ]
    )


def build_image_tasks(video_id: str, community_count: int, package_path: Path) -> list[dict]:
    rows = []
    prompts_dir = package_path / "images" / "prompts"
    raw_dir = package_path / "images" / "raw"
    blueprints = list(IMAGE_TASK_BLUEPRINTS[:6])
    blueprints.extend(
        (f"{6 + plan_index:02d}", f"community{plan_index}", "1x1", f"{6 + plan_index:02d}_社群图{plan_index}_1x1.png")
        for plan_index in range(1, community_count + 1)
    )
    for order, slug, ratio, filename in blueprints:
        safe_video_id = re.sub(r"[^A-Za-z0-9_-]+", "_", video_id).strip("_")
        task_id = f"{safe_video_id}_{order}_{slug}_{ratio}" if safe_video_id else f"{package_path.name}_{order}_{slug}_{ratio}"
        rows.append(
            {
                "task_id": task_id,
                "order": int(order),
                "slug": slug,
                "ratio": ratio,
                "target_filename": filename,
                "target_path": str(raw_dir / filename),
                "prompt_file": str(prompts_dir / f"{task_id}.md"),
                "status": "pending_prompt",
            }
        )
    return rows


def ensure_dirs(package_path: Path) -> None:
    for folder in [
        package_path,
        package_path / "images",
        package_path / "images" / "prompts",
        package_path / "images" / "raw",
        package_path / "images" / "final",
    ]:
        folder.mkdir(parents=True, exist_ok=True)


def load_json(path: Path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def ensure_workflow_state(
    state_path: Path,
    drama_name: str,
    slot_code: str,
    slot_label: str,
    row: dict,
    channel_row: dict,
    package_path: Path,
    batch_id: str,
    community_count: int,
    workflow_contract_version: int,
) -> dict:
    state = load_json(state_path, {})
    state.setdefault("drama_name", drama_name)
    state.setdefault("slot", slot_code)
    state["slot_label"] = slot_label
    state["language"] = channel_row["language"]
    state["channel"] = channel_row["channel_name"]
    state["nickname"] = channel_row.get("nickname", "")
    state["gender"] = channel_row.get("gender", "")
    state["direction"] = channel_row.get("direction", "")
    state["workflow_contract_version"] = workflow_contract_version
    state.setdefault("status", "INITIALIZED")
    state.setdefault("package_status", "INITIALIZED")
    state.setdefault("image_status", "pending")
    state["video_id"] = row["剧id"]
    state["url"] = row["地址"]
    state["community_output_version"] = COMMUNITY_OUTPUT_VERSION
    state["community_count"] = community_count
    state["need_community"] = community_count > 0
    state["package_path"] = str(package_path)
    state.setdefault("steps", {})
    for step in STEP_NAMES:
        state["steps"].setdefault(step, "pending")
    state.setdefault("core_words_selected", [])
    state.setdefault("notes", [])
    history = state.setdefault("batch_history", [])
    if batch_id not in history:
        history.append(batch_id)
    state["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    write_json(state_path, state)
    return state


def write_package_metadata(package_path: Path, payload: dict) -> None:
    write_json(package_path / "剧目元数据.json", payload)


def validate_v2_package_path(root: Path, package_path: Path) -> None:
    """Keep every V2 package physically inside the isolated runtime root."""
    target = package_path.expanduser().resolve()
    isolated_root = root.expanduser().resolve()
    try:
        target.relative_to(isolated_root)
    except ValueError as exc:
        raise SystemExit(f"V2 package escaped isolated root: {target}") from exc
    if target.parent.name != "剧目":
        raise SystemExit(f"V2 package must be a direct child of a 剧目 directory: {target}")


def write_channel_snapshot(package_path: Path, channel_row: dict) -> Path:
    """Freeze the channel inputs used by every downstream batch step.

    The simplified workflow does not run xy-data as a separate step, so the
    package must carry the equivalent channel-data snapshot itself.  Keep the
    generation brief and the analysis report together, plus fixed assets that
    place/post need (playlist/description/footer rules).
    """
    channel_dir = Path(channel_row["channel_dir"])
    channel_name = channel_row["channel_name"]
    candidates = [
        channel_dir / f"{channel_name}_生成规范.md",
        channel_dir / f"{channel_name}_频道分析报告.md",
        channel_dir / "description_fixed_assets.json",
        channel_dir / "community_footer_cta.json",
    ]
    sections = [
        "# 频道数据快照",
        "",
        "本文件由 xy-batch 初始化时生成，是本任务各步骤共同使用的频道数据。",
        "xy-find 不读取本文件；xy-title、xy-cover、xy-place、xy-post 必须读取本文件。",
        "",
        f"- 频道：{channel_name}",
        f"- 本地昵称：{channel_row.get('nickname', '')}",
        f"- 语言：{channel_row.get('language', '')}",
        f"- 频道性别：{channel_row.get('gender', '')}",
        f"- 频道主题：{channel_row.get('direction', '')}",
        "",
    ]
    registered_playlists = str(channel_row.get("playlist") or "").strip()
    if registered_playlists:
        sections.extend([f"- 播放列表：{registered_playlists}", ""])
    for source in candidates:
        if not source.exists():
            continue
        try:
            body = source.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            body = source.read_text(encoding="utf-8-sig", errors="replace")
        sections.extend([f"## 来源：{source.name}", "", body.rstrip(), ""])
    if len(sections) <= 10:
        sections.extend(["## 状态", "", "频道目录中未找到可读取的生成规范或频道报告。", ""])
    snapshot = package_path / "01_频道数据.md"
    snapshot.write_text("\n".join(sections).rstrip() + "\n", encoding="utf-8")
    return snapshot


def write_channel_asset_snapshot(package_path: Path, channel_dir: Path) -> Path:
    payload = {"version": 1}
    for key, filename in (
        ("description_fixed_assets", "description_fixed_assets.json"),
        ("community_footer_cta", "community_footer_cta.json"),
    ):
        source = channel_dir / filename
        payload[key] = load_json(source, {}) if source.exists() else {}
    path = package_path / "02_频道固定资产.json"
    write_json(path, payload)
    return path


def ensure_prompt_manifest(package_path: Path, item: dict, image_tasks: list[dict]) -> tuple[Path, Path]:
    json_path = package_path / "images" / "prompts" / "出图任务清单.json"
    md_path = package_path / "images" / "prompts" / "出图任务清单.md"
    if not json_path.exists():
        payload = {
            "drama_name": item["drama_name"],
            "video_id": item["video_id"],
            "channel": item["channel"],
            "nickname": item.get("nickname", ""),
            "language": item["language"],
            "slot": item["slot"],
            "need_community": item["need_community"],
            "community_output_version": item.get("community_output_version", COMMUNITY_OUTPUT_VERSION),
            "community_count": item.get("community_count", 1 if item["need_community"] else 0),
            "prompt_status": "pending_generation",
            "required_asset_manifest": {
                "scope": "all_declared_tasks",
                "required_count": len(image_tasks),
                "required_task_ids": [task["task_id"] for task in image_tasks],
            },
            "tasks": image_tasks,
        }
        write_json(json_path, payload)
    if not md_path.exists():
        lines = [
            "# 出图任务清单",
            "",
            f"剧名：{item['drama_name']}",
            f"频道：{item['channel']}",
            f"本地昵称：{item.get('nickname', '')}",
            f"语言：{item['language']}",
            f"档期：{item['slot']}",
            "",
        ]
        for task in image_tasks:
            lines.extend(
                [
                    f"## {task['task_id']}",
                    "",
                    f"Task ID: {task['task_id']}",
                    f"Channel: {item['channel']}",
                    f"Drama: {item['drama_name']}",
                    f"Slot: {item['slot']}",
                    f"Target file: {task['target_filename']}",
                    "",
                    "Prompt: pending",
                    "",
                ]
            )
        md_path.write_text("\n".join(lines), encoding="utf-8")
    return json_path, md_path


def archive_source(batch_dir: Path, input_path: str | None, raw_text: str) -> str:
    if input_path:
        src = Path(input_path)
        target = batch_dir / f"今日任务表_归档{src.suffix or '.txt'}"
        shutil.copy2(src, target)
        return str(target)
    target = batch_dir / "今日任务表_归档.tsv"
    target.write_text(raw_text, encoding="utf-8")
    return str(target)


def write_records(batch_dir: Path, summary: dict) -> tuple[Path, Path]:
    md_path = batch_dir / "批量执行记录.md"
    json_path = batch_dir / "批量执行记录.json"
    lines = [
        "# 批量执行记录",
        "",
        f"时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"创建：{len(summary['created'])}",
        f"续跑：{len(summary['resumed'])}",
        f"失败：{len(summary['failed'])}",
        "",
    ]
    for label, key in (("已创建", "created"), ("已续跑", "resumed"), ("失败", "failed")):
        lines.append(f"## {label}")
        lines.append("")
        if not summary[key]:
            lines.append("无")
            lines.append("")
            continue
        for row in summary[key]:
            lines.append(f"- 第{row['row_number']}行｜{row['drama_name']}｜{row['channel_input']}")
            if row.get("reason"):
                lines.append(f"  - {row['reason']}")
        lines.append("")
    md_path.write_text("\n".join(lines), encoding="utf-8")
    write_json(json_path, summary)
    return md_path, json_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument(
        "--channel-source-root",
        default="运营/工作流运营",
        help="Read-only source for channel registry and channel rules",
    )
    parser.add_argument("--input")
    parser.add_argument("--stdin", action="store_true")
    parser.add_argument("--batch-id", default="")
    parser.add_argument("--new", dest="new_batch", action="store_true", help="Force a new batch instead of merging into unfinished current_batch")
    parser.add_argument("--continue-existing", action="store_true", help="Force continuing unfinished current_batch before creating a new batch")
    parser.add_argument("--auto", action="store_true", help="Run xy-pack automation after index initialization")
    parser.add_argument("--init-only", action="store_true", help="Only initialize index and package folders")
    parser.add_argument("--model", default="", help="Optional model passed to codex exec during --auto")
    parser.add_argument("--timeout", type=int, default=900, help="Per-item codex exec timeout in seconds during --auto")
    parser.add_argument("--dry-run", action="store_true", help="With --auto, write prompts but do not run codex exec")
    args = parser.parse_args()
    if args.new_batch and args.continue_existing:
        raise SystemExit("--new and --continue-existing cannot be used together")
    if args.init_only:
        args.auto = False

    root = Path(args.root).expanduser().resolve()
    channel_source_root = Path(args.channel_source_root).expanduser().resolve()
    ensure_registry(channel_source_root)
    input_path, rows, raw_text = load_input(args)
    now = datetime.now()

    batch_root = root / "批量任务"
    batch_root.mkdir(parents=True, exist_ok=True)
    existing_index_path, existing_index = load_existing_current_batch(batch_root)
    use_existing_batch = False
    explicit_input = bool(args.input or args.stdin)
    may_continue_existing = args.continue_existing or (not args.new_batch and not explicit_input)
    if not args.batch_id.strip() and may_continue_existing and existing_index_path and has_unfinished_items(existing_index):
        use_existing_batch = True
        normalize_stale_running_items(existing_index)
        batch_id = existing_index.get("batch_id") or existing_index_path.parent.name
        batch_dir = existing_index_path.parent
        index_items = list(existing_index.get("items", []))
        archive_path = archive_source(batch_dir, input_path, raw_text)
        seen_signatures = {item_signature(item) for item in index_items}
        summary = {"created": [], "resumed": [], "failed": [], "merged_into_existing": True}
    else:
        batch_id = args.batch_id.strip() or unique_batch_id(batch_root, now.strftime("%Y%m%d%H"))
        batch_dir = batch_root / batch_id
        batch_dir.mkdir(parents=True, exist_ok=True)
        index_items = []
        archive_path = archive_source(batch_dir, input_path, raw_text)
        seen_signatures = set()
        summary = {"created": [], "resumed": [], "failed": [], "merged_into_existing": False}

    workflow_contract_version = workflow_contract_version_for_batch(batch_dir, use_existing_batch)

    for row in rows:
        if is_placeholder_row(row):
            continue
        signature = row_signature(row, now)
        if signature and signature in seen_signatures:
            continue
        drama_name = sanitize_drama_name(row["剧名"])
        slot_code, slot_label = normalize_slot(row["档期"], now)
        channel_input = row["频道"].strip()
        row["剧id"] = normalize_video_id(row["剧id"], row["地址"], drama_name, channel_input, slot_code)
        row["地址"] = normalize_url(row["剧id"], row["地址"])
        community_count = parse_community_count(row["是否需要社区"])
        need_community = community_count > 0

        try:
            channel_row = resolve_channel(channel_source_root, channel_input)
            package_name = f"{drama_name}_{slot_code}"
            package_path = (
                root
                / str(channel_row["language"])
                / str(channel_row["channel_name"])
                / "剧目"
                / package_name
            )
            validate_v2_package_path(root, package_path)
            existed = package_path.exists()
            ensure_dirs(package_path)

            image_tasks = build_image_tasks(row["剧id"], community_count, package_path)
            item = {
                "row_number": row["_row_number"],
                "drama_name": drama_name,
                "video_id": row["剧id"],
                "url": row["地址"],
                "language": channel_row["language"],
                "channel": channel_row["channel_name"],
                "nickname": channel_row.get("nickname", ""),
                "gender": channel_row.get("gender", ""),
                "direction": channel_row.get("direction", ""),
                "channel_input": channel_input,
                "channel_dir": channel_row["channel_dir"],
                "slot": slot_code,
                "slot_label": slot_label,
                "need_community": 1 if need_community else 0,
                "community_output_version": COMMUNITY_OUTPUT_VERSION,
                "community_count": community_count,
                "workflow_contract_version": workflow_contract_version,
                "package_path": str(package_path),
                "prompt_manifest": str(package_path / "images" / "prompts" / "出图任务清单.json"),
                "images_raw_dir": str(package_path / "images" / "raw"),
                "images_final_dir": str(package_path / "images" / "final"),
                "expected_images": len(image_tasks),
                "status": "INITIALIZED",
                "error": "",
                "image_tasks": image_tasks,
            }

            ensure_workflow_state(
                package_path / "workflow_state.json",
                drama_name,
                slot_code,
                slot_label,
                row,
                channel_row,
                package_path,
                batch_id,
                community_count,
                workflow_contract_version,
            )
            # Preserve an existing snapshot when resuming a package; a resume
            # must continue with the same channel rules as its original run.
            if not (package_path / "01_频道数据.md").exists():
                write_channel_snapshot(package_path, channel_row)
            if not (package_path / "02_频道固定资产.json").exists():
                write_channel_asset_snapshot(package_path, Path(channel_row["channel_dir"]))
            write_package_metadata(
                package_path,
                {
                    "batch_id": batch_id,
                    "drama_name": drama_name,
                    "video_id": row["剧id"],
                    "url": row["地址"],
                    "slot": slot_code,
                    "slot_label": slot_label,
                    "channel": channel_row["channel_name"],
                    "nickname": channel_row.get("nickname", ""),
                    "language": channel_row["language"],
                    "gender": channel_row.get("gender", ""),
                    "direction": channel_row.get("direction", ""),
                    "workflow_contract_version": workflow_contract_version,
                    "need_community": need_community,
                    "community_output_version": COMMUNITY_OUTPUT_VERSION,
                    "community_count": community_count,
                    "package_path": str(package_path),
                },
            )
            ensure_prompt_manifest(package_path, item, image_tasks)
            index_items.append(item)
            seen_signatures.add(item_signature(item))
            summary["resumed" if existed else "created"].append(item)
        except Exception as exc:
            failed = {
                "row_number": row["_row_number"],
                "drama_name": drama_name,
                "video_id": row["剧id"],
                "url": row["地址"],
                "channel_input": channel_input,
                "slot": row["档期"],
                "need_community": row["是否需要社区"],
                "reason": str(exc),
            }
            summary["failed"].append(failed)
            index_items.append(
                {
                    "row_number": row["_row_number"],
                    "drama_name": drama_name,
                    "video_id": row["剧id"],
                    "url": row["地址"],
                    "language": "",
                    "channel": "",
                    "nickname": "",
                    "gender": "",
                    "direction": "",
                    "channel_input": channel_input,
                    "channel_dir": "",
                    "slot": row["档期"],
                    "slot_label": row["档期"],
                    "need_community": 1 if need_community else 0,
                    "community_output_version": COMMUNITY_OUTPUT_VERSION,
                    "community_count": community_count,
                    "workflow_contract_version": workflow_contract_version,
                    "package_path": "",
                    "prompt_manifest": "",
                    "images_raw_dir": "",
                    "images_final_dir": "",
                    "expected_images": 6 + community_count,
                    "status": "failed",
                    "error": str(exc),
                    "image_tasks": [],
                }
            )
            if signature:
                seen_signatures.add(signature)

    index_path = existing_index_path if use_existing_batch and existing_index_path else (batch_dir / "今日任务索引.json")
    index_payload = existing_index if use_existing_batch else {}
    index_payload.update(
        {
            "batch_id": batch_id,
            "created_at": index_payload.get("created_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "active",
            "archive_path": archive_path,
            "items": index_items,
        }
    )
    if not use_existing_batch:
        index_payload["community_output_version"] = COMMUNITY_OUTPUT_VERSION
    write_json(index_path, index_payload)

    current_batch_path = batch_root / "current_batch.json"
    write_json(
        current_batch_path,
        {
            "batch_id": batch_id,
            "index_path": str(index_path),
            "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        },
    )
    report_md, report_json = write_records(batch_dir, summary)

    result = {
        "batch_id": batch_id,
        "batch_dir": str(batch_dir),
        "index_path": str(index_path),
        "current_batch": str(current_batch_path),
        "archive_path": archive_path,
        "used_existing_batch": use_existing_batch,
        "created": len(summary["created"]),
        "resumed": len(summary["resumed"]),
        "failed": len(summary["failed"]),
        "report_md": str(report_md),
        "report_json": str(report_json),
    }
    if args.auto:
        run_batch = Path(__file__).resolve().parent / "run_batch.py"
        cmd = [sys.executable, str(run_batch), "--root", str(root), "--index", str(index_path)]
        cmd.extend(["--timeout", str(args.timeout)])
        if args.model:
            cmd.extend(["--model", args.model])
        if args.dry_run:
            cmd.append("--dry-run")
        proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        result["auto_exit_code"] = proc.returncode
        result["auto_output"] = proc.stdout
        if proc.returncode != 0:
            print(json.dumps(result, ensure_ascii=False, indent=2))
            raise SystemExit(proc.returncode)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
