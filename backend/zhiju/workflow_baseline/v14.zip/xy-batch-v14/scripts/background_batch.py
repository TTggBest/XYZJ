#!/usr/bin/env python3
"""Launch the unchanged V14 batch controller under a detached local supervisor.

The launcher performs one synchronous read-only preflight, returns a PID and
evidence paths, then exits.  The detached supervisor waits for run_batch.py and
writes its exit code to the job JSON without requiring Codex polling.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any


TERMINAL_STATUSES = {"SUCCEEDED", "FAILED"}
ACTIVE_STATUSES = {"STARTING", "RUNNING"}


def timestamp() -> str:
    return datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %z")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return payload


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    os.close(handle)
    temp_path = Path(name)
    try:
        temp_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        os.replace(temp_path, path)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def process_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def runner_prefix(runner: Path) -> list[str]:
    if runner.suffix == ".py":
        return [sys.executable, str(runner)]
    return [str(runner)]


def active_job_for_index(job_dir: Path, index_path: Path) -> Path | None:
    for job_file in sorted(job_dir.glob("后台任务_*.json"), reverse=True):
        try:
            payload = load_json(job_file)
        except (OSError, ValueError, json.JSONDecodeError):
            continue
        if Path(str(payload.get("index_path") or "")).resolve() != index_path.resolve():
            continue
        status = str(payload.get("status") or "")
        pid = int(payload.get("pid") or 0)
        if status == "STARTING" or (status == "RUNNING" and process_alive(pid)):
            return job_file
    return None


def build_run_command(args: argparse.Namespace, runner: Path, index_path: Path) -> list[str]:
    command = [
        *runner_prefix(runner),
        "--root", str(Path(args.root).expanduser().resolve()),
        "--index", str(index_path),
        "--workers", str(args.workers),
        "--chunk-size", str(args.chunk_size),
        "--timeout", str(args.timeout),
    ]
    if args.max_output_row:
        command.extend(["--max-output-row", str(args.max_output_row)])
    if args.model:
        command.extend(["--model", args.model])
    if args.enable_live_writeback:
        command.append("--enable-live-writeback")
    if args.retry_failed:
        command.append("--retry-failed")
    if args.skip_export:
        command.append("--skip-export")
    return command


def supervise(job_file: Path) -> int:
    # The parent records the detached PID immediately after Popen.  Wait for
    # that atomic update so this process never overwrites it with pid=0.
    payload: dict[str, Any] = {}
    for _ in range(100):
        payload = load_json(job_file)
        if int(payload.get("pid") or 0) > 0:
            break
        time.sleep(0.01)
    payload["pid"] = os.getpid()
    payload["status"] = "RUNNING"
    payload["supervisor_started_at"] = timestamp()
    atomic_write_json(job_file, payload)
    log_path = Path(payload["log_file"])
    command = [str(value) for value in payload["command"]]
    exit_code = 255
    error = ""
    try:
        with log_path.open("a", encoding="utf-8") as log:
            log.write(f"[{timestamp()}] background supervisor pid={os.getpid()}\n")
            log.write(json.dumps({"command": command}, ensure_ascii=False) + "\n")
            log.flush()
            completed = subprocess.run(
                command,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
                check=False,
                close_fds=True,
            )
            exit_code = completed.returncode
    except BaseException as exc:
        error = f"{type(exc).__name__}: {exc}"
    final = load_json(job_file)
    final["status"] = "SUCCEEDED" if exit_code == 0 and not error else "FAILED"
    final["exit_code"] = exit_code
    final["error"] = error
    final["finished_at"] = timestamp()
    final["monitoring_model_calls"] = 0
    atomic_write_json(job_file, final)
    return 0


def start(args: argparse.Namespace) -> dict[str, Any]:
    if not args.apply:
        raise SystemExit("background production is write-capable; pass --apply after authorization")
    if args.chunk_size != 1:
        raise SystemExit("--chunk-size must remain 1")
    if args.workers < 1:
        raise SystemExit("--workers must be positive")
    root = Path(args.root).expanduser().resolve()
    index_path = Path(args.index).expanduser().resolve()
    runner = Path(args.runner).expanduser().resolve()
    if not index_path.exists():
        raise SystemExit(f"index does not exist: {index_path}")
    if not runner.exists():
        raise SystemExit(f"runner does not exist: {runner}")
    index = load_json(index_path)
    batch_id = str(index.get("batch_id") or index_path.parent.name)
    snapshot_path = index_path.parent / "生产契约快照.json"
    if not snapshot_path.exists():
        raise SystemExit(f"contract snapshot does not exist: {snapshot_path}")
    snapshot = load_json(snapshot_path)
    contract_id = str(snapshot.get("contract_id") or "")
    if not contract_id:
        raise SystemExit(f"contract snapshot has no contract_id: {snapshot_path}")
    job_dir = index_path.parent / "后台运行"
    job_dir.mkdir(parents=True, exist_ok=True)
    active = active_job_for_index(job_dir, index_path)
    if active:
        raise SystemExit(f"active background job already exists: {active}")

    command = build_run_command(args, runner, index_path)
    preflight = subprocess.run(
        [*command, "--preflight"],
        stdin=subprocess.DEVNULL,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
        close_fds=True,
    )
    if preflight.returncode != 0:
        raise SystemExit(
            f"background preflight failed ({preflight.returncode}):\n{preflight.stdout[-4000:]}"
        )

    job_id = datetime.now().strftime("%Y%m%d%H%M%S") + "-" + uuid.uuid4().hex[:8]
    job_file = job_dir / f"后台任务_{job_id}.json"
    log_file = job_dir / f"后台任务_{job_id}.log"
    payload: dict[str, Any] = {
        "job_id": job_id,
        "status": "STARTING",
        "pid": 0,
        "started_at": timestamp(),
        "batch_id": batch_id,
        "contract_id": contract_id,
        "root": str(root),
        "index_path": str(index_path),
        "index_sha256_at_start": sha256_file(index_path),
        "contract_snapshot_path": str(snapshot_path),
        "contract_snapshot_sha256": sha256_file(snapshot_path),
        "runner_path": str(runner),
        "runner_sha256": sha256_file(runner),
        "command": command,
        "preflight_output": preflight.stdout.strip(),
        "log_file": str(log_file),
        "monitoring_mode": "detached_local_supervisor_no_codex_polling",
        "monitoring_model_calls": 0,
    }
    atomic_write_json(job_file, payload)
    supervisor = subprocess.Popen(
        [sys.executable, str(Path(__file__).resolve()), "_supervise", "--job-file", str(job_file)],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        close_fds=True,
    )
    payload["pid"] = supervisor.pid
    payload["status"] = "RUNNING"
    atomic_write_json(job_file, payload)
    return {
        "job_id": job_id,
        "status": "RUNNING",
        "pid": supervisor.pid,
        "batch_id": batch_id,
        "contract_id": contract_id,
        "job_file": str(job_file),
        "log_file": str(log_file),
        "monitoring_model_calls": 0,
        "message": "background production started; no Codex polling is required",
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="action", required=True)
    start_parser = subparsers.add_parser("start")
    start_parser.add_argument("--root", required=True)
    start_parser.add_argument("--index", required=True)
    start_parser.add_argument(
        "--runner",
        default=str(Path(__file__).resolve().parent / "run_batch.py"),
    )
    start_parser.add_argument("--workers", type=int, default=10)
    start_parser.add_argument("--chunk-size", type=int, default=1)
    start_parser.add_argument("--timeout", type=int, default=900)
    start_parser.add_argument("--max-output-row", type=int, default=0)
    start_parser.add_argument("--model", default="")
    start_parser.add_argument("--enable-live-writeback", action="store_true")
    start_parser.add_argument("--retry-failed", action="store_true")
    start_parser.add_argument("--skip-export", action="store_true")
    start_parser.add_argument("--apply", action="store_true")
    supervise_parser = subparsers.add_parser("_supervise", help=argparse.SUPPRESS)
    supervise_parser.add_argument("--job-file", required=True)
    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("--job-file", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.action == "start":
        print(json.dumps(start(args), ensure_ascii=False, indent=2))
        return
    if args.action == "_supervise":
        raise SystemExit(supervise(Path(args.job_file).expanduser().resolve()))
    print(json.dumps(load_json(Path(args.job_file).expanduser().resolve()), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
