#!/usr/bin/env python3
"""Public xy-batch entrypoint for the deterministic production engine."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from deterministic_batch import main
from migrate_v7_scope import create_migration_batch
from prepare_controlled_retry import create_controlled_retry_batch


def option_value(argv: list[str], name: str, default: str = "") -> str:
    if name not in argv:
        return default
    index = argv.index(name)
    if index + 1 >= len(argv):
        raise SystemExit(f"{name} 缺少参数")
    return argv[index + 1]


def without_options(argv: list[str], names_with_values: set[str], flags: set[str]) -> list[str]:
    result: list[str] = []
    index = 0
    while index < len(argv):
        value = argv[index]
        if value in names_with_values:
            index += 2
            continue
        if value in flags:
            index += 1
            continue
        result.append(value)
        index += 1
    return result


def dispatch() -> None:
    argv = sys.argv[1:]
    if "--controlled-retry-scope" in argv:
        scope = option_value(argv, "--controlled-retry-scope")
        root = Path(option_value(argv, "--root", "运营/工作流运营")).expanduser().resolve()
        apply = "--apply-controlled-retry" in argv
        dry_run = "--dry-run" in argv
        prepare_only = "--prepare-only" in argv
        if not apply and not dry_run:
            raise SystemExit(
                "受控重试默认拒绝写入；先用 --dry-run，正式建立时必须显式 --apply-controlled-retry"
            )
        result = create_controlled_retry_batch(root, Path(scope), apply=apply and not dry_run)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if dry_run or prepare_only:
            return
        cleaned = without_options(
            argv,
            {"--controlled-retry-scope"},
            {"--apply-controlled-retry", "--prepare-only"},
        )
        cleaned = [value for value in cleaned if value != "--dry-run"]
        cleaned.extend(["--index", str(result["index_path"])])
        if "--retry-failed" not in cleaned:
            cleaned.append("--retry-failed")
        sys.argv = [sys.argv[0], *cleaned]
        main()
        return
    scope_option = (
        "--clean-recreate-scope"
        if "--clean-recreate-scope" in argv
        else "--clean-recreate-v7-scope"
    )
    if scope_option not in argv:
        main()
        return
    scope = option_value(argv, scope_option)
    root = Path(option_value(argv, "--root", "运营/工作流运营")).expanduser().resolve()
    apply = "--apply-clean-recreate" in argv
    dry_run = "--dry-run" in argv
    prepare_only = "--prepare-only" in argv
    if not apply and not dry_run:
        raise SystemExit("V7全新重建默认拒绝写入；先用 --dry-run，正式建立时必须显式 --apply-clean-recreate")
    result = create_migration_batch(root, Path(scope), apply=apply and not dry_run)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if dry_run or prepare_only:
        return
    cleaned = without_options(
        argv,
        {scope_option},
        {"--apply-clean-recreate", "--prepare-only"},
    )
    cleaned = [value for value in cleaned if value != "--dry-run"]
    cleaned.extend(["--index", str(result["index_path"])])
    sys.argv = [sys.argv[0], *cleaned]
    main()


if __name__ == "__main__":
    dispatch()
