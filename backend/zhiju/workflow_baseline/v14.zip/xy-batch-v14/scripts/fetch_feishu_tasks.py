#!/usr/bin/env python3
import argparse
import json
import sys
from datetime import datetime
from pathlib import Path


WORKSPACE = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube")
FEISHU_TOOLS = WORKSPACE / "tools" / "feishu_sync"
if str(FEISHU_TOOLS) not in sys.path:
    sys.path.append(str(FEISHU_TOOLS))

from feishu_sheet_sync import BASE
from feishu_sheet_sync import get_token
from feishu_sheet_sync import list_sheets
from feishu_sheet_sync import load_config
from feishu_sheet_sync import request_json


WIKI_TOKEN = "MUJ0wBw9yiyeJNkIt0cczSCgn3f"
SHEET_NAME = "工单"
SHEET_ID = "5EPSHD"
HEADERS = ["剧名", "剧id", "地址", "频道", "档期", "是否需要社区"]
HEADERS_NO_VIDEO_ID = ["剧名", "地址", "频道", "档期", "是否需要社区"]


def col_name(index: int) -> str:
    name = ""
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


def get_wiki_sheet_token(token: str) -> str:
    result = request_json("GET", f"{BASE}/wiki/v2/spaces/get_node?token={WIKI_TOKEN}", token=token)
    node = result.get("data", {}).get("node", {})
    if node.get("obj_type") != "sheet" or not node.get("obj_token"):
        raise SystemExit(f"Wiki node is not a sheet: obj_type={node.get('obj_type')}")
    return node["obj_token"]


def find_sheet_id(token: str, spreadsheet_token: str) -> str:
    sheets = list_sheets(token, spreadsheet_token)
    for sheet in sheets:
        if sheet.get("sheet_id") == SHEET_ID or sheet.get("title") == SHEET_NAME:
            return sheet["sheet_id"]
    known = ", ".join(f"{sheet.get('title')}({sheet.get('sheet_id')})" for sheet in sheets)
    raise SystemExit(f"Sheet not found: {SHEET_NAME}/{SHEET_ID}. Current sheets: {known}")


def normalize_cell(value) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        parts = [normalize_cell(item) for item in value]
        return "".join(part for part in parts if part)
    if isinstance(value, dict):
        for key in ("link", "text"):
            if value.get(key):
                return str(value[key]).strip()
        return ""
    if isinstance(value, float):
        if 0 <= value < 1:
            total_minutes = round(value * 24 * 60)
            hour = total_minutes // 60
            minute = total_minutes % 60
            return f"{hour}:{minute:02d}"
        if value.is_integer():
            return str(int(value))
    return str(value).strip()


def read_values(token: str, spreadsheet_token: str, sheet_id: str, rows: int, cols: int) -> list[list[str]]:
    range_name = f"{sheet_id}!A1:{col_name(cols)}{rows}"
    result = request_json(
        "GET",
        f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/values/{range_name}",
        token=token,
    )
    values = result.get("data", {}).get("valueRange", {}).get("values", [])
    normalized = []
    for row in values:
        cells = [normalize_cell(cell) for cell in row]
        cells = (cells + [""] * cols)[:cols]
        if any(cells):
            normalized.append(cells)
    return normalized


def normalize_header(cell: str) -> str:
    return cell.strip()


def ensure_headers(rows: list[list[str]]) -> None:
    if not rows:
        raise SystemExit("任务清单为空")
    header = [normalize_header(cell) for cell in rows[0]]
    if header[: len(HEADERS)] == HEADERS:
        rows[0] = HEADERS + rows[0][len(HEADERS) :]
        return
    if header[: len(HEADERS_NO_VIDEO_ID)] == HEADERS_NO_VIDEO_ID:
        converted = [HEADERS]
        for row in rows[1:]:
            cells = (row + [""] * len(HEADERS_NO_VIDEO_ID))[: len(HEADERS_NO_VIDEO_ID)]
            converted.append([cells[0], "", cells[1], cells[2], cells[3], cells[4]])
        rows[:] = converted
        return
    raise SystemExit("任务表表头必须是: " + " / ".join(HEADERS) + "  或  " + " / ".join(HEADERS_NO_VIDEO_ID))


def rows_to_tsv(rows: list[list[str]]) -> str:
    return "\n".join("\t".join(cell.replace("\t", " ").replace("\n", " ") for cell in row) for row in rows) + "\n"


def is_meaningful_task_row(row: list[str]) -> bool:
    cells = (row + [""] * len(HEADERS))[: len(HEADERS)]
    drama_name, video_id, url, channel, slot, _need_community = [cell.strip() for cell in cells]
    has_primary_task_data = bool(drama_name or video_id or url)
    has_routing_data = bool(channel or slot)
    return has_primary_task_data and has_routing_data


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--config", default=str(WORKSPACE / "tools" / "feishu_sync" / "feishu_sync_config.json"))
    parser.add_argument("--rows", type=int, default=200)
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    config = load_config(args.config)
    token = get_token(config)
    spreadsheet_token = get_wiki_sheet_token(token)
    sheet_id = find_sheet_id(token, spreadsheet_token)
    rows = read_values(token, spreadsheet_token, sheet_id, args.rows, len(HEADERS))
    ensure_headers(rows)
    filtered = [rows[0]]
    for row in rows[1:]:
        if is_meaningful_task_row(row):
            filtered.append((row + [""] * len(HEADERS))[: len(HEADERS)])
    rows = filtered
    if len(rows) <= 1:
        raise SystemExit("任务清单没有有效任务行")

    record_dir = root / "_运行记录" / "飞书拉取"
    record_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d%H%M")
    tsv_path = record_dir / f"任务清单_飞书拉取_{stamp}.tsv"
    tsv_path.write_text(rows_to_tsv(rows), encoding="utf-8")
    print(
        json.dumps(
            {
                "spreadsheet_token": spreadsheet_token,
                "sheet_name": SHEET_NAME,
                "sheet_id": sheet_id,
                "rows": len(rows) - 1,
                "tsv_path": str(tsv_path),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
