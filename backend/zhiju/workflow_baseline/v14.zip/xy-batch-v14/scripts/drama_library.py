#!/usr/bin/env python3
"""Deterministic Feishu drama-library lookup for xy-batch."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any


WORKSPACE = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube")
FEISHU_TOOLS = WORKSPACE / "tools" / "feishu_sync"
if str(FEISHU_TOOLS) not in sys.path:
    sys.path.append(str(FEISHU_TOOLS))

from feishu_sheet_sync import BASE, get_token, list_sheets, load_config, request_json


WIKI_TOKEN = "KNxew7DIUiNr6ukbgYrciIqongh"
SHEET_TITLE = "总库表"
PLOT_FIELDS = ("内容概述", "剧情档案", "剧情套路", "核心人设")
# The authoritative 剧库表 currently uses “作品名称”.  Keep the older
# aliases for backward compatibility, but accept the live header first so
# deterministic preflight and exact matching use the same source contract as
# xy-find.
TITLE_HEADERS = ("作品名称", "剧名", "中文剧名", "剧目名称", "短剧名称", "名称")
ALIAS_HEADERS = ("别名", "剧名别名", "其他名称")


def normalize_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "".join(normalize_cell(item) for item in value).strip()
    if isinstance(value, dict):
        for key in ("text", "link"):
            if value.get(key):
                return str(value[key]).strip()
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def col_name(index: int) -> str:
    name = ""
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


class DramaLibraryClient:
    def __init__(self, config_path: str | Path | None = None) -> None:
        self.config_path = Path(config_path or WORKSPACE / "tools/feishu_sync/feishu_sync_config.json")
        self._rows: list[list[str]] | None = None

    def _load_rows(self) -> list[list[str]]:
        if self._rows is not None:
            return self._rows
        config = load_config(str(self.config_path))
        token = get_token(config)
        node_result = request_json("GET", f"{BASE}/wiki/v2/spaces/get_node?token={WIKI_TOKEN}", token=token)
        node = node_result.get("data", {}).get("node", {})
        spreadsheet_token = str(node.get("obj_token") or "")
        if node.get("obj_type") != "sheet" or not spreadsheet_token:
            raise RuntimeError("剧库 Wiki 节点不是电子表格")
        sheet_id = ""
        for sheet in list_sheets(token, spreadsheet_token):
            if str(sheet.get("title") or "").strip() == SHEET_TITLE:
                sheet_id = str(sheet.get("sheet_id") or "")
                break
        if not sheet_id:
            raise RuntimeError("剧库表不存在")
        # Plot archives make the old A1:AZ2000 request exceed Feishu's
        # response-size limit. Keep the same source scope, read in pages.
        raw_rows = []
        for start in range(1, 2001, 100):
            end = min(start + 99, 2000)
            range_name = f"{sheet_id}!A{start}:{col_name(52)}{end}"
            result = request_json(
                "GET",
                f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/values/{range_name}",
                token=token,
            )
            page = result.get("data", {}).get("valueRange", {}).get("values", [])
            raw_rows.extend(page)
            # Preserve physical row numbers if trailing empty rows are omitted.
            raw_rows.extend([[] for _ in range(end - start + 1 - len(page))])
        self._rows = [[normalize_cell(cell) for cell in row] for row in raw_rows]
        return self._rows

    def preflight(self) -> dict[str, Any]:
        rows = self._load_rows()
        header = rows[0] if rows else []
        title_header = next((name for name in TITLE_HEADERS if name in header), "")
        missing = [name for name in PLOT_FIELDS if name not in header]
        if not title_header or missing:
            raise RuntimeError(
                "剧库表头不符合生产契约: "
                + ("缺少剧名列; " if not title_header else "")
                + ("缺少 " + ", ".join(missing) if missing else "")
            )
        return {"rows": max(0, len(rows) - 1), "title_header": title_header, "plot_fields": list(PLOT_FIELDS)}

    def exact_match(self, drama_name: str, video_id: str = "", slot: str = "") -> dict[str, Any]:
        rows = self._load_rows()
        if not rows:
            raise RuntimeError("剧库表为空")
        header = rows[0]
        columns = {name: index for index, name in enumerate(header)}
        title_header = next((name for name in TITLE_HEADERS if name in columns), "")
        missing = [name for name in PLOT_FIELDS if name not in columns]
        if not title_header or missing:
            raise RuntimeError("剧库表缺少生产必需列: " + ", ".join((["剧名列"] if not title_header else []) + missing))

        matches: list[tuple[int, dict[str, str]]] = []
        for row_number, row in enumerate(rows[1:], start=2):
            def value(name: str) -> str:
                index = columns[name]
                return row[index].strip() if index < len(row) else ""

            if value(title_header) != drama_name.strip():
                continue
            record = {name: value(name) for name in PLOT_FIELDS}
            record["剧名"] = value(title_header)
            alias_header = next((name for name in ALIAS_HEADERS if name in columns), "")
            record["别名"] = value(alias_header) if alias_header else ""
            matches.append((row_number, record))
        if not matches:
            raise RuntimeError(f"剧库表未找到完全匹配剧名: {drama_name}")

        # Most complete wins.  Equal completeness preserves physical row order.
        selected_row, selected = max(
            matches,
            key=lambda pair: (sum(bool(pair[1].get(name, "").strip()) for name in PLOT_FIELDS), -pair[0]),
        )
        completeness = sum(bool(selected.get(name, "").strip()) for name in PLOT_FIELDS)
        if completeness == 0:
            raise RuntimeError(f"剧库表匹配到《{drama_name}》，但四个剧情字段全部为空")
        result_id = f"{video_id}_1" if video_id else f"{slot}_1"
        return {
            "section": "plot",
            "results": [
                {
                    "search_result_index": 1,
                    "source_block_label": "搜索资料1",
                    "result_id": result_id,
                    "video_id": video_id,
                    "drama_name": drama_name,
                    "alias": selected.get("别名", ""),
                    "plot_fields": {name: selected.get(name, "") for name in PLOT_FIELDS},
                    "source": "feishu_drama_library_exact",
                    "source_row_number": selected_row,
                    "duplicate_match_count": len(matches),
                    "completeness": completeness,
                }
            ],
        }
