#!/usr/bin/env python3
"""Build an exact 1..N clean-recreate scope from a complete daily work order."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
from deterministic_batch import load_json, write_json  # noqa: E402
from migrate_v7_scope import SAFE_BATCH_ID, SAFE_CONTRACT_ID  # noqa: E402

COMMUNITY_SCRIPT_DIR = SCRIPT_DIR.parents[1] / "xy-generate-tasks-v14" / "scripts"
if str(COMMUNITY_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(COMMUNITY_SCRIPT_DIR))
from community_counts import assign_community_counts, scope_identity  # noqa: E402


def load_daily_tsv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    assigned = assign_community_counts(rows)
    for row in assigned:
        actual = str(row.get("是否需要社区") or "").strip()
        expected = str(row["是否需要社区"])
        if actual != expected:
            raise ValueError(f"完整日工单社群数量不符: {scope_identity(row)}")
    return assigned


def build_daily_rebuild_scope(
    work_order_tsv: Path, source_indices: list[Path], *, batch_id: str,
    target_contract_id: str, expected_items: int, expected_channels: int,
) -> dict:
    if not SAFE_BATCH_ID.fullmatch(batch_id):
        raise ValueError("batch_id格式无效")
    if not SAFE_CONTRACT_ID.fullmatch(target_contract_id):
        raise ValueError("target_contract_id格式无效")
    rows = load_daily_tsv(work_order_tsv)
    if len(rows) != expected_items:
        raise ValueError(f"完整日任务数不符: expected={expected_items}, actual={len(rows)}")
    if len({row["频道"] for row in rows}) != expected_channels:
        raise ValueError("完整日频道数不符")
    sources = {}
    for index_path in source_indices:
        index_path = index_path.expanduser().resolve()
        data = load_json(index_path, {})
        for item in data.get("items", []):
            identity = (
                str(item.get("channel") or ""), str(item.get("drama_name") or ""),
                str(item.get("slot") or ""),
            )
            if identity in sources:
                raise ValueError(f"源索引任务重复: {identity}")
            sources[identity] = (index_path, item)
    work_identities = [scope_identity(row) for row in rows]
    if set(work_identities) != set(sources):
        missing = sorted(set(work_identities) - set(sources))
        extra = sorted(set(sources) - set(work_identities))
        raise ValueError(f"完整日源包集合不闭环: missing={missing}, extra={extra}")
    items = []
    for output_row, row in enumerate(rows, start=2):
        identity = scope_identity(row)
        index_path, source = sources[identity]
        if str(source.get("status") or "").upper() != "INITIALIZED":
            raise ValueError(f"源任务不是INITIALIZED: {identity}")
        source_count = int(source.get("community_count") or (1 if source.get("need_community") else 0))
        items.append({
            "source_index": str(index_path),
            "source_row_number": int(source.get("row_number") or 0),
            "output_row_number": output_row,
            "video_id": str(source.get("video_id") or ""),
            "expected_source_contract_id": "",
            "expected_source_status": "INITIALIZED",
            "expected_source_community_count": source_count,
            "target_community_count": int(row["是否需要社区"]),
            "reason": "完整日期频道集合补齐后重新冻结39条正式生产范围",
        })
    return {
        "scope_version": 1, "mode": "clean_recreate", "batch_id": batch_id,
        "target_contract_id": target_contract_id,
        "expected_item_count": len(items),
        "expected_video_ids": [item["video_id"] for item in items],
        "items": items,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work-order-tsv", required=True, type=Path)
    parser.add_argument("--source-index", action="append", required=True, type=Path)
    parser.add_argument("--batch-id", required=True)
    parser.add_argument("--target-contract-id", required=True)
    parser.add_argument("--expected-items", type=int, required=True)
    parser.add_argument("--expected-channels", type=int, required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    scope = build_daily_rebuild_scope(
        args.work_order_tsv, args.source_index, batch_id=args.batch_id,
        target_contract_id=args.target_contract_id, expected_items=args.expected_items,
        expected_channels=args.expected_channels,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(args.output, scope)
    print(json.dumps({"output": str(args.output.resolve()), "items": len(scope["items"])}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
