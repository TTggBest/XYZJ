#!/usr/bin/env python3
import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

PACK_SCRIPT_DIR = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts"
if str(PACK_SCRIPT_DIR) not in sys.path:
    sys.path.append(str(PACK_SCRIPT_DIR))

from skill_rule_loader import load_community_rule_bundle
from skill_rule_loader import load_cover_rule_bundle
from skill_rule_loader import load_description_rule_bundle
from skill_rule_loader import load_title_rule_bundle
from canonical_outputs import cover_rows
from canonical_outputs import first_result
from canonical_outputs import title_rows
from workflow_contract import normalize_status, verify_contract_snapshot, verify_runtime_sources


WORKSPACE = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube")
FEISHU_TOOLS = WORKSPACE / "tools" / "feishu_sync"
if str(FEISHU_TOOLS) not in sys.path:
    sys.path.append(str(FEISHU_TOOLS))

from feishu_sheet_sync import BASE
from feishu_sheet_sync import get_token
from feishu_sheet_sync import list_sheets
from feishu_sheet_sync import load_config
from feishu_sheet_sync import put_values
from feishu_sheet_sync import request_json


WIKI_TOKEN = "MUJ0wBw9yiyeJNkIt0cczSCgn3f"
TASK_OUTPUT_SHEET_ID = "Pii5w9"
TASK_OUTPUT_SHEET_TITLE = "任务"
OLD_HEADERS = ["日期", "频道", "频道昵称", "剧名", "剧id", "剧目地址", "档期", "是否需要社区", "标题", "封面", "说明", "播放列表", "社群文案", "社群图"]
HEADERS = [
    "日期",
    "频道",
    "频道昵称",
    "剧名",
    "剧id",
    "剧目地址",
    "档期",
    "是否需要社区",
    "标题",
    "标题翻译",
    "封面4：5",
    "封面16：9",
    "说明",
    "说明翻译",
    "播放列表",
    "社群文案",
    "社群图描述",
]
COMPLETED_EXPORT_STATUSES = {"PACKAGE_READY", "DELIVERED", "package_ready", "delivered"}


def load_json(path: Path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_batch_machine_contracts(batch_dir: Path) -> dict:
    snapshot_path = batch_dir / "生产契约快照.json"
    if not snapshot_path.exists():
        return {}
    snapshot = load_json(snapshot_path, {})
    try:
        verify_contract_snapshot(snapshot)
        verify_runtime_sources(snapshot)
    except ValueError as exc:
        raise RuntimeError(f"生产契约快照完整性失败: {exc}") from exc
    contracts = {}
    for stage, row in snapshot.get("machine_contracts", {}).items():
        content = row.get("content") if isinstance(row, dict) else None
        if isinstance(content, dict):
            contracts[stage] = content
    return contracts


def col_name(index: int) -> str:
    name = ""
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


def get_wiki_sheet_token(token: str) -> str:
    result = request_json("GET", f"{BASE}/wiki/v2/spaces/get_node?token={WIKI_TOKEN}", token=token)
    node = result.get("data", {}).get("node", {})
    if node.get("obj_type") != "sheet" or not node.get("obj_token"):
        raise SystemExit(f"Wiki node is not a sheet: obj_type={node.get('obj_type')}")
    return node["obj_token"]


def normalize_header(row) -> list[str]:
    return [("" if cell is None else str(cell).strip()) for cell in row]


def canonical_header(row) -> list[str]:
    return [canonical_header_cell(cell) for cell in normalize_header(row)]


def canonical_header_cell(cell: str) -> str:
    value = cell.strip().replace("：", ":").replace(" ", "")
    if value in {"封面4:5", "封面5:4"}:
        return "封面4:5"
    return value


def read_row(token: str, spreadsheet_token: str, sheet_id: str, range_name: str):
    result = request_json("GET", f"{BASE}/sheets/v2/spreadsheets/{spreadsheet_token}/values/{range_name}", token=token)
    return result.get("data", {}).get("valueRange", {}).get("values", [])


def find_output_sheet_id(token: str, spreadsheet_token: str) -> str:
    sheets = list_sheets(token, spreadsheet_token)
    for sheet in sheets:
        if sheet.get("sheet_id") == TASK_OUTPUT_SHEET_ID:
            return TASK_OUTPUT_SHEET_ID
    for sheet in sheets:
        if (sheet.get("title") or "").strip() == TASK_OUTPUT_SHEET_TITLE:
            return sheet.get("sheet_id")
    for sheet in sheets:
        sid = sheet.get("sheet_id")
        values = read_row(token, spreadsheet_token, sid, f"{sid}!A1:{col_name(len(HEADERS))}1")
        if not values:
            continue
        header = canonical_header(values[0])
        if header[: len(HEADERS)] == canonical_header(HEADERS) or header[: len(OLD_HEADERS)] == canonical_header(OLD_HEADERS):
            return sid
    known = ", ".join(sheet.get("title", "") for sheet in sheets)
    raise SystemExit(f"找不到每日任务输出表头。当前 sheets: {known}")


def current_index(root: Path, index_arg: str) -> Path:
    if index_arg:
        return Path(index_arg).expanduser().resolve()
    pointer = root / "批量任务" / "current_batch.json"
    data = load_json(pointer, {})
    if not data.get("index_path"):
        raise SystemExit(f"Missing current batch pointer: {pointer}")
    return Path(data["index_path"]).expanduser().resolve()


def channel_root_for_package(package: Path) -> Path:
    if package.name == "剧目":
        raise ValueError(f"Invalid package path: {package}")
    if package.parent.name != "剧目":
        raise ValueError(f"Unexpected package path layout: {package}")
    return package.parent.parent


def language_and_channel_for_package(package: Path) -> tuple[str, str]:
    parts = package.parts
    if "V2" in parts and "工作流实验室" in parts:
        idx = parts.index("V2")
    elif "工作流运营" in parts:
        idx = parts.index("工作流运营")
    else:
        return "", ""
    language = parts[idx + 1] if idx + 1 < len(parts) else ""
    channel = parts[idx + 2] if idx + 2 < len(parts) else ""
    return language, channel


def default_description_fixed_assets(language: str, channel_name: str) -> dict:
    base = load_description_rule_bundle(language, channel_name)["fixed_assets"]
    return {
        "version": 1,
        "source": "xy-place-v14/rules/description_rules.json",
        "language": language,
        "channel_name": channel_name,
        "welcome_line": base["welcome_line"],
        "welcome_body": base["welcome_body"],
        "subscribe_line": base["subscribe_line"],
        "comment_line": base["comment_line"],
        "disclaimer_lines": base["disclaimer_lines"],
        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def load_description_fixed_assets(package: Path) -> tuple[dict, Path]:
    frozen_path = package / "02_频道固定资产.json"
    frozen = load_json(frozen_path, {})
    frozen_assets = frozen.get("description_fixed_assets") if isinstance(frozen, dict) else None
    if isinstance(frozen_assets, dict) and frozen_assets:
        return frozen_assets, frozen_path
    if "V2" in package.parts and "工作流实验室" in package.parts:
        raise RuntimeError(f"V2包缺少冻结频道固定资产: {frozen_path}")
    channel_root = channel_root_for_package(package)
    asset_path = channel_root / "description_fixed_assets.json"
    language, channel_name = language_and_channel_for_package(package)
    data = load_json(asset_path, {})
    required = {"welcome_line", "welcome_body", "subscribe_line", "disclaimer_lines"}
    should_refresh_auto_seed = (
        data.get("source") == "language_fallback_auto_seed"
        and contains_chinese(str(data.get("welcome_line", "")))
        and language != "中文"
    )
    if not required.issubset(set(data.keys())) or not isinstance(data.get("disclaimer_lines"), list) or should_refresh_auto_seed:
        data = default_description_fixed_assets(language, channel_name)
        asset_path.parent.mkdir(parents=True, exist_ok=True)
        write_json(asset_path, data)
    return data, asset_path


def split_final_marker(description: str) -> tuple[str, str]:
    desc = description.strip()
    marker = re.search(r"(\n==.+?==)\s*$", desc, flags=re.S)
    if marker:
        return desc[: marker.start()].rstrip(), marker.group(1).strip()
    return desc, ""


def expected_final_marker(package: Path) -> str:
    metadata_path = package / "剧目元数据.json"
    drama_name = ""
    if metadata_path.exists():
        try:
            drama_name = str(load_json(metadata_path, {}).get("drama_name", "")).strip()
        except Exception:
            drama_name = ""
    if not drama_name:
        match = re.match(r"(.+)_\d{10}$", package.name)
        if match:
            drama_name = match.group(1).strip()
        else:
            drama_name = package.name.strip()
    return f"=={drama_name}=="


def ensure_description_marker(description: str, package: Path) -> str:
    desc = description.strip()
    marker = expected_final_marker(package)
    if not desc:
        return marker
    matched = re.search(r"\n==.+?==\s*$", desc, flags=re.S)
    if matched:
        before = desc[: matched.start()].rstrip()
        return f"{before}\n\n{marker}"
    return f"{desc}\n\n{marker}"


def normalize_description_fixed_tail(description: str, package: Path) -> str:
    assets, _ = load_description_fixed_assets(package)
    body, _ = split_final_marker(description)
    lines = [line for line in body.splitlines() if not re.fullmatch(r"\s*==.+?==\s*", line)] if body else []
    prefix = []
    reached_tail = False
    in_playlist_block = False
    for raw in lines:
        stripped = raw.strip()
        if not stripped:
            if not reached_tail:
                prefix.append("")
            in_playlist_block = False
            continue
        if not reached_tail:
            if stripped.startswith("👇"):
                prefix.append(raw.rstrip())
                in_playlist_block = True
                continue
            if in_playlist_block and (("👉" in stripped and stripped.startswith(("💖", "📌", "1", "2", "3", "4"))) or stripped.startswith(("http://", "https://"))):
                prefix.append(raw.rstrip())
                continue
        if stripped.startswith(("💖", "🔔", "💬", "⚠️")):
            reached_tail = True
            continue
        if reached_tail:
            continue
        prefix.append(raw.rstrip())
    while prefix and not str(prefix[-1]).strip():
        prefix.pop()
    tail_lines = [
        assets["subscribe_line"],
        "",
        *assets["disclaimer_lines"],
    ]
    rebuilt = "\n".join(prefix + [""] + tail_lines).strip()
    return rebuilt.strip()


def sync_place_package_files(package: Path, description: str) -> None:
    json_path = package / "place_result.json"
    if not json_path.exists():
        json_path = package / "07_播放列表建议.json"
    data = load_json(json_path, {})
    if data.get("description") != description:
        data["description"] = description
        write_json(json_path, data)
    md_path = package / "place_result.md"
    if not md_path.exists():
        md_path = package / "07_播放列表建议.md"
    if md_path.exists():
        text = md_path.read_text(encoding="utf-8")
        updated = re.sub(
            r"(?s)(说明：\n)(.*?)(\n翻译：\n)",
            lambda m: f"{m.group(1)}{description}{m.group(3)}",
            text,
            count=1,
        )
        if updated == text and "说明：\n" in text and "\n翻译：\n" not in text:
            updated = re.sub(r"(?s)(说明：\n)(.*)$", lambda m: f"{m.group(1)}{description}", text, count=1)
        if updated != text:
            md_path.write_text(updated, encoding="utf-8")


def title_text(package: Path) -> str:
    data = load_json(package / "04_标题方案.json", {})
    titles = [row.get("title", "") for row in title_rows(data)]
    return "\n".join([title for title in titles if title])


def title_translation_text(package: Path) -> str:
    data = load_json(package / "04_标题方案.json", {})
    translations = [row.get("translation", "") for row in title_rows(data)]
    return "\n".join([translation for translation in translations if translation])


def title_issues_from_cell(text: str, frozen_contract: dict | None = None) -> list[str]:
    title_contract = (frozen_contract or load_title_rule_bundle()).get("title_contract", {})
    max_visible_characters = int(title_contract.get("max_visible_characters", 100))
    required_direction_count = int(title_contract.get("required_direction_count", 3))
    titles = [line.strip() for line in str(text).splitlines() if line.strip()]
    issues = []
    if not titles:
        return ["标题为空"]
    if len(titles) != required_direction_count:
        issues.append(f"标题数量错误: {len(titles)}条, 应为{required_direction_count}条")
    for idx, title in enumerate(titles, start=1):
        actual = len(title)
        if actual > max_visible_characters:
            issues.append(f"标题{idx}超长: {actual}字符")
    return issues


def compiled_regex_map(mapping: dict[str, str]) -> dict[str, re.Pattern]:
    return {key: re.compile(pattern, re.IGNORECASE) for key, pattern in mapping.items()}


def matched_family_names(text: str, patterns: dict[str, re.Pattern]) -> list[str]:
    hits = []
    for name, pattern in patterns.items():
        if pattern.search(text or ""):
            hits.append(name)
    return hits


def positive_prompt_text(prompt: str) -> str:
    text = prompt or ""
    text = re.sub(r"\bSafety:\s*no unsafe depiction of children or teenagers\.?", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bno unsafe depiction of children or teenagers\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bno child characters\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bno children\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bno babies\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bchild-safe\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bfamily-safe\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bDo not [^.。]*[.。]", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\bNo [^.。]*[.。]", " ", text)
    text = re.sub(
        r"\bnot\s+(?:a|an|another)?\s*[^,.。;]*?\b(hospital|clinic|medical|dna|paternity|wedding|marriage|bride|groom|boardroom|office|children|child|crowd)\b[^,.。;]*",
        " ",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(
        r"\bno\s+[^,.。;]*?\b(hospital|clinic|medical|dna|paternity|wedding|marriage|bride|groom|boardroom|office|children|child|crowd)\b[^,.。;]*",
        " ",
        text,
        flags=re.IGNORECASE,
    )
    return text


def expected_child_count_from_text(text: str) -> int:
    lowered = text or ""
    mapping = [
        (6, [r"六宝", r"six children", r"six kids"]),
        (5, [r"五宝", r"five children", r"five kids"]),
        (4, [r"四宝", r"four children", r"four kids"]),
        (3, [r"三宝", r"three children", r"three kids"]),
        (2, [r"双宝", r"双胞胎", r"twins", r"two children", r"two kids"]),
    ]
    for count, patterns in mapping:
        for pattern in patterns:
            if re.search(pattern, lowered, re.IGNORECASE):
                return count
    return 0


def title_package_issues(package: Path, frozen_contract: dict | None = None) -> list[str]:
    data = load_json(package / "04_标题方案.json", {})
    directions = title_rows(data)
    title_contract = frozen_contract or load_title_rule_bundle()
    distinct = title_contract.get("distinctness_audit", {})
    issues = []
    required_direction_count = int(title_contract.get("title_contract", {}).get("required_direction_count", 3))
    max_visible_characters = int(title_contract.get("title_contract", {}).get("max_visible_characters", 100))
    if len(directions) != required_direction_count:
        issues.append(f"标题方案数量错误: {len(directions)}条, 应为{required_direction_count}条")
        return issues

    scene_patterns = compiled_regex_map(distinct.get("scene_anchor_families", {}))
    hook_patterns = compiled_regex_map(distinct.get("hook_families", {}))
    max_same_scene_anchor_hits = int(distinct.get("max_same_scene_anchor_hits", 1))
    min_unique_hook_families = int(distinct.get("min_unique_hook_families", 2))

    scene_counts: dict[str, list[int]] = {}
    hook_hits = set()
    normalized_titles = []

    for row in directions:
        idx = int(row.get("index", 0) or 0)
        title_text = str(row.get("title", "") or "")
        actual_len = len(title_text)
        if actual_len > max_visible_characters:
            issues.append(f"标题{idx}超长: {actual_len}字符")
        recorded_count = str(row.get("char_count", "") or "").strip()
        if recorded_count.isdigit() and int(recorded_count) != actual_len:
            issues.append(f"标题{idx}字符数标注不一致: 标注{recorded_count}, 实际{actual_len}")
        direction_text = str(row.get("direction", "") or "")
        hook_text = " ".join(
            [
                direction_text,
                title_text,
                str(row.get("translation", "")),
            ]
        )
        for name in matched_family_names(direction_text, scene_patterns):
            scene_counts.setdefault(name, []).append(idx)
        for name in matched_family_names(hook_text, hook_patterns):
            hook_hits.add(name)
        normalized_titles.append(re.sub(r"[\W_]+", "", title_text.lower()))

    for family, indexes in scene_counts.items():
        if len(indexes) > max_same_scene_anchor_hits:
            issues.append(f"标题方向重复场景锚点 {family}: {indexes}")
    if len(hook_hits) < min_unique_hook_families:
        issues.append(f"标题钩子族过少: 仅{len(hook_hits)}类")
    if len(set(normalized_titles)) < len(normalized_titles):
        issues.append("标题存在重复或近重复文本")
    return issues


def cover_prompt_text(package: Path, prompt_key: str) -> str:
    data = load_json(package / "04_封面提示词.json", {})
    lines = []
    canonical_key = {"prompt_4x5": "prompt_4_5", "prompt_16x9": "prompt_16_9"}.get(prompt_key, prompt_key)
    for item in cover_rows(data):
        index = item.get("title_index", "")
        title = item.get("title", "")
        core_word = item.get("core_words", "")
        prompt = item.get(canonical_key, "")
        if not prompt:
            continue
        header = f"标题{index}：{title}".strip()
        core = f"核心词：{core_word}".strip() if core_word else ""
        block = "\n".join(part for part in [header, core, prompt] if part)
        lines.append(block)
    return "\n\n".join(lines)


def cover_package_issues(package: Path, cover_rule_contract: dict | None = None) -> list[str]:
    cover_data = load_json(package / "04_封面提示词.json", {})
    title_data = load_json(package / "04_标题方案.json", {})
    contract = cover_rule_contract if isinstance(cover_rule_contract, dict) else load_cover_rule_bundle()
    cover_rules = contract.get("prompt_audit", {})
    issues = []
    items = cover_rows(cover_data)
    if len(items) != 3:
        issues.append(f"封面方案数量错误: {len(items)}组, 应为3组")
        return issues

    scene_patterns = compiled_regex_map(cover_rules.get("repeated_scene_families", {}))
    action_patterns = compiled_regex_map(cover_rules.get("main_action_families", {}))
    blocking_patterns = compiled_regex_map(cover_rules.get("blocking_skeleton_families", {}))
    wide_shot_risk = re.compile(cover_rules.get("wide_shot_risk_pattern", r"$^"), re.IGNORECASE)
    half_body_positive = re.compile(cover_rules.get("half_body_positive_pattern", r"$^"), re.IGNORECASE)
    child_count_required = re.compile(cover_rules.get("child_count_required_pattern", r"$^"), re.IGNORECASE)
    child_count_substitution = re.compile(cover_rules.get("child_count_substitution_pattern", r"$^"), re.IGNORECASE)
    explicit_child_count_patterns = {
        int(key): re.compile(pattern, re.IGNORECASE)
        for key, pattern in cover_rules.get("explicit_child_count_patterns", {}).items()
    }
    max_same_scene_family_hits = int(cover_rules.get("max_same_scene_family_hits", 1))
    max_same_action_family_hits = int(cover_rules.get("max_same_action_family_hits", 1))
    max_same_blocking_skeleton_hits = int(cover_rules.get("max_same_blocking_skeleton_hits", 1))

    title_by_index = {int(row.get("index", 0) or 0): row for row in title_rows(title_data)}
    scene_counts: dict[str, list[int]] = {}
    action_counts: dict[str, list[int]] = {}
    blocking_counts: dict[str, list[int]] = {}

    for item in items:
        idx = int(item.get("title_index", 0) or 0)
        prompt_4x5 = str(item.get("prompt_4_5", ""))
        positive_prompt = positive_prompt_text(prompt_4x5)
        if wide_shot_risk.search(positive_prompt):
            issues.append(f"封面{idx}含远景/全身风险词")
        if not half_body_positive.search(positive_prompt):
            issues.append(f"封面{idx}缺少半身/近景明确约束")
        for name in matched_family_names(positive_prompt, scene_patterns):
            scene_counts.setdefault(name, []).append(idx)
        for name in matched_family_names(positive_prompt, action_patterns):
            action_counts.setdefault(name, []).append(idx)
        for name in matched_family_names(positive_prompt, blocking_patterns):
            blocking_counts.setdefault(name, []).append(idx)

        title_row = title_by_index.get(idx, {})
        title_context = " ".join(
            [
                str(title_row.get("direction", "")),
                str(title_row.get("translation", "")),
                str(item.get("title", "")),
            ]
        )
        expected_count = expected_child_count_from_text(title_context)
        if child_count_required.search(title_context) and child_count_substitution.search(positive_prompt):
            issues.append(f"封面{idx}在多宝题材中用暗示/替代方式处理孩子人数")
        if expected_count >= 2:
            count_pattern = explicit_child_count_patterns.get(expected_count)
            if count_pattern and not count_pattern.search(positive_prompt):
                issues.append(f"封面{idx}未明确要求可见{expected_count}个孩子")

    for family, indexes in scene_counts.items():
        if len(indexes) > max_same_scene_family_hits:
            issues.append(f"封面重复场景族 {family}: {indexes}")
    for family, indexes in action_counts.items():
        if len(indexes) > max_same_action_family_hits:
            issues.append(f"封面重复动作族 {family}: {indexes}")
    for family, indexes in blocking_counts.items():
        if len(indexes) > max_same_blocking_skeleton_hits:
            issues.append(f"封面重复blocking骨架 {family}: {indexes}")
    return issues


DEFAULT_MANDATORY_DESCRIPTION_HASHTAGS = ("#cdrama",)


def mandatory_description_hashtags(contract: dict | None = None) -> tuple[str, ...]:
    contract = contract or {}
    configured = contract.get("mandatory_hashtags")
    if isinstance(configured, list):
        values = tuple(str(value).strip() for value in configured if str(value).strip())
        if values:
            return values
    legacy = str(contract.get("mandatory_hashtag") or "").strip()
    if legacy:
        return (legacy,)
    return DEFAULT_MANDATORY_DESCRIPTION_HASHTAGS


def description_hashtag_present(description: str, hashtag: str) -> bool:
    return bool(re.search(
        rf"(?<![A-Za-z0-9_]){re.escape(hashtag)}(?![A-Za-z0-9_])",
        description,
        flags=re.I,
    ))


def ensure_description_hashtags(description: str, package: Path) -> str:
    desc = description.strip()
    if not desc:
        return desc
    mandatory = DEFAULT_MANDATORY_DESCRIPTION_HASHTAGS
    lines = desc.splitlines()
    for index, line in enumerate(lines):
        if not line.strip().startswith("#"):
            continue
        missing = [tag for tag in mandatory if not description_hashtag_present(line, tag)]
        if not missing:
            return desc
        lines[index] = f"{line.rstrip()} {' '.join(missing)}"
        return "\n".join(lines)
    hashtag_line = " ".join(mandatory)
    marker = re.search(r"\n==.+?==\s*$", desc, flags=re.S)
    if marker:
        before = desc[: marker.start()].rstrip()
        after = desc[marker.start() :].strip()
        return f"{before}\n\n{hashtag_line}\n\n{after}"
    return f"{desc}\n\n{hashtag_line}"


def extract_hashtag_line(description: str) -> str:
    for line in description.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            return stripped
    return ""


def normalize_whitespace_blocks(text: str) -> str:
    text = re.sub(r"\n{3,}", "\n\n", text.strip())
    return text.strip()


def contains_chinese(text: str) -> bool:
    return bool(re.search(r"[\u4e00-\u9fff]", text))


def description_body_without_final_marker(description: str) -> str:
    desc = description.strip()
    marker = re.search(r"\n==.+?==\s*$", desc, flags=re.S)
    if marker:
        return desc[: marker.start()].rstrip()
    return desc


def description_format_issues(description: str, frozen_contract: dict | None = None) -> list[str]:
    desc = description.strip()
    issues = []
    if not desc:
        return ["说明为空"]
    contract_bundle = frozen_contract or load_description_rule_bundle("", "")
    contract = (
        contract_bundle.get("description_contract", {})
        if isinstance(contract_bundle.get("description_contract"), dict)
        else contract_bundle.get("contract", {})
    )
    required = contract.get("fixed_structure_emojis", ["🔥", "🧩", "😱", "🔓", "✨", "🎯", "👇", "💖", "🔔", "💬", "⚠️"])
    missing = [emoji for emoji in required if emoji not in desc]
    if missing:
        issues.append("说明缺少固定结构: " + "".join(missing))
    for mandatory_hashtag in mandatory_description_hashtags(contract):
        if not description_hashtag_present(desc, mandatory_hashtag):
            issues.append(f"说明缺少 {mandatory_hashtag}")
    if contract.get("hashtag_markdown_escape_forbidden"):
        hashtag_tokens = [token.rstrip(".,;:!?，。！？、؛؛)]}》】〉”’\"'") for token in re.findall(r"#[^\s#]+", desc)]
        if any("\\" in token for token in hashtag_tokens):
            issues.append("说明 hashtag 含 Markdown 反斜杠转义")
    if contract.get("forbid_markdown_links", True) and re.search(r"\[[^\]]+\]\(https?://[^)]+\)", desc):
        issues.append("说明含 Markdown 链接")
    if not re.search(r"^👇.+[:：]\s*$", desc, flags=re.M):
        issues.append("主播放列表模块不是独立标题行")
    if "👉" not in desc:
        issues.append("主播放列表缺少 👉")
    if re.search(r"^📌.+[:：]\s*$", desc, flags=re.M) and not re.search(r"(?m)^\s*1[.)।]?\s+", desc):
        issues.append("更多播放列表缺少编号")
    body_without_marker = description_body_without_final_marker(desc)
    non_hashtag_body = "\n".join(
        line for line in body_without_marker.splitlines()
        if not line.strip().startswith("#")
    )
    if contains_chinese(non_hashtag_body):
        issues.append("说明正文含中文字符")
    if re.search(r"(?mi)^\s*\d+[.)।]?\s*playlist\b", body_without_marker) or re.search(r"(?mi)^(?!https?://)\s*playlist(?:\s+terkait)?\b", body_without_marker):
        issues.append("说明含未翻译的 Playlist 占位词")
    if not re.search(r"https?://", desc):
        issues.append("说明缺少播放列表链接")
    if re.search(r"==.+?==", desc):
        issues.append("说明含内部审核标记")
    disclaimer_tail = desc.split("⚠️", 1)[-1] if "⚠️" in desc else ""
    lower_tail = disclaimer_tail.lower()
    authorization_terms = [
        "authorized",
        "officially authorized",
        "professional dubb",
        "professionally dubbed",
        "resmi",
        "yetki",
        "yetkili",
        "yetkil",
        "izin",
        "awtorisado",
        "lisensi",
        "অনুমোদিত",
        "অফিসিয়াল",
        "অফিসিয়াল",
        "পেশাদার",
        "ডাবিং",
        "অনুবাদ",
        "अनुमोदित",
        "अधिकृत",
        "आधिकारिक",
        "पेशेवर",
        "डबिंग",
        "अनुवादित",
        "lisans",
        "autoryz",
        "awtor",
    ]
    copy_terms = [
        "copy",
        "reupload",
        "upload ulang",
        "mengunggah ulang",
        "muling pag-upload",
        "salin",
        "কপি",
        "कॉपी",
        "री-अपलोड",
        "बिना अनुमति",
        "पुन",
        "kopya",
        "ponow",
        "kopiowanie",
    ]
    fiction_terms = [
        "fiction",
        "fictional",
        "fiksi",
        "kathang-isip",
        "কাল্পনিক",
        "কল্পনানির্ভর",
        "নাট্যরূপে",
        "বিনোদনের জন্য",
        "काल्पनिक",
        "kurgu",
        "kurmaca",
        "fikcyj",
        "hiburan",
        "entertainment",
        "eğlence",
        "libangan",
    ]
    if not any(term in lower_tail or term in disclaimer_tail for term in authorization_terms):
        issues.append("免责声明缺少授权/专业配音说明")
    if not any(term in lower_tail or term in disclaimer_tail for term in copy_terms):
        issues.append("免责声明缺少禁止复制/搬运/重传说明")
    if not any(term in lower_tail or term in disclaimer_tail for term in fiction_terms):
        issues.append("免责声明缺少虚构娱乐说明")
    return issues


def normalize_single_links(text: str, contract: dict | None = None) -> str:
    contract = contract if isinstance(contract, dict) else load_community_rule_bundle()
    if not contract.get("normalize_markdown_links_before_validation", True):
        return text
    text = re.sub(
        r"\[(https://youtu\.be/[A-Za-z0-9_-]+)\]\(https://www\.youtube\.com/watch\?v=[A-Za-z0-9_-]+\)",
        r"\1",
        text,
    )
    text = re.sub(
        r"\[(https://youtu\.be/[A-Za-z0-9_-]+)\]\(https://youtu\.be/[A-Za-z0-9_-]+\)",
        r"\1",
        text,
    )
    text = re.sub(
        r"\[[^\]]*?(https://youtu\.be/[A-Za-z0-9_-]+)[^\]]*?\]\(https?://[^)]+\)",
        r"\1",
        text,
    )
    text = re.sub(
        r"\[([^\]]+)\]\((https?://[^)]+)\)",
        r"\2",
        text,
    )
    return text


def normalize_community_copy(text: str, contract: dict | None = None) -> str:
    text = normalize_single_links(text, contract).strip()
    if not text:
        return text
    lines = text.splitlines()
    if len(lines) >= 2 and not lines[1].strip():
        lines = [lines[0]] + [line for line in lines[1:] if line.strip()]
    question_index = None
    for idx, raw in enumerate(lines):
        line = raw.strip()
        if idx == 0 or not line:
            continue
        if "🤔" in line:
            question_index = idx
            break
        if "?" in line or "？" in line:
            question_index = idx
            break
    if question_index is not None and "🤔" not in lines[question_index]:
        lines[question_index] = f"🤔 {lines[question_index].lstrip()}"
    for idx, raw in enumerate(lines):
        line = raw.strip()
        if not line:
            continue
        if "🔔" not in line and re.search(r"(?i)\b(subscribe|mag-subscribe|subskryb|abone|langganan)\b", line):
            lines[idx] = f"{line} 🔔" if not line.endswith("🔔") else line
        if "🙏" not in line and re.search(r"(?i)\b(share|i-share|udost|bahagi)\b", line):
            lines[idx] = f"{line} 🙏" if not line.endswith("🙏") else line
    return "\n".join(lines).strip()


def community_copy_issues(copy: str, contract: dict | None = None) -> list[str]:
    contract = contract if isinstance(contract, dict) else load_community_rule_bundle()
    text = normalize_community_copy(copy, contract)
    issues = []
    if not text:
        return ["社群文案为空"]
    if contract.get("forbid_markdown_links", True) and re.search(r"\[[^\]]+\]\(https?://[^)]+\)", text):
        issues.append("社群文案含 Markdown 双链接")
    urls = re.findall(r"https://youtu\.be/[A-Za-z0-9_-]+", text)
    if contract.get("require_single_short_url", True) and len(urls) != 1:
        issues.append(f"社群文案短链数量不是1: {len(urls)}")
    non_empty = [line.strip() for line in text.splitlines() if line.strip()]
    min_non_empty_lines = int(contract.get("min_non_empty_lines", 8) or 8)
    if len(non_empty) < min_non_empty_lines:
        issues.append(f"社群文案少于{min_non_empty_lines}行，疑似短格式")
    if contains_chinese(text):
        issues.append("社群文案含中文字符")
    first = non_empty[0] if non_empty else ""
    if "🔥" not in first or "👉" not in first or not re.search(r"https://youtu\.be/[A-Za-z0-9_-]+", first):
        issues.append("社群文案首行不是固定单短链格式")
    if len(text.splitlines()) >= 2 and not text.splitlines()[1].strip():
        issues.append("社群文案首行后有空行")
    for emoji in contract.get("fixed_emojis", ["🔥", "👉", "🤔", "👇", "🔔", "🙏"]):
        if emoji not in text:
            issues.append(f"社群文案缺少固定emoji {emoji}")
    if "🔔" not in non_empty[-2:] and "🔔" not in (non_empty[-2] if len(non_empty) >= 2 else ""):
        issues.append("社群文案末尾缺少订阅引导")
    if "🙏" not in (non_empty[-1] if non_empty else ""):
        issues.append("社群文案末尾缺少分享引导")
    return issues


def place_data(package: Path) -> tuple[str, str]:
    data = load_json(package / "place_result.json", {})
    if not data:
        data = load_json(package / "07_播放列表建议.json", {})
    result = first_result(data)
    return str(result.get("description") or "").strip(), str(result.get("playlist") or "").strip()


def place_translation_text(package: Path) -> str:
    data = load_json(package / "place_result.json", {})
    if not data:
        data = load_json(package / "07_播放列表建议.json", {})
    return str(first_result(data).get("translation") or "").strip()


def audit_rows(
    rows: list[list[str]],
    index: dict,
    completed_only: bool,
    machine_contracts: dict | None = None,
) -> list[dict]:
    issues = []
    header = rows[0] if rows else []
    columns = {name: idx for idx, name in enumerate(header)}
    title_idx = columns.get("标题")
    desc_idx = columns.get("说明")
    cover4_idx = columns.get("封面4：5")
    cover16_idx = columns.get("封面16：9")
    community_idx = columns.get("社群文案")
    need_community_idx = columns.get("是否需要社区")
    video_idx = columns.get("剧id")
    exported_items = [item for item in index.get("items", []) if should_export_item(item, completed_only)]
    for row, item in zip(rows[1:], exported_items):
        video_id = row[video_idx] if video_idx is not None and video_idx < len(row) else ""
        drama_name = row[columns["剧名"]] if "剧名" in columns and columns["剧名"] < len(row) else ""
        package = Path(item.get("package_path", ""))
        row_issues = []
        if title_idx is not None and title_idx < len(row):
            row_issues.extend(title_issues_from_cell(row[title_idx], (machine_contracts or {}).get("xy-title")))
        if package.exists():
            row_issues.extend(title_package_issues(package, (machine_contracts or {}).get("xy-title")))
        if desc_idx is not None and desc_idx < len(row):
            desc = row[desc_idx]
            row_issues.extend(description_format_issues(desc, (machine_contracts or {}).get("xy-place")))
        if cover4_idx is not None and cover4_idx < len(row) and not str(row[cover4_idx]).strip():
            row_issues.append("封面4：5为空")
        if cover16_idx is not None and cover16_idx < len(row) and not str(row[cover16_idx]).strip():
            row_issues.append("封面16：9为空")
        if package.exists():
            row_issues.extend(cover_package_issues(package, (machine_contracts or {}).get("xy-cover")))
        need_community = row[need_community_idx] if need_community_idx is not None and need_community_idx < len(row) else ""
        if str(need_community).strip() in {"1", "true", "True"} and community_idx is not None and community_idx < len(row):
            row_issues.extend(community_copy_issues(row[community_idx], (machine_contracts or {}).get("xy-post")))
        if row_issues:
            issues.append({"video_id": video_id, "drama_name": drama_name, "issues": row_issues, "row": row})
    return issues


def filter_exportable_rows(rows: list[list[str]], issues: list[dict]) -> list[list[str]]:
    bad_ids = {issue["video_id"] for issue in issues if issue.get("video_id")}
    if not bad_ids:
        return rows
    header = rows[0]
    columns = {name: idx for idx, name in enumerate(header)}
    video_idx = columns.get("剧id")
    kept = [header]
    for row in rows[1:]:
        video_id = row[video_idx] if video_idx is not None and video_idx < len(row) else ""
        if video_id not in bad_ids:
            kept.append(row)
    return kept


def cleanup_legacy_export_artifacts(batch_dir: Path) -> None:
    patterns = (
        "每日输出表_待写回_*.tsv",
        "每日输出问题报告_*.json",
        "每日输出问题报告_*.md",
    )
    for pattern in patterns:
        for path in batch_dir.glob(pattern):
            if path.is_file():
                path.unlink()


def write_issue_report(index_path: Path, issues: list[dict], rows: list[list[str]], export_rows: list[list[str]]) -> tuple[Path, Path]:
    json_path = index_path.parent / "每日输出问题报告.json"
    md_path = index_path.parent / "每日输出问题报告.md"
    payload = {
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "index_path": str(index_path),
        "total_rows": max(len(rows) - 1, 0),
        "exported_rows": max(len(export_rows) - 1, 0),
        "advisory_rows": len(issues),
        "blocked_rows": 0,
        "problem_video_ids": [issue.get("video_id", "") for issue in issues if issue.get("video_id")],
        "issues": [
            {
                "video_id": issue.get("video_id", ""),
                "drama_name": issue.get("drama_name", ""),
                "issues": issue.get("issues", []),
            }
            for issue in issues
        ],
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# 每日输出问题报告",
        "",
        f"总行数：{payload['total_rows']}",
        f"已写入可用行：{payload['exported_rows']}",
        f"已写入但建议检查行：{payload['advisory_rows']}",
        "",
    ]
    if not issues:
        lines.append("无问题行。")
    else:
        for issue in issues:
            lines.extend(
                [
                    f"## {issue.get('video_id', '')} {issue.get('drama_name', '')}",
                    "",
                    "问题：",
                    *[f"- {text}" for text in issue.get("issues", [])],
                    "",
                    "处理建议：该行已回写；如需提升质量，只重跑该剧目的对应步骤，不要重跑整批。",
                    "",
                ]
            )
    md_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return md_path, json_path


def clear_issue_report(index_path: Path) -> None:
    for name in ("每日输出问题报告.json", "每日输出问题报告.md"):
        path = index_path.parent / name
        if path.exists():
            path.unlink()


def community_results(package: Path) -> list[dict]:
    data = load_json(package / "06_社群方案.json", {})
    results = data.get("results") if isinstance(data, dict) else []
    return [row for row in results if isinstance(row, dict)] if isinstance(results, list) else []


def community_data(package: Path, plan_index: int = 1) -> str:
    rows = community_results(package)
    result = rows[plan_index - 1] if 0 < plan_index <= len(rows) else {}
    return normalize_community_copy(result.get("copy", ""))


def community_image_prompt(package: Path, plan_index: int = 1) -> str:
    rows = community_results(package)
    result = rows[plan_index - 1] if 0 < plan_index <= len(rows) else {}
    return str(result.get("image_prompt_1x1") or "")


def normalize_match(value) -> str:
    if isinstance(value, list):
        return "".join(normalize_match(part) for part in value)
    if isinstance(value, dict):
        for key in ("link", "text"):
            if value.get(key):
                return normalize_match(value[key])
        return ""
    return re.sub(r"\s+", "", "" if value is None else str(value)).strip()


def read_output_table(token: str, spreadsheet_token: str, sheet_id: str, max_rows: int = 500) -> list[list[str]]:
    return read_row(token, spreadsheet_token, sheet_id, f"{sheet_id}!A1:AZ{max_rows}")


def output_header_is_empty(header: list[str]) -> bool:
    return not any(normalize_header(header))


def ensure_output_base_headers(
    token: str, spreadsheet_token: str, sheet_id: str, header: list[str]
) -> tuple[list[str], bool]:
    """Initialize an empty production output sheet before attempting row matching."""
    current = normalize_header(header)
    if not output_header_is_empty(current):
        required = HEADERS[:8]
        missing = [name for name in required if name not in current]
        if missing:
            raise RuntimeError("任务表缺少基础列: " + ", ".join(missing))
        return current, False
    put_values(
        token,
        spreadsheet_token,
        f"{sheet_id}!A1:{col_name(len(HEADERS))}1",
        [HEADERS],
    )
    readback = read_row(
        token,
        spreadsheet_token,
        sheet_id,
        f"{sheet_id}!A1:{col_name(len(HEADERS))}1",
    )
    actual = normalize_header(readback[0] if readback else [])
    if canonical_header(actual[: len(HEADERS)]) != canonical_header(HEADERS):
        raise RuntimeError("任务表标准表头初始化后回读不一致")
    return actual, True


def plan_v2_community_headers(header: list[str], required: list[str]) -> tuple[list[str], list[tuple[int, str]]]:
    """Plan narrow header writes without treating trailing empty grid cells as columns."""
    planned = normalize_header(header)
    while planned and not planned[-1]:
        planned.pop()
    writes: list[tuple[int, str]] = []
    legacy = {"社群文案": "社群文案1", "社群图描述": "社群图描述1"}
    for old, new in legacy.items():
        if old in planned and new in required and new not in planned:
            index = planned.index(old)
            planned[index] = new
            writes.append((index, new))
    for name in required:
        if name not in planned:
            index = len(planned)
            planned.append(name)
            writes.append((index, name))
    return planned, writes


def ensure_v2_community_headers(
    token: str, spreadsheet_token: str, sheet_id: str, header: list[str], required: list[str]
) -> list[str]:
    planned, writes = plan_v2_community_headers(header, required)
    for index, value in writes:
        column = col_name(index + 1)
        put_values(token, spreadsheet_token, f"{sheet_id}!{column}1:{column}1", [[value]])
    rows = read_output_table(token, spreadsheet_token, sheet_id)
    actual = normalize_header(rows[0] if rows else [])
    missing = [name for name in required if name not in actual]
    if missing:
        raise RuntimeError("动态社群列创建后读回失败: " + ", ".join(missing))
    return actual


def stage_output_values(package: Path, stage: str, item: dict | None = None) -> tuple[list[str], list[str]]:
    """Return output headers and values for exactly one completed stage."""
    if stage == "xy-title":
        return ["标题", "标题翻译"], [title_text(package), title_translation_text(package)]
    if stage == "xy-cover":
        return ["封面4：5", "封面16：9"], [
            cover_prompt_text(package, "prompt_4x5"),
            cover_prompt_text(package, "prompt_16x9"),
        ]
    if stage == "xy-place":
        description, playlist = place_data(package)
        return ["说明", "说明翻译", "播放列表"], [
            description,
            place_translation_text(package),
            playlist,
        ]
    if stage == "xy-post":
        if item and int(item.get("community_output_version") or 2) >= 2:
            count = int(item.get("community_count", 1 if item.get("need_community") else 0) or 0)
            headers, values = [], []
            for plan_index in range(1, count + 1):
                headers.extend([f"社群文案{plan_index}", f"社群图描述{plan_index}"])
                values.extend([community_data(package, plan_index), community_image_prompt(package, plan_index)])
            return headers, values
        return ["社群文案", "社群图描述"], [community_data(package), community_image_prompt(package)]
    return [], []


def match_task_row(rows: list[list[str]], item: dict) -> tuple[int, dict] | None:
    if not rows:
        raise RuntimeError("任务表为空")
    header = normalize_header(rows[0])
    columns = {name: idx for idx, name in enumerate(header)}
    required = ["剧名", "频道", "档期"]
    missing = [name for name in required if name not in columns]
    if missing:
        raise RuntimeError("任务表缺少匹配列: " + ", ".join(missing))
    drama = normalize_match(item.get("drama_name", ""))
    channel = normalize_match(item.get("channel", ""))
    slot_values = {
        normalize_match(item.get("slot_label", "")),
        normalize_match(item.get("slot", "")),
    }
    slot_values.discard("")
    matches = []
    for row_number, row in enumerate(rows[1:], start=2):
        if not row:
            continue
        get = lambda name: row[columns[name]] if columns[name] < len(row) else ""
        if normalize_match(get("剧名")) != drama or normalize_match(get("频道")) != channel:
            continue
        if normalize_match(get("档期")) in slot_values:
            matches.append((row_number, columns))
    if len(matches) == 0:
        return None
    if len(matches) != 1:
        raise RuntimeError(
            f"无法唯一匹配任务表行: 剧名={item.get('drama_name','')}, 频道={item.get('channel','')}, "
            f"档期={item.get('slot_label') or item.get('slot','')}, 匹配数={len(matches)}"
        )
    return matches[0]


def expected_base_row(item: dict) -> list:
    date_value = str(item.get("slot", ""))[:8]
    if len(date_value) == 8 and date_value.isdigit():
        date_value = f"{date_value[:4]}-{date_value[4:6]}-{date_value[6:8]}"
    return [
        date_value,
        item.get("channel", ""),
        item.get("nickname", ""),
        item.get("drama_name", ""),
        item.get("video_id", ""),
        item.get("url", ""),
        item.get("slot", ""),
        str(item.get("community_count", item.get("need_community", ""))),
    ]


def base_row_differences(row: list, columns: dict[str, int], item: dict) -> list[str]:
    expected = expected_base_row(item)
    differences = []
    for header, expected_value in zip(HEADERS[:8], expected):
        index = columns.get(header, -1)
        actual = row[index] if 0 <= index < len(row) else ""
        if normalize_match(actual) != normalize_match(expected_value):
            differences.append(header)
    return differences


def write_and_verify_base_row(
    token: str, spreadsheet_token: str, sheet_id: str, row_number: int, base: list
) -> None:
    range_name = f"{sheet_id}!A{row_number}:H{row_number}"
    put_values(token, spreadsheet_token, range_name, [base])
    readback = read_row(token, spreadsheet_token, sheet_id, range_name)
    actual = readback[0][: len(base)] if readback else []
    if [normalize_match(value) for value in actual] != [normalize_match(value) for value in base]:
        raise RuntimeError(f"飞书基础字段写后回读不一致: row={row_number}")


def ensure_matched_base_row(
    token: str,
    spreadsheet_token: str,
    sheet_id: str,
    rows: list[list[str]],
    row_number: int,
    columns: dict[str, int],
    item: dict,
) -> bool:
    row = rows[row_number - 1] if row_number - 1 < len(rows) else []
    differences = base_row_differences(row, columns, item)
    if not differences:
        return False
    if "剧id" in differences:
        video_index = columns.get("剧id", -1)
        existing_video_id = row[video_index] if 0 <= video_index < len(row) else ""
        if normalize_match(existing_video_id):
            raise RuntimeError(
                f"飞书已有行剧id冲突，禁止覆盖: row={row_number}, existing={existing_video_id}, expected={item.get('video_id','')}"
            )
    write_and_verify_base_row(
        token, spreadsheet_token, sheet_id, row_number, expected_base_row(item)
    )
    return True


def append_output_base_row(
    token: str,
    spreadsheet_token: str,
    sheet_id: str,
    rows: list[list[str]],
    columns: dict[str, int],
    item: dict,
) -> int:
    """Create the result-sheet base row once, before the first stage write."""
    required = ["日期", "频道", "频道昵称", "剧名", "剧id", "剧目地址", "档期", "是否需要社区"]
    missing = [name for name in required if name not in columns]
    if missing:
        raise RuntimeError("任务表缺少基础列: " + ", ".join(missing))
    row_number = None
    for candidate, row in enumerate(rows[1:], start=2):
        if not any(normalize_match(cell) for cell in row[: len(HEADERS)]):
            row_number = candidate
            break
    if row_number is None:
        row_number = len(rows) + 1
    base = expected_base_row(item)
    # The authoritative output header places these eight fields in A:H.
    write_and_verify_base_row(token, spreadsheet_token, sheet_id, row_number, base)
    return row_number


def ensure_output_base_row(item: dict, config_path: str = "") -> dict:
    """Claim a task by writing only the authoritative A:H base fields once."""
    config = config_path or str(WORKSPACE / "tools" / "feishu_sync" / "feishu_sync_config.json")
    token = get_token(load_config(config))
    spreadsheet_token = get_wiki_sheet_token(token)
    sheet_id = find_output_sheet_id(token, spreadsheet_token)
    rows = read_output_table(token, spreadsheet_token, sheet_id)
    header, initialized = ensure_output_base_headers(
        token, spreadsheet_token, sheet_id, rows[0] if rows else []
    )
    if initialized:
        rows = read_output_table(token, spreadsheet_token, sheet_id)
        header = normalize_header(rows[0] if rows else [])
    columns = {name: idx for idx, name in enumerate(header)}
    matched = match_task_row(rows, item)
    if matched is not None:
        row_number, matched_columns = matched
        updated = ensure_matched_base_row(
            token, spreadsheet_token, sheet_id, rows, row_number, matched_columns, item
        )
        return {
            "updated": updated, "sheet_id": sheet_id, "row_number": row_number,
            "columns": HEADERS[:8], "readback_verified": True,
        }
    row_number = append_output_base_row(token, spreadsheet_token, sheet_id, rows, columns, item)
    return {"updated": True, "sheet_id": sheet_id, "row_number": row_number, "columns": HEADERS[:8]}


def rewrite_output_base_row(
    item: dict, row_number: int, expected_source_drama_name: str, config_path: str = ""
) -> dict:
    """Rewrite one explicitly pinned result row during an identity correction."""
    if row_number < 2:
        raise RuntimeError(f"任务表行号无效: {row_number}")
    config = config_path or str(WORKSPACE / "tools" / "feishu_sync" / "feishu_sync_config.json")
    token = get_token(load_config(config))
    spreadsheet_token = get_wiki_sheet_token(token)
    sheet_id = find_output_sheet_id(token, spreadsheet_token)
    rows = read_output_table(token, spreadsheet_token, sheet_id)
    header = normalize_header(rows[0] if rows else [])
    columns = {name: idx for idx, name in enumerate(header)}
    required = ["剧名", "剧id", "频道", "档期"]
    missing = [name for name in required if name not in columns]
    if missing:
        raise RuntimeError("任务表缺少身份校验列: " + ", ".join(missing))
    if row_number - 1 >= len(rows):
        raise RuntimeError(f"任务表目标行不存在: row={row_number}")
    row = rows[row_number - 1]
    get = lambda name: row[columns[name]] if columns[name] < len(row) else ""
    exact_pairs = {
        "剧id": item.get("video_id", ""),
        "频道": item.get("channel", ""),
        "档期": item.get("slot", ""),
    }
    for field, expected in exact_pairs.items():
        if normalize_match(get(field)) != normalize_match(expected):
            raise RuntimeError(
                f"飞书既有行身份不符，禁止覆盖: row={row_number}, field={field}, "
                f"existing={get(field)}, expected={expected}"
            )
    existing_drama = normalize_match(get("剧名"))
    allowed_drama_names = {
        normalize_match(expected_source_drama_name),
        normalize_match(item.get("drama_name", "")),
    }
    if existing_drama not in allowed_drama_names:
        raise RuntimeError(
            f"飞书既有行剧名不符，禁止覆盖: row={row_number}, existing={get('剧名')}"
        )
    write_and_verify_base_row(
        token, spreadsheet_token, sheet_id, row_number, expected_base_row(item)
    )
    return {
        "updated": True,
        "sheet_id": sheet_id,
        "row_number": row_number,
        "columns": HEADERS[:8],
        "readback_verified": True,
    }


def plan_stage_write_segments(output_headers: list[str], values: list, columns: dict[str, int]) -> list[dict]:
    """Plan narrow writes without spanning unrelated physical sheet columns."""
    segments: list[dict] = []
    for header, value in zip(output_headers, values):
        index = columns[header]
        if segments and index == segments[-1]["end_index"] + 1:
            segments[-1]["end_index"] = index
            segments[-1]["headers"].append(header)
            segments[-1]["values"].append(value)
        else:
            segments.append(
                {
                    "start_index": index,
                    "end_index": index,
                    "headers": [header],
                    "values": [value],
                }
            )
    return segments


def write_stage_back(item: dict, package: Path, stage: str, config_path: str = "") -> dict:
    """Write only the fields produced by one stage to the Feishu output row."""
    output_headers, values = stage_output_values(package, stage, item)
    if not output_headers:
        return {"stage": stage, "updated": False, "reason": "no output columns"}
    config = config_path or str(WORKSPACE / "tools" / "feishu_sync" / "feishu_sync_config.json")
    token = get_token(load_config(config))
    spreadsheet_token = get_wiki_sheet_token(token)
    sheet_id = find_output_sheet_id(token, spreadsheet_token)
    rows = read_output_table(token, spreadsheet_token, sheet_id)
    header, initialized = ensure_output_base_headers(
        token, spreadsheet_token, sheet_id, rows[0] if rows else []
    )
    if initialized:
        rows = read_output_table(token, spreadsheet_token, sheet_id)
        header = normalize_header(rows[0] if rows else [])
    columns = {name: idx for idx, name in enumerate(header)}
    if stage == "xy-post" and int(item.get("community_output_version") or 1) >= 2:
        if any(name not in columns for name in output_headers):
            ensure_v2_community_headers(token, spreadsheet_token, sheet_id, header, output_headers)
            rows = read_output_table(token, spreadsheet_token, sheet_id)
            header = normalize_header(rows[0]) if rows else []
            columns = {name: idx for idx, name in enumerate(header)}
    matched = match_task_row(rows, item)
    if matched is None:
        row_number = append_output_base_row(token, spreadsheet_token, sheet_id, rows, columns, item)
    else:
        row_number, columns = matched
        ensure_matched_base_row(
            token, spreadsheet_token, sheet_id, rows, row_number, columns, item
        )
    missing = [name for name in output_headers if name not in columns]
    if missing:
        raise RuntimeError("任务表缺少阶段回填列: " + ", ".join(missing))
    segments = plan_stage_write_segments(output_headers, values, columns)
    ranges = []
    for segment in segments:
        start = col_name(segment["start_index"] + 1)
        end = col_name(segment["end_index"] + 1)
        range_name = f"{sheet_id}!{start}{row_number}:{end}{row_number}"
        put_values(token, spreadsheet_token, range_name, [segment["values"]])
        readback = read_row(token, spreadsheet_token, sheet_id, range_name)
        actual = readback[0][: len(segment["values"])] if readback else []
        expected = segment["values"]
        if [normalize_match(value) for value in actual] != [normalize_match(value) for value in expected]:
            raise RuntimeError(f"飞书阶段字段写后回读不一致: stage={stage}, range={range_name}")
        ranges.append(range_name)
    return {
        "stage": stage,
        "updated": True,
        "sheet_id": sheet_id,
        "row_number": row_number,
        "columns": output_headers,
        "ranges": ranges,
        "readback_verified": True,
    }


def existing_images(package: Path, kind: str) -> str:
    files = []
    if kind == "cover":
        final_dir = package / "images" / "final"
        if not final_dir.exists():
            return ""
        for path in sorted(final_dir.iterdir()):
            name = path.name
            if not path.is_file():
                continue
            if "16x9" in name or "标题" in name or "title" in name.lower():
                files.append(str(path))
        return "\n".join(files)

    if kind == "community":
        # Community images usually stop at images/raw because xy-logo-v14 only processes 16:9 covers.
        # Prefer final if a later workflow put a file there, otherwise fall back to raw.
        for folder in [package / "images" / "final", package / "images" / "raw"]:
            if not folder.exists():
                continue
            current = []
            for path in sorted(folder.iterdir()):
                name = path.name
                if not path.is_file():
                    continue
                if "社群" in name or "community" in name.lower():
                    current.append(str(path))
            if current:
                return "\n".join(current)
        return ""

    return ""


def should_export_item(item: dict, completed_only: bool) -> bool:
    return normalize_status(str(item.get("status") or "")) in {"PACKAGE_READY", "DELIVERED"}


def ensure_no_stage_errors(stage_errors: list[dict]) -> None:
    """Make any failed stage writeback visible to callers through a non-zero exit."""
    if not stage_errors:
        return
    details = "; ".join(
        f"{row.get('drama_name', '')}/{row.get('stage', '')}: {row.get('error', '')}"
        for row in stage_errors
    )
    raise RuntimeError(f"飞书阶段回写未全部成功: {details}")


def build_rows(index: dict, today: str, completed_only: bool) -> list[list[str]]:
    rows = [HEADERS]
    for item in index.get("items", []):
        if not should_export_item(item, completed_only):
            continue
        package = Path(item.get("package_path", ""))
        description, playlist = place_data(package)
        need_community = str(item.get("need_community", ""))
        rows.append(
            [
                today,
                item.get("channel", ""),
                item.get("nickname", ""),
                item.get("drama_name", ""),
                item.get("video_id", ""),
                item.get("url", ""),
                item.get("slot", ""),
                need_community,
                title_text(package),
                title_translation_text(package),
                cover_prompt_text(package, "prompt_4x5"),
                cover_prompt_text(package, "prompt_16x9"),
                description,
                place_translation_text(package),
                playlist,
                community_data(package) if need_community in {"1", "true", "True"} else "",
                community_image_prompt(package) if need_community in {"1", "true", "True"} else "",
            ]
        )
    return rows


def write_local_fallback(index_path: Path, rows: list[list[str]]) -> Path:
    output_path = index_path.parent / "每日输出表_待写回.tsv"
    text = "\n".join(
        "\t".join(str(cell).replace("\t", " ").replace("\r", " ").replace("\n", "\\n") for cell in row)
        for row in rows
    )
    output_path.write_text(text + "\n", encoding="utf-8")
    return output_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="运营/工作流运营")
    parser.add_argument("--enable-live-writeback", action="store_true")
    parser.add_argument("--index", default="")
    parser.add_argument("--config", default=str(WORKSPACE / "tools" / "feishu_sync" / "feishu_sync_config.json"))
    parser.add_argument("--date", default=datetime.now().strftime("%Y-%m-%d"))
    parser.add_argument("--completed-only", action="store_true", help="Only export rows whose batch item status is done/skipped/dry_run")
    args = parser.parse_args()
    if not args.enable_live_writeback:
        raise SystemExit("V2 live Feishu writeback is disabled; explicit --enable-live-writeback is required")

    root = Path(args.root).expanduser().resolve()
    index_path = current_index(root, args.index)
    index = load_json(index_path, {})
    cleanup_legacy_export_artifacts(index_path.parent)
    token = get_token(load_config(args.config))
    spreadsheet_token = get_wiki_sheet_token(token)
    sheet_id = find_output_sheet_id(token, spreadsheet_token)
    rows = build_rows(index, args.date, args.completed_only)
    machine_contracts = load_batch_machine_contracts(index_path.parent)
    issues = audit_rows(rows, index, args.completed_only, machine_contracts)
    export_rows = filter_exportable_rows(rows, issues)
    local_fallback = write_local_fallback(index_path, export_rows)
    issue_md = issue_json = None
    if issues:
        issue_md, issue_json = write_issue_report(index_path, issues, rows, export_rows)
        if int(load_json(index_path.parent / "生产契约快照.json", {}).get("version") or 0) >= 7:
            raise SystemExit(f"V2严格导出预检失败，已阻止回写：{len(issues)}条；报告：{issue_md}")
    else:
        clear_issue_report(index_path)

    # Stage writeback is the authoritative path.  Never clear/rewrite the
    # whole sheet here: it can contain other batches and manual corrections.
    # Reconcile only fields whose stage files already exist, using the same
    # exact (剧名, 频道, 档期) matcher as the immediate writeback path.
    stage_updates = []
    stage_errors = []
    for item in index.get("items", []):
        if not should_export_item(item, args.completed_only):
            continue
        package = Path(item.get("package_path", ""))
        if not package.exists():
            continue
        for stage, required in (
            ("xy-title", "04_标题方案.json"),
            ("xy-cover", "04_封面提示词.json"),
            ("xy-place", "place_result.json"),
            ("xy-post", "06_社群方案.json"),
        ):
            if stage == "xy-post" and str(item.get("need_community", "")) not in {"1", "true", "True"}:
                continue
            if not (package / required).exists():
                continue
            try:
                stage_updates.append(write_stage_back(item, package, stage, args.config))
            except Exception as exc:
                stage_errors.append({"stage": stage, "drama_name": item.get("drama_name", ""), "error": str(exc)})

    ensure_no_stage_errors(stage_errors)

    print(
        json.dumps(
            {
                "index_path": str(index_path),
                "sheet_id": sheet_id,
                "rows": len(export_rows) - 1,
                "total_rows": len(rows) - 1,
                "skipped_problem_rows": 0,
                "problem_video_ids": [],
                "advisory_issue_rows": len(issues),
                "advisory_video_ids": [issue.get("video_id", "") for issue in issues if issue.get("video_id")],
                "issue_report_md": str(issue_md) if issue_md else "",
                "issue_report_json": str(issue_json) if issue_json else "",
                "local_fallback": str(local_fallback),
                "completed_only": args.completed_only,
                "stage_updates": len(stage_updates),
                "stage_errors": stage_errors,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
