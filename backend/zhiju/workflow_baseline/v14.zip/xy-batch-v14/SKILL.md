---
name: xy-batch-v14
description: Isolated V2 deterministic Xiaoyu batch workflow. Uses a separate runtime root and blocks live Feishu writeback unless explicitly enabled.
---

Feishu account: always use the approved `筱宇` account through `feishu-api-accounts` (`feishu_accounts.py run --account 筱宇 -- ...`) for any script that reads or writes Feishu. Never invoke a legacy local config directly.

# XY Batch

Before execution, read the authoritative production lock:
`运营/工作流实验室/V14/公用/XY生产锁定规范_V14.md`.

V2 is physically isolated from the current `运营/工作流运营` production route. Its default runtime root is
`运营/工作流运营`, and live Feishu writeback is disabled unless the user
explicitly authorizes `--enable-live-writeback`.

## Purpose

Process a task table row by row, create the batch index and per-drama folders, then continue into the `xy-pack` workflow automatically. The user should only intervene when a row fails or needs manual correction.

## Input Table

If the user runs `xy-batch` without pasted table or file input, fetch the fixed Feishu task sheet automatically:

```text
https://unvcmqz7dp.feishu.cn/wiki/MUJ0wBw9yiyeJNkIt0cczSCgn3f?sheet=5EPSHD
sheet: 工单
```

The fetched table is saved as:

```text
运营/工作流运营/_运行记录/飞书拉取/任务清单_飞书拉取_YYYYMMDDHHMM.tsv
```

If the user provides pasted text or `--input`, use that input instead of Feishu.

Supported headers:

```text
剧名, 剧id, 地址, 频道, 档期, 是否需要社区
剧名, 地址, 频道, 档期, 是否需要社区
```

Column meaning:

- `剧名`: Chinese drama name. Use this exact value for package naming and bottom marker `==剧名==`.
- `剧id`: Optional YouTube video ID. If present, use it for tracking and image task IDs. If blank or the whole column is omitted, extract the video ID automatically from `地址`.
- `地址`: YouTube video URL. If both URL and `剧id` are blank in a future V2 batch, the controller creates a stable `pending_...` identity from drama/channel/slot and uses `【视频链接待补】` exactly once in every community copy.
- If `剧id` and `地址` both exist but point to different video IDs, fail that row instead of guessing.
- `频道`: Current channel name or local nickname. V2 reads the current production
  registry and channel rules as read-only source data, but always writes package
  output under the V2 root. Resolve by this priority:
  `1.` `运营/工作流运营/公用/频道注册表.json` exact match `channel_name`
  `2.` `运营/工作流运营/公用/频道注册表.json` exact match `nickname`
  `3.` exact channel folder name
  `4.` parse local nickname from right to left as `频道名-语言-性别-方向`, then use the parsed `频道名`
- `档期`: Beijing publish slot. Use it directly in `剧名_YYYYMMDDHH`.
- `是否需要社区` (new V2 batches): blank or numeric `0` = 0 sets; positive integer `N` = exactly N independent community sets; every other non-empty value = 1 set. Old batches without `community_output_version: 2` retain their legacy boolean behavior.

## Output Paths

Batch folder:

```text
运营/工作流运营/批量任务/YYYYMMDDHH/
```

Current batch pointer:

```text
运营/工作流运营/批量任务/current_batch.json
```

Per-drama package folder:

```text
运营/工作流运营/语言/频道名/剧目/剧名_YYYYMMDDHH/
```

Never write packages directly under the channel root.

## Batch Files

Create:

```text
运营/工作流运营/批量任务/YYYYMMDDHH/今日任务索引.json
运营/工作流运营/批量任务/YYYYMMDDHH/批量执行记录.md
运营/工作流运营/批量任务/YYYYMMDDHH/批量执行记录.json
```

If practical, copy or export the original table into the batch folder as `今日任务表_归档.*`.

Write `current_batch.json`:

```json
{
  "batch_id": "YYYYMMDDHH",
  "index_path": "运营/工作流运营/批量任务/YYYYMMDDHH/今日任务索引.json"
}
```

## Index Shape

`今日任务索引.json` must include all data `xy-sort-v14` needs:

```json
{
  "batch_id": "YYYYMMDDHH",
  "created_at": "YYYY-MM-DD HH:MM:SS +0800",
  "status": "active",
  "items": [
    {
      "row_number": 2,
      "drama_name": "中文剧名",
      "video_id": "youtube_video_id",
      "url": "https://youtube.com/watch?v=...",
      "language": "语言",
      "channel": "频道名",
      "slot": "YYYYMMDDHH",
      "need_community": 1,
      "package_path": "运营/工作流运营/语言/频道名/剧目/剧名_YYYYMMDDHH",
      "prompt_manifest": "运营/工作流运营/语言/频道名/剧目/剧名_YYYYMMDDHH/images/prompts/出图任务清单.json",
      "expected_images": 7,
      "status": "pending|text_ready|image_partial|package_ready|delivered|failed",
      "error": ""
    }
  ]
}
```

`expected_images` is 7 when `是否需要社区` is `1`, otherwise 6.

## Per-Drama Workflow

For each valid row:

1. Resolve channel folder by channel name or local nickname.
2. Create `01_频道数据.md` in the package as a frozen snapshot of the channel inputs. In V14 context-isolation Phase 1, `xy-title` receives only the exact `## [GLOBAL]` and `## [TITLE]` sections extracted by code from the channel generation specification. Missing, duplicate, or out-of-order required section markers are a pre-model `SYSTEM_ERROR`. `xy-cover`, `xy-place`, and `xy-post` retain their prior snapshot input until their separately reviewed migration phases; `xy-find` must not use channel material for plot facts.
   New V2.1 tasks also freeze structured `gender`, `direction`, and
   `workflow_contract_version`. Every creative stage receives the same
   `channel_theme_contract`: the same channel stays semantically consistent,
   different channels choose different packaging angles, and different dramas
   inside one channel still use distinct hooks, scenes, actions, and layouts.
3. Create package folder under `剧目/`.
4. Initialize or resume:

```text
workflow_state.json
剧目元数据.json
images/prompts/出图任务清单.json
images/prompts/出图任务清单.md
images/raw/
images/final/
```

5. Then run the `xy-pack` workflow for that row to fill actual research, title, cover, post, and placement content.
6. Generate image prompt task files under:

```text
images/prompts/
```

Required prompt manifest:

```text
images/prompts/出图任务清单.json
images/prompts/出图任务清单.md
```

Required directories:

```text
images/raw/
images/final/
```

## Script

Prefer the bundled script for batch initialization and indexing:

```text
scripts/init_batch.py --root "运营/工作流运营" --input /path/to/task-table.tsv
scripts/init_batch.py --root "运营/工作流运营" --stdin
scripts/init_batch.py --root "运营/工作流运营"
scripts/init_batch.py --root "运营/工作流运营" --stdin --auto
scripts/init_batch.py --root "运营/工作流运营" --input /path/to/task-table.tsv --new --auto
scripts/init_batch.py --root "运营/工作流运营" --continue-existing --auto
scripts/run_batch.py --root "运营/工作流运营"
```

When the user explicitly requires selected old packages to be deleted and
created again without inheriting historical locks, use the recoverable clean
recreate entry. Never delete package files or edit `workflow_state.json` by
hand:

```text
scripts/run_batch.py --root "运营/工作流运营" --clean-recreate-scope /absolute/path/scope.json --dry-run
scripts/run_batch.py --root "运营/工作流运营" --clean-recreate-scope /absolute/path/scope.json --apply-clean-recreate --prepare-only
```

The scope must pin exact `video_id + output_row_number + source_index` values
and the exact currently accepted target contract ID. Apply moves each complete old
package into the new batch's `已删除旧数据` archive with per-file hashes, then
creates a clean package at the original path. The new package starts at
`xy-find` and must not inherit any old contract ID, attempt counters, retry
cycles, stage outputs, or writeback state. Omit `--prepare-only` only when the
same command is also authorized to begin generation.

If the old package was initialized with the wrong community count, the selected
scope item must additionally pin both `expected_source_community_count` and
`target_community_count`. The clean-recreate entry verifies the old count before
archiving and rebuilds the new package, image-task manifest, metadata, and
workflow state from the target count. The target count is restricted to `1` or
`2`; never edit an index or package JSON by hand.

For a whole batch that failed only while claiming empty Feishu output rows, use
`scripts/prepare_claim_recovery.py` to generate the scope. It verifies every
source item is a claim-only `WRITEBACK_PENDING` failure with no assigned output
row, derives single-update `2` / double-update `1` from the complete production
date, and pins each source row to the same new output row number. Do not handcraft
this scope.

If a prepared-only recovery batch is later found to omit a valid work-order
task, keep it stopped. Initialize the missing task alone as a pristine source
batch, export the corrected complete-date work-order TSV, then use
`scripts/prepare_daily_rebuild_scope.py` with both source indices. The tool must
prove the work-order identities and source-package identities are exactly equal
before generating one new clean-recreate scope. The omitted task may have an
empty URL; its stable `pending_...` video identity is valid.

When the user approves a new three-attempt cycle for an exhausted stage while
accepted upstream stages must be preserved, use the exact controlled-retry
entry instead of copying an index or editing workflow state by hand:

```text
scripts/run_batch.py --root "运营/工作流运营" --controlled-retry-scope /absolute/path/scope.json --dry-run
scripts/run_batch.py --root "运营/工作流运营" --controlled-retry-scope /absolute/path/scope.json --apply-controlled-retry --prepare-only
```

The scope must pin the exact source index SHA-256, `video_id +
output_row_number`, source/target contract ID, real exhausted stage, and current
error list. Apply creates a new exact index without changing the source index,
package, accepted outputs, or Feishu row. The subsequent production command
opens the cycle with `--retry-failed` and resumes from the pinned failed stage;
it must not revisit or rewrite accepted upstream stages.

When the source package itself is an immutable failed test baseline, set the
scope-level `isolated_package_copy` to `true` and pin a new exact
`target_package_path` for every item. This mode currently supports `xy-cover`
retries only. The controller atomically clones the accepted upstream package
into each new path, rewrites only the cloned package identity, and points the
new retry index at the clone. The source package, source index, accepted
find/title artifacts, Feishu row identity, and their hashes remain unchanged.
An existing, nested, or non-isolated target path fails closed; never copy the
package or edit its state by hand.

When a legacy source index omitted `output_row_number`, the scope must also pin
its exact `source_row_number`; the controller may assign the explicit new
`output_row_number` without editing the source index. An empty
`expected_source_contract_id` is accepted only when the scope also declares
`expected_source_status: INITIALIZED` and the source item plus package are
provably pristine: no contract, both item/package status `INITIALIZED`, every
workflow step is the literal string `pending`, and no creative-stage output
files exist. A claim-only infrastructure failure may instead pin
`expected_source_status: WRITEBACK_PENDING`; it is accepted only when no output
row was assigned, `current_stage=claim`, the error is a Feishu base-writeback
failure, the package remains `INITIALIZED`, every step is still `pending`, and
no creative-stage output exists. Any other uncontracted package fails closed.

When the user invokes `xy-batch` normally, run `init_batch.py` with `--auto` unless the user explicitly asks for only initialization/indexing.

Batch continuation rule:

- If the user provides a pasted table, `--input`, or `--stdin`, initialize a new batch by default instead of merging into the unfinished `current_batch.json`.
- If the user explicitly asks to continue the current batch, use `--continue-existing`.
- If `xy-batch` is run without pasted table or file input and `current_batch.json` points to an older batch that still has unfinished items, continue that old batch first.
- Before continuing, compare the latest Feishu task table or provided input against the existing batch index. If new task rows are found, append only the incremental rows into that same old batch.
- If there is no unfinished old batch, create a new batch from the current table.
- Placeholder rows that only contain `频道/档期/是否需要社区` but have no `剧名/剧id/地址` are not valid tasks and must be ignored.

`init_batch.py` does these fixed tasks:

- parse the task table
- fetch `工单` from Feishu when no table input is provided
- resolve `频道` through `频道注册表.json`
- create/resume package folders
- create `今日任务索引.json`
- create/update `current_batch.json`
- create placeholder prompt manifests for later image generation and sorting

With `--auto`, it immediately calls `scripts/run_batch.py`. The runtime is a deterministic controller plus ordinary Python workers. A worker owns one drama, while the AI is called only as a JSON content function:

```text
xy-find -> controller reads exact Feishu drama row -> saves 01_搜索资料.json/md as plot truth -> searches YouTube and saves separately verified 01_市场包装证据.json/md -> supplies only final A/B/C angles to xy-title
xy-title -> AI returns schema-constrained 04_标题方案.json -> controller validates -> renders Markdown -> immediately writes 标题/标题翻译
xy-cover -> AI returns schema-constrained 04_封面提示词.json -> controller validates -> renders Markdown -> immediately writes 封面4：5/封面16：9
xy-place -> AI returns schema-constrained place_result.json -> controller validates -> renders Markdown -> immediately writes 说明/说明翻译/播放列表
xy-post -> AI returns exactly community_count independent results -> controller validates intra-package and cross-channel independence -> renders Markdown -> immediately writes numbered 社群文案N/社群图描述N columns
assemble 运营包.md
repair images/prompts/出图任务清单.*
核心词统计不属于当前生产流程，禁止同步或更新。
```

Completing these text stages is `text_ready`. `xy-sort-v14` is a later file-routing
utility only: it copies or moves filename-matched images into the package and
must not inspect image content, validate assets, or advance package/workflow
state. `xy-logo-v14` only composites the configured channel logo and likewise must
not change package/workflow state.

Future V2 title and cover production is locked to these marketing rules:

- Titles use the channel's real A!B! shell. Each title needs only one short verifiable plot anchor; the rest may be aggressively amplified for click-through.
- A presents the provocative conflict. B escalates the information gap but cannot reveal the true identity, relationship, truth, ending, final winner, reunion, punishment, or inheritance result.
- Same-drama packages across different channels cannot translate, paraphrase, or reuse even one accepted title direction or cover blueprint.
- Covers stage the unresolved title premise as a believable live-action Chinese short-drama still. They do not explain the full plot or expose the ending.
- Female-frequency covers forbid visual effects. Child/cute-child angles require visible safe Chinese children. Every cover forbids beating, threatened hitting, weapons, blood, and wounds.
- Hard validation remains limited to the frozen structural, plot-mapping, identity, safety, core-word, explicit invented-technology/named-geometry, and full-history uniqueness contracts. Natural-location/light guidance, prompt word count, real-drama score, prop density, lighting-description density, and overly designed staging are generation guidance or audit evidence only; they never reject content or trigger a creative retry.

Each content stage has one initial attempt plus two automatic content retries. Only a real, model-correctable `CONTENT_ERROR` consumes those attempts and retries the same stage with exact validation feedback. Schema, field, internal assembly, model-call, network, and Feishu failures are `SYSTEM_ERROR` and never consume creative attempts. Feishu writes are retried independently and never cause content regeneration. A still-failing Feishu write becomes `writeback_pending` and is runnable on the next ordinary continuation without `--retry-failed`; accepted JSON is reused. After three content-validation failures, that drama becomes `needs_user_review`; the worker immediately claims the next queued drama so one bad row cannot reduce batch throughput. Do not fake-complete a row or write fallback package content.

Persist the attempt number before every Feishu drama-library or content-model
call. Process restarts must continue from the remaining attempts in the current
three-attempt cycle and must reuse the last saved validation feedback. Never
reset attempts merely because the controller restarted. A fresh three-attempt
cycle is allowed only through explicit `--retry-failed`; preserve the closed
cycle in `workflow_state.json.steps.<stage>.retry_history` and increment
`retry_cycle`. Set `resume_from_stage` to the real exhausted stage when the
cycle is approved so accepted upstream stages are not revisited. Include the retry cycle in model prompt/result log filenames so
an approved new cycle cannot overwrite the previous cycle's evidence.
For `xy-cover`, every visual-collision error encountered during the current or
an earlier approved cycle is an accumulated forbidden fingerprint. Every later
attempt must receive the complete ordered ledger, because all three cover
groups are regenerated together and a group fixed on one attempt must not
regress while another group is corrected. New history identities must include
the stable package and group key `channel:drama:video_id:groupN`. For legacy
errors without `groupN`, use the diagnostic ordinal only when the row at that
ordinal still matches the encoded package identity; otherwise resolve by the
stable package identity.
When older logs predate the ledger, a controlled-retry scope may freeze an
explicit `retry_feedback_seed`; it must contain the current complete error and
may contain only audited visual-collision errors.
Every seed must be copied into the step's `collision_feedback_history` on the
next state update. If an already completed historical run predates that
persistence behavior, reconcile only the audited evidence through the
hash-pinned `reconcile_retry_feedback_evidence.py` entry; it must make zero
model calls, zero Feishu writes, and must not change accepted content files.

After packages are generated or edited, write the current batch result back to the Feishu output sheet:

```text
https://unvcmqz7dp.feishu.cn/wiki/MUJ0wBw9yiyeJNkIt0cczSCgn3f?sheet=Pii5w9
sheet: 任务
```

The fixed first 17 columns remain unchanged. For future `community_output_version: 2` batches, append numbered pairs to the right without migrating or rewriting old data:

```text
日期 频道 频道昵称 剧名 剧id 剧目地址 档期 是否需要社区 标题 标题翻译 封面4：5 封面16：9 说明 说明翻译 播放列表 社群文案 社群图描述
社群文案1 社群图描述1 社群文案2 社群图描述2 ...
```

`封面` and `社群图` are reserved for final image paths. `封面4：5`, `封面16：9`, and `社群图描述` must be populated from the generated operation package prompt JSON:

- `04_封面提示词.json.results[0].titles[].prompt_4_5`
- `04_封面提示词.json.results[0].titles[].prompt_16_9`
- `06_社群方案.json.results[N-1].image_prompt_1x1` -> `社群图描述N`

Use:

```text
scripts/export_daily_tasks.py --root "运营/工作流运营"
scripts/export_daily_tasks.py --root "运营/工作流运营" --completed-only
```

Both commands are blocked by default in V2. Live writeback requires the user's
explicit authorization and the additional `--enable-live-writeback` flag.

`scripts/run_batch.py` now exports incrementally after each completed row unless `--skip-export` is passed. This means the Feishu output table updates one completed drama at a time instead of waiting for the whole batch to finish. The final end-of-batch export also runs in `--completed-only` mode, so the sheet stays focused on rows that are already usable for image generation.

核心词统计已从当前生产流程移除，不读取、不更新、不回填。

If title/cover/description/community content is regenerated later, run the export script again to refresh the Feishu output table.

Each row has a per-item timeout. Default is 900 seconds:

```text
scripts/run_batch.py --root "运营/工作流运营" --timeout 900
```

Rows already in `needs_user_review` are not restarted without explicit review. After approval, retry with:

```text
scripts/run_batch.py --root "运营/工作流运营" --retry-failed
```

并发执行使用“10 个普通 Python Worker、每个 Worker 每次领取 1 部剧”的模型。Worker 只执行固定状态机；AI 不充当 Worker，不访问飞书、不读写文件、不维护状态。领取任务时先回写 A:H 八个基础字段，之后每个阶段通过严格验证后只回写对应字段组，并保存断点。默认并发为 10：

```text
scripts/run_batch.py --root "运营/工作流运营" --workers 10 --chunk-size 1
```

`--workers` 控制普通执行进程数量；`--chunk-size` 固定为 1。任务索引、文件渲染、状态和飞书回写只由控制器拥有。AI 只接收规范化输入并返回 JSON。300 个频道也必须通过有限 Worker + 队列运行，不得按频道数无限启动进程。

## Deterministic Role Boundary

- Skills define input fields, output schema, content rules and hard validators.
- The controller owns Feishu, files, state, retries, Markdown rendering and writeback.
- Workers only claim one task and execute the fixed state machine.
- AI only produces title/cover-description/description/community content as schema-constrained JSON.
- Markdown is display-only. Never parse Markdown back into JSON.
- Each batch stores `生产契约快照.json`; in-flight tasks keep the frozen Skill hashes and content.

## Cross-Channel Creative Independence

- Objective plot facts may be shared, but every channel × drama package must independently choose titles, cover directions, description framing, playlist framing, and community concepts.
- The controller loads accepted same-drama packages into `creative_history` for all four creative stages. This history is a negative reference only.
- Validation rejects translated, paraphrased, or materially similar same-drama packages before stage writeback.
- Validation and acceptance use one controller-owned lock so parallel workers cannot approve collisions against stale history.
- Cover acceptance compares against the complete accepted V2 visual fingerprint
  history across channels and dramas. The model receives a bounded priority
  sample for speed, while the deterministic validator remains full-history and
  rejects semantic as well as exact blueprint reuse.
- Cover history is a negative reference, not a novelty quota. Future covers
  must select a different plot-supported moment, relationship emphasis, main
  action, and camera blocking; they must never invent gadgets, futuristic
  displays, implausible locations, or arbitrary color schemes merely to evade
  a historical collision.
- Every future `4:5` cover prompt is audited as a real Chinese drama still.
  Word count, real-drama score, prop density, lighting-description density, and
  overly designed staging are evidence only and never cause rejection or a
  creative retry. Hard rejection is limited to explicit invented/futuristic
  visual technology and named AI-poster geometric compositions from the same
  frozen rule source used by generation.
- New V2.1 title output carries one `packaging_brief`. Cover, description, and
  community generation must inherit it. When the verified plot supports the
  channel direction, every module must make that direction prominent; when it
  does not, the model must use the closest truthful angle and must not invent a
  child, marriage, wealthy-family, or revenge fact.
- Every downstream JSON returns the exact `packaging_brief_id`,
  `channel_direction`, and `core_story_promise`; validation rejects drift before
  files or Feishu are written. Theme support uses specific positive plot
  evidence, not generic parent/truth words or negated phrases, and every title,
  cover group, and community plan is checked separately.
- Fixed channel CTA text is exempt from creative-similarity rejection. The
  community first-line full-video CTA and the community-image subscribe/share
  CTA are resolved once from the batch-frozen community contract plus any
  explicit channel override, then copied exactly by generation and validation.
- New batches freeze model rules, machine rules, and output schemas together in
  `生产契约快照.json`; generation and validation read the same frozen schema.

If the batch was already initialized and the user says continue/run current batch, run:

```text
scripts/run_batch.py --root "运营/工作流运营"
```

This reads `运营/工作流运营/批量任务/current_batch.json`.

## Image Task IDs

Use task IDs based on `剧id`:

```text
<剧id>_01_title1_4x5
<剧id>_02_title1_16x9
<剧id>_03_title2_4x5
<剧id>_04_title2_16x9
<剧id>_05_title3_4x5
<剧id>_06_title3_16x9
<剧id>_07_community1_1x1
<剧id>_08_community2_1x1
...
```

Create exactly `community_count` community image tasks; omit all of them when the count is zero.

Every prompt text file should start with:

```text
Task ID: <task_id>
Channel: <channel>
Drama: <drama_name>
Slot: <slot>
Target file: <target_filename>
```

## Failure Handling

- Do not stop the entire batch because one row fails.
- Mark failed rows in `今日任务索引.json` and `批量执行记录`.
- Continue with the next row.
- If a package already exists, read `workflow_state.json` and resume/skip completed steps unless the user requests redo.
- If `codex exec` times out, exits non-zero, or leaves the row in `running/failed`, `scripts/run_batch.py` must re-check the package folder. When the required step files, structured JSON, and `运营包.md` are already complete, automatically recover that row to `done` instead of keeping a false failure.
- At the end of text generation, items become `text_ready`; `done` is retained
  only as a legacy readable status. Later `xy-sort-v14` and `xy-logo-v14` file operations
  do not change that production state.
- After automatic execution, write `批量自动执行报告.md` and per-row logs in `自动执行日志/`.
