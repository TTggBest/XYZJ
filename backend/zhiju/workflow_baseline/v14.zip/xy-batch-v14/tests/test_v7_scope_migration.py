import copy
import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
SCRIPT = SCRIPTS / "migrate_v7_scope.py"
SPEC = importlib.util.spec_from_file_location("v7_scope_clean_recreate_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


with tempfile.TemporaryDirectory() as contract_preview_dir:
    TARGET_CONTRACT_ID = MODULE.ContractBundle(Path(contract_preview_dir)).contract_id


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class V7ScopeCleanRecreateTests(unittest.TestCase):
    def make_source(
        self, root, *, video_id="video-a", output_row=17,
        source_row=2, pristine_initialized=False, omit_output_row=False,
    ):
        channel_dir = root / "channel-source" / "频道A"
        channel_dir.mkdir(parents=True)
        (channel_dir / "频道A_生成规范.md").write_text("# channel rules\n", encoding="utf-8")
        (channel_dir / "community_footer_cta.json").write_text("{}\n", encoding="utf-8")
        package = root / "西班牙" / "频道A" / "剧目" / "测试剧_2026081800"
        package.mkdir(parents=True)
        (package / "04_标题方案.json").write_text('{"old":true}\n', encoding="utf-8")
        (package / "04_封面提示词.json").write_text('{"old":true}\n', encoding="utf-8")
        (package / "运营包.md").write_text("old package", encoding="utf-8")
        (package / "workflow_events.jsonl").write_text('{"event":"old"}\n', encoding="utf-8")
        if pristine_initialized:
            for name in ("04_标题方案.json", "04_封面提示词.json", "运营包.md"):
                (package / name).unlink()
            (package / "workflow_events.jsonl").unlink()
        if pristine_initialized:
            state = {
                "drama_name": "测试剧", "video_id": video_id, "channel": "频道A",
                "language": "西班牙", "slot": "2026081800", "status": "INITIALIZED",
                "package_status": "INITIALIZED",
                "steps": {
                    "xy-find": "pending", "xy-title": "pending", "xy-cover": "pending",
                    "xy-place": "pending", "xy-post": "pending",
                },
            }
        else:
            state = {
                "drama_name": "测试剧", "video_id": video_id, "channel": "频道A",
                "language": "西班牙", "slot": "2026081800", "status": "TEXT_READY",
                "contract_id": "xy-v2-old-contract", "contract_version": 10,
                "steps": {"xy-find": {"status": "done", "attempts": 3, "retry_cycle": 4}},
            }
        (package / "workflow_state.json").write_text(
            json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        item = {
            "row_number": source_row, "video_id": video_id,
            "drama_name": "测试剧", "channel": "频道A", "channel_input": "频道A",
            "nickname": "频道A昵称", "language": "西班牙", "gender": "女频",
            "direction": "复仇逆袭", "channel_dir": str(channel_dir),
            "slot": "2026081800", "slot_label": "2026081800",
            "url": f"https://youtu.be/{video_id}", "package_path": str(package),
            "status": "INITIALIZED" if pristine_initialized else "TEXT_READY",
            "need_community": 1, "community_count": 1,
            "community_output_version": 2, "writeback_readback_stages": ["xy-find"],
            "creative_slot": {"creative_slot_id": "slot-test"},
        }
        if not omit_output_row:
            item["output_row_number"] = output_row
        other_package = root / "西班牙" / "频道A" / "剧目" / "其他剧_2026081802"
        other_package.mkdir(parents=True)
        (other_package / "keep.txt").write_text("unchanged", encoding="utf-8")
        other = copy.deepcopy(item)
        other.update({
            "video_id": "not-selected", "output_row_number": 18,
            "package_path": str(other_package), "drama_name": "其他剧",
        })
        index_path = root / "批量任务" / "source" / "今日任务索引.json"
        index_path.parent.mkdir(parents=True)
        index_path.write_text(
            json.dumps({"batch_id": "source", "items": [item, other]}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        scope = {
            "scope_version": 1, "mode": "clean_recreate",
            "batch_id": "V7-CLEAN-RECREATE-TEST",
            "target_contract_id": TARGET_CONTRACT_ID,
            "expected_item_count": 1, "expected_video_ids": [video_id],
            "items": [{
                "source_index": str(index_path.relative_to(root)),
                "output_row_number": output_row, "video_id": video_id,
                "expected_source_contract_id": "xy-v2-old-contract",
                "reason": "explicit test clean recreate",
            }],
        }
        scope_path = root / "scope.json"
        scope_path.write_text(json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return package, other_package, index_path, scope_path

    def test_pristine_uncontracted_source_can_pin_source_row_and_new_output_row(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, other, index_path, scope_path = self.make_source(
                root, output_row=28, source_row=13,
                pristine_initialized=True, omit_output_row=True,
            )
            scope = json.loads(scope_path.read_text())
            scope["items"][0].update({
                "source_row_number": 13,
                "expected_source_contract_id": "",
                "expected_source_status": "INITIALIZED",
            })
            scope_path.write_text(
                json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
            before = (digest(index_path), digest(package / "workflow_state.json"), digest(other / "keep.txt"))

            dry_run = MODULE.create_migration_batch(root, scope_path, apply=False)
            self.assertEqual(dry_run["items"][0]["output_row_number"], 28)
            self.assertEqual(dry_run["items"][0]["source_row_number"], 13)

            result = MODULE.create_migration_batch(root, scope_path, apply=True)
            item = json.loads(Path(result["index_path"]).read_text())["items"][0]
            self.assertEqual(item["output_row_number"], 28)
            self.assertEqual(item["status"], "INITIALIZED")
            self.assertEqual(digest(index_path), before[0])
            self.assertEqual(digest(other / "keep.txt"), before[2])
            self.assertNotEqual(digest(package / "workflow_state.json"), before[1])

    def test_clean_recreate_can_correct_pinned_community_count(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, _, index_path, scope_path = self.make_source(
                root, output_row=28, source_row=13,
                pristine_initialized=True, omit_output_row=True,
            )
            scope = json.loads(scope_path.read_text())
            scope["items"][0].update({
                "source_row_number": 13,
                "expected_source_contract_id": "",
                "expected_source_status": "INITIALIZED",
                "expected_source_community_count": 1,
                "target_community_count": 2,
            })
            scope_path.write_text(
                json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )

            result = MODULE.create_migration_batch(root, scope_path, apply=True)
            item = json.loads(Path(result["index_path"]).read_text())["items"][0]
            self.assertEqual(item["community_count"], 2)
            self.assertEqual(item["expected_images"], 8)
            state = json.loads((package / "workflow_state.json").read_text())
            self.assertEqual(state["community_count"], 2)
            archived = Path(result["archive_root"]) / "row28_video-a" / "归档记录.json"
            record = json.loads(archived.read_text())
            self.assertEqual(record["source_community_count"], 1)
            self.assertEqual(record["target_community_count"], 2)

    def test_community_count_change_requires_source_count_pin(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            _, _, _, scope_path = self.make_source(
                root, output_row=28, source_row=13,
                pristine_initialized=True, omit_output_row=True,
            )
            scope = json.loads(scope_path.read_text())
            scope["items"][0].update({
                "source_row_number": 13,
                "expected_source_contract_id": "",
                "expected_source_status": "INITIALIZED",
                "target_community_count": 2,
            })
            scope_path.write_text(json.dumps(scope, ensure_ascii=False), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "expected_source_community_count"):
                MODULE.create_migration_batch(root, scope_path, apply=False)

    def test_claim_only_writeback_failure_can_be_clean_recreated(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, _, index_path, scope_path = self.make_source(
                root, output_row=28, source_row=13,
                pristine_initialized=True, omit_output_row=True,
            )
            index = json.loads(index_path.read_text())
            item = index["items"][0]
            item.update({
                "status": "WRITEBACK_PENDING",
                "current_stage": "claim",
                "error": "领取任务失败: Feishu基础字段回写失败: 任务表为空",
            })
            index_path.write_text(
                json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
            scope = json.loads(scope_path.read_text())
            scope["items"][0].update({
                "source_row_number": 13,
                "expected_source_contract_id": "",
                "expected_source_status": "WRITEBACK_PENDING",
                "expected_source_community_count": 1,
                "target_community_count": 2,
            })
            scope_path.write_text(
                json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )

            dry_run = MODULE.create_migration_batch(root, scope_path, apply=False)
            self.assertEqual(dry_run["items"][0]["source_status"], "WRITEBACK_PENDING")
            result = MODULE.create_migration_batch(root, scope_path, apply=True)
            fresh = json.loads(Path(result["index_path"]).read_text())["items"][0]
            self.assertEqual(fresh["status"], "INITIALIZED")
            self.assertEqual(fresh["community_count"], 2)

    def test_uncontracted_source_is_rejected_unless_it_is_pristine_initialized(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, _, _, scope_path = self.make_source(
                root, output_row=28, source_row=13,
                pristine_initialized=True, omit_output_row=True,
            )
            state_path = package / "workflow_state.json"
            state = json.loads(state_path.read_text())
            state["steps"]["xy-find"] = {"status": "done", "attempts": 1}
            state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            scope = json.loads(scope_path.read_text())
            scope["items"][0].update({
                "source_row_number": 13,
                "expected_source_contract_id": "",
                "expected_source_status": "INITIALIZED",
            })
            scope_path.write_text(json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "无契约源包不是全新 INITIALIZED"):
                MODULE.create_migration_batch(root, scope_path, apply=False)

    def test_dry_run_is_read_only_and_exact(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, other, index_path, scope_path = self.make_source(root)
            before = (digest(index_path), digest(package / "workflow_state.json"), digest(other / "keep.txt"))

            result = MODULE.create_migration_batch(root, scope_path, apply=False)

            self.assertTrue(result["dry_run"])
            self.assertEqual(result["mode"], "clean_recreate")
            self.assertEqual(result["items"][0]["fresh_start_stage"], "xy-find")
            self.assertEqual(before, (digest(index_path), digest(package / "workflow_state.json"), digest(other / "keep.txt")))
            self.assertFalse(Path(result["batch_dir"]).exists())

    def test_apply_archives_complete_old_package_and_creates_fresh_state(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, other, index_path, scope_path = self.make_source(root)
            old_state_hash = digest(package / "workflow_state.json")
            other_hash = digest(other / "keep.txt")
            index_hash = digest(index_path)

            result = MODULE.create_migration_batch(root, scope_path, apply=True)

            index = json.loads(Path(result["index_path"]).read_text())
            self.assertEqual(len(index["items"]), 1)
            item = index["items"][0]
            self.assertEqual(item["status"], "INITIALIZED")
            self.assertEqual(item["writeback_readback_stages"], [])
            self.assertNotIn("contract_id", item)
            state = json.loads((package / "workflow_state.json").read_text())
            self.assertNotIn("contract_id", state)
            self.assertEqual(set(state["steps"].values()), {"pending"})
            self.assertFalse((package / "04_标题方案.json").exists())
            self.assertFalse((package / "04_封面提示词.json").exists())
            archive = Path(result["archive_root"]) / "row17_video-a" / "package"
            self.assertEqual(digest(archive / "workflow_state.json"), old_state_hash)
            self.assertTrue((archive / "04_标题方案.json").is_file())
            self.assertEqual(digest(index_path), index_hash)
            self.assertEqual(digest(other / "keep.txt"), other_hash)
            snapshot = json.loads((Path(result["batch_dir"]) / "生产契约快照.json").read_text())
            self.assertEqual(snapshot["contract_id"], TARGET_CONTRACT_ID)

    def test_clean_recreate_can_correct_drama_identity_and_keep_output_row(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            old_package, _, index_path, scope_path = self.make_source(root)
            old_state_hash = digest(old_package / "workflow_state.json")
            old_index_hash = digest(index_path)
            scope = json.loads(scope_path.read_text())
            scope["items"][0].update({
                "expected_source_drama_name": "测试剧",
                "target_drama_name": "测试剧（权威完整名）",
            })
            scope_path.write_text(
                json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )

            result = MODULE.create_migration_batch(root, scope_path, apply=True)

            item = json.loads(Path(result["index_path"]).read_text())["items"][0]
            new_package = (old_package.parent / "测试剧（权威完整名）_2026081800").resolve()
            self.assertEqual(item["output_row_number"], 17)
            self.assertEqual(item["drama_name"], "测试剧（权威完整名）")
            self.assertEqual(Path(item["package_path"]), new_package)
            self.assertFalse(old_package.exists())
            self.assertTrue((new_package / "workflow_state.json").is_file())
            state = json.loads((new_package / "workflow_state.json").read_text())
            self.assertEqual(state["drama_name"], "测试剧（权威完整名）")
            archive = Path(result["archive_root"]) / "row17_video-a" / "package"
            self.assertEqual(digest(archive / "workflow_state.json"), old_state_hash)
            self.assertEqual(digest(index_path), old_index_hash)

    def test_drama_identity_correction_rejects_wrong_source_name_pin(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            old_package, _, _, scope_path = self.make_source(root)
            before = digest(old_package / "workflow_state.json")
            scope = json.loads(scope_path.read_text())
            scope["items"][0].update({
                "expected_source_drama_name": "错误旧名",
                "target_drama_name": "测试剧（权威完整名）",
            })
            scope_path.write_text(
                json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )

            with self.assertRaisesRegex(ValueError, "源剧名不符"):
                MODULE.create_migration_batch(root, scope_path, apply=False)
            self.assertEqual(digest(old_package / "workflow_state.json"), before)

    def test_clean_recreate_can_move_a_misclaimed_source_back_to_intended_output_row(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            _, _, _, scope_path = self.make_source(root, output_row=287)
            scope = json.loads(scope_path.read_text())
            scope["items"][0].update({
                "source_output_row_number": 287,
                "output_row_number": 97,
            })
            scope_path.write_text(
                json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )

            result = MODULE.create_migration_batch(root, scope_path, apply=True)

            item = json.loads(Path(result["index_path"]).read_text())["items"][0]
            self.assertEqual(item["output_row_number"], 97)
            record = json.loads(
                (Path(result["archive_root"]) / "row97_video-a" / "归档记录.json").read_text()
            )
            self.assertEqual(record["source_output_row_number"], 287)
            self.assertEqual(record["output_row_number"], 97)

    def test_wrong_output_row_fails_without_mutation(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, _, index_path, scope_path = self.make_source(root)
            before = (digest(index_path), digest(package / "workflow_state.json"))
            scope = json.loads(scope_path.read_text())
            scope["items"][0]["output_row_number"] = 999
            scope_path.write_text(json.dumps(scope, ensure_ascii=False), encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "无法按剧id\\+任务表行唯一定位"):
                MODULE.create_migration_batch(root, scope_path, apply=True)
            self.assertEqual(before, (digest(index_path), digest(package / "workflow_state.json")))
            self.assertFalse((root / "批量任务" / scope["batch_id"]).exists())


if __name__ == "__main__":
    unittest.main()
