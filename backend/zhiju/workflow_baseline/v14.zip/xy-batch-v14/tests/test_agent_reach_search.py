import json
import subprocess
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import market_packaging as market


class AgentReachSearchTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(hasattr(market, 'collect_agent_reach_evidence'), 'Find尚未接入Agent-Reach搜索')

    def test_real_metadata_reaches_prompt_without_becoming_plot_truth(self):
        row = {'id': 'abcdefghijk', 'title': '婚礼换新郎', 'channel': '短剧频道',
               'view_count': 123456, 'upload_date': '20260901', 'description': '公开视频简介'}
        response = subprocess.CompletedProcess([], 0, json.dumps(row), '')
        with patch('subprocess.run', return_value=response):
            evidence = market.collect_agent_reach_evidence({'drama_name': '测试短剧'})
        self.assertEqual(evidence['videos'][0]['views'], 123456)
        self.assertEqual(evidence['videos'][0]['published_at'], '2026-09-01')
        prompt = market.build_market_packaging_prompt({}, {'fact': '剧库原文'}, 'rules', evidence)
        self.assertIn('123456', prompt)
        self.assertIn('剧库原文', prompt)
        self.assertIn('agent_reach_search', prompt)

    def test_missing_dates_and_views_are_not_invented(self):
        row = {'id': 'abcdefghijk', 'title': '搜索结果'}
        response = subprocess.CompletedProcess([], 0, json.dumps(row), '')
        with patch('subprocess.run', return_value=response):
            evidence = market.collect_agent_reach_evidence({'drama_name': '测试短剧'})
        self.assertIsNone(evidence['videos'][0]['views'])
        self.assertIsNone(evidence['videos'][0]['published_at'])

    def test_search_timeout_returns_failure_for_existing_fallback(self):
        with patch('subprocess.run', side_effect=subprocess.TimeoutExpired('yt-dlp', 30)):
            evidence = market.collect_agent_reach_evidence({'drama_name': '测试短剧'})
        self.assertEqual(evidence['status'], 'failed')
        self.assertEqual(evidence['videos'], [])


if __name__ == '__main__':
    unittest.main()
