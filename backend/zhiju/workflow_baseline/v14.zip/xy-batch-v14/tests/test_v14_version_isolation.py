import importlib.util
import json
import sys
from pathlib import Path


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
WORKSPACE = Path("/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube")
SCRIPT = SKILLS / "xy-batch-v14/scripts/deterministic_batch.py"
sys.path.insert(0, str(SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("v14_deterministic_isolation", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def test_v14_controller_uses_only_v14_prompt_and_machine_assets():
    all_paths = list(MODULE.SIMULATED_SKILLS.values()) + list(MODULE.MACHINE_RULE_PATHS.values())
    all_paths.append(MODULE.CHANNEL_HASHTAG_WHITELISTS_PATH)
    assert all(path.exists() for path in all_paths)
    assert all("-v14" in str(path) for path in all_paths)
    assert all("-v2" not in str(path) for path in all_paths)
    assert all("运营/模拟工作流" not in str(path) for path in all_paths)


def test_v14_and_v2_compatibility_paths_resolve_to_one_data_root():
    shared = WORKSPACE / "运营/工作流运营"
    v2 = WORKSPACE / "运营/工作流实验室/V2"
    for name in ("批量任务", "_运行记录", "俄语", "印地", "阿拉伯语"):
        assert (v2 / name).is_symlink()
        assert (v2 / name).resolve() == (shared / name).resolve()


def test_new_v14_contract_has_distinct_version_prefix(tmp_path):
    bundle = MODULE.ContractBundle(tmp_path, persist_if_missing=False)
    assert bundle.contract_id.startswith("xy-v14-")
    assert not bundle.contract_id.startswith("xy-v2-")


def test_version_router_keeps_code_separate_and_data_shared():
    router_path = WORKSPACE / "运营/工作流实验室/XY版本路由.json"
    router = json.loads(router_path.read_text(encoding="utf-8"))
    shared = (WORKSPACE / "运营/工作流运营").resolve()

    assert Path(router["data_policy"]["data_root"]).resolve() == shared
    assert router["data_policy"]["mode"] == "single_shared_physical_root"

    v2 = router["versions"]["V2"]
    v14 = router["versions"]["V14"]
    assert v2["selector_skill"] == "xy-workflow-v2"
    assert v14["selector_skill"] == "xy-workflow-v14"
    assert v2["contract_prefix"] == "xy-v2"
    assert v14["contract_prefix"] == "xy-v14"
    assert set(v2["skill_chain"]).isdisjoint(v14["skill_chain"])
    assert all((SKILLS / name / "SKILL.md").is_file() for name in v2["skill_chain"])
    assert all((SKILLS / name / "SKILL.md").is_file() for name in v14["skill_chain"])


def test_v14_authoritative_docs_freeze_exact_channel_hashtag_whitelist_contract():
    lock_path = WORKSPACE / "运营/工作流实验室/V14/公用/XY生产锁定规范_V14.md"
    version_path = WORKSPACE / "运营/工作流实验室/V14/公用/XY流程版本_V14.json"
    lock_text = lock_path.read_text(encoding="utf-8")
    version_text = version_path.read_text(encoding="utf-8")
    version = json.loads(version_text)
    contract = version["verification"]["hashtag_contract"]

    assert "channel_hashtag_whitelist.additional_candidates" in lock_text
    assert "固定输出12个标签" in lock_text
    assert "频道名是唯一白名单路由键" in lock_text
    assert "hashtag_pool_evidence" not in lock_text
    assert "hashtag_pool_evidence" not in version_text
    assert contract["channel_count"] == 30
    assert contract["output_hashtag_count"] == 12
    assert contract["additional_hashtag_count"] == 11
    assert contract["channel_routing_key"] == "exact_formal_channel_name_only"
    assert Path(contract["whitelist_source"]) == MODULE.CHANNEL_HASHTAG_WHITELISTS_PATH


def test_v14_authoritative_docs_require_every_registered_playlist_in_description():
    lock_path = WORKSPACE / "运营/工作流实验室/V14/公用/XY生产锁定规范_V14.md"
    version_path = WORKSPACE / "运营/工作流实验室/V14/公用/XY流程版本_V14.json"
    lock_text = lock_path.read_text(encoding="utf-8")
    version = json.loads(version_path.read_text(encoding="utf-8"))
    contract = version["verification"]["description_playlist_contract"]

    assert "说明必须完整列出当前频道登记的全部播放列表" in lock_text
    assert contract["primary_fields"] == ["playlist", "url"]
    assert contract["public_description_scope"] == "all_registered_channel_playlists"
    assert contract["missing_playlist_policy"] == "content_error_retry_xy_place_before_writeback"
