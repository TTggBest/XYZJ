import importlib.util
import sys
import unittest
from pathlib import Path


MODULE_PATH = (
    Path(__file__).resolve().parents[2]
    / "xy-pack-v14"
    / "scripts"
    / "canonical_outputs.py"
)
SPEC = importlib.util.spec_from_file_location("cover_core_word_uniqueness_contract", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class CoverCoreWordUniquenessTests(unittest.TestCase):
    def test_rejects_real_row17_duplicate_core_words_after_normalization(self):
        rows = []
        cores = ["Gemelos adorables", "Familia reunida", "  FAMILIA   REUNIDA  "]
        for index, core in enumerate(cores, 1):
            rows.append(
                {
                    "title_index": index,
                    "title": f"title {index}",
                    "title_translation": f"translation {index}",
                    "core_words": core,
                    "core_words_translation": f"核心词 {index}",
                    "story_hook": f"distinct story hook {index}",
                    "scene_family": f"scene family {index}",
                    "scene": f"scene {index}",
                    "main_action": f"main action {index}",
                    "key_prop": f"prop {index}",
                    "composition": f"composition {index}",
                    "palette": f"palette {index}",
                    "lighting": f"lighting {index}",
                    "prompt_4_5": (
                        "Chinese actors, Chinese facial features, East Asian appearance. "
                        f"Render {core} as non-diegetic cover typography that is visually prominent, highly legible."
                    ),
                    "prompt_16_9": (
                        "Extend the approved center. Chinese actors, Chinese facial features, East Asian appearance. "
                        f"Preserve {core} and preserve the non-diegetic cover typography exactly."
                    ),
                }
            )
        payload = {"results": [{"titles": rows}]}
        context = {
            "title_payload": {"results": [{"directions": [
                {"title": f"title {index}", "translation": f"translation {index}"}
                for index in range(1, 4)
            ]}]},
            "cover_rule_contract": {
                "prompt_audit": {"core_words_unique_across_three_groups": True}
            },
        }

        issues = MODULE.validate_cover(payload, {}, context)

        self.assertIn("cover_current_drama_core_words_not_distinct", issues)


if __name__ == "__main__":
    unittest.main()
