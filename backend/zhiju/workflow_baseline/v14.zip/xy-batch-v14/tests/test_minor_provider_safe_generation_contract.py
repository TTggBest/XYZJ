import importlib.util
import json
import sys
import unittest
from pathlib import Path

from channel_context_fixture import structured_channel_snapshot


SKILLS_ROOT = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
SCRIPTS = SKILLS_ROOT / "xy-batch-v14" / "scripts"
sys.path.insert(0, str(SCRIPTS))

SPEC = importlib.util.spec_from_file_location(
    "minor_provider_safe_generation_batch", SCRIPTS / "deterministic_batch.py"
)
BATCH = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = BATCH
SPEC.loader.exec_module(BATCH)


class MinorProviderSafeGenerationContractTests(unittest.TestCase):
    def test_title_generation_keeps_clickbait_but_separates_child_visual_staging(self):
        prompt = BATCH.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "萌宝测试剧", "language": "印地", "workflow_contract_version": 2},
                "channel_theme_contract": {"channel_direction": "萌宝家庭", "plot_supported": True},
                "channel_snapshot": structured_channel_snapshot(),
            },
            [],
        )

        self.assertIn("Keep the public A+B title explosive", prompt)
        self.assertIn("visual_thesis, child_role, and safe_cover_scene", prompt)
        self.assertIn("must not make a minor the visible target", prompt)
        self.assertIn("Move the visible wrongdoing, confrontation, or consequence onto adults", prompt)

    def test_cover_generation_reframes_minor_scene_before_image_prompt(self):
        rows = [
            {
                "index": index,
                "title": f"标题{index}",
                "translation": f"翻译{index}",
                "visual_thesis": f"第{index}组成人权力反转，孩子受到保护",
                "child_angle": True,
                "child_role": "safe protected family anchor",
                "safe_cover_scene": "The child stays calm beside the mother while adults carry the reversal.",
            }
            for index in range(1, 4)
        ]
        prompt = BATCH.build_prompt(
            "xy-cover",
            "cover rules",
            {
                "task": {"drama_name": "萌宝测试剧", "language": "印地", "workflow_contract_version": 2},
                "cover_rule_contract": BATCH.load_cover_rule_bundle(),
                "title_payload": {"results": [{"titles": rows}]},
            },
            [],
        )

        self.assertIn("When a required minor is visible", prompt)
        self.assertIn("do not combine that minor in the same image prompt", prompt)
        self.assertIn("hidden surveillance", prompt)
        self.assertIn("bedroom or bedside intimacy", prompt)
        self.assertIn("police restraint, escort, or control", prompt)
        self.assertIn("Do not remove a required child", prompt)

    def test_place_generation_separates_child_facts_from_adult_wrongdoing(self):
        prompt = BATCH.build_prompt(
            "xy-place",
            "place rules",
            {
                "task": {"drama_name": "萌宝测试剧", "language": "印地", "workflow_contract_version": 2},
                "title_payload": {"results": [{"packaging_brief": {}}]},
            },
            [],
        )

        self.assertIn("keep adult wrongdoing and child-safe facts in separate sentences", prompt)
        self.assertIn("Do not describe a minor as the direct target", prompt)
        self.assertIn("Keep the child as a protected relationship, identity, reunion, or family anchor", prompt)

    def test_frozen_rule_sources_carry_generation_reframing_without_new_validator_gate(self):
        title_rules = json.loads((SKILLS_ROOT / "xy-title-v14/rules/title_rules.json").read_text())
        cover_rules = json.loads((SKILLS_ROOT / "xy-cover-v14/rules/cover_rules.json").read_text())
        place_rules = json.loads((SKILLS_ROOT / "xy-place-v14/rules/description_rules.json").read_text())

        self.assertIn("child_visual_reframing", title_rules["title_contract"])
        self.assertIn("minor_provider_safe_staging", cover_rules["prompt_audit"]["generation_plan"])
        self.assertIn("minor_sensitive_language_reframing", place_rules["description_contract"])
        self.assertNotIn("provider_moderation_pattern", cover_rules["prompt_audit"])


if __name__ == "__main__":
    unittest.main()
