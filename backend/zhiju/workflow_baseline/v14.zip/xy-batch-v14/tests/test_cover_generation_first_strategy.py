import importlib.util
import sys
import unittest
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
PACK_SCRIPT = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts" / "canonical_outputs.py"
sys.path.insert(0, str(SCRIPTS))

BATCH_SPEC = importlib.util.spec_from_file_location("cover_generation_first_batch", SCRIPTS / "deterministic_batch.py")
BATCH = importlib.util.module_from_spec(BATCH_SPEC)
sys.modules[BATCH_SPEC.name] = BATCH
BATCH_SPEC.loader.exec_module(BATCH)

PACK_SPEC = importlib.util.spec_from_file_location("cover_generation_first_pack", PACK_SCRIPT)
PACK = importlib.util.module_from_spec(PACK_SPEC)
sys.modules[PACK_SPEC.name] = PACK
PACK_SPEC.loader.exec_module(PACK)


class CoverGenerationFirstStrategyTests(unittest.TestCase):
    def _prompt(self, previous_issues=None):
        return BATCH.build_prompt(
            "xy-cover",
            "cover rules",
            {
                "task": {"drama_name": "测试剧", "language": "印地", "workflow_contract_version": 2},
                "cover_rule_contract": BATCH.load_cover_rule_bundle(),
                "title_payload": {"results": [{"titles": [
                    {
                        "index": index,
                        "title": f"标题{index}",
                        "translation": f"翻译{index}",
                        "visual_thesis": f"第{index}组独有权力翻转",
                        "child_angle": False,
                        "child_role": "",
                        "safe_cover_scene": "",
                    }
                    for index in range(1, 4)
                ]}]},
            },
            previous_issues or [],
        )

    def test_cover_prompt_commits_to_fresh_free_scene_and_action_before_prompt_text(self):
        prompt = self._prompt()

        self.assertIn("Before writing any scene_prompt_4_5, commit in this order", prompt)
        self.assertIn("scene_family, scene, and main_action are fresh free creative text", prompt)
        self.assertIn("Do not choose a scene, action, composition, prop, or reaction from any reusable candidate list", prompt)
        self.assertIn("fixed creative answers are forbidden", prompt)
        self.assertNotIn("interior, corridor, reception, table-side", prompt)
        self.assertNotIn("public exposure, physical interception, discovery, separation", prompt)

    def test_new_creative_slots_are_identity_only_not_fixed_hook_or_layout_answers(self):
        index = {"items": [
            {"drama_name": "同剧", "channel": f"频道{n}", "language": "印地", "direction": "复仇逆袭", "slot": "主档", "workflow_contract_version": 2}
            for n in range(1, 4)
        ]}

        BATCH.allocate_creative_slots(index)

        slots = [item.get("creative_slot", {}) for item in index["items"]]
        self.assertEqual(len({slot["creative_slot_id"] for slot in slots}), 3)
        self.assertTrue(all("title_hook_preference" not in slot for slot in slots))
        self.assertTrue(all("thumbnail_layout_preference" not in slot for slot in slots))
        self.assertTrue(all(slot["creative_answer_policy"] == "fresh_model_creation_no_candidate_library" for slot in slots))

    def test_cover_schema_requires_generation_plan_before_scene_prompt(self):
        schema = BATCH.schema_for("xy-cover", {"workflow_contract_version": 2})
        row = schema["properties"]["results"]["items"]["properties"]["titles"]["items"]
        required = set(row["required"])

        for field in (
            "visual_payoff",
            "required_characters",
            "visible_adult_count",
            "visible_child_count",
            "removed_optional_characters",
            "scene_choice_reason",
            "action_choice_reason",
            "prop_role",
            "camera_angle",
            "core_words_category",
            "core_words_selection_reason",
        ):
            self.assertIn(field, required)
        self.assertEqual(
            row["properties"]["camera_angle"]["enum"],
            ["eye-level", "slightly low-angle", "slightly high-angle", "over-the-shoulder", "three-quarter view"],
        )

    def test_generation_prompt_sets_cast_before_scene_and_keeps_non_child_groups_to_two_to_four(self):
        prompt = self._prompt()

        self.assertIn("For a group with no required child, plan 2 to 4 visible adults and no extra people", prompt)
        self.assertIn("Keep every required child and remove optional adults first", prompt)
        self.assertIn("The final scene may contain only required_characters", prompt)
        self.assertIn("no background crowd, assistants, guards, shareholders, relatives, or readable extra faces", prompt)

    def test_generation_prompt_visualizes_power_shift_instead_of_title_nouns_as_props(self):
        prompt = self._prompt()

        self.assertIn("visual_payoff must state the strongest emotional power shift, relationship reversal, or visible consequence", prompt)
        self.assertIn("Do not convert title nouns directly into props", prompt)
        self.assertIn("key_prop is optional supporting evidence, never the sole visual B explosion", prompt)

    def test_generation_prompt_prefers_specific_core_words_without_a_word_library(self):
        prompt = self._prompt()

        self.assertIn("specific relationship > shocking identity > concrete number > concrete consequence > abnormal action > abstract theme", prompt)
        self.assertIn("Use abstract_theme only when no concise package-specific phrase is available", prompt)
        self.assertIn("Never select core words from a reusable multilingual candidate library", prompt)

    def test_generation_prompt_removes_ai_art_direction_before_scene_prompt(self):
        prompt = self._prompt()

        self.assertIn("If a location detail does not improve story comprehension, emotional intensity, or visual realism, omit it during generation", prompt)
        self.assertIn("Do not invent decorative architecture, luxury dressing, lighting spectacle, or art-direction detail merely to sound professional", prompt)

    def test_cross_video_generation_allows_partial_visual_grammar_reuse_without_copying_a_template(self):
        prompt = BATCH.build_prompt(
            "xy-cover",
            BATCH.SIMULATED_SKILLS["xy-cover"].read_text(encoding="utf-8"),
            {
                "task": {"drama_name": "测试剧", "language": "印地", "workflow_contract_version": 2},
                "cover_rule_contract": BATCH.load_cover_rule_bundle(),
                "title_payload": {"results": [{"titles": [
                    {
                        "index": index,
                        "title": f"标题{index}",
                        "translation": f"翻译{index}",
                        "visual_thesis": f"第{index}组独有权力翻转",
                        "child_angle": False,
                        "child_role": "",
                        "safe_cover_scene": "",
                    }
                    for index in range(1, 4)
                ]}]},
                "visual_history": [{
                    "scene_family": "豪宅客厅",
                    "main_action": "女主公开解除婚约",
                    "key_prop": "戒指",
                    "composition": "三人半身女左男右",
                    "palette": "自然暖色",
                    "lighting": "窗边日光",
                }],
                "creative_history": [],
            },
            [],
        )

        self.assertIn("Partial reuse of channel-level visual grammar is allowed across videos", prompt)
        self.assertIn("A single similar visual dimension is not narrative duplication", prompt)
        self.assertIn("Do not reproduce the whole visual combination as a template", prompt)
        self.assertIn("character relationship, primary action or reversal, key event or evidence prop, and core cover words", prompt)
        self.assertNotIn("Do not reuse a historical `scene_family + main_action` pair", prompt)
        self.assertNotIn("do not match 4 or more of the 6 visual-fingerprint dimensions", prompt)
        self.assertNotIn("Same drama and same topic do not permit similar covers", prompt)
        self.assertNotIn("max_historical_matching_dimensions", prompt)
        self.assertNotIn("actual_image_similarity_threshold", prompt)

    def test_new_cover_plan_rejects_more_than_four_adults_but_legacy_contract_does_not_drift(self):
        plan_issues = getattr(PACK, "cover_generation_plan_issues", lambda *args, **kwargs: [])
        issues = plan_issues(
            {
                "visual_payoff": "The heroine takes visible control while her former husband loses status.",
                "required_characters": ["heroine", "former husband", "sister", "chairman", "assistant"],
                "visible_adult_count": 5,
                "visible_child_count": 0,
                "removed_optional_characters": "none",
                "scene_choice_reason": "The location makes the power transfer immediately readable.",
                "action_choice_reason": "The action shows the relationship reversal without relying on a document.",
                "prop_role": "none",
                "camera_angle": "eye-level",
                "core_words_category": "concrete_consequence",
                "core_words_selection_reason": "The phrase names the visible loss.",
            },
            1,
            child_required=False,
            cover_rule_contract={"prompt_audit": {"generation_plan": {"required": True, "non_child_visible_adult_hard_max": 4}}},
        )
        legacy = plan_issues(
            {"visible_adult_count": 5},
            1,
            child_required=False,
            cover_rule_contract={"prompt_audit": {}},
        )

        self.assertIn("cover_1_non_child_visible_adult_count_over_4", issues)
        self.assertEqual(legacy, [])

    def test_required_children_are_kept_while_optional_adults_are_removed_first(self):
        plan_issues = getattr(PACK, "cover_generation_plan_issues", lambda *args, **kwargs: [])
        issues = plan_issues(
            {
                "visual_payoff": "Three children visibly back their mother during the adult reversal.",
                "required_characters": ["mother", "three children", "father"],
                "visible_adult_count": 2,
                "visible_child_count": 3,
                "removed_optional_characters": "grandparents, assistant, and unrelated relatives",
                "scene_choice_reason": "The fresh title-specific place keeps every required child readable.",
                "action_choice_reason": "The mother carries the adult conflict while the children stay safe.",
                "prop_role": "none",
                "camera_angle": "three-quarter view",
                "core_words_category": "specific_relationship",
                "core_words_selection_reason": "The phrase states the title-specific family relationship.",
            },
            1,
            child_required=True,
            cover_rule_contract={"prompt_audit": {"generation_plan": {"required": True, "non_child_visible_adult_hard_max": 4}}},
        )

        self.assertNotIn("cover_1_non_child_visible_adult_count_over_4", issues)
        self.assertNotIn("cover_1_required_child_count_missing", issues)

    def test_generation_prompt_requires_one_continuous_moment_and_one_physical_location(self):
        prompt = self._prompt()

        self.assertIn("Each 4:5 group must show exactly one continuous moment in one physical location", prompt)
        self.assertIn("Choose only one strongest visible instant from the A+B title", prompt)
        self.assertIn("Do not combine before/after, accusation/consequence, present/later, or cause/result in one image", prompt)
        self.assertIn("No split screen, stacked scenes, collage, diptych, multi-panel, temporal montage, or adjacent second moment", prompt)
        self.assertIn("Use one coherent lighting environment for that single location", prompt)

    def test_cover_schema_requires_structured_single_moment_commitment(self):
        schema = BATCH.schema_for("xy-cover", {"workflow_contract_version": 2})
        row = schema["properties"]["results"]["items"]["properties"]["titles"]["items"]

        self.assertIn("single_continuous_moment", row["required"])
        self.assertIn("single_physical_location", row["required"])
        self.assertIn("temporal_montage", row["required"])
        self.assertEqual(row["properties"]["single_continuous_moment"]["type"], "boolean")
        self.assertEqual(row["properties"]["single_physical_location"]["type"], "boolean")
        self.assertEqual(row["properties"]["temporal_montage"]["type"], "boolean")

    def test_new_contract_rejects_jt_m5rljbwa_dual_time_blueprint_but_legacy_does_not_drift(self):
        issues_for = getattr(PACK, "cover_single_moment_issues", lambda *args, **kwargs: [])
        row = {
            "single_continuous_moment": False,
            "single_physical_location": False,
            "temporal_montage": True,
            "visual_thesis": "The accusation appears beside the later donation reversal.",
            "scene": "A press hearing and another later hospital moment are shown together.",
            "main_action": "She points at her mother while her later self holds a donation file.",
            "composition": "An asymmetrical two-moment composition with the hearing above and hospital below.",
            "lighting": "Press lights above and hospital window light below.",
            "scene_prompt_4_5": "In a press hearing, while an adjacent later moment shows her in a hospital.",
        }
        contract = {
            "prompt_audit": {
                "single_moment_scene": {
                    "required": True,
                    "forbidden_explicit_patterns": [
                        "adjacent later moment",
                        "two-moment",
                        "hearing above and hospital below",
                    ],
                }
            }
        }

        issues = issues_for(row, 3, contract)
        legacy = issues_for(row, 3, {"prompt_audit": {}})

        self.assertIn("cover_3_single_continuous_moment_required", issues)
        self.assertIn("cover_3_single_physical_location_required", issues)
        self.assertIn("cover_3_temporal_montage_forbidden", issues)
        self.assertIn("cover_3_explicit_multi_moment_staging_forbidden", issues)
        self.assertEqual(legacy, [])


if __name__ == "__main__":
    unittest.main()
