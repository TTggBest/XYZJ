import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
SCRIPT = SCRIPTS / "prepare_controlled_retry.py"
SPEC = importlib.util.spec_from_file_location("controlled_retry_scope_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ControlledRetryScopeTests(unittest.TestCase):
    def make_source(self, root: Path):
        package = root / "印地" / "频道A" / "剧目" / "测试剧_2026081812"
        package.mkdir(parents=True)
        source_batch = root / "批量任务" / "source"
        source_batch.mkdir(parents=True)
        contracts = MODULE.ContractBundle(source_batch)
        contract_id = contracts.contract_id
        state = {
            "contract_id": contract_id,
            "steps": {
                "xy-find": {"status": "done", "attempts": 1, "contract_sha256": contracts.sha("xy-find")},
                "xy-title": {"status": "done", "attempts": 2, "contract_sha256": contracts.sha("xy-title")},
                "xy-cover": {
                    "status": "retrying", "attempts": 3, "attempts_total": 3,
                    "retry_cycle": 1,
                    "contract_sha256": contracts.sha("xy-cover"),
                    "errors": ["cover_1_visual_collision_with_history_6_fields_main_action_composition_palette_source_history-id"],
                },
                "xy-place": "pending", "xy-post": "pending",
            },
        }
        state_path = package / "workflow_state.json"
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (package / "04_标题方案.json").write_text('{"preserve":true}\n', encoding="utf-8")
        item = {
            "row_number": 2, "output_row_number": 2, "video_id": "video-a",
            "drama_name": "测试剧", "package_path": str(package),
            "status": "NEEDS_USER_REVIEW", "current_stage": "xy-cover",
            "contract_id": contract_id, "community_output_version": 2,
            "writeback_readback_stages": ["xy-title"],
        }
        untouched = dict(item)
        untouched.update({"output_row_number": 3, "video_id": "video-b", "status": "TEXT_READY"})
        index_path = source_batch / "今日任务索引.json"
        index_path.write_text(
            json.dumps({"batch_id": "source", "items": [item, untouched]}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        scope = {
            "scope_version": 1,
            "mode": "controlled_retry",
            "batch_id": "V7-CONTROLLED-RETRY-TEST",
            "target_contract_id": contract_id,
            "expected_item_count": 1,
            "expected_video_ids": ["video-a"],
            "items": [{
                "source_index": str(index_path.relative_to(root)),
                "expected_source_index_sha256": digest(index_path),
                "output_row_number": 2,
                "video_id": "video-a",
                "expected_source_contract_id": contract_id,
                "retry_stage": "xy-cover",
                "expected_errors": state["steps"]["xy-cover"]["errors"],
                "retry_feedback_seed": [
                    state["steps"]["xy-cover"]["errors"][0],
                    "cover_2_visual_collision_with_history_8_fields_composition_source_transient-id",
                ],
                "reason": "retry exact collision with actionable history feedback",
            }],
        }
        scope_path = root / "scope.json"
        scope_path.write_text(json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return package, state_path, index_path, scope_path, contract_id

    def test_dry_run_is_read_only_and_exact(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, state_path, index_path, scope_path, _ = self.make_source(root)
            before = (digest(state_path), digest(index_path), digest(package / "04_标题方案.json"))

            result = MODULE.create_controlled_retry_batch(root, scope_path, apply=False)

            self.assertTrue(result["dry_run"])
            self.assertEqual(result["item_count"], 1)
            self.assertEqual(result["items"][0]["retry_stage"], "xy-cover")
            self.assertEqual(result["items"][0]["preserved_upstream"], ["xy-find", "xy-title"])
            self.assertIn("source_history-id", result["items"][0]["carried_errors"][0])
            self.assertEqual(len(result["items"][0]["retry_feedback_seed"]), 2)
            self.assertEqual(before, (digest(state_path), digest(index_path), digest(package / "04_标题方案.json")))
            self.assertFalse(Path(result["batch_dir"]).exists())

    def test_apply_creates_one_item_index_without_mutating_package_or_source(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, state_path, index_path, scope_path, contract_id = self.make_source(root)
            before = (digest(state_path), digest(index_path), digest(package / "04_标题方案.json"))

            result = MODULE.create_controlled_retry_batch(root, scope_path, apply=True)

            new_index = json.loads(Path(result["index_path"]).read_text())
            self.assertEqual(len(new_index["items"]), 1)
            item = new_index["items"][0]
            self.assertEqual(item["video_id"], "video-a")
            self.assertEqual(item["current_stage"], "xy-cover")
            self.assertEqual(item["writeback_readback_stages"], ["xy-title"])
            self.assertEqual(item["controlled_retry"]["retry_stage"], "xy-cover")
            self.assertEqual(len(item["retry_feedback_seed"]), 2)
            self.assertEqual(before, (digest(state_path), digest(index_path), digest(package / "04_标题方案.json")))
            snapshot = json.loads((Path(result["batch_dir"]) / "生产契约快照.json").read_text())
            self.assertEqual(snapshot["contract_id"], contract_id)

    def test_stale_error_feedback_is_rejected(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            _, _, _, scope_path, _ = self.make_source(root)
            scope = json.loads(scope_path.read_text())
            scope["items"][0]["expected_errors"] = ["different"]
            scope_path.write_text(json.dumps(scope, ensure_ascii=False), encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "失败反馈已变化"):
                MODULE.create_controlled_retry_batch(root, scope_path, apply=False)

    def test_isolated_apply_clones_upstream_to_new_package_without_mutating_source(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, state_path, index_path, scope_path, contract_id = self.make_source(root)
            before = (digest(state_path), digest(index_path), digest(package / "04_标题方案.json"))
            scope = json.loads(scope_path.read_text())
            target = root / "_测试运行" / "R3" / "印地" / "频道A" / "剧目" / package.name
            scope["isolated_package_copy"] = True
            scope["items"][0]["target_package_path"] = str(target.relative_to(root))
            scope_path.write_text(json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

            dry_run = MODULE.create_controlled_retry_batch(root, scope_path, apply=False)
            self.assertTrue(dry_run["items"][0]["isolated_package_copy"])
            self.assertEqual(Path(dry_run["items"][0]["target_package_path"]), target.resolve())
            self.assertFalse(target.exists())

            result = MODULE.create_controlled_retry_batch(root, scope_path, apply=True)

            item = json.loads(Path(result["index_path"]).read_text())["items"][0]
            self.assertEqual(Path(item["package_path"]), target.resolve())
            self.assertEqual(item["contract_id"], contract_id)
            self.assertTrue(target.is_dir())
            self.assertEqual(json.loads((target / "04_标题方案.json").read_text()), {"preserve": True})
            metadata = json.loads((target / "剧目元数据.json").read_text())
            state = json.loads((target / "workflow_state.json").read_text())
            self.assertEqual(metadata["batch_id"], scope["batch_id"])
            self.assertEqual(metadata["package_path"], str(target.resolve()))
            self.assertEqual(state["package_path"], str(target.resolve()))
            self.assertEqual(state["isolated_retry_source"]["package_path"], str(package.resolve()))
            self.assertEqual(before, (digest(state_path), digest(index_path), digest(package / "04_标题方案.json")))

    def test_isolated_retry_rejects_existing_target(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, _, _, scope_path, _ = self.make_source(root)
            target = root / "_测试运行" / "R3" / package.name
            target.mkdir(parents=True)
            scope = json.loads(scope_path.read_text())
            scope["isolated_package_copy"] = True
            scope["items"][0]["target_package_path"] = str(target.relative_to(root))
            scope_path.write_text(json.dumps(scope, ensure_ascii=False), encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "隔离目标包已存在"):
                MODULE.create_controlled_retry_batch(root, scope_path, apply=False)


if __name__ == "__main__":
    unittest.main()
