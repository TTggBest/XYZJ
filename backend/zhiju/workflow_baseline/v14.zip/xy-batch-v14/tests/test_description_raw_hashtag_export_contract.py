import importlib.util
import sys
import unittest
from pathlib import Path


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
BATCH_SCRIPTS = SKILLS / "xy-batch-v14/scripts"
PACK_SCRIPTS = SKILLS / "xy-pack-v14/scripts"
for path in (BATCH_SCRIPTS, PACK_SCRIPTS):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


BATCH = load_module("raw_hashtag_batch_test", BATCH_SCRIPTS / "deterministic_batch.py")
CANONICAL = load_module("raw_hashtag_canonical_test", PACK_SCRIPTS / "canonical_outputs.py")
EXPORT = load_module("raw_hashtag_export_test", BATCH_SCRIPTS / "export_daily_tasks.py")


class DescriptionRawHashtagExportContractTests(unittest.TestCase):
    def test_generation_owns_literal_hashtags_and_forbids_markdown_escape_characters(self):
        directive = BATCH.STAGE_DIRECTIVES["xy-place"]

        self.assertIn("hashtags are final YouTube plain text, not Markdown source", directive)
        self.assertIn("copy every selected hashtag character-for-character from the whitelist", directive)
        self.assertIn("Never insert a backslash before an underscore", directive)

    def test_new_contract_rejects_escaped_arabic_hashtag_but_accepts_raw_whitelist_value(self):
        whitelist = {
            "channel_name": "حب الوريث",
            "mandatory_hashtags": ["#cdrama", "#ChineseDrama", "#ShortDrama"],
            "selection_count": 4,
            "additional_selection_count": 1,
            "additional_candidates": ["#دراما_صينية"],
        }
        context = {
            "channel_hashtag_whitelist": whitelist,
            "description_rule_contract": {"hashtag_markdown_escape_forbidden": True},
        }

        raw = "#cdrama #ChineseDrama #ShortDrama #دراما_صينية"
        escaped = "#cdrama #ChineseDrama #ShortDrama #دراما\\_صينية"

        self.assertEqual(CANONICAL.channel_hashtag_whitelist_issues(raw, context), [])
        self.assertIn(
            "description_hashtag_markdown_escape_forbidden:#دراما\\_صينية",
            CANONICAL.channel_hashtag_whitelist_issues(escaped, context),
        )

    def test_final_export_rejects_literal_backslash_in_hashtag_for_new_contract_only(self):
        body = """🔥 hook
🧩 story
😱 reversal
🔓 payoff
✨ details:
one
two
three
four
🎯 type:
drama
{hashtags}
👇 playlist:
name 👉
https://www.youtube.com/playlist?list=PL1
💖 welcome
🔔 subscribe
💬 comment
⚠️ disclaimer
==测试剧=="""
        contract = {
            "description_contract": {
                "mandatory_hashtags": ["#cdrama", "#ChineseDrama", "#ShortDrama"],
                "hashtag_markdown_escape_forbidden": True,
            }
        }
        raw = body.format(hashtags="#cdrama #ChineseDrama #ShortDrama #دراما_صينية")
        escaped = body.format(hashtags="#cdrama #ChineseDrama #ShortDrama #دراما\\_صينية")

        self.assertNotIn("说明 hashtag 含 Markdown 反斜杠转义", EXPORT.description_format_issues(raw, contract))
        self.assertIn("说明 hashtag 含 Markdown 反斜杠转义", EXPORT.description_format_issues(escaped, contract))
        self.assertNotIn(
            "说明 hashtag 含 Markdown 反斜杠转义",
            EXPORT.description_format_issues(escaped, {"description_contract": {}}),
        )


if __name__ == "__main__":
    unittest.main()
