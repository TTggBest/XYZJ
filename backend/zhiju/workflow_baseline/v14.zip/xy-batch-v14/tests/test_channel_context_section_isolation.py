import importlib.util
import sys
import unittest
from pathlib import Path


BATCH_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "deterministic_batch.py"
if str(BATCH_SCRIPT.parent) not in sys.path:
    sys.path.insert(0, str(BATCH_SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("deterministic_batch_context_isolation_test", BATCH_SCRIPT)
BATCH = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = BATCH
SPEC.loader.exec_module(BATCH)


def structured_snapshot(*, markers=None):
    ordered = markers or (
        "GLOBAL",
        "TITLE",
        "COVER",
        "DESCRIPTION",
        "HASHTAG",
        "COMMUNITY",
        "PLAYLIST",
    )
    bodies = {
        "GLOBAL": "频道身份与语言环境。",
        "TITLE": "标题只说明怎么表达。",
        "COVER": "封面只说明视觉表达。",
        "DESCRIPTION": "说明正文表达规则。",
        "HASHTAG": "标签选择规则。",
        "COMMUNITY": "社群表达规则。",
        "PLAYLIST": "播放列表规则。",
    }
    sections = [
        "# 频道数据快照",
        "",
        "## 来源：测试频道_生成规范.md",
        "",
    ]
    for marker in ordered:
        sections.extend((f"## [{marker}]", bodies[marker], ""))
    sections.extend((
        "## 来源：测试频道_频道分析报告.md",
        "",
        "这段分析报告绝不能进入标题上下文。",
        "",
        "## 来源：description_fixed_assets.json",
        "",
        '{"welcome": "固定说明资产"}',
    ))
    return "\n".join(sections)


def final_angle_context():
    return {"final_angles": [{"angle_id": value} for value in ("A", "B", "C")]}


class ChannelContextSectionIsolationTests(unittest.TestCase):
    def test_numbered_production_spec_scopes_title_without_global_marker(self):
        snapshot = (
            '# 频道数据快照\n## 来源：频道_生成规范.md\n'
            '## 1. 频道生成定位\n语言：印尼\n'
            '## 2. 冷启动内容方向\n经营选题不进入Title\n'
            '## 5. 标题生成规则\n标题表达规则\n### 固定规则\n三条标题\n'
            '## 6. 封面生成规则\n封面规则不进入Title\n'
            '## 来源：频道_频道分析报告.md\n分析报告不进入Title\n'
        )
        scoped = BATCH.stage_context('xy-title', {
            'task': {'workflow_contract_version': 2}, 'channel_snapshot': snapshot,
        })
        self.assertEqual(scoped['channel_snapshot'],
            '## 1. 频道生成定位\n语言：印尼\n\n'
            '## 5. 标题生成规则\n标题表达规则\n### 固定规则\n三条标题\n')
        issues = BATCH.stage_preflight_issues('xy-title', {
            'task': {'workflow_contract_version': 2}, 'channel_snapshot': snapshot,
            'channel_theme_contract': {'channel_direction': '女王崛起'},
            'plot_payload': {'results': [{}]}, 'market_packaging': final_angle_context(),
        }, {'version': 1})
        self.assertEqual(issues, [])

    def test_title_receives_only_global_and_title_sections(self):
        snapshot = structured_snapshot()

        scoped = BATCH.stage_context("xy-title", {
            "task": {"workflow_contract_version": 2},
            "channel_snapshot": snapshot,
        })

        self.assertEqual(
            scoped["channel_snapshot"],
            "## [GLOBAL]\n频道身份与语言环境。\n\n"
            "## [TITLE]\n标题只说明怎么表达。\n",
        )
        self.assertNotIn("[COVER]", scoped["channel_snapshot"])
        self.assertNotIn("频道分析报告", scoped["channel_snapshot"])
        self.assertNotIn("固定说明资产", scoped["channel_snapshot"])

    def test_title_preflight_rejects_missing_required_section(self):
        snapshot = structured_snapshot(markers=(
            "GLOBAL", "TITLE", "COVER", "DESCRIPTION", "HASHTAG", "COMMUNITY",
        ))

        issues = BATCH.stage_preflight_issues(
            "xy-title",
            {
                "task": {"workflow_contract_version": 2},
                "channel_snapshot": snapshot,
                "channel_theme_contract": {"channel_direction": "豪门婚恋"},
                "plot_payload": {"results": [{}]},
                "market_packaging": final_angle_context(),
            },
            {"version": 1},
        )

        self.assertEqual(issues, ["preflight_channel_generation_spec_section_missing:PLAYLIST"])

    def test_title_preflight_rejects_duplicate_section(self):
        snapshot = structured_snapshot(markers=(
            "GLOBAL", "TITLE", "TITLE", "COVER", "DESCRIPTION", "HASHTAG", "COMMUNITY", "PLAYLIST",
        ))

        issues = BATCH.stage_preflight_issues(
            "xy-title",
            {
                "task": {"workflow_contract_version": 2},
                "channel_snapshot": snapshot,
                "channel_theme_contract": {"channel_direction": "豪门婚恋"},
                "plot_payload": {"results": [{}]},
                "market_packaging": final_angle_context(),
            },
            {"version": 1},
        )

        self.assertEqual(issues, ["preflight_channel_generation_spec_section_duplicate:TITLE"])

    def test_title_preflight_rejects_out_of_order_sections(self):
        snapshot = structured_snapshot(markers=(
            "TITLE", "GLOBAL", "COVER", "DESCRIPTION", "HASHTAG", "COMMUNITY", "PLAYLIST",
        ))

        issues = BATCH.stage_preflight_issues(
            "xy-title",
            {
                "task": {"workflow_contract_version": 2},
                "channel_snapshot": snapshot,
                "channel_theme_contract": {"channel_direction": "豪门婚恋"},
                "plot_payload": {"results": [{}]},
                "market_packaging": final_angle_context(),
            },
            {"version": 1},
        )

        self.assertEqual(issues, ["preflight_channel_generation_spec_section_order_invalid"])

    def test_place_preflight_rejects_missing_registered_playlists(self):
        issues = BATCH.stage_preflight_issues(
            "xy-place",
            {
                "task": {"workflow_contract_version": 2},
                "channel_snapshot": structured_snapshot(),
                "channel_theme_contract": {"channel_direction": "萌宝家庭"},
                "plot_payload": {"results": [{}]},
                "title_payload": {"results": [{"packaging_brief": {}}]},
                "playlists": [],
            },
            {"description_contract": {}},
        )

        self.assertEqual(issues, ["preflight_channel_registered_playlist_missing"])

    def test_phase_one_leaves_downstream_snapshots_unchanged(self):
        snapshot = structured_snapshot()

        cover = BATCH.stage_context("xy-cover", {"channel_snapshot": snapshot})
        place = BATCH.stage_context("xy-place", {"channel_snapshot": snapshot})
        post = BATCH.stage_context("xy-post", {"channel_snapshot": snapshot})

        self.assertEqual(cover["channel_snapshot"], snapshot)
        self.assertEqual(place["channel_snapshot"], snapshot)
        self.assertEqual(post["channel_snapshot"], snapshot)


if __name__ == "__main__":
    unittest.main()
