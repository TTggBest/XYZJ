import importlib.util
import json
import sys
import unittest
from pathlib import Path


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
PACK_SCRIPTS = SKILLS / "xy-pack-v14/scripts"
if str(PACK_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(PACK_SCRIPTS))

CANONICAL_SPEC = importlib.util.spec_from_file_location(
    "canonical_outputs_channel_hashtag_test",
    PACK_SCRIPTS / "canonical_outputs.py",
)
CANONICAL = importlib.util.module_from_spec(CANONICAL_SPEC)
sys.modules[CANONICAL_SPEC.name] = CANONICAL
CANONICAL_SPEC.loader.exec_module(CANONICAL)

BATCH_SCRIPTS = SKILLS / "xy-batch-v14/scripts"
if str(BATCH_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(BATCH_SCRIPTS))
BATCH_SPEC = importlib.util.spec_from_file_location(
    "deterministic_batch_channel_hashtag_test",
    BATCH_SCRIPTS / "deterministic_batch.py",
)
BATCH = importlib.util.module_from_spec(BATCH_SPEC)
sys.modules[BATCH_SPEC.name] = BATCH
BATCH_SPEC.loader.exec_module(BATCH)


ASSET = SKILLS / "xy-place-v14/rules/channel_hashtag_whitelists.json"
CHANNEL_REGISTRY = Path(
    "/Volumes/TTggg_mini01_2T/ai/筱宇短剧运营-youtube/运营/工作流运营/公用/频道注册表.json"
)
EXPECTED_CHANNELS = {
    "নতুন করে আমি", "امرأة تنهض من جديد", "Rahasia Keluarga Kecil",
    "রাজকীয় প্রেমকথা", "Munting Lihim ng Pamilya", "Cinta Sang Pewaris",
    "Minik Aile Sırları", "Её новая жизнь", "Mulher que Renasce",
    "ছোট্ট পরিবারের গল্প", "Varisin Aşkı", "Маленькие семейные тайны",
    "Amor de Herdeiros", "दिल की शाही कहानी", "Amor de Herederos",
    "Little Family Secrets", "Yeniden Doğan Kadın", "Pequeños Secretos de Familia",
    "Любовь наследника", "Babaeng Muling Bumangon", "Mujer que Renace",
    "Her New Beginning", "मेरी नई शुरुआत", "नन्हे रिश्तों की दुनिया",
    "Bangkit Setelah Terluka", "دفء الأسرة الصغيرة", "Pag-ibig ng Tagapagmana",
    "Heir to My Heart", "حب الوريث", "Pequenos Segredos de Família",
}
MANDATORY = ["#cdrama"]


class ChannelHashtagWhitelistTests(unittest.TestCase):
    def test_asset_covers_exactly_the_30_registered_channels(self):
        asset = json.loads(ASSET.read_text(encoding="utf-8"))
        registry = json.loads(CHANNEL_REGISTRY.read_text(encoding="utf-8"))
        registered = {
            row["channel_name"]
            for row in registry["channels"]
            if isinstance(row, dict) and row.get("channel_name")
        }

        self.assertEqual(set(asset["channels"]), EXPECTED_CHANNELS)
        self.assertEqual(set(asset["channels"]), registered)
        self.assertEqual(asset["mandatory_hashtags"], MANDATORY)
        self.assertEqual(asset["selection_count"], 12)
        self.assertEqual(asset["additional_selection_count"], 11)
        for channel, row in asset["channels"].items():
            with self.subTest(channel=channel):
                candidates = row["additional_whitelist"]
                self.assertGreaterEqual(len(candidates), 11)
                self.assertEqual(len(candidates), len({tag.casefold() for tag in candidates}))
                self.assertFalse({tag.casefold() for tag in candidates} & {tag.casefold() for tag in MANDATORY})

    def test_resolver_uses_exact_channel_and_never_same_language_neighbor(self):
        machine = {
            "channel_hashtag_whitelists": {
                "mandatory_hashtags": MANDATORY,
                "selection_count": 12,
                "additional_selection_count": 11,
                "channels": {
                    "频道甲": {"additional_whitelist": [f"#A{i}" for i in range(1, 12)], "target_language_tags": ["#A1"]},
                    "频道乙": {"additional_whitelist": [f"#B{i}" for i in range(1, 12)], "target_language_tags": ["#B1"]},
                },
            }
        }

        resolved = BATCH.resolved_channel_hashtag_whitelist(
            {"task": {"channel": "频道甲", "language": "同一种语言"}}, machine
        )

        self.assertEqual(resolved["channel_name"], "频道甲")
        self.assertEqual(resolved["additional_candidates"], [f"#A{i}" for i in range(1, 12)])
        self.assertNotIn("#B1", resolved["additional_candidates"])

    def test_resolver_fails_closed_when_channel_is_not_registered(self):
        machine = {
            "channel_hashtag_whitelists": {
                "mandatory_hashtags": MANDATORY,
                "selection_count": 12,
                "additional_selection_count": 11,
                "channels": {},
            }
        }

        with self.assertRaisesRegex(RuntimeError, "channel_hashtag_whitelist_missing:未知频道"):
            BATCH.resolved_channel_hashtag_whitelist(
                {"task": {"channel": "未知频道", "language": "孟加拉"}}, machine
            )

    def test_validator_rejects_any_table_external_hashtag_and_wrong_count(self):
        item = {
            "drama_name": "测试剧", "video_id": "video", "slot": "2026082001",
            "workflow_contract_version": 1, "language": "英语", "channel": "频道甲",
        }
        allowed = [f"#Allowed{i}" for i in range(1, 12)]
        base_result = {
            "search_result_index": 1, "source_block_label": "搜索资料1",
            "result_id": "video_1", "video_id": "video", "drama_name": "测试剧",
            "playlist": "Playlist", "url": "https://www.youtube.com/playlist?list=PL123",
            "description": " ".join([allowed[0], allowed[1], "#cdrama", *allowed[2:]]) + "\n\n==测试剧==",
            "translation": "中文审阅", "opening_hook_type": "identity_reveal",
            "payoff_hook_type": "truth_reveal", "editorial_anchor": "身份在宴会现场公开揭晓",
        }
        context = {
            "task": item,
            "playlists": [],
            "description_fixed_assets": {},
            "description_rule_contract": {
                "mandatory_hashtags": MANDATORY,
                "cdrama_position": 3,
                "target_language_tag_required_within_positions": [1, 2],
            },
            "channel_hashtag_whitelist": {
                "channel_name": "频道甲",
                "mandatory_hashtags": MANDATORY,
                "selection_count": 12,
                "additional_selection_count": 11,
                "additional_candidates": allowed,
                "target_language_tags": [allowed[0]],
            },
        }

        valid_issues = CANONICAL.validate_place({"results": [base_result]}, item, context)
        self.assertFalse(any(issue.startswith("description_hashtag_") for issue in valid_issues))

        external = dict(base_result)
        external["description"] = external["description"].replace("#Allowed11", "#InventedByAI")
        external_issues = CANONICAL.validate_place({"results": [external]}, item, context)
        self.assertIn("description_hashtag_not_in_channel_whitelist:#InventedByAI", external_issues)

        short = dict(base_result)
        short["description"] = short["description"].replace(" #Allowed11", "")
        short_issues = CANONICAL.validate_place({"results": [short]}, item, context)
        self.assertIn("description_hashtag_count_mismatch:11!=12", short_issues)


if __name__ == "__main__":
    unittest.main()
