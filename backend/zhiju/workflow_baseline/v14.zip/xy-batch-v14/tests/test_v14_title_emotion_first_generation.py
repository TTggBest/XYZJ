import importlib.util
import json
import sys
import unittest
from pathlib import Path

from channel_context_fixture import structured_channel_snapshot


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "deterministic_batch.py"
sys.path.insert(0, str(SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("v14_title_emotion_first_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class V14TitleEmotionFirstGenerationTests(unittest.TestCase):
    def context(self):
        rules = json.loads(MODULE.MACHINE_RULE_PATHS["xy-title"].read_text(encoding="utf-8"))
        return {
            "task": {"drama_name": "动态剧目证据"},
            "identity": {"video_id": "dynamic-video"},
            "channel_snapshot": structured_channel_snapshot(title_body="动态频道标题外壳"),
            "channel_theme_contract": {
                "channel_direction": "动态频道方向",
                "plot_supported": True,
            },
            "semantic_contract": {},
            "creative_slot": {},
            "title_rule_contract": rules["title_contract"],
            "plot_payload": {"results": [{"plot_fields": {"内容概述": "动态真实剧情证据"}}]},
            "creative_history": [{
                "channel": "动态历史频道",
                "title_payload": {"results": [{"directions": [{
                    "hook_a_type": "betrayal",
                    "hook_a_fact": "动态历史A",
                    "hook_b_type": "power_reversal",
                    "hook_b_fact": "动态历史B",
                }]}]},
            }],
        }

    def prompt(self, issues=None):
        rules = MODULE.SIMULATED_SKILLS["xy-title"].read_text(encoding="utf-8")
        return MODULE.build_prompt("xy-title", rules, self.context(), issues or [])

    def test_prompt_uses_emotion_first_single_causal_chain(self):
        prompt = self.prompt()
        ordered_markers = [
            "strongest immediate emotion",
            "concrete perceptible event",
            "relationship inside that event",
            "protagonist's response, choice, or gain",
            "clear position change",
            "optional amplifier",
            "single A-to-B causal chain",
        ]
        offsets = [prompt.index(marker) for marker in ordered_markers]
        self.assertEqual(offsets, sorted(offsets))
        self.assertIn("B directly repays the emotional debt created by A", prompt)

    def test_prompt_prioritizes_position_change_not_event_category(self):
        prompt = self.prompt()
        self.assertIn(
            "Prioritize events that directly change the position between people",
            prompt,
        )
        self.assertIn(
            "An event's type does not determine its priority",
            prompt,
        )
        self.assertIn(
            "selection, exclusion, recognition, replacement, protection, or a change in status",
            prompt,
        )
        self.assertIn(
            "A procedural fact receives high priority only when it carries such a position change",
            prompt,
        )

    def test_semantic_self_check_is_model_only_not_controller_detection(self):
        prompt = self.prompt()
        self.assertIn("model-only self-check", prompt)
        self.assertIn("must not become a mechanical Validator", prompt)
        feedback = prompt.split(
            "Controller-owned actionable correction instructions:\n", 1
        )[1].split("\n\nPersistent generation requirements", 1)[0]
        self.assertEqual(feedback, "")

    def test_static_prompt_has_no_prebuilt_story_examples_or_solution_templates(self):
        prompt = self.prompt()
        for forbidden in (
            "hidden CEO",
            "inheritance fight",
            "kneeling",
            "money cutoff",
            "pregnancy",
            "fake marriage",
        ):
            self.assertNotIn(forbidden, prompt)
        self.assertIn("Protocol-only allowed hook_a_type values", prompt)
        self.assertIn("must not be used as a creative candidate list", prompt)

    def test_dynamic_task_evidence_remains_in_generation_context(self):
        prompt = self.prompt()
        for dynamic_value in (
            "动态剧目证据",
            "动态频道标题外壳",
            "动态频道方向",
            "动态真实剧情证据",
            "动态历史A",
        ):
            self.assertIn(dynamic_value, prompt)

    def test_existing_error_signal_gets_abstract_not_template_solution(self):
        prompt = self.prompt(["title_1_public_payoff_anchor_abstract"])
        feedback = prompt.split(
            "Controller-owned actionable correction instructions:\n", 1
        )[1].split("\n\nPersistent generation requirements", 1)[0]
        self.assertIn("directly responds to the preceding conflict", feedback)
        self.assertIn("one causal line", feedback)
        for forbidden in ("amount", "asset loss", "public punishment", "power transfer"):
            self.assertNotIn(forbidden, feedback)


if __name__ == "__main__":
    unittest.main()
