import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path


LAUNCHER = Path(__file__).resolve().parents[1] / "scripts" / "background_batch.py"


class BackgroundBatchTests(unittest.TestCase):
    def _fixture(self, temp_name: str, *, sleep_seconds: float = 0.8, exit_code: int = 0):
        root = Path(temp_name)
        batch = root / "批量任务" / "batch-one"
        batch.mkdir(parents=True)
        index = batch / "今日任务索引.json"
        index.write_text(json.dumps({"batch_id": "batch-one", "items": []}), encoding="utf-8")
        (batch / "生产契约快照.json").write_text(
            json.dumps({"contract_id": "xy-v14-test"}), encoding="utf-8"
        )
        runner = root / "fake_run_batch.py"
        runner.write_text(
            "\n".join([
                "#!/usr/bin/env python3",
                "import json, sys, time",
                "if '--preflight' in sys.argv:",
                "    print(json.dumps({'ok': True, 'preflight': True}))",
                "    raise SystemExit(0)",
                f"time.sleep({sleep_seconds})",
                "print('background payload finished')",
                f"raise SystemExit({exit_code})",
            ]) + "\n",
            encoding="utf-8",
        )
        os.chmod(runner, 0o755)
        return root, index, runner

    def _start(self, root: Path, index: Path, runner: Path, *, workers: str | None = "5"):
        command = [
                sys.executable, str(LAUNCHER), "start",
                "--root", str(root),
                "--index", str(index),
                "--runner", str(runner),
                "--chunk-size", "1",
                "--timeout", "900",
                "--max-output-row", "112",
                "--enable-live-writeback",
                "--apply",
            ]
        if workers is not None:
            command[9:9] = ["--workers", workers]
        return subprocess.run(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )

    def test_default_worker_count_is_ten(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root, index, runner = self._fixture(temp_name, sleep_seconds=0.1)

            result = self._start(root, index, runner, workers=None)

            self.assertEqual(result.returncode, 0, result.stdout)
            launch = json.loads(result.stdout)
            job = json.loads(Path(launch["job_file"]).read_text(encoding="utf-8"))
            worker_flag = job["command"].index("--workers")
            self.assertEqual(job["command"][worker_flag + 1], "10")
            self._wait_for_terminal_job(Path(launch["job_file"]))

    def _wait_for_terminal_job(self, job_file: Path, timeout: float = 5.0):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            payload = json.loads(job_file.read_text(encoding="utf-8"))
            if payload.get("status") in {"SUCCEEDED", "FAILED"}:
                return payload
            time.sleep(0.05)
        self.fail(f"background job did not finish: {job_file}")

    def test_start_returns_before_runner_finishes_and_supervisor_records_success(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root, index, runner = self._fixture(temp_name, sleep_seconds=0.8, exit_code=0)
            started_at = time.monotonic()

            result = self._start(root, index, runner)

            elapsed = time.monotonic() - started_at
            self.assertEqual(result.returncode, 0, result.stdout)
            self.assertLess(elapsed, 0.6)
            launch = json.loads(result.stdout)
            self.assertEqual(launch["status"], "RUNNING")
            self.assertGreater(launch["pid"], 0)
            job_file = Path(launch["job_file"])
            final = self._wait_for_terminal_job(job_file)
            self.assertEqual(final["status"], "SUCCEEDED")
            self.assertEqual(final["exit_code"], 0)
            self.assertIn("background payload finished", Path(final["log_file"]).read_text(encoding="utf-8"))

    def test_supervisor_records_nonzero_exit_without_codex_polling(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root, index, runner = self._fixture(temp_name, sleep_seconds=0.1, exit_code=7)

            result = self._start(root, index, runner)

            self.assertEqual(result.returncode, 0, result.stdout)
            final = self._wait_for_terminal_job(Path(json.loads(result.stdout)["job_file"]))
            self.assertEqual(final["status"], "FAILED")
            self.assertEqual(final["exit_code"], 7)

    def test_second_start_is_blocked_while_same_index_job_is_running(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root, index, runner = self._fixture(temp_name, sleep_seconds=1.0, exit_code=0)
            first = self._start(root, index, runner)
            self.assertEqual(first.returncode, 0, first.stdout)

            second = self._start(root, index, runner)

            self.assertNotEqual(second.returncode, 0)
            self.assertIn("active background job already exists", second.stdout)
            self._wait_for_terminal_job(Path(json.loads(first.stdout)["job_file"]))

if __name__ == "__main__":
    unittest.main()
