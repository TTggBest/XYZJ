import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
PACK_SCRIPTS = SKILL_ROOT.parent / "xy-pack-v14" / "scripts"
for scripts_dir in (SKILL_ROOT / "scripts", PACK_SCRIPTS):
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


INIT_BATCH = load_module("v14_init_batch_playlist_test", SKILL_ROOT / "scripts/init_batch.py")
CANONICAL = load_module("v14_canonical_playlist_test", PACK_SCRIPTS / "canonical_outputs.py")


class ChannelPlaylistSnapshotTests(unittest.TestCase):
    def test_snapshot_freezes_registered_channel_playlists(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            channel_dir = root / "频道"
            package_dir = root / "任务"
            channel_dir.mkdir()
            package_dir.mkdir()
            (channel_dir / "频道_生成规范.md").write_text("# 生成规范\n", encoding="utf-8")
            channel_row = {
                "channel_dir": str(channel_dir),
                "channel_name": "频道",
                "language": "孟加拉",
                "playlist": (
                    "列表一 | https://studio.youtube.com/playlist/PL_ALPHA/videos；"
                    "列表二 | https://www.youtube.com/playlist?list=PL_BETA"
                ),
            }

            snapshot_path = INIT_BATCH.write_channel_snapshot(package_dir, channel_row)
            playlists = CANONICAL.playlists_from_snapshot(
                snapshot_path.read_text(encoding="utf-8")
            )

            self.assertEqual(
                playlists,
                [
                    {
                        "name": "列表一",
                        "url": "https://www.youtube.com/playlist?list=PL_ALPHA",
                    },
                    {
                        "name": "列表二",
                        "url": "https://www.youtube.com/playlist?list=PL_BETA",
                    },
                ],
            )


if __name__ == "__main__":
    unittest.main()
