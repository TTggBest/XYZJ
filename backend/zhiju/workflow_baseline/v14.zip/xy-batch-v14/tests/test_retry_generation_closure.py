import importlib.util
import sys
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
SCRIPT = SCRIPTS / "deterministic_batch.py"
SPEC = importlib.util.spec_from_file_location("retry_generation_closure_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def title_context():
    return {
        "task": {"drama_name": "爹地妈咪快结婚", "gender": "女频"},
        "identity": {},
        "channel_snapshot": "- 固定标题格式：`🔥【ПОЛНОСТЬЮ】A!🎀B!`\n",
        "channel_theme_contract": {
            "channel_direction": "萌宝家庭", "plot_supported": True,
            "required_output_signals": ["孩子"],
        },
        "semantic_contract": {}, "creative_slot": {}, "title_rule_contract": {},
        "plot_payload": {}, "creative_history": [],
    }


def cover_context():
    return {
        "task": {"drama_name": "一胎双宝，夫人拒不复婚", "gender": "女频"},
        "identity": {}, "channel_snapshot": "",
        "channel_theme_contract": {"channel_direction": "豪门婚恋", "plot_supported": True},
        "semantic_contract": {}, "creative_slot": {},
        "cover_rule_contract": {"prompt_audit": {"prompt_word_count_mode": "audit_only"}},
        "plot_payload": {}, "visual_history": [], "creative_history": [],
        "title_payload": {"results": [{"directions": [
            {
                "index": 1, "title": "T1", "translation": "译1", "child_angle": True,
                "child_role": "two twin boys beside their mother",
                "safe_cover_scene": "two healthy cheerful twin boys with their mother in a sunny family garden",
            },
            {
                "index": 2, "title": "T2", "translation": "译2", "child_angle": True,
                "child_role": "two twin boys with a caring nanny",
                "safe_cover_scene": "two calm twin boys with a nanny in a bright family lounge",
            },
            {
                "index": 3, "title": "T3", "translation": "译3", "child_angle": True,
                "child_role": "two twin boys holding their mother's hands",
                "safe_cover_scene": "two safe twins holding their mother's hands in a courtyard",
            },
        ]}]},
    }


def place_context():
    return {
        "task": {"drama_name": "妈咪本事大爹地别害怕", "language": "孟加拉"},
        "identity": {},
        "channel_snapshot": "",
        "channel_theme_contract": {},
        "semantic_contract": {},
        "creative_slot": {},
        "playlists": [],
        "description_fixed_assets": {},
        "channel_hashtag_whitelist": {},
        "plot_payload": {},
        "title_payload": {},
        "creative_history": [],
    }


def test_title_retry_always_repeats_exact_format_and_child_safe_contract():
    prompt = MODULE.build_prompt(
        "xy-title", "rules", title_context(), ["title_cross_channel_package_collision"]
    )
    assert "Persistent generation requirements" in prompt
    assert "🔥【ПОЛНОСТЬЮ】A!🎀B!" in prompt
    assert "Resolve child presence independently for each supplied Find final angle" in prompt
    assert "Choose three new hook pairs" in prompt


def test_description_chinese_leak_has_actionable_target_language_retry_feedback():
    prompt = MODULE.build_prompt(
        "xy-place",
        "rules",
        place_context(),
        ["description_contains_chinese_outside_final_marker"],
    )
    feedback = prompt.split("Controller-owned actionable correction instructions:\n", 1)[1].split(
        "\n\nPersistent generation requirements", 1
    )[0]

    assert "Rewrite every Chinese character in the public description into the registered channel language" in feedback
    assert "Keep Chinese only in the separate review translation fields and the exact final ==Chinese drama name== marker" in feedback


def test_cover_retry_keeps_child_requirements_for_any_group_content_retry():
    prompt = MODULE.build_prompt(
        "xy-cover", "rules", cover_context(), ["cover_2_physical_violence_forbidden"]
    )
    assert "Persistent generation requirements" in prompt
    assert "GROUP 1" in prompt and "GROUP 2" in prompt and "GROUP 3" in prompt
    assert "two twin boys beside their mother" in prompt
    assert "two twin boys with a caring nanny" in prompt
    assert "two twin boys holding their mother's hands" in prompt
    assert "Copy title and title_translation exactly" in prompt
    assert "female-frequency" in prompt




def test_cover_unexpected_final_prompt_fields_have_actionable_schema_correction():
    prompt = MODULE.build_prompt(
        "xy-cover",
        "rules",
        cover_context(),
        [
            "$.results[0].titles[0].prompt_4_5_unexpected",
            "$.results[0].titles[0].prompt_16_9_unexpected",
        ],
    )
    feedback = prompt.split("Controller-owned actionable correction instructions:\n", 1)[1].split(
        "\n\nPersistent generation requirements", 1
    )[0]
    assert "Remove the unexpected fields prompt_4_5 and prompt_16_9" in feedback
    assert "use scene_prompt_4_5 and outpaint_environment" in feedback
    assert "controller constructs them downstream" in feedback


def test_model_owned_scene_boilerplate_is_content_error_not_controller_error():
    issues = [
        "cover_1_scene_prompt_contains_controller_owned_identity",
        "cover_1_final_prompt_identity_block_count_2",
    ]

    assert MODULE.system_validation_issues(issues) == []


def test_unexplained_final_prompt_block_count_remains_system_error():
    issues = ["cover_1_final_prompt_identity_block_count_0"]

    assert MODULE.system_validation_issues(issues) == issues


def test_title_format_error_has_actionable_exact_shell_feedback():
    prompt = MODULE.build_prompt(
        "xy-title", "rules", title_context(), ["title_1_format_mismatch"]
    )
    feedback = prompt.split("Controller-owned actionable correction instructions:\n", 1)[1]
    assert "Rewrite every failed title with the exact shell" in feedback
    assert "🔥【ПОЛНОСТЬЮ】A!🎀B!" in feedback


def test_twin_drama_cover_prompt_repeats_child_contract_for_every_group():
    context = cover_context()
    context["title_payload"]["results"][0]["directions"][0].update({
        "title": "T1 without a child word",
        "translation": "第一方向正文只写离婚突袭",
    })
    prompt = MODULE.build_prompt("xy-cover", "rules", context, ["cover_1_child_angle_missing_visible_child"])
    persistent = prompt.split("Persistent generation requirements", 1)[1]
    assert "GROUP 1: a real visible safe Chinese child or children are mandatory" in persistent
    assert "two twin boys beside their mother" in persistent


def test_visual_collision_error_has_source_fingerprint_redesign_feedback():
    context = cover_context()
    context["visual_history"] = [{
        "channel": "Varisin Aşkı",
        "drama_name": "三个男友把我宠",
        "video_id": "g_CtG_mHVug",
        "scene_family": "company banquet elevator reopening",
        "main_action": "heroine supports a man out of the elevator",
        "composition": "three-quarter view from behind a waiting boyfriend",
        "palette": "hotel stone beige and midnight blue",
        "lighting": "warm elevator light into a cooler foyer",
    }]
    issue = (
        "cover_2_visual_collision_with_history_1_fields_"
        "scene_family_composition_palette_lighting_source_"
        "Varisin Aşkı:三个男友把我宠:g_CtG_mHVug"
    )
    prompt = MODULE.build_prompt("xy-cover", "rules", context, [issue])
    feedback = prompt.split("Controller-owned actionable correction instructions:\n", 1)[1].split(
        "\n\nPersistent generation requirements", 1
    )[0]
    assert "GROUP 2" in feedback
    assert "Varisin Aşkı:三个男友把我宠:g_CtG_mHVug" in feedback
    assert "scene_family" in feedback and "composition" in feedback
    assert "different plot-supported story moment" in feedback


def test_collision_feedback_looks_up_fingerprint_by_source_not_stale_ordinal():
    context = cover_context()
    context["visual_history"] = [
        {"channel": "other", "drama_name": "other", "video_id": "other"},
        {
            "channel": "Varisin Aşkı", "drama_name": "三个男友把我宠", "video_id": "g_CtG_mHVug",
            "main_action": "source-specific action",
            "composition": "source-specific composition",
            "palette": "source-specific palette",
        },
    ]
    issue = (
        "cover_2_visual_collision_with_history_1_fields_main_action_composition_palette_source_"
        "Varisin Aşkı:三个男友把我宠:g_CtG_mHVug"
    )
    prompt = MODULE.build_prompt("xy-cover", "rules", context, [issue])
    assert 'main_action="source-specific action"' in prompt
    assert 'composition="source-specific composition"' in prompt
    assert 'palette="source-specific palette"' in prompt


def test_new_collision_error_carries_stable_source_group_identity():
    current = [{
        "scene_family": "mansion proposal",
        "main_action": "chairman offers ring to mother",
        "key_prop": "ring box",
        "composition": "mother foreground chairman behind",
        "palette": "walnut ivory blue",
        "lighting": "warm practical lamp",
    }]
    history = [{
        **current[0],
        "channel": "频道A", "drama_name": "剧A", "video_id": "video-a",
        "source_group_index": "2",
    }]
    issues = MODULE.visual_history_collision_issues(current, history)
    assert issues and issues[0].endswith("_source_频道A:剧A:video-a:group2")


def test_stage_retry_feedback_accumulates_collisions_across_attempts_cycles_and_seed(tmp_path):
    package = tmp_path
    state = {
        "steps": {
            "xy-cover": {
                "status": "retrying", "attempts": 3,
                "errors": ["cover_3_visual_collision_with_history_9_fields_main_action_source_current"],
                "collision_feedback_history": [
                    "cover_2_visual_collision_with_history_8_fields_composition_source_transient"
                ],
                "retry_history": [{
                    "errors": ["cover_1_visual_collision_with_history_6_fields_palette_source_old"]
                }],
            }
        }
    }
    (package / "workflow_state.json").write_text(__import__("json").dumps(state), encoding="utf-8")
    item = {
        "package_path": str(package),
        "retry_feedback_seed": [
            "cover_2_visual_collision_with_history_8_fields_composition_source_transient",
            "cover_3_visual_collision_with_history_9_fields_main_action_source_current",
        ],
    }
    feedback = MODULE.stage_retry_feedback(package, item, "xy-cover")
    assert feedback == [
        "cover_3_visual_collision_with_history_9_fields_main_action_source_current",
        "cover_2_visual_collision_with_history_8_fields_composition_source_transient",
        "cover_1_visual_collision_with_history_6_fields_palette_source_old",
    ]


def test_update_step_state_persists_retry_feedback_seed_into_collision_ledger(tmp_path):
    package = tmp_path
    (package / "workflow_state.json").write_text(
        __import__("json").dumps({"steps": {"xy-cover": {"retry_cycle": 3}}}),
        encoding="utf-8",
    )
    seed = [
        "cover_1_visual_collision_with_history_6_fields_palette_source_old",
        "cover_2_visual_collision_with_history_8_fields_composition_source_other",
    ]
    item = {"package_path": str(package), "retry_feedback_seed": seed}
    MODULE.update_step_state(package, item, "xy-cover", "done", 1, [], "sha-cover")
    state = __import__("json").loads((package / "workflow_state.json").read_text())
    assert state["steps"]["xy-cover"]["collision_feedback_history"] == seed


def test_system_error_rolls_back_the_creative_attempt_counter(tmp_path):
    package = tmp_path
    item = {"package_path": str(package), "video_id": "system-error-probe", "contract_id": "contract"}

    MODULE.update_step_state(package, item, "xy-cover", "running", 1, [], "sha-cover")
    MODULE.update_step_state(
        package,
        item,
        "xy-cover",
        "system_error",
        0,
        ["SYSTEM_ERROR:response_schema_mismatch"],
        "sha-cover",
        count_attempt=False,
    )

    step = MODULE.stage_step(package, item, "xy-cover")
    assert step["status"] == "system_error"
    assert step["attempts"] == 0
    assert step["attempts_total"] == 0
