import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "workflow_contract.py"
SPEC = importlib.util.spec_from_file_location("workflow_contract_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class UnifiedContractStateMachineTests(unittest.TestCase):
    def test_current_contract_is_v14(self):
        self.assertEqual(MODULE.CONTRACT_VERSION, 11)
        self.assertEqual(MODULE.SEALED_CONTRACT_MIN_VERSION, 7)

    def test_contract_id_covers_every_effective_contract_section(self):
        snapshot = {
            "version": 7,
            "rules": {"xy-title": {"content": "rule"}},
            "machine_contracts": {"xy-title": {"content": {"version": 1}}},
            "schema_contracts": {"xy-title": {"content": {"type": "object"}}},
            "stage_directives": {"xy-title": {"content": "directive"}},
            "semantic_contract": {"version": 7},
            "visual_review_contract": {"version": 1},
            "regeneration_contract": {"version": 1},
            "state_machine_contract": {"version": 1},
        }
        first = MODULE.contract_id_for(snapshot)
        snapshot["visual_review_contract"]["version"] = 2
        second = MODULE.contract_id_for(snapshot)
        self.assertNotEqual(first, second)

    def test_snapshot_integrity_rejects_content_tampering(self):
        snapshot = MODULE.seal_contract_snapshot({
            "version": 7,
            "rules": {"xy-title": {"content": "original"}},
            "machine_contracts": {},
            "schema_contracts": {},
            "stage_directives": {},
            "semantic_contract": {},
            "visual_review_contract": {},
            "regeneration_contract": {},
            "state_machine_contract": {},
        })
        MODULE.verify_contract_snapshot(snapshot)
        snapshot["rules"]["xy-title"]["content"] = "tampered"
        with self.assertRaises(ValueError):
            MODULE.verify_contract_snapshot(snapshot)

    def test_v7_sealed_snapshot_still_rejects_tampering_after_v14_creation(self):
        snapshot = MODULE.seal_contract_snapshot({
            "version": 7,
            "rules": {"xy-title": {"content": "v7 baseline"}},
            "machine_contracts": {}, "schema_contracts": {}, "stage_directives": {},
            "semantic_contract": {}, "visual_review_contract": {},
            "regeneration_contract": {}, "state_machine_contract": {},
            "runtime_sources": {},
        })
        snapshot["rules"]["xy-title"]["content"] = "tampered"
        with self.assertRaisesRegex(ValueError, "contract_content_tampered"):
            MODULE.verify_contract_snapshot(snapshot)

    def test_v10_snapshot_uses_its_complete_historical_section_profile(self):
        snapshot = {
            key: ({"version": 1} if key != "version" else 10)
            for key in MODULE.V10_EFFECTIVE_CONTRACT_SECTIONS
        }
        snapshot["integrity"] = {
            key: MODULE.sha256_json(snapshot.get(key))
            for key in MODULE.V10_EFFECTIVE_CONTRACT_SECTIONS
        }
        snapshot["contract_id"] = MODULE.contract_id_for(
            snapshot, MODULE.V10_EFFECTIVE_CONTRACT_SECTIONS
        )

        MODULE.verify_contract_snapshot(snapshot)

        snapshot["community_plan_contract"]["version"] = 2
        with self.assertRaisesRegex(ValueError, "contract_content_tampered:community_plan_contract"):
            MODULE.verify_contract_snapshot(snapshot)

    def test_snapshot_rejects_unknown_integrity_section_profile(self):
        snapshot = MODULE.seal_contract_snapshot({
            "version": 7,
            "rules": {}, "machine_contracts": {}, "schema_contracts": {},
            "stage_directives": {}, "semantic_contract": {},
            "visual_review_contract": {}, "regeneration_contract": {},
            "state_machine_contract": {}, "runtime_sources": {},
        })
        snapshot["integrity"].pop("visual_review_contract")

        with self.assertRaisesRegex(ValueError, "contract_integrity_profile_unknown"):
            MODULE.verify_contract_snapshot(snapshot)

    def test_package_ready_requires_every_declared_asset_and_validation(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            present = root / "present.png"
            present.write_bytes(b"image")
            manifest = {
                "required_task_ids": ["a", "b"],
                "tasks": [
                    {"task_id": "a", "target_path": str(present), "validation_status": "accepted"},
                    {"task_id": "b", "target_path": str(root / "missing.png"), "validation_status": "accepted"},
                ],
            }
            evidence = MODULE.evaluate_asset_manifest(manifest)
            self.assertFalse(evidence["complete"])
            self.assertEqual(evidence["missing_task_ids"], ["b"])

    def test_runtime_source_drift_is_rejected_by_downstream_stages(self):
        with tempfile.TemporaryDirectory() as temp_name:
            source = Path(temp_name) / "runtime.py"
            source.write_text("version = 1\n", encoding="utf-8")
            snapshot = MODULE.seal_contract_snapshot({
                "version": 7,
                "rules": {}, "machine_contracts": {}, "schema_contracts": {},
                "stage_directives": {}, "semantic_contract": {},
                "visual_review_contract": {}, "regeneration_contract": {},
                "state_machine_contract": {},
                "runtime_sources": {"runtime": {
                    "source_path": str(source),
                    "sha256": __import__("hashlib").sha256(source.read_bytes()).hexdigest(),
                }},
            })
            MODULE.verify_runtime_sources(snapshot)
            source.write_text("version = 2\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                MODULE.verify_runtime_sources(snapshot)

    def test_delivered_requires_package_ready_logos_delivery_and_writeback(self):
        evidence = {
            "assets_complete": True,
            "text_complete": True,
            "logo_complete": False,
            "delivery_complete": True,
            "writeback_complete": True,
        }
        self.assertEqual(MODULE.derive_package_status(evidence), "PACKAGE_READY")
        evidence["logo_complete"] = True
        self.assertEqual(MODULE.derive_package_status(evidence), "DELIVERED")

    def test_done_is_legacy_text_ready_not_terminal_delivery(self):
        self.assertEqual(MODULE.normalize_status("done"), "TEXT_READY")
        self.assertNotIn("done", MODULE.TERMINAL_SUCCESS_STATUSES)

    def test_event_records_transition_identity(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            MODULE.record_transition(
                package,
                old_status="TEXT_READY",
                new_status="IMAGE_PARTIAL",
                event="image_accepted",
                actor="xy-sort-v14",
                contract_id="xy-v2-test",
                asset_id="asset-1",
                prompt_version=3,
                attempt=2,
            )
            event = json.loads((package / "workflow_events.jsonl").read_text(encoding="utf-8"))
            self.assertEqual(event["old_status"], "TEXT_READY")
            self.assertEqual(event["new_status"], "IMAGE_PARTIAL")
            self.assertEqual(event["contract_id"], "xy-v2-test")
            self.assertEqual(event["attempt"], 2)


if __name__ == "__main__":
    unittest.main()
