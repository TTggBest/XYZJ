import importlib.util
import json
import sys
import unittest
from pathlib import Path


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
ASSET = SKILLS / "xy-place-v14/rules/channel_hashtag_whitelists.json"
RULES = SKILLS / "xy-place-v14/rules/description_rules.json"
SCRIPT = SKILLS / "xy-batch-v14/scripts/deterministic_batch.py"
sys.path.insert(0, str(SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("v14_hashtag_position_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)

PACK_SCRIPT = SKILLS / "xy-pack-v14/scripts/canonical_outputs.py"
PACK_SPEC = importlib.util.spec_from_file_location("v14_hashtag_position_canonical", PACK_SCRIPT)
CANONICAL = importlib.util.module_from_spec(PACK_SPEC)
sys.modules[PACK_SPEC.name] = CANONICAL
PACK_SPEC.loader.exec_module(CANONICAL)


class V14HashtagPositionContractTests(unittest.TestCase):
    def test_asset_has_one_mandatory_tag_and_registered_target_language_tags(self):
        asset = json.loads(ASSET.read_text(encoding="utf-8"))
        self.assertEqual(asset["mandatory_hashtags"], ["#cdrama"])
        self.assertEqual(asset["selection_count"], 12)
        self.assertEqual(asset["additional_selection_count"], 11)
        for channel, row in asset["channels"].items():
            with self.subTest(channel=channel):
                candidates = row["additional_whitelist"]
                target_tags = row["target_language_tags"]
                self.assertGreaterEqual(len(candidates), 11)
                self.assertTrue(target_tags)
                self.assertTrue(set(target_tags).issubset(candidates))
                self.assertNotIn("#cdrama", target_tags)

    def test_user_approved_hindi_and_bengali_sets_are_distributed_by_channel_direction(self):
        asset = json.loads(ASSET.read_text(encoding="utf-8"))["channels"]
        bengali_channels = ["নতুন করে আমি", "রাজকীয় প্রেমকথা", "ছোট্ট পরিবারের গল্প"]
        hindi_channels = ["दिल की शाही कहानी", "मेरी नई शुरुआत", "नन्हे रिश्तों की दुनिया"]
        expected_bengali = {
            "#বাংলাডাবিং", "#বাংলাড্রামা", "#চাইনিজড্রামা", "#চাইনিজড্রামাবাংলা",
            "#রোমান্টিকড্রামা", "#প্রেমেরগল্প", "#ভালোবাসারগল্প", "#পারিবারিকড্রামা",
            "#পারিবারিকগল্প", "#পরিবার", "#ভালোবাসা", "#বিয়ে", "#সম্পর্ক", "#প্রতিশোধ",
            "#বিশ্বাসঘাতকতা", "#নতুনশুরু", "#মাএবংসন্তান", "#মেয়েরগল্প", "#স্বামীস্ত্রী",
            "#পারিবারিকরহস্য",
        }
        expected_hindi = {
            "#हिंदीडब", "#हिंदीडबिंग", "#हिंदीड्रामा", "#चीनीड्रामा", "#रोमांटिकड्रामा",
            "#प्रेमकहानी", "#पारिवारिकड्रामा", "#पारिवारिककहानी", "#प्यारकीकहानी",
            "#भावनात्मककहानी", "#परिवार", "#रिश्ते", "#शादी", "#बदला", "#धोखा",
            "#सच्चाप्यार", "#नईशुरुआत", "#माँऔरबच्चा", "#माँबेटी", "#पति_पत्नी",
        }
        bengali_registered = set().union(
            *(set(asset[channel]["target_language_tags"]) for channel in bengali_channels)
        )
        hindi_registered = set().union(
            *(set(asset[channel]["target_language_tags"]) for channel in hindi_channels)
        )
        self.assertTrue(expected_bengali.issubset(bengali_registered))
        self.assertTrue(expected_hindi.issubset(hindi_registered))

    def test_resolver_exposes_asset_owned_position_contract(self):
        machine = {
            "channel_hashtag_whitelists": {
                "mandatory_hashtags": ["#cdrama"],
                "selection_count": 12,
                "additional_selection_count": 11,
                "channels": {
                    "频道甲": {
                        "additional_whitelist": [f"#标签{i}" for i in range(1, 12)],
                        "target_language_tags": ["#标签1", "#标签2"],
                    }
                },
            }
        }
        resolved = MODULE.resolved_channel_hashtag_whitelist(
            {"task": {"channel": "频道甲", "language": "测试语"}}, machine
        )
        self.assertEqual(resolved["mandatory_hashtags"], ["#cdrama"])
        self.assertEqual(resolved["target_language_tags"], ["#标签1", "#标签2"])
        self.assertEqual(resolved["selection_contract"]["cdrama_position"], 3)
        self.assertEqual(
            resolved["selection_contract"]["target_language_tag_required_within_positions"],
            [1, 2],
        )
        self.assertTrue(
            resolved["selection_contract"]["target_language_qualification_is_asset_owned"]
        )

    def test_generation_rules_drop_old_three_public_tag_requirement(self):
        rules = json.loads(RULES.read_text(encoding="utf-8"))["description_contract"]
        self.assertEqual(rules["mandatory_hashtags"], ["#cdrama"])
        self.assertEqual(rules["additional_hashtag_count"], 11)
        self.assertEqual(rules["cdrama_position"], 3)
        self.assertEqual(rules["target_language_tag_required_within_positions"], [1, 2])
        directive = MODULE.STAGE_DIRECTIVES["xy-place"]
        self.assertIn("Place #cdrama exactly once at position 3", directive)
        self.assertIn("At least one of positions 1 and 2", directive)
        self.assertNotIn("Include #cdrama, #ChineseDrama, and #ShortDrama exactly once", directive)

    def test_structural_validator_checks_cdrama_and_registered_lead_position(self):
        contract = {
            "mandatory_hashtags": ["#cdrama"],
            "cdrama_position": 3,
            "target_language_tag_required_within_positions": [1, 2],
        }
        whitelist = {
            "selection_count": 12,
            "mandatory_hashtags": ["#cdrama"],
            "additional_candidates": [f"#Tag{i}" for i in range(1, 12)],
            "target_language_tags": ["#Tag1"],
        }
        context = {
            "description_rule_contract": contract,
            "channel_hashtag_whitelist": whitelist,
        }
        valid = " ".join(["#Tag1", "#Tag2", "#cdrama", *[f"#Tag{i}" for i in range(3, 12)]])
        self.assertEqual(CANONICAL.channel_hashtag_whitelist_issues(valid, context), [])

        wrong_position = valid.replace("#Tag2 #cdrama", "#cdrama #Tag2")
        self.assertIn(
            "description_cdrama_position_mismatch:3",
            CANONICAL.channel_hashtag_whitelist_issues(wrong_position, context),
        )

        missing_target = " ".join(["#Tag2", "#Tag3", "#cdrama", "#Tag1", *[f"#Tag{i}" for i in range(4, 12)]])
        self.assertIn(
            "description_target_language_hashtag_missing_from_lead_positions",
            CANONICAL.channel_hashtag_whitelist_issues(missing_target, context),
        )


if __name__ == "__main__":
    unittest.main()
