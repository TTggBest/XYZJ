import importlib.util
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path


SCRIPTS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills/xy-batch-v14/scripts")
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
SPEC = importlib.util.spec_from_file_location("v14_market_find_batch", SCRIPTS / "deterministic_batch.py")
BATCH = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = BATCH
SPEC.loader.exec_module(BATCH)


def valid_market_payload():
    return {
        "schema_version": "1.0",
        "drama_id": "drama-1",
        "drama_title": "测试短剧",
        "searched_at": "2026-09-06T12:00:00+08:00",
        "search_status": "completed",
        "verified_market_angle_count": 1,
        "selection_context": {
            "channel_name": "频道甲",
            "channel_language": "印地",
            "channel_type": "豪门婚恋",
        },
        "search_window": {"primary": "recent_180d", "fallback": "none"},
        "market_videos": [
            {
                "market_video_id": "mv_001",
                "video_url": "https://www.youtube.com/watch?v=abcdefghijk",
                "video_title": "A market title",
                "channel_name": "Example Channel",
                "published_at": "2026-08-01",
                "views": 250000,
                "source_type": "external_youtube",
                "extracted_angle": "公开抛弃后当场改嫁",
                "extracted_visual_thesis": "婚礼现场女主转身选择另一位新郎",
                "fact_verification": {"status": "passed", "evidence": "剧情档案明确记录婚礼换新郎"},
                "eligible_for_angles": True,
                "evidence_freshness": "recent_180d",
            }
        ],
        "angle_candidates": [
            {
                "candidate_id": "candidate_001",
                "core_conflict": "婚礼公开抛弃与当场改嫁",
                "hook_a_fact": "未婚夫在婚礼当天离开",
                "hook_b_fact": "女主当场选择另一位新郎",
                "visual_moment": "女主从原新郎身边转向新郎的对手",
                "plot_evidence": "剧情档案明确记录该事件",
                "market_evidence_refs": ["mv_001"],
                "source_type": "external_market_verified",
                "market_confidence": "strong",
                "evidence_freshness": "recent_180d",
            }
        ],
        "final_angles": [
            {
                "angle_id": angle_id,
                "core_conflict": f"冲突{angle_id}",
                "hook_a_fact": f"A事实{angle_id}",
                "hook_b_fact": f"B事实{angle_id}",
                "visual_moment": f"视觉时刻{angle_id}",
                "plot_evidence": f"剧情证据{angle_id}",
                "market_evidence_refs": ["mv_001"] if angle_id == "A" else [],
                "channel_fit_reason": f"适合频道{angle_id}",
                "source_type": "external_market_verified" if angle_id == "A" else "story_derived",
                "market_confidence": "strong" if angle_id == "A" else "story_only",
                "evidence_freshness": "recent_180d" if angle_id == "A" else "none",
            }
            for angle_id in ("A", "B", "C")
        ],
        "fallback": {"used": True, "reason": "仅找到一个通过剧情核验的市场角度"},
    }


class MarketPackagingFindTests(unittest.TestCase):
    def setUp(self):
        retrieval = patch.object(BATCH, 'collect_agent_reach_evidence', return_value={
            'provider': 'agent-reach', 'status': 'failed', 'videos': [], 'reason': 'offline test'})
        retrieval.start()
        self.addCleanup(retrieval.stop)

    def test_failed_search_must_be_story_only_and_use_fallback(self):
        payload = valid_market_payload()
        payload["search_status"] = "failed"
        payload["verified_market_angle_count"] = 1
        payload["fallback"] = {"used": False, "reason": ""}
        issues = BATCH.validate_market_packaging_evidence(payload)
        self.assertIn("failed_search_must_have_zero_verified_market_angles", issues)
        self.assertIn("failed_search_must_use_fallback", issues)
        self.assertIn("failed_search_final_angles_must_be_story_derived", issues)

    def test_verified_market_contract_is_accepted_and_failed_video_cannot_be_eligible(self):
        self.assertTrue(hasattr(BATCH, "validate_market_packaging_evidence"), "V14 market evidence validator is missing")
        payload = valid_market_payload()
        self.assertEqual(BATCH.validate_market_packaging_evidence(payload), [])

        payload["market_videos"][0]["fact_verification"]["status"] = "failed"
        self.assertIn(
            "market_video_mv_001_failed_fact_verification_cannot_be_eligible",
            BATCH.validate_market_packaging_evidence(payload),
        )

    def test_market_evidence_identity_must_match_current_task(self):
        payload = valid_market_payload()
        payload["drama_title"] = "另一部剧"
        expected = {
            "drama_id": "drama-1",
            "drama_title": "测试短剧",
            "channel_name": "频道甲",
            "channel_language": "印地",
            "channel_type": "豪门婚恋",
        }
        try:
            issues = BATCH.validate_market_packaging_evidence(payload, expected)
        except TypeError as exc:
            self.fail(f"market evidence identity validation is missing: {exc}")
        self.assertIn("market_drama_title_mismatch", issues)

    def test_title_receives_only_final_angles_not_raw_market_videos(self):
        self.assertTrue(hasattr(BATCH, "market_context_for_title"), "V14 title market-context reducer is missing")
        reduced = BATCH.market_context_for_title(valid_market_payload())
        self.assertEqual([row["angle_id"] for row in reduced["final_angles"]], ["A", "B", "C"])
        self.assertNotIn("market_videos", reduced)
        self.assertNotIn("angle_candidates", reduced)

    def test_market_evidence_is_written_separately_from_plot_truth(self):
        self.assertTrue(hasattr(BATCH, "write_market_packaging_outputs"), "V14 market evidence writer is missing")
        payload = valid_market_payload()
        with tempfile.TemporaryDirectory() as temp_dir:
            package = Path(temp_dir)
            json_path, md_path = BATCH.write_market_packaging_outputs(package, payload)
            self.assertEqual(json_path.name, "01_市场包装证据.json")
            self.assertEqual(md_path.name, "01_市场包装证据.md")
            self.assertTrue(json_path.is_file())
            self.assertTrue(md_path.is_file())
            self.assertFalse((package / "01_搜索资料.json").exists())
            rendered = md_path.read_text(encoding="utf-8")
            self.assertIn("方向 A", rendered)
            self.assertIn("https://www.youtube.com/watch?v=abcdefghijk", rendered)

    def test_find_execution_writes_plot_truth_then_market_evidence(self):
        self.assertTrue(hasattr(BATCH, "execute_find_stage"), "V14 Find execution is not wired")

        plot_payload = {
            "section": "plot",
            "results": [
                {
                    "drama_name": "测试短剧",
                    "alias": "",
                    "plot_fields": {
                        "内容概述": "剧情事实",
                        "剧情档案": "人物关系",
                        "剧情套路": "反转",
                        "核心人设": "女主",
                    },
                }
            ],
        }

        class Library:
            def exact_match(self, drama_name, video_id, slot):
                self.args = (drama_name, video_id, slot)
                return plot_payload

        class Model:
            def generate(self, stage, prompt, item, attempt, output_schema=None):
                self.stage = stage
                self.prompt = prompt
                self.schema = output_schema
                payload = valid_market_payload()
                payload["drama_id"] = "abcdefghijk"
                return payload

        item = {
            "drama_name": "测试短剧",
            "video_id": "abcdefghijk",
            "slot": "2026090612",
            "channel": "频道甲",
            "language": "印地",
            "direction": "豪门婚恋",
        }
        library = Library()
        model = Model()
        with tempfile.TemporaryDirectory() as temp_dir:
            package = Path(temp_dir)
            BATCH.execute_find_stage(package, item, "market rules", library, model, 1)
            self.assertTrue((package / "01_搜索资料.json").is_file())
            self.assertTrue((package / "01_市场包装证据.json").is_file())
            self.assertEqual(library.args, ("测试短剧", "abcdefghijk", "2026090612"))
            self.assertEqual(model.stage, "xy-find-market")
            self.assertIn('agent_reach_search', model.prompt)
            self.assertIn('offline test', model.prompt)
            self.assertIn("剧情事实", model.prompt)
            self.assertIs(model.schema, BATCH.MARKET_PACKAGING_SCHEMA)

    def test_find_execution_falls_back_to_story_angles_when_web_call_fails(self):
        plot_payload = {
            "section": "plot",
            "results": [
                {
                    "drama_name": "测试短剧",
                    "alias": "",
                    "plot_fields": {
                        "内容概述": "剧情事实",
                        "剧情档案": "人物关系",
                        "剧情套路": "反转",
                        "核心人设": "女主",
                    },
                }
            ],
        }

        class Library:
            def exact_match(self, drama_name, video_id, slot):
                return plot_payload

        class Model:
            def __init__(self):
                self.stages = []

            def generate(self, stage, prompt, item, attempt, output_schema=None):
                self.stages.append(stage)
                if stage == "xy-find-market":
                    raise RuntimeError("web search unavailable")
                payload = valid_market_payload()
                payload["drama_id"] = "abcdefghijk"
                payload["search_status"] = "failed"
                payload["verified_market_angle_count"] = 0
                payload["search_window"]["fallback"] = "none"
                payload["market_videos"] = []
                payload["angle_candidates"] = []
                for angle in payload["final_angles"]:
                    angle["source_type"] = "story_derived"
                    angle["market_confidence"] = "story_only"
                    angle["evidence_freshness"] = "none"
                    angle["market_evidence_refs"] = []
                payload["fallback"] = {"used": True, "reason": "YouTube搜索不可用，按剧情事实回退"}
                self.assert_fallback_instruction = "不得声称已获得外部市场证据" in prompt
                return payload

        item = {
            "drama_name": "测试短剧",
            "video_id": "abcdefghijk",
            "slot": "2026090612",
            "channel": "频道甲",
            "language": "印地",
            "direction": "豪门婚恋",
        }
        model = Model()
        with tempfile.TemporaryDirectory() as temp_dir:
            package = Path(temp_dir)
            BATCH.execute_find_stage(package, item, "market rules", Library(), model, 1)
            self.assertEqual(model.stages, ["xy-find-market", "xy-find-story-fallback"])
            self.assertTrue(model.assert_fallback_instruction)
            saved = BATCH.load_json(package / "01_市场包装证据.json", {})
            self.assertEqual(saved["search_status"], "failed")
            self.assertEqual(saved["verified_market_angle_count"], 0)
            self.assertTrue(saved["fallback"]["used"])

    def test_downstream_resume_rewinds_to_find_when_market_angles_are_incomplete(self):
        plot_payload = {
            "section": "plot",
            "results": [
                {
                    "drama_name": "测试短剧",
                    "alias": "",
                    "plot_fields": {
                        "内容概述": "剧情事实",
                        "剧情档案": "人物关系",
                        "剧情套路": "反转",
                        "核心人设": "女主",
                    },
                }
            ],
        }
        item = {
            "drama_name": "测试短剧",
            "video_id": "abcdefghijk",
            "slot": "2026090612",
            "channel": "频道甲",
            "language": "印地",
            "direction": "豪门婚恋",
        }
        with tempfile.TemporaryDirectory() as temp_dir:
            package = Path(temp_dir)
            BATCH.write_stage_outputs(package, "xy-find", plot_payload)
            BATCH.write_json(
                package / "01_市场包装证据.json",
                {
                    "drama_id": "abcdefghijk",
                    "drama_title": "测试短剧",
                    "selection_context": {
                        "channel_name": "频道甲",
                        "channel_language": "印地",
                        "channel_type": "豪门婚恋",
                    },
                    "final_angles": [],
                },
            )
            self.assertTrue(
                hasattr(BATCH, "resume_stage_after_find_validation"),
                "V14 resume must revalidate Find before resuming a downstream stage",
            )
            self.assertEqual(
                BATCH.resume_stage_after_find_validation("xy-title", package, item, {}),
                "",
            )

    def test_interrupted_find_resume_restarts_find_when_market_evidence_is_missing(self):
        plot_payload = {
            "section": "plot",
            "results": [
                {
                    "drama_name": "测试短剧",
                    "alias": "",
                    "plot_fields": {
                        "内容概述": "剧情事实",
                        "剧情档案": "人物关系",
                        "剧情套路": "反转",
                        "核心人设": "女主",
                    },
                }
            ],
        }
        item = {
            "drama_name": "测试短剧",
            "video_id": "abcdefghijk",
            "slot": "2026090612",
            "channel": "频道甲",
            "language": "印地",
            "direction": "豪门婚恋",
        }
        with tempfile.TemporaryDirectory() as temp_dir:
            package = Path(temp_dir)
            BATCH.write_stage_outputs(package, "xy-find", plot_payload)

            self.assertEqual(
                BATCH.resume_stage_after_find_validation("xy-find", package, item, {}),
                "",
            )

if __name__ == "__main__":
    unittest.main()
