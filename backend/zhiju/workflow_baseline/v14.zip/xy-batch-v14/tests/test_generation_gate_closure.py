import importlib.util
import sys
import unittest
from pathlib import Path


BATCH_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "deterministic_batch.py"
PACK_SCRIPT = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts" / "canonical_outputs.py"
sys.path.insert(0, str(BATCH_SCRIPT.parent))
sys.path.insert(0, str(PACK_SCRIPT.parent))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


batch = load_module("deterministic_batch_gate_closure_test", BATCH_SCRIPT)
canonical = load_module("canonical_outputs_gate_closure_test", PACK_SCRIPT)


class GenerationGateClosureTests(unittest.TestCase):
    def test_place_generation_requires_primary_fields_and_all_registered_playlists_in_description(self):
        directive = batch.STAGE_DIRECTIVES["xy-place"]

        self.assertNotIn("Choose exactly one name+URL pair from playlists", directive)
        self.assertIn("playlist and url fields", directive)
        self.assertIn("every registered playlist", directive)

    def test_place_retry_names_every_missing_registered_playlist(self):
        prompt = batch.build_prompt(
            "xy-place",
            "place rules",
            {
                "task": {"drama_name": "测试剧"},
                "playlists": [
                    {"name": "主列表", "url": "https://www.youtube.com/playlist?list=PL_MAIN"},
                    {"name": "列表二", "url": "https://www.youtube.com/playlist?list=PL_TWO"},
                    {"name": "列表三", "url": "https://www.youtube.com/playlist?list=PL_THREE"},
                ],
            },
            [
                "description_missing_registered_playlist_2",
                "description_missing_registered_playlist_3",
            ],
        )

        self.assertIn("列表二 | https://www.youtube.com/playlist?list=PL_TWO", prompt)
        self.assertIn("列表三 | https://www.youtube.com/playlist?list=PL_THREE", prompt)
        self.assertIn("include every registered playlist", prompt)

    def test_cover_model_schema_is_not_reapplied_after_controller_assembly(self):
        schema = canonical.schema_for("xy-cover", {"workflow_contract_version": 2})

        def minimal(node):
            kind = node.get("type")
            if kind == "object":
                return {
                    key: minimal((node.get("properties") or {})[key])
                    for key in node.get("required", [])
                }
            if kind == "array":
                count = max(1, int(node.get("minItems", 0)))
                return [minimal(node.get("items") or {}) for _ in range(count)]
            if kind == "integer":
                return 1
            if node.get("enum"):
                return node["enum"][0]
            return "x"

        payload = minimal(schema)
        item = {
            "workflow_contract_version": 2,
            "drama_name": payload["results"][0]["drama_name"],
            "video_id": payload["results"][0]["video_id"],
        }
        context = {"output_schema": schema}

        self.assertEqual(
            canonical.validate_model_output_schema("xy-cover", payload, item, context),
            [],
        )
        canonical.normalize_cover_prompt_contract(payload)
        self.assertTrue(
            any("prompt_4_5_unexpected" in issue for issue in canonical.validate_model_output_schema(
                "xy-cover", payload, item, context
            ))
        )
        final_issues = canonical.validate_payload(
            "xy-cover", payload, item, context, validate_schema=False
        )
        self.assertFalse(any("_unexpected" in issue for issue in final_issues))


    def test_title_theme_alignment_does_not_require_fixed_localized_phrase(self):
        direction = {
            "title": "Anakku Menemukan Surat Itu! Siapa yang Menukar Hasil DNA?",
            "hook_a_fact": "她当众拒绝认亲。",
            "hook_b_fact": "DNA秘密仍未揭晓。",
            "specificity_anchor": "被调换的DNA样本",
            "translation": "我的孩子找到了那封信！谁调换了DNA结果！",
        }
        payload = {
            "results": [{
                "packaging_brief": {"core_story_promise": "孩子发现DNA被调换后的身份谜局"},
                "directions": [direction],
            }]
        }
        context = {
            "semantic_contract": {"version": 7},
            "channel_theme_contract": {
                "plot_supported": True,
                "channel_direction": "萌宝家庭",
                "required_output_signals": ["孩子", "萌宝", "女孩"],
            },
        }

        issues = canonical.channel_theme_alignment_issues("xy-title", payload, context)

        self.assertNotIn("title_1_channel_theme_not_prominent", issues)
        self.assertNotIn("packaging_brief_core_story_promise_not_channel_theme", issues)

    def test_title_theme_failure_has_nonempty_actionable_generation_feedback(self):
        prompt = batch.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "星河若无声灯火有归期"},
                "channel_theme_contract": {
                    "plot_supported": True,
                    "channel_direction": "萌宝家庭",
                    "required_output_signals": ["孩子", "萌宝", "女孩"],
                },
            },
            ["title_1_channel_theme_not_prominent"],
        )

        self.assertIn("failed title direction 1", prompt)
        self.assertIn("孩子, 萌宝, 女孩", prompt)
        self.assertNotIn("家庭团聚", prompt)
        self.assertNotIn("Controller-owned actionable correction instructions:\n\n", prompt)

    def test_v14_cover_does_not_recreate_deleted_fixed_theme_word_gate(self):
        payload = {"results": [{
            "story_hook": "董事会里她把股权文件推到桌中央",
            "scene": "集团会议室",
            "main_action": "女主公开签名页",
            "core_words_translation": "隐藏协议",
        }]}
        context = {
            "semantic_contract": {
                "version": 11,
                "fixed_localized_title_candidates": False,
            },
            "channel_theme_contract": {
                "plot_supported": True,
                "channel_direction": "复仇逆袭",
                "required_output_signals": ["复仇", "逆袭", "反击"],
            },
        }

        issues = canonical.channel_theme_alignment_issues("xy-cover", payload, context)

        self.assertEqual(issues, [])

    def test_cover_prompt_receives_validator_owned_acceptance_spec_before_generation(self):
        prompt = batch.build_prompt(
            "xy-cover",
            "cover rules",
            {
                "task": {"drama_name": "春迟海棠"},
                "cover_rule_contract": {
                    "prompt_audit": {
                        "minimum_real_drama_score_audit": 10,
                        "maximum_story_evidence_props": 2,
                        "hard_forbidden_ai_poster_terms": ["hologram"],
                    }
                },
            },
            [],
        )

        self.assertIn("Generation acceptance specification", prompt)
        self.assertIn('"real_drama_score": true', prompt)
        self.assertIn('"prompt_word_count": true', prompt)
        self.assertIn('"hard_forbidden_ai_poster_terms": ["hologram"]', prompt)
        self.assertIn('"prop_density": true', prompt)

    def test_cover_forbids_official_police_uniform_but_allows_plain_commercial_security(self):
        contract = canonical.load_cover_rule_bundle()
        policy = contract["prompt_audit"]["official_uniform_policy"]
        self.assertEqual(policy["enforcement"], "hard_generation_and_validation")
        self.assertTrue(hasattr(canonical, "cover_official_uniform_issues"))

        police_row = {
            "scene": "A Chinese police officer in a current PRC police uniform watches the family.",
            "scene_prompt_4_5": "A Chinese police officer wears a police cap, police badge, and police epaulettes.",
        }
        security_row = {
            "scene": "A commercial security guard watches the family.",
            "scene_prompt_4_5": "A commercial security guard wears a plain neutral security uniform without government insignia.",
        }

        self.assertEqual(
            canonical.cover_official_uniform_issues(police_row, 1, contract),
            ["cover_1_official_police_or_public_service_uniform_forbidden"],
        )
        self.assertEqual(canonical.cover_official_uniform_issues(security_row, 1, contract), [])

    def test_cover_generation_prompt_requires_plain_security_replacement(self):
        prompt = batch.build_prompt(
            "xy-cover",
            "cover rules",
            {
                "task": {"drama_name": "测试剧"},
                "cover_rule_contract": canonical.load_cover_rule_bundle(),
            },
            [],
        )

        self.assertIn("commercial security guard", prompt)
        self.assertIn("no government or police insignia", prompt)

    def test_cover_normalization_does_not_invent_context_free_drama_action(self):
        payload = {
            "results": [{
                "titles": [{
                    "core_words": "秘密",
                    "scene_prompt_4_5": (
                        "A mother turns in a garden under natural light with body overlap. Natural skin texture, ordinary clothing "
                        "wrinkles, realistic lens rendering, believable lighting, and softer environmental detail."
                    ),
                    "outpaint_environment": "Continue the garden hedge and daylight.",
                }]
            }]
        }

        canonical.normalize_cover_prompt_contract(payload)
        after = canonical.audit_cover_prompt(payload["results"][0]["titles"][0]["prompt_4_5"])

        self.assertLess(after["real_drama_score"], 10)
        self.assertNotIn("Controlled shock; asymmetrical blocking.", payload["results"][0]["titles"][0]["prompt_4_5"])

    def test_model_visual_history_is_bounded_before_generation_and_validation(self):
        rows = [{"scene_family": f"scene-{index}"} for index in range(96)]

        selected = batch.select_model_visual_history(rows)

        self.assertEqual(len(selected), batch.MODEL_VISUAL_HISTORY_LIMIT)
        self.assertLessEqual(batch.MODEL_VISUAL_HISTORY_LIMIT, 32)
        self.assertEqual(selected, rows[: batch.MODEL_VISUAL_HISTORY_LIMIT])

    def test_cover_uses_title_child_flag_without_reinterpreting_adult_sons(self):
        row = {
            "child_angle": False,
            "title": "我拒绝回到三个儿子的家！",
            "translation": "我拒绝回到三个儿子的家！",
            "hook_a_fact": "三名成年儿子与母亲断绝关系。",
            "hook_b_fact": "成年儿子后来请求她回家。",
            "specificity_anchor": "三名成年儿子",
            "safe_cover_scene": "三名成年儿子站在饭馆内。",
            "child_role": "三名成年儿子均为成年人。",
        }

        issues = canonical.title_direction_child_policy_issues(1, row, False)
        _, cover_child_required = canonical._cover_task_policy(
            {"task": {}, "channel_snapshot": ""},
            {},
            [dict(row, child_angle=True)],
        )

        self.assertEqual(issues, [])
        self.assertTrue(cover_child_required)

    def test_cover_generation_context_does_not_reinterpret_title_child_flag(self):
        context = {
            "task": {"drama_name": "春迟海棠"},
            "title_payload": {
                "results": [{
                    "directions": [{
                        "child_angle": True,
                        "hook_a_fact": "三名成年儿子与母亲断绝关系。",
                        "hook_b_fact": "成年儿子后来请求她回家。",
                        "specificity_anchor": "三名成年儿子",
                        "safe_cover_scene": "三名成年儿子站在饭馆内。",
                        "child_role": "三名成年儿子均为成年人。",
                    }]
                }]
            },
        }

        scoped = batch.stage_context("xy-cover", context)
        row = scoped["title_payload"]["results"][0]["directions"][0]

        self.assertTrue(row["child_angle"])

    def test_adult_daughter_frightened_does_not_trigger_child_safety(self):
        issues = canonical.cover_policy_issues(
            "An adult daughter is frightened while her healthy child smiles beside the mother.",
            1,
            female_frequency=True,
            child_required=True,
        )

        self.assertNotIn("cover_1_child_safety_violation", issues)

    def test_adult_tears_near_safe_child_do_not_trigger_child_safety(self):
        issues = canonical.cover_policy_issues(
            "The mother is tearful while her healthy five-year-old child smiles beside her, supervised and spatially safe.",
            2,
            female_frequency=True,
            child_required=True,
        )

        self.assertNotIn("cover_2_child_safety_violation", issues)

    def test_child_smiling_while_mother_is_frightened_does_not_transfer_risk(self):
        issues = canonical.cover_policy_issues(
            "The healthy child smiles while the mother is frightened by the adult revelation.",
            2,
            female_frequency=True,
            child_required=True,
        )

        self.assertNotIn("cover_2_child_safety_violation", issues)

    def test_risk_directly_applied_to_verified_minor_still_fails(self):
        issues = canonical.cover_policy_issues(
            "A frightened five-year-old child is threatened by an angry adult.",
            3,
            female_frequency=True,
            child_required=True,
        )

        self.assertIn("cover_3_child_safety_violation", issues)

    def test_system_error_and_content_error_are_distinct(self):
        system = batch.failure_result_for_exception(batch.SystemStageError("schema mismatch"))
        content = batch.failure_result_for_exception(RuntimeError("real child danger"))

        self.assertEqual(system["status"], "SYSTEM_ERROR")
        self.assertEqual(system["error_type"], "SYSTEM_ERROR")
        self.assertEqual(content["status"], "NEEDS_USER_REVIEW")
        self.assertEqual(content["error_type"], "CONTENT_ERROR")

if __name__ == "__main__":
    unittest.main()
