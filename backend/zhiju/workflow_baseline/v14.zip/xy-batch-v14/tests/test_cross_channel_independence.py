import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

from channel_context_fixture import structured_channel_snapshot


PACK_SCRIPTS = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts"
if str(PACK_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(PACK_SCRIPTS))

SCRIPT = PACK_SCRIPTS / "canonical_outputs.py"
SPEC = importlib.util.spec_from_file_location("canonical_outputs_independence_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)

BATCH_SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "deterministic_batch.py"
if str(BATCH_SCRIPT.parent) not in sys.path:
    sys.path.insert(0, str(BATCH_SCRIPT.parent))
BATCH_SPEC = importlib.util.spec_from_file_location("deterministic_batch_independence_test", BATCH_SCRIPT)
BATCH_MODULE = importlib.util.module_from_spec(BATCH_SPEC)
sys.modules[BATCH_SPEC.name] = BATCH_MODULE
BATCH_SPEC.loader.exec_module(BATCH_MODULE)

RULE_LOADER_SCRIPT = PACK_SCRIPTS / "skill_rule_loader.py"
RULE_LOADER_SPEC = importlib.util.spec_from_file_location(
    "skill_rule_loader_language_alias_test", RULE_LOADER_SCRIPT
)
RULE_LOADER_MODULE = importlib.util.module_from_spec(RULE_LOADER_SPEC)
sys.modules[RULE_LOADER_SPEC.name] = RULE_LOADER_MODULE
RULE_LOADER_SPEC.loader.exec_module(RULE_LOADER_MODULE)


def history(stage, result):
    return [
        {
            "channel": "另一个频道",
            "language": "西班牙语",
            "drama_name": "同一部剧",
            "video_id": "old-video",
            stage: {"results": [result]},
        }
    ]


class CrossChannelIndependenceTests(unittest.TestCase):
    def test_theme_support_ignores_internal_notes_outside_authoritative_plot_fields(self):
        item = {"direction": "萌宝家庭", "nickname": "女频-萌宝家庭"}
        plot = {"results": [{
            "plot_fields": {
                "内容概述": "成年总裁争夺公司控制权。",
                "剧情档案": "成年人的商业竞争。",
            },
            "internal_note": "萌宝孩子频道",
        }]}

        contract = BATCH_MODULE.channel_theme_contract(item, plot)

        self.assertFalse(contract["plot_supported"])
        self.assertEqual(contract["plot_support_signals"], [])

    def test_channel_theme_contract_contains_no_fixed_localized_candidate_library(self):
        item = {"direction": "萌宝家庭", "language": "西班牙", "nickname": "女频-萌宝家庭"}
        plot = {"results": [{"plot_fields": {"内容概述": "两个孩子发现亲子鉴定被调换。"}}]}

        contract = BATCH_MODULE.channel_theme_contract(item, plot)

        self.assertTrue(contract["plot_supported"])
        self.assertNotIn("localized_theme_phrases", contract)
        self.assertFalse(hasattr(BATCH_MODULE, "LOCALIZED_THEME_PHRASES"))

    def test_new_cross_channel_slot_has_identity_but_no_historical_creative_answers(self):
        pair = {
            "creative_slot_id": "old",
            "title_hook_preference": "public_exposure",
            "thumbnail_layout_preference": "foreground_reaction_background_witness",
        }
        index = {"items": [{
            "workflow_contract_version": 2, "channel": "频道B", "drama_name": "同一部剧",
            "language": "俄语", "direction": "豪门婚恋", "slot": "2026081700",
        }]}
        history = [{"items": [{
            "channel": "频道A", "drama_name": "同一部剧", "language": "西班牙",
            "direction": "萌宝家庭", "creative_slot": pair,
        }]}]

        BATCH_MODULE.allocate_creative_slots(index, history)

        created = index["items"][0]["creative_slot"]
        self.assertNotEqual(created["creative_slot_id"], pair["creative_slot_id"])
        self.assertNotIn("title_hook_preference", created)
        self.assertNotIn("thumbnail_layout_preference", created)
        self.assertEqual(created["creative_answer_policy"], "fresh_model_creation_no_candidate_library")

    def test_interrupted_writeback_keeps_existing_feishu_row_identity(self):
        index = {"items": [{
            "status": "running",
            "output_row_number": 23,
            "current_stage": "xy-cover",
        }]}

        changed = BATCH_MODULE.normalize_interrupted_items(index)

        self.assertEqual(changed, 1)
        self.assertEqual(index["items"][0]["status"], "WRITEBACK_PENDING")
        self.assertEqual(index["items"][0]["resume_from_stage"], "xy-cover")

    def test_rule_loader_uses_v2_rule_bundles(self):
        self.assertGreaterEqual(RULE_LOADER_MODULE.load_cover_rule_bundle()["version"], 5)
        self.assertGreaterEqual(RULE_LOADER_MODULE.load_community_rule_bundle()["version"], 2)
        self.assertGreaterEqual(
            RULE_LOADER_MODULE.load_description_rule_bundle("西班牙", "频道测试")["rules_version"],
            2,
        )

    def test_new_batch_snapshot_freezes_machine_rule_contracts(self):
        with tempfile.TemporaryDirectory() as temp_name:
            contracts = BATCH_MODULE.ContractBundle(Path(temp_name))

            self.assertEqual(contracts.snapshot["version"], BATCH_MODULE.CONTRACT_VERSION)
            self.assertTrue(contracts.snapshot["contract_id"].startswith("xy-v14-"))
            self.assertGreaterEqual(contracts.machine("xy-cover")["version"], 5)
            self.assertGreaterEqual(contracts.machine("xy-post")["version"], 2)
            self.assertGreaterEqual(contracts.machine("xy-place")["version"], 2)
            frozen_schema = contracts.schema("xy-cover", {"workflow_contract_version": 2})
            result_properties = frozen_schema["properties"]["results"]["items"]["properties"]
            self.assertIn("packaging_brief_id", result_properties)
            self.assertIn("xy-cover", contracts.snapshot["schema_contracts"])
            self.assertEqual(contracts.directive("xy-title"), BATCH_MODULE.STAGE_DIRECTIVES["xy-title"])
            self.assertIn("runtime_sources", contracts.snapshot)
            contracts.assert_runtime_compatible()

    def test_legacy_batch_without_machine_contract_keeps_its_frozen_behavior(self):
        with tempfile.TemporaryDirectory() as temp_name:
            batch_dir = Path(temp_name)
            legacy = {
                "version": 2,
                "rules": {
                    stage: {"sha256": "legacy", "content": f"legacy {stage}"}
                    for stage in BATCH_MODULE.ALL_STAGES
                },
            }
            (batch_dir / "生产契约快照.json").write_text(
                json.dumps(legacy, ensure_ascii=False), encoding="utf-8"
            )
            contracts = BATCH_MODULE.ContractBundle(batch_dir)
            context = {
                "description_rule_contract": {"forbid_studio_youtube_urls": True},
                "channel_snapshot": "播放列表：https://studio.youtube.com/playlist/PL123/videos",
            }

            scoped = BATCH_MODULE.with_frozen_machine_contract(context, contracts, "xy-place")

            self.assertEqual(scoped["description_rule_contract"], {})
            model_context = BATCH_MODULE.stage_context("xy-place", {
                "task": {"language": "西班牙", "channel": "频道测试"},
                "channel_snapshot": scoped["channel_snapshot"],
                "description_rule_contract": scoped["description_rule_contract"],
            })
            self.assertIn("studio.youtube.com", model_context["channel_snapshot"])
            self.assertEqual(
                MODULE.place_publication_issues(
                    {"url": "https://studio.youtube.com/playlist/PL123/videos", "description": ""},
                    "西班牙",
                    scoped["description_rule_contract"],
                ),
                [],
            )


    def test_studio_playlist_url_is_normalized_for_public_viewers(self):
        self.assertEqual(
            MODULE.public_playlist_url("https://studio.youtube.com/playlist/PLccMHfNv_iKs/videos"),
            "https://www.youtube.com/playlist?list=PLccMHfNv_iKs",
        )

    def test_playlist_snapshot_exposes_only_public_urls_to_generation(self):
        snapshot = (
            "播放列表：Familias | "
            "https://studio.youtube.com/playlist/PLccMHfNv_iKs/videos"
        )

        self.assertEqual(
            MODULE.playlists_from_snapshot(snapshot),
            [{
                "name": "Familias",
                "url": "https://www.youtube.com/playlist?list=PLccMHfNv_iKs",
            }],
        )

    def test_playlist_snapshot_strips_registered_route_label_from_name(self):
        snapshot = (
            "- 注册表允许路由：⚡ अपमान से शानदार वापसी | "
            "https://www.youtube.com/playlist?list=PLOJnzNM59JPM；"
            "👑 छुपी पहचान और अमीर परिवार | "
            "https://www.youtube.com/playlist?list=PLEcPMWeTWSYI"
        )

        self.assertEqual(
            MODULE.playlists_from_snapshot(snapshot),
            [
                {
                    "name": "⚡ अपमान से शानदार वापसी",
                    "url": "https://www.youtube.com/playlist?list=PLOJnzNM59JPM",
                },
                {
                    "name": "👑 छुपी पहचान और अमीर परिवार",
                    "url": "https://www.youtube.com/playlist?list=PLEcPMWeTWSYI",
                },
            ],
        )

    def test_playlist_snapshot_deduplicates_same_id_across_plain_and_quoted_assets(self):
        snapshot = (
            "- 播放列表：Familias | https://www.youtube.com/playlist?list=PLccMHfNv_iKs\n"
            "- \"Familias | https://studio.youtube.com/playlist/PLccMHfNv_iKs/videos\"\n"
        )

        self.assertEqual(
            MODULE.playlists_from_snapshot(snapshot),
            [{
                "name": "Familias",
                "url": "https://www.youtube.com/playlist?list=PLccMHfNv_iKs",
            }],
        )

    def test_playlist_url_without_id_is_rejected(self):
        issues = MODULE.place_publication_issues(
            {
                "url": "https://www.youtube.com/playlist?list=",
                "description": "https://www.youtube.com/playlist?list=",
            },
            "英语",
            {"forbid_studio_youtube_urls": True},
        )

        self.assertIn("playlist_url_missing_id", issues)
        self.assertIn("description_playlist_url_missing_id", issues)

    def test_spanish_description_rejects_english_template_labels_and_studio_links(self):
        result = {
            "url": "https://studio.youtube.com/playlist/PLccMHfNv_iKs/videos",
            "description": (
                "✨ Today’s story includes:\n🎯 Story type:\n"
                "https://studio.youtube.com/playlist/PLccMHfNv_iKs/videos"
            ),
        }

        issues = MODULE.place_publication_issues(result, "西班牙")

        self.assertIn("playlist_studio_url_forbidden", issues)
        self.assertIn("description_studio_url_forbidden", issues)
        self.assertIn("description_foreign_template_label_forbidden", issues)

    def test_english_description_keeps_english_template_labels(self):
        result = {
            "url": "https://www.youtube.com/playlist?list=PL123",
            "description": "✨ Today’s story includes:\n🎯 Story type:",
        }

        self.assertEqual(MODULE.place_publication_issues(result, "英语"), [])

    def test_target_language_description_rejects_chinese_and_internal_marker(self):
        result = {
            "drama_name": "妈咪本事大爹地别害怕",
            "url": "https://www.youtube.com/playlist?list=PL123",
            "description": (
                "বাংলা ডাব করা গল্প।\n"
                "😱厉集团 CEO মায়ের শক্তি দেখে চমকে গেলেন।\n"
                "==妈咪本事大爹地别害怕=="
            ),
            "translation": "厉氏集团总裁见识到母亲的力量。",
        }

        issues = MODULE.place_publication_issues(
            result,
            "孟加拉",
            {"forbid_chinese_characters_outside_final_marker": True},
        )

        self.assertIn("description_contains_chinese", issues)
        self.assertIn("description_contains_internal_marker", issues)

    def test_target_language_description_allows_chinese_review_translation_and_final_marker(self):
        result = {
            "drama_name": "妈咪本事大爹地别害怕",
            "url": "https://www.youtube.com/playlist?list=PL123",
            "description": "বাংলা ডাব করা গল্প।\n==妈咪本事大爹地别害怕==",
            "translation": "厉氏集团总裁见识到母亲的力量。",
        }

        issues = MODULE.place_publication_issues(
            result,
            "孟加拉",
            {"forbid_chinese_characters_outside_final_marker": True},
        )

        self.assertNotIn("description_contains_chinese_outside_final_marker", issues)

    def test_japanese_description_allows_kanji_used_by_the_target_language(self):
        result = {
            "drama_name": "妈咪本事大爹地别害怕",
            "url": "https://www.youtube.com/playlist?list=PL123",
            "description": (
                "彼女は家族の秘密を知り、自分の人生を取り戻した。\n"
                "==妈咪本事大爹地别害怕=="
            ),
        }

        issues = MODULE.place_publication_issues(
            result,
            "日语",
            {
                "forbid_chinese_characters_outside_final_marker": True,
                "chinese_character_check_exempt_languages": ["日语"],
            },
        )

        self.assertNotIn("description_contains_chinese_outside_final_marker", issues)

    def test_community_keeps_overlay_contract_but_rejects_ai_advertising_style(self):
        prompt = (
            "Natural live-action TV drama still with realistic lens rendering, natural skin texture, "
            "ordinary clothing wrinkles, believable lighting, and slightly softer environmental detail. "
            "Chinese facial features and contemporary Chinese short-drama actors. "
            "Hook sentence overlay: ¿Qué harías? Bottom CTA overlay: 🔔 Suscríbete 🙏 Comparte. "
            "Ultra sharp focus, crisp facial details, high micro-contrast, clean edges."
        )

        issues = MODULE.image_prompt_style_issues(prompt, "post_1")

        self.assertIn("post_1_overprocessed_advertising_style", issues)
        self.assertIn("Hook sentence overlay", prompt)
        self.assertIn("Bottom CTA overlay", prompt)

    def test_title_prompt_translates_order_and_child_plan_errors_into_actions(self):
        prompt = BATCH_MODULE.build_prompt(
            "xy-title",
            "title rules",
            {"task": {"drama_name": "一胎双宝，夫人拒不复婚"}},
            [
                "title_strongest_recommendation_not_first",
                "title_2_child_safe_cover_scene_missing",
            ],
        )

        self.assertIn("Give three unique recommendation_score values", prompt)
        self.assertIn("Re-read each supplied Find final angle independently", prompt)
        self.assertIn("only child fact is not yet born", prompt)

    def test_cover_prompt_translates_child_validation_codes_into_actionable_instructions(self):
        context = {
            "task": {"drama_name": "一胎双宝，夫人拒不复婚"},
            "title_payload": {"results": [{"directions": []}]},
        }
        prompt = BATCH_MODULE.build_prompt(
            "xy-cover",
            "cover rules",
            context,
            ["cover_1_child_angle_missing_visible_child", "cover_2_child_safety_violation"],
        )
        self.assertIn("only the failed cover groups", prompt)
        self.assertIn("Do not use the channel direction or drama name to add children", prompt)

    def test_cover_contract_rejects_blanket_background_text_bans(self):
        self.assertTrue(MODULE.has_blanket_background_text_ban(
            "Extend the rescue station with signage shapes without readable words."
        ))
        self.assertTrue(MODULE.has_blanket_background_text_ban(
            "Add no new people, children, text, logos, or boats."
        ))
        self.assertTrue(MODULE.has_blanket_background_text_ban(
            "No other visible text, letters, logos, subtitles, or watermarks."
        ))
        self.assertFalse(MODULE.has_blanket_background_text_ban(
            "Preserve the Portuguese core words exactly. Incidental Chinese rescue-station signage is allowed."
        ))

    def test_hindi_production_label_resolves_hindi_fixed_assets(self):
        bundle = RULE_LOADER_MODULE.load_description_rule_bundle("印地", "दिल की शाही कहानी")

        self.assertEqual(bundle["fixed_assets"]["welcome_line"], '💖 "दिल की शाही कहानी" में आपका स्वागत है।')
        self.assertIn("यहाँ", bundle["fixed_assets"]["welcome_body"])
        self.assertNotIn("Welcome to", json.dumps(bundle["fixed_assets"], ensure_ascii=False))

    def test_every_production_language_resolves_its_localized_fixed_assets(self):
        expected_opening = {
            "俄语": "Добро пожаловать",
            "印地": "स्वागत",
            "印尼": "Selamat datang",
            "土耳其": "hoş geldin",
            "孟加拉": "স্বাগতম",
            "巴葡": "Bem-vindo",
            "英语": "Welcome to",
            "菲律宾": "Maligayang pagdating",
            "西班牙": "Bienvenido",
            "阿拉伯语": "مرحبًا",
            "波兰": "Witaj",
            "泰语": "ยินดีต้อนรับ",
            "越南语": "Chào mừng",
            "法语": "Bienvenue",
            "乌尔都语": "خوش آمدید",
            "马来语": "Selamat datang",
            "德语": "Willkommen",
            "意大利语": "Benvenuti",
            "韩语": "환영합니다",
            "日语": "ようこそ",
            "希腊语": "Καλώς ήρθατε",
        }

        for language, marker in expected_opening.items():
            with self.subTest(language=language):
                assets = RULE_LOADER_MODULE.load_description_rule_bundle(language, "频道测试")["fixed_assets"]
                self.assertIn(marker, assets["welcome_line"])
                if language != "英语":
                    self.assertNotIn("Welcome to", json.dumps(assets, ensure_ascii=False))

        self.assertEqual(len(expected_opening), 21)

    def test_every_v14_language_has_complete_non_default_footer_assets(self):
        rules = json.loads(
            (Path(__file__).resolve().parents[2] / "xy-place-v14" / "rules" / "description_rules.json")
            .read_text(encoding="utf-8")
        )
        english = rules["fixed_assets_defaults"]["英语"]
        languages = [key for key in rules["fixed_assets_defaults"] if key != "default"]

        self.assertEqual(len(languages), 21)
        for language in languages:
            with self.subTest(language=language):
                assets = rules["fixed_assets_defaults"][language]
                self.assertEqual(
                    set(assets),
                    {"welcome_line", "welcome_body", "subscribe_line", "comment_line", "disclaimer_lines"},
                )
                self.assertEqual(len(assets["disclaimer_lines"]), 2)
                self.assertEqual(assets["welcome_line"].count("{channel_name}"), 1)
                if language != "英语":
                    self.assertNotEqual(assets["welcome_line"], english["welcome_line"])
                    self.assertNotEqual(assets["welcome_body"], english["welcome_body"])
                    self.assertNotEqual(assets["subscribe_line"], english["subscribe_line"])
                    self.assertNotEqual(assets["comment_line"], english["comment_line"])
                    self.assertNotEqual(assets["disclaimer_lines"], english["disclaimer_lines"])

    def test_v14_has_no_fixed_hashtag_defaults_or_hidden_hashtag_context(self):
        rules = json.loads(
            (Path(__file__).resolve().parents[2] / "xy-place-v14" / "rules" / "description_rules.json")
            .read_text(encoding="utf-8")
        )

        self.assertNotIn("hashtag_defaults", rules)
        self.assertNotIn("description_hashtags", BATCH_MODULE.STAGE_CONTEXT_KEYS["xy-place"])
        self.assertNotIn(
            "hashtags",
            RULE_LOADER_MODULE.load_description_rule_bundle("孟加拉", "测试频道"),
        )

    def test_v14_hashtag_directive_requires_exact_channel_whitelist_and_twelve_tags(self):
        directive = BATCH_MODULE.STAGE_DIRECTIVES["xy-place"]

        self.assertIn("Generate exactly 12 hashtags", directive)
        self.assertIn("Place #cdrama exactly once at position 3", directive)
        self.assertIn("At least one of positions 1 and 2", directive)
        self.assertIn("channel_hashtag_whitelist.additional_candidates", directive)
        self.assertIn("Never borrow from another channel", directive)
        self.assertIn("never invent, translate, concatenate, respell, change case", directive)
        self.assertNotIn("description_hashtags", directive)

    def test_v14_resolves_hashtag_candidates_for_exact_registered_channel(self):
        context = {"task": {"language": "孟加拉", "channel": "测试频道"}}
        machine = {
            "channel_hashtag_whitelists": {
                "mandatory_hashtags": ["#cdrama"],
                "selection_count": 12,
                "additional_selection_count": 11,
                "channels": {
                    "孟加拉": {
                        "additional_whitelist": [f"#Wrong{i}" for i in range(1, 12)],
                        "target_language_tags": ["#Wrong1"],
                    },
                    "测试频道": {
                        "additional_whitelist": [f"#Right{i}" for i in range(1, 12)],
                        "target_language_tags": ["#Right1"],
                    },
                },
            },
        }

        evidence = BATCH_MODULE.resolved_channel_hashtag_whitelist(context, machine)

        self.assertEqual(evidence["channel_name"], "测试频道")
        self.assertEqual(evidence["additional_candidates"], [f"#Right{i}" for i in range(1, 12)])
        self.assertNotIn("#Wrong1", evidence["additional_candidates"])

    def test_v14_fails_closed_when_exact_channel_has_no_whitelist(self):
        context = {"task": {"language": "孟加拉", "channel": "测试频道"}}
        machine = {
            "channel_hashtag_whitelists": {
                "mandatory_hashtags": ["#cdrama"],
                "selection_count": 12,
                "additional_selection_count": 11,
                "channels": {"同语言其他频道": {"additional_whitelist": [f"#Tag{i}" for i in range(9)]}},
            },
        }

        with self.assertRaisesRegex(RuntimeError, "channel_hashtag_whitelist_missing:测试频道"):
            BATCH_MODULE.resolved_channel_hashtag_whitelist(context, machine)

    def test_v14_hashtag_whitelist_preserves_registered_tag_spelling(self):
        context = {"task": {"language": "印地", "channel": "测试频道"}}
        machine = {
            "channel_hashtag_whitelists": {
                "mandatory_hashtags": ["#cdrama"],
                "selection_count": 12,
                "additional_selection_count": 11,
                "channels": {"测试频道": {"additional_whitelist": [
                    "#HindiDubbed", "#CEO", "#DNA", "#LoveStory", "#Revenge",
                    "#FamilyDrama", "#HiddenIdentity", "#Twins", "#SecondChance",
                    "#LocalDrama", "#DramaStory",
                ], "target_language_tags": ["#HindiDubbed"]}},
            },
        }

        evidence = BATCH_MODULE.resolved_channel_hashtag_whitelist(context, machine)

        self.assertEqual(evidence["additional_candidates"][0], "#HindiDubbed")

    def test_v14_place_context_exposes_only_current_channel_whitelist_to_existing_ai(self):
        context = {
            "task": {"language": "孟加拉", "channel": "测试频道"},
            "channel_hashtag_whitelist": {
                "channel_name": "测试频道",
                "additional_candidates": ["#bangladrama"],
            },
        }

        scoped = BATCH_MODULE.stage_context("xy-place", context)

        self.assertEqual(
            scoped["channel_hashtag_whitelist"]["additional_candidates"][0],
            "#bangladrama",
        )

    def test_v14_place_preflight_rejects_missing_channel_whitelist_before_model_call(self):
        context = {
            "task": {"workflow_contract_version": 2},
            "channel_theme_contract": {"channel_direction": "萌宝家庭"},
            "plot_payload": {"results": [{"plot_fields": {"内容概述": "测试"}}]},
            "title_payload": {"results": [{"packaging_brief": {"creative_slot_id": "slot"}}]},
            "description_fixed_assets": {"welcome_line": "ok"},
        }

        issues = BATCH_MODULE.stage_preflight_issues(
            "xy-place", context, {
                "description_contract": {"channel_hashtag_whitelist_required": True}
            }
        )

        self.assertIn("preflight_channel_hashtag_whitelist_missing", issues)

    def test_v14_place_validator_requires_all_three_base_hashtags_only(self):
        item = {
            "drama_name": "测试剧", "video_id": "video", "slot": "2026081901",
            "workflow_contract_version": 1, "language": "英语",
        }
        base_result = {
            "search_result_index": 1, "source_block_label": "搜索资料1",
            "result_id": "video_1", "video_id": "video", "drama_name": "测试剧",
            "playlist": "Playlist", "url": "https://www.youtube.com/playlist?list=PL123",
            "description": "#cdrama #ChineseDrama #ShortDrama #家庭秘密 #PolskiDramat\n\n==测试剧==",
            "translation": "中文审阅", "opening_hook_type": "identity_reveal",
            "payoff_hook_type": "truth_reveal", "editorial_anchor": "身份在宴会现场公开揭晓",
        }
        context = {
            "task": item, "playlists": [], "description_fixed_assets": {},
            "description_rule_contract": {
                "mandatory_hashtags": ["#cdrama", "#ChineseDrama", "#ShortDrama"],
            },
        }

        issues = MODULE.validate_place({"results": [base_result]}, item, context)

        self.assertNotIn("description_missing_cdrama", issues)
        self.assertNotIn("description_missing_chinesedrama", issues)
        self.assertNotIn("description_missing_shortdrama", issues)

        missing_result = dict(base_result)
        missing_result["description"] = base_result["description"].replace(" #ChineseDrama", "")
        missing_issues = MODULE.validate_place({"results": [missing_result]}, item, context)
        self.assertIn("description_missing_chinesedrama", missing_issues)

    def test_v14_place_validator_rejects_description_missing_registered_playlists(self):
        item = {
            "drama_name": "测试剧", "video_id": "video", "slot": "2026081901",
            "workflow_contract_version": 1, "language": "英语",
        }
        playlists = [
            {"name": "主列表", "url": "https://www.youtube.com/playlist?list=PL_MAIN"},
            {"name": "列表二", "url": "https://www.youtube.com/playlist?list=PL_TWO"},
            {"name": "列表三", "url": "https://www.youtube.com/playlist?list=PL_THREE"},
        ]
        payload = {"results": [{
            "search_result_index": 1, "source_block_label": "搜索资料1",
            "result_id": "video_1", "video_id": "video", "drama_name": "测试剧",
            "playlist": playlists[0]["name"], "url": playlists[0]["url"],
            "description": (
                "#cdrama #ChineseDrama #ShortDrama\n\n"
                "主列表 👉\nhttps://www.youtube.com/playlist?list=PL_MAIN\n\n"
                "==测试剧=="
            ),
            "translation": "中文审阅", "opening_hook_type": "identity_reveal",
            "payoff_hook_type": "truth_reveal", "editorial_anchor": "身份在宴会现场公开揭晓",
        }]}
        context = {
            "task": item, "playlists": playlists, "description_fixed_assets": {},
            "description_rule_contract": {},
        }

        issues = MODULE.validate_place(payload, item, context)

        self.assertIn("description_missing_registered_playlist_2", issues)
        self.assertIn("description_missing_registered_playlist_3", issues)

        complete = json.loads(json.dumps(payload, ensure_ascii=False))
        complete["results"][0]["description"] = (
            "#cdrama #ChineseDrama #ShortDrama\n\n"
            "主列表 👉\nhttps://www.youtube.com/playlist?list=PL_MAIN\n\n"
            "列表二 👉\nhttps://www.youtube.com/playlist?list=PL_TWO\n\n"
            "列表三 👉\nhttps://www.youtube.com/playlist?list=PL_THREE\n\n"
            "==测试剧=="
        )

        complete_issues = MODULE.validate_place(complete, item, context)

        self.assertFalse(any("description_missing_registered_playlist" in issue for issue in complete_issues))

    def test_v14_frozen_assets_fail_closed_for_unknown_language(self):
        context = {"task": {"language": "未知语言", "channel": "测试频道"}}
        machine = json.loads(
            (Path(__file__).resolve().parents[2] / "xy-place-v14" / "rules" / "description_rules.json")
            .read_text(encoding="utf-8")
        )

        with self.assertRaisesRegex(RuntimeError, "description_fixed_assets_language_missing"):
            BATCH_MODULE.resolved_description_assets(context, machine)

    def test_v14_language_asset_cannot_be_overridden_by_legacy_english_channel_file(self):
        context = {
            "task": {"language": "阿拉伯语", "channel": "حب الوريث"},
            "description_fixed_assets": {
                "welcome_line": '💖 Welcome to "حب الوريث".',
                "subscribe_line": "🔔 Subscribe for new complete stories.",
            },
        }
        machine = json.loads(
            (Path(__file__).resolve().parents[2] / "xy-place-v14" / "rules" / "description_rules.json")
            .read_text(encoding="utf-8")
        )

        assets = BATCH_MODULE.resolved_description_assets(context, machine)

        self.assertIn("مرحبًا", assets["welcome_line"])
        self.assertNotIn("Welcome to", json.dumps(assets, ensure_ascii=False))
        self.assertEqual(assets["source"], "batch_frozen_description_contract")

    def test_v14_controller_replaces_model_footer_with_exact_arabic_assets(self):
        assets = RULE_LOADER_MODULE.load_description_rule_bundle(
            "阿拉伯语", "حب الوريث"
        )["fixed_assets"]
        context = {"description_fixed_assets": assets}
        item = {"drama_name": "测试剧"}
        payload = {"results": [{
            "description": (
                "🔥 مقدمة خاصة بالقصة\n\n"
                "💖 Welcome to \"حب الوريث\".\n"
                "🔔 Subscribe for new complete stories.\n"
                "⚠️ This story is fictional.\n\n"
                "==测试剧=="
            )
        }]}

        MODULE.normalize_place_fixed_footer(payload, context, item)
        description = payload["results"][0]["description"]

        self.assertIn("🔥 مقدمة خاصة بالقصة", description)
        self.assertNotIn("Welcome to", description)
        self.assertNotIn("Subscribe for", description)
        self.assertNotIn(assets["welcome_line"], description)
        self.assertNotIn(assets["welcome_body"], description)
        self.assertNotIn(assets["comment_line"], description)
        self.assertIn(assets["subscribe_line"], description)
        self.assertNotIn("==测试剧==", description)
        for value in assets["disclaimer_lines"]:
            self.assertEqual(description.count(value), 1)

    def test_v14_controller_publishes_compact_footer_without_playlist_reason_or_internal_marker(self):
        assets = RULE_LOADER_MODULE.load_description_rule_bundle(
            "英语", "Test Channel"
        )["fixed_assets"]
        playlists = [
            {"name": "Family Stories", "url": "https://www.youtube.com/playlist?list=PLFAMILY"},
            {"name": "Romance Stories", "url": "https://www.youtube.com/playlist?list=PLROMANCE"},
            {"name": "Revenge Stories", "url": "https://www.youtube.com/playlist?list=PLREVENGE"},
        ]
        context = {"description_fixed_assets": assets, "playlists": playlists}
        item = {"drama_name": "Mermaid Mother"}
        payload = {"results": [{
            "playlist": "Romance Stories",
            "url": "https://www.youtube.com/playlist?list=PLROMANCE",
            "description": (
                "🔥 Her friend stole her identity.\n\n"
                "#HindiDub #Romance #cdrama #Betrayal #TrueLove #FamilyDrama "
                "#FamilySecret #IdentityReveal #FamilyReunion #CEORomance #HiddenIdentity #Drama\n\n"
                "👇 More stories like this:\n"
                "Romance Stories 👉\n"
                "https://www.youtube.com/playlist?list=PLROMANCE\n"
                "This playlist is the best match because the heroine was betrayed.\n\n"
                "📌 More playlists:\n"
                "1. Family Stories 👉\n"
                "https://www.youtube.com/playlist?list=PLFAMILY\n\n"
                "2. Revenge Stories 👉\n"
                "https://www.youtube.com/playlist?list=PLREVENGE\n\n"
                "💖 Welcome to Test Channel.\n"
                "💬 When did the truth come out?\n\n"
                "==Mermaid Mother=="
            ),
        }]}

        MODULE.normalize_place_fixed_footer(payload, context, item)
        description = payload["results"][0]["description"]

        self.assertNotIn("best match because", description)
        self.assertNotIn(assets["welcome_line"], description)
        self.assertNotIn(assets["welcome_body"], description)
        self.assertNotIn(assets["comment_line"], description)
        self.assertNotIn("==Mermaid Mother==", description)
        self.assertIn(assets["subscribe_line"], description)
        for value in assets["disclaimer_lines"]:
            self.assertEqual(description.count(value), 1)
        self.assertLess(description.index("Romance Stories"), description.index("Family Stories"))
        self.assertLess(description.index("Family Stories"), description.index("Revenge Stories"))
        for playlist in playlists:
            self.assertEqual(description.count(playlist["name"]), 1)
            self.assertEqual(description.count(playlist["url"]), 1)

    def test_v14_validator_does_not_require_legacy_welcome_or_interaction_lines(self):
        assets = RULE_LOADER_MODULE.load_description_rule_bundle(
            "英语", "Test Channel"
        )["fixed_assets"]
        description = "\n".join([
            "🔥 Story hook #cdrama",
            assets["welcome_line"],
            assets["welcome_body"],
            assets["subscribe_line"],
            *assets["disclaimer_lines"],
            "==测试剧==",
        ])
        item = {
            "drama_name": "测试剧", "video_id": "video", "slot": "2026081901",
            "workflow_contract_version": 1, "language": "英语",
        }
        payload = {"results": [{
            "search_result_index": 1, "source_block_label": "搜索资料1",
            "result_id": "video_1", "video_id": "video", "drama_name": "测试剧",
            "playlist": "Playlist", "url": "https://www.youtube.com/playlist?list=PL123",
            "description": description, "translation": "中文审阅",
            "opening_hook_type": "identity_reveal", "payoff_hook_type": "truth_reveal",
            "editorial_anchor": "身份在宴会现场公开揭晓",
        }]}
        context = {
            "task": item, "playlists": [], "description_fixed_assets": assets,
            "description_rule_contract": {},
        }

        issues = MODULE.validate_place(payload, item, context)

        self.assertFalse(any(issue.startswith("description_missing_fixed_asset_") for issue in issues))

    def test_model_context_replaces_english_auto_seed_for_hindi_channel(self):
        context = {
            "task": {"language": "印地", "channel": "दिल की शाही कहानी"},
            "identity": {},
            "channel_snapshot": structured_channel_snapshot(),
            "playlists": [],
            "description_fixed_assets": {
                "source": "xy-place/rules/description_rules.json",
                "language": "印地",
                "channel_name": "दिल की शाही कहानी",
                "welcome_line": '💖 Welcome to "दिल की शाही कहानी".',
                "welcome_body": "Here you can watch complete dubbed Chinese short dramas.",
                "subscribe_line": "🔔 Subscribe for new complete stories.",
                "comment_line": "💬 When did the truth come out?",
                "disclaimer_lines": ["⚠️ This content is authorized.", "This story is fictional."],
            },
            "plot_payload": {},
            "title_payload": {},
            "creative_history": [],
        }

        scoped = BATCH_MODULE.stage_context("xy-place", context)
        assets = scoped["description_fixed_assets"]

        self.assertIn("स्वागत", assets["welcome_line"])
        self.assertNotIn("Welcome to", json.dumps(assets, ensure_ascii=False))

    def test_visual_history_does_not_drop_entries_after_48(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name) / "工作流实验室" / "V2"
            current = root / "孟加拉" / "当前频道" / "剧目" / "当前剧_2026081210"
            current.mkdir(parents=True)
            for index in range(49):
                prior = root / "英语" / f"频道{index:02d}" / "剧目" / f"旧剧{index:02d}_20260801{index:02d}"
                prior.mkdir(parents=True)
                row = {
                    "scene_family": f"scene {index}",
                    "main_action": f"action {index}",
                    "key_prop": f"prop {index}",
                    "composition": f"composition {index}",
                    "palette": f"palette {index}",
                    "lighting": f"lighting {index}",
                }
                payload = {"results": [{"drama_name": f"旧剧{index:02d}", "titles": [row]}]}
                (prior / "04_封面提示词.json").write_text(
                    json.dumps(payload, ensure_ascii=False), encoding="utf-8"
                )

            rows = BATCH_MODULE.visual_history_for(
                current, {"channel": "当前频道", "drama_name": "当前剧"}
            )

            self.assertEqual(len(rows), 49)

    def test_cover_model_and_validator_receive_identical_selected_history(self):
        history = [
            {
                "scene_family": f"scene-{index}",
                "main_action": f"action-{index}",
                "key_prop": f"prop-{index}",
                "composition": f"composition-{index}",
                "palette": f"palette-{index}",
                "lighting": f"lighting-{index}",
            }
            for index in range(60)
        ]
        context = {
            "task": {},
            "identity": {},
            "channel_snapshot": {},
            "plot_payload": {},
            "title_payload": {},
            "visual_history": history,
            "creative_history": [],
        }

        scoped = BATCH_MODULE.stage_context("xy-cover", context)

        self.assertEqual(scoped["visual_history"], history)
        self.assertEqual(len(context["visual_history"]), 60)
        self.assertEqual(scoped["visual_history"][0]["scene_family"], "scene-0")

    def test_general_visual_history_rejects_semantic_rewording(self):
        current = {
            "scene_family": "company board room confrontation",
            "main_action": "woman forcefully drops the controlling-share document on the desk",
            "key_prop": "certificate proving controlling shares",
            "composition": "dramatic low-angle triangle blocking",
            "palette": "gold accents against cool blue",
            "lighting": "strong rim light from the windows",
        }
        previous = {
            "scene_family": "corporate boardroom showdown",
            "main_action": "heroine slams share certificate onto table",
            "key_prop": "controlling share certificate",
            "composition": "low angle triangular confrontation",
            "palette": "cold blue and gold",
            "lighting": "hard window rim light",
            "channel": "历史频道",
            "drama_name": "历史剧",
            "video_id": "old-video",
        }

        issues = MODULE.visual_history_collision_issues([current], [previous])

        self.assertTrue(any("history_1" in issue for issue in issues))

    def test_place_schema_requires_editorial_signature(self):
        result = {
            "search_result_index": 1,
            "source_block_label": "搜索资料1",
            "result_id": "v_1",
            "video_id": "v",
            "drama_name": "同一部剧",
            "playlist": "列表",
            "url": "https://example.test",
            "description": "description",
            "translation": "翻译",
        }
        issues = MODULE._schema_issues(
            {"section": "placement", "results": [result]}, MODULE.SCHEMAS["xy-place"]
        )
        self.assertTrue(any("opening_hook_type" in issue for issue in issues))

    def test_post_schema_requires_community_signature(self):
        result = {
            "search_result_index": 1,
            "source_block_label": "搜索资料1",
            "result_id": "v_1",
            "video_id": "v",
            "drama_name": "同一部剧",
            "image_prompt_1x1": "prompt",
            "copy": "copy",
            "copy_translation": "翻译",
        }
        issues = MODULE._schema_issues(
            {"section": "community", "results": [result]}, MODULE.SCHEMAS["xy-post"]
        )
        self.assertTrue(any("community_hook_type" in issue for issue in issues))

    def test_blank_creative_signatures_are_rejected(self):
        item = {"drama_name": "同一部剧", "video_id": "v", "slot": "2026081118"}
        identity = {
            "search_result_index": 1,
            "source_block_label": "搜索资料1",
            "result_id": "v_1",
            "video_id": "v",
            "drama_name": "同一部剧",
        }
        place = {
            **identity,
            "opening_hook_type": "",
            "payoff_hook_type": "",
            "editorial_anchor": "",
            "playlist": "列表",
            "url": "https://example.test",
            "description": "#cdrama\n==同一部剧==",
            "translation": "翻译",
        }
        post = {
            **identity,
            "community_hook_type": "",
            "selected_moment": "",
            "interaction_angle": "",
            "image_prompt_1x1": "Chinese short-drama Chinese facial features",
            "copy": "🔥 Hook\n👉 https://youtu.be/v\nLine 3\nLine 4\n🤔 Q\n👇 C\n🔔 S\n🙏 Share",
            "copy_translation": "翻译",
        }
        place_issues = MODULE.validate_payload(
            "xy-place", {"section": "placement", "results": [place]}, item, {"playlists": []}
        )
        post_issues = MODULE.validate_payload(
            "xy-post", {"section": "community", "results": [post]}, item, {}
        )
        self.assertIn("place_creative_signature_blank", place_issues)
        self.assertIn("post_creative_signature_blank", post_issues)

    def test_same_drama_history_loads_all_four_creative_stages(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name) / "工作流实验室" / "V2"
            prior = root / "西班牙语" / "频道甲" / "剧目" / "同一部剧_2026081110"
            current = root / "孟加拉语" / "频道乙" / "剧目" / "同一部剧_2026081118"
            prior.mkdir(parents=True)
            current.mkdir(parents=True)
            files = {
                "04_标题方案.json": {"results": [{"directions": [{"translation": "旧标题"}]}]},
                "04_封面提示词.json": {"results": [{"titles": [{"scene_family": "旧场景"}]}]},
                "place_result.json": {"results": [{"translation": "旧说明"}]},
                "06_社群方案.json": {"results": [{"copy_translation": "旧社群"}]},
            }
            for name, payload in files.items():
                (prior / name).write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")

            rows = BATCH_MODULE.creative_history_for(
                current,
                {"drama_name": "同一部剧", "channel": "频道乙", "video_id": "new-video"},
            )

            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["channel"], "频道甲")
            self.assertIn("title_payload", rows[0])
            self.assertIn("cover_payload", rows[0])
            self.assertIn("place_payload", rows[0])
            self.assertIn("post_payload", rows[0])

    def test_history_excludes_other_dramas(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name) / "工作流实验室" / "V2"
            prior = root / "西班牙语" / "频道甲" / "剧目" / "另一部剧_2026081110"
            current = root / "孟加拉语" / "频道乙" / "剧目" / "同一部剧_2026081118"
            prior.mkdir(parents=True)
            current.mkdir(parents=True)
            payload = {"results": [{"drama_name": "另一部剧", "directions": []}]}
            (prior / "04_标题方案.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")

            rows = BATCH_MODULE.creative_history_for(
                current,
                {"drama_name": "同一部剧", "channel": "频道乙", "video_id": "new-video"},
            )

            self.assertEqual(rows, [])

    def test_different_editorial_angles_are_allowed(self):
        old = {
            "translation": "她在婚礼上揭穿未婚夫出轨，转身嫁给隐藏身份的继承人。"
        }
        new = {
            "translation": "母亲留下的旧账本揭开公司黑幕，她联合员工夺回工厂控制权。"
        }
        issues = MODULE.creative_collision_issues(
            "xy-place", {"results": [new]}, {"creative_history": history("place_payload", old)}
        )
        self.assertEqual(issues, [])

    def test_model_receives_only_current_stage_negative_history(self):
        context = {
            "task": {},
            "identity": {},
            "channel_snapshot": structured_channel_snapshot(),
            "plot_payload": {},
            "creative_history": [
                {
                    "channel": "频道甲",
                    "drama_name": "同一部剧",
                    "title_payload": {"results": [{"directions": []}]},
                    "cover_payload": {"results": [{"titles": []}]},
                    "place_payload": {"results": [{"translation": "说明"}]},
                    "post_payload": {"results": [{"copy_translation": "社群"}]},
                }
            ],
        }
        scoped = BATCH_MODULE.stage_context("xy-title", context)
        row = scoped["creative_history"][0]
        self.assertIn("title_payload", row)
        self.assertNotIn("cover_payload", row)
        self.assertNotIn("place_payload", row)
        self.assertNotIn("post_payload", row)

    def test_negative_history_is_compact_enough_for_batch_speed(self):
        context = {
            "task": {},
            "identity": {},
            "channel_snapshot": "snapshot",
            "plot_payload": {},
            "title_payload": {},
            "playlists": [],
            "description_fixed_assets": {},
            "creative_history": [
                {
                    "channel": "频道甲",
                    "drama_name": "同一部剧",
                    "place_payload": {"results": [{"translation": "旧说明" * 3000}]},
                }
            ],
        }
        scoped = BATCH_MODULE.stage_context("xy-place", context)
        translation = scoped["creative_history"][0]["place_payload"]["results"][0]["translation"]
        self.assertLessEqual(len(translation), 1600)

    def test_compact_history_preserves_place_creative_signature(self):
        context = {
            "task": {}, "identity": {}, "channel_snapshot": "snapshot",
            "plot_payload": {}, "title_payload": {}, "playlists": [],
            "description_fixed_assets": {},
            "creative_history": [{
                "channel": "频道甲", "drama_name": "同一部剧",
                "place_payload": {"results": [{
                    "opening_hook_type": "forced_choice",
                    "payoff_hook_type": "marriage_reveal",
                    "editorial_anchor": "手术前叫停程序并签订婚姻契约",
                    "translation": "旧说明",
                }]},
            }],
        }

        scoped = BATCH_MODULE.stage_context("xy-place", context)
        result = scoped["creative_history"][0]["place_payload"]["results"][0]

        self.assertEqual(result["opening_hook_type"], "forced_choice")
        self.assertEqual(result["payoff_hook_type"], "marriage_reveal")
        self.assertEqual(result["editorial_anchor"], "手术前叫停程序并签订婚姻契约")

    def test_compact_history_preserves_post_creative_signature(self):
        context = {
            "task": {}, "identity": {}, "channel_snapshot": "snapshot",
            "plot_payload": {}, "title_payload": {}, "place_payload": {},
            "community_footer_cta": {},
            "creative_history": [{
                "channel": "频道甲", "drama_name": "同一部剧",
                "post_payload": {"results": [{
                    "community_hook_type": "identity_reveal",
                    "selected_moment": "董事会亮出继承证明",
                    "interaction_angle": "你会当场反击吗",
                    "copy_translation": "旧社群",
                    "image_prompt_1x1": "old image",
                }]},
            }],
        }

        scoped = BATCH_MODULE.stage_context("xy-post", context)
        result = scoped["creative_history"][0]["post_payload"]["results"][0]

        self.assertEqual(result["community_hook_type"], "identity_reveal")
        self.assertEqual(result["selected_moment"], "董事会亮出继承证明")
        self.assertEqual(result["interaction_angle"], "你会当场反击吗")

    def test_stage_validator_applies_cross_channel_gate(self):
        item = {
            "drama_name": "同一部剧",
            "video_id": "new-video",
            "slot": "2026081118",
        }
        current = {
            "search_result_index": 1,
            "source_block_label": "搜索资料1",
            "result_id": "new-video_1",
            "video_id": "new-video",
            "drama_name": "同一部剧",
            "copy": "🔥 Hook\n👉 https://youtu.be/new-video\nLine 3\nLine 4\n🤔 Question\n👇 Comment\n🔔 Subscribe\n🙏 Share",
            "community_hook_type": "identity_reveal",
            "selected_moment": "公开继承人身份",
            "interaction_angle": "你会如何反击",
            "copy_translation": "所有人都以为赶走她就赢了，直到她在公司会议亮出继承证明。你会立即反击吗？",
            "image_prompt_1x1": "Chinese short-drama corporate board room, Chinese facial features, woman reveals inheritance document, enemies shocked",
        }
        old = {
            "copy_translation": "他们以为她被赶走就输了，直到她在董事会上亮出继承文件。你会当场反击吗？",
            "image_prompt_1x1": "Chinese short-drama boardroom, Chinese facial features, heroine reveals inheritance file, rivals shocked",
        }
        issues = MODULE.validate_payload(
            "xy-post",
            {"section": "community", "results": [current]},
            item,
            {"creative_history": history("post_payload", old)},
        )
        self.assertIn("post_cross_channel_package_collision", issues)

    def test_title_rejects_translated_reuse_of_same_hook_package(self):
        result = {
            "directions": [
                {
                    "hook_a_type": "betrayal",
                    "hook_a_fact": "丈夫逼我净身出户",
                    "hook_b_type": "wealth_reveal",
                    "hook_b_fact": "我亮出首富继承人身份让他破产",
                    "specificity_anchor": "离婚协议",
                    "translation": "丈夫逼我净身出户！我亮出首富继承人身份让他破产！",
                },
                {
                    "hook_a_type": "public_attack",
                    "hook_a_fact": "情人在董事会上羞辱我",
                    "hook_b_type": "power_reversal",
                    "hook_b_fact": "我收回股份赶走他们全家",
                    "specificity_anchor": "股权书",
                    "translation": "情人在董事会上羞辱我！我收回股份赶走他们全家！",
                },
                {
                    "hook_a_type": "theft",
                    "hook_a_fact": "父亲偷走母亲公司",
                    "hook_b_type": "revenge",
                    "hook_b_fact": "我回国夺回公司送他入狱",
                    "specificity_anchor": "母亲遗嘱",
                    "translation": "父亲偷走母亲公司！我回国夺回公司送他入狱！",
                },
            ]
        }
        payload = {"results": [result]}
        issues = MODULE.creative_collision_issues(
            "xy-title", payload, {"creative_history": history("title_payload", result)}
        )
        self.assertIn("title_cross_channel_package_collision", issues)

    def test_cover_rejects_semantically_same_scene_action_with_rewording(self):
        old_result = {
            "titles": [
                {
                    "story_hook": "她在董事会上公开夺回公司",
                    "scene_family": "corporate boardroom showdown",
                    "main_action": "heroine slams share certificate onto table",
                    "key_prop": "controlling share certificate",
                    "composition": "low angle triangular confrontation",
                    "palette": "cold blue and gold",
                    "lighting": "hard window rim light",
                    "prompt_4_5": "boardroom prompt",
                }
            ]
        }
        new_result = {
            "titles": [
                {
                    "story_hook": "女主在公司会议公开拿回控制权",
                    "scene_family": "company board room confrontation",
                    "main_action": "woman forcefully drops the controlling-share document on the desk",
                    "key_prop": "certificate proving controlling shares",
                    "composition": "dramatic low-angle triangle blocking",
                    "palette": "gold accents against cool blue",
                    "lighting": "strong rim light from the windows",
                    "prompt_4_5": "another boardroom prompt",
                }
            ]
        }
        issues = MODULE.creative_collision_issues(
            "xy-cover", {"results": [new_result]}, {"creative_history": history("cover_payload", old_result)}
        )
        self.assertIn("cover_cross_channel_package_collision", issues)

    def test_place_rejects_same_public_description_angle(self):
        old_result = {
            "description": "Her husband cast her out, but she returned to the board meeting as the heir and took back her mother's company."
        }
        new_result = {
            "description": "Her husband threw her out, yet she came back to the boardroom as the heir and reclaimed her mother's company."
        }
        issues = MODULE.creative_collision_issues(
            "xy-place", {"results": [new_result]}, {"creative_history": history("place_payload", old_result)}
        )
        self.assertIn("place_cross_channel_package_collision", issues)

    def test_post_rejects_same_community_concept(self):
        old_result = {
            "copy_translation": "他们以为她被赶走就输了，直到她在董事会上亮出继承文件。你会当场反击吗？",
            "image_prompt_1x1": "Chinese short-drama boardroom, heroine reveals inheritance file, rivals shocked",
        }
        new_result = {
            "copy_translation": "所有人都以为赶走她就赢了，直到她在公司会议亮出继承证明。你会立即反击吗？",
            "image_prompt_1x1": "Chinese short-drama corporate board room, woman reveals inheritance document, enemies shocked",
        }
        issues = MODULE.creative_collision_issues(
            "xy-post", {"results": [new_result]}, {"creative_history": history("post_payload", old_result)}
        )
        self.assertIn("post_cross_channel_package_collision", issues)

    def test_place_rejects_same_structured_editorial_signature(self):
        old = {
            "opening_hook_type": "forced_choice",
            "payoff_hook_type": "marriage_reveal",
            "editorial_anchor": "手术前叫停堕胎并契约结婚",
            "translation": "完全不同的旧说明文本",
        }
        new = {
            "opening_hook_type": "forced_choice",
            "payoff_hook_type": "marriage_reveal",
            "editorial_anchor": "堕胎手术被叫停后签订婚姻契约",
            "translation": "另一套不同措辞，字符串不会直接相似",
        }
        issues = MODULE.creative_collision_issues(
            "xy-place", {"results": [new]}, {"creative_history": history("place_payload", old)}
        )
        self.assertIn("place_cross_channel_package_collision", issues)

    def test_post_rejects_same_structured_moment_signature(self):
        old = {
            "community_hook_type": "marriage_reveal",
            "selected_moment": "总裁在手术前叫停程序",
            "interaction_angle": "你会相信曾经怀疑你的总裁吗",
            "copy_translation": "旧社群文本",
            "image_prompt_1x1": "old visual",
        }
        new = {
            "community_hook_type": "marriage_reveal",
            "selected_moment": "手术开始前CEO突然叫停",
            "interaction_angle": "被怀疑后你还会相信CEO吗",
            "copy_translation": "完全不同的新社群文本",
            "image_prompt_1x1": "new visual",
        }
        issues = MODULE.creative_collision_issues(
            "xy-post", {"results": [new]}, {"creative_history": history("post_payload", old)}
        )
        self.assertIn("post_cross_channel_package_collision", issues)


if __name__ == "__main__":
    unittest.main()
