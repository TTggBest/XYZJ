import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "prepare_daily_rebuild_scope.py"
SPEC = importlib.util.spec_from_file_location("prepare_daily_rebuild_under_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class PrepareDailyRebuildScopeTests(unittest.TestCase):
    def test_combines_prepared_batch_and_new_pending_item(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            tsv = root / "daily.tsv"
            tsv.write_text(
                "剧名\t剧id\t地址\t频道\t档期\t是否需要社区\n"
                "剧A\tvideo-a\thttps://youtu.be/a\t频道A\t2026081906\t2\n"
                "一胎双宝，夫人拒不复婚\t\t\tছোট্ট পরিবারের গল্প\t2026081920\t2\n",
                encoding="utf-8",
            )
            first = root / "source-a" / "今日任务索引.json"
            first.parent.mkdir()
            first.write_text(json.dumps({"items": [{
                "row_number": 2, "video_id": "video-a", "drama_name": "剧A",
                "channel": "频道A", "slot": "2026081906", "community_count": 2,
                "status": "INITIALIZED",
            }]}), encoding="utf-8")
            second = root / "source-b" / "今日任务索引.json"
            second.parent.mkdir()
            second.write_text(json.dumps({"items": [{
                "row_number": 2, "video_id": "pending-1", "drama_name": "一胎双宝，夫人拒不复婚",
                "channel": "ছোট্ট পরিবারের গল্প", "slot": "2026081920", "community_count": 2,
                "status": "INITIALIZED",
            }]}), encoding="utf-8")
            scope = MODULE.build_daily_rebuild_scope(
                tsv, [first, second], batch_id="V2-19-FULL39-R3",
                target_contract_id="xy-v14-0123456789abcdefabcd",
                expected_items=2, expected_channels=2,
            )
            self.assertEqual(len(scope["items"]), 2)
            self.assertEqual([row["output_row_number"] for row in scope["items"]], [2, 3])
            self.assertEqual(scope["items"][1]["video_id"], "pending-1")


if __name__ == "__main__":
    unittest.main()
