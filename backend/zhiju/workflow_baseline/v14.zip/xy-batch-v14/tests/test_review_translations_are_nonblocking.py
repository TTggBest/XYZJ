import importlib.util
import sys
import unittest
from pathlib import Path


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
PACK_SCRIPTS = SKILLS / "xy-pack-v14/scripts"
if str(PACK_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(PACK_SCRIPTS))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


CANONICAL = load_module(
    "v14_review_translation_contract_test",
    PACK_SCRIPTS / "canonical_outputs.py",
)


class ReviewTranslationContractTests(unittest.TestCase):
    def test_place_chinese_review_translation_cannot_fail_theme_alignment(self):
        payload = {
            "results": [
                {
                    "editorial_anchor": "婚姻中的公开选择",
                    "channel_theme_phrase": "Pag-ibig na muling pinili",
                    "channel_theme_phrase_translation": "重新选择的爱情",
                    "description": "Pag-ibig na muling pinili.",
                    "translation": "这是一段重新选择的爱情。",
                }
            ]
        }
        context = {
            "semantic_contract": {"version": 11},
            "channel_theme_contract": {
                "channel_direction": "豪门婚恋",
                "plot_supported": True,
                "required_output_signals": ["婚姻", "结婚", "离婚"],
            },
        }

        issues = CANONICAL.channel_theme_alignment_issues("xy-place", payload, context)

        self.assertNotIn("place_localized_theme_phrase_translation_not_theme", issues)

    def test_blank_description_review_translation_does_not_block_public_description(self):
        item = {"drama_name": "测试剧", "video_id": "v"}
        result = {
            "search_result_index": 1,
            "source_block_label": "搜索资料1",
            "result_id": "v_1",
            "video_id": "v",
            "drama_name": "测试剧",
            "opening_hook_type": "betrayal",
            "payoff_hook_type": "power_reversal",
            "editorial_anchor": "婚姻关系中的公开选择",
            "playlist": "列表",
            "url": "https://example.test/playlist",
            "description": "Public target-language description.\n==测试剧==",
            "translation": "",
        }

        issues = CANONICAL.validate_payload(
            "xy-place",
            {"section": "placement", "results": [result]},
            item,
            {"playlists": []},
            validate_schema=False,
        )

        self.assertNotIn("place_translation_blank", issues)

    def test_blank_community_review_translation_does_not_block_public_copy(self):
        item = {"drama_name": "测试剧", "video_id": "v"}
        result = {
            "search_result_index": 1,
            "source_block_label": "搜索资料1",
            "result_id": "v_1",
            "video_id": "v",
            "drama_name": "测试剧",
            "community_hook_type": "identity_reveal",
            "selected_moment": "女主在家族聚会上被公开承认",
            "interaction_angle": "观众判断她是否应接受这段关系",
            "image_prompt_1x1": "Chinese short-drama scene with Chinese facial features.",
            "copy": (
                "🔥 Watch here 👉 https://youtu.be/v\n"
                "The family rejects her.\n"
                "One choice changes the room.\n"
                "She is finally recognized.\n"
                "🤔 Would you accept them?\n"
                "👇 Tell us below.\n"
                "🔔 Subscribe.\n"
                "🙏 Share."
            ),
            "copy_translation": "",
        }

        issues = CANONICAL.validate_payload(
            "xy-post",
            {"section": "community", "results": [result]},
            item,
            {},
            validate_schema=False,
        )

        self.assertNotIn("post_1_translation_blank", issues)

    def test_title_child_policy_ignores_chinese_review_translation(self):
        row = {
            "title": "I was rejected, then I took back my place!",
            "translation": "孩子被羞辱后我夺回位置",
            "hook_a_fact": "成年女主被拒绝",
            "hook_b_fact": "成年女主夺回位置",
            "specificity_anchor": "公开选择",
            "child_angle": False,
        }

        issues = CANONICAL.title_direction_child_policy_issues(1, row, False)

        self.assertNotIn("title_1_minor_humiliation_or_age_inappropriate", issues)
        self.assertNotIn("title_1_child_angle_flag_missing", issues)

    def test_title_review_translation_does_not_define_public_payoff_acceptance(self):
        issues = CANONICAL.title_public_clarity_issues(
            1,
            "他公开选择我",
            "我离开旧关系！他终于后悔！",
            "A！B！",
            "",
        )

        self.assertNotIn("title_1_public_payoff_anchor_not_in_B", issues)

    def test_cross_channel_title_collision_uses_public_titles_not_review_translations(self):
        current = {
            "directions": [
                {
                    "hook_a_type": "betrayal",
                    "hook_b_type": "power_reversal",
                    "specificity_anchor": "公开婚礼",
                    "title": "My groom left, so I chose a new life!",
                    "translation": "相同的中文审核翻译",
                }
            ]
        }
        previous = {
            "directions": [
                {
                    "hook_a_type": "public_attack",
                    "hook_b_type": "identity_reveal",
                    "specificity_anchor": "家族晚宴",
                    "title": "They denied me until the family chose me!",
                    "translation": "相同的中文审核翻译",
                }
            ]
        }

        issues = CANONICAL.creative_collision_issues(
            "xy-title",
            {"results": [current]},
            {"creative_history": [{"title_payload": {"results": [previous]}}]},
        )

        self.assertNotIn("title_cross_channel_package_collision", issues)

    def test_cover_does_not_require_title_review_translation_to_match(self):
        title_payload = {
            "results": [
                {
                    "directions": [
                        {"title": f"Public title {index}", "translation": f"审核翻译{index}", "visual_thesis": f"visible event {index}"}
                        for index in range(1, 4)
                    ]
                }
            ]
        }
        cover_payload = {
            "results": [
                {
                    "titles": [
                        {
                            "title_index": index,
                            "title": f"Public title {index}",
                            "title_translation": "不同或空白的审核翻译",
                            "visual_thesis": f"visible event {index}",
                        }
                        for index in range(1, 4)
                    ]
                }
            ]
        }

        issues = CANONICAL.validate_cover(
            cover_payload,
            {"drama_name": "测试剧", "video_id": "v"},
            {"title_payload": title_payload},
        )

        self.assertFalse(any("title_translation_mismatch" in issue for issue in issues))

    def test_cross_channel_post_collision_uses_public_copy_not_review_translation(self):
        current = {
            "community_hook_type": "identity_reveal",
            "selected_moment": "女主在婚礼上离开旧关系",
            "interaction_angle": "观众判断她是否应重新开始",
            "copy": "She leaves the wedding and chooses a new life.",
            "copy_translation": "相同的中文审核翻译",
            "image_prompt_1x1": "A bright outdoor wedding exit with one Chinese heroine.",
        }
        previous = {
            "community_hook_type": "child_recognition",
            "selected_moment": "孩子在家中主动拥抱母亲",
            "interaction_angle": "观众判断这次团聚是否可信",
            "copy": "The children welcome their mother home.",
            "copy_translation": "相同的中文审核翻译",
            "image_prompt_1x1": "A warm Chinese family reunion in a modest living room.",
        }

        issues = CANONICAL.creative_collision_issues(
            "xy-post",
            {"results": [current]},
            {"creative_history": [{"post_payload": {"results": [previous]}}]},
        )

        self.assertNotIn("post_cross_channel_package_collision", issues)

    def test_sibling_post_collision_uses_public_copy_not_review_translation(self):
        shared = {
            "scene_family": "family lounge",
            "palette": "warm daylight",
            "copy_translation": "相同的中文审核翻译",
        }
        results = [
            {
                **shared,
                "selected_moment": "女主决定离开旧关系",
                "interaction_angle": "是否应该接受新的开始",
                "main_action": "heroine removes her ring",
                "key_prop": "ring",
                "composition": "single close triangle",
                "copy": "She chooses to leave the old relationship.",
                "image_prompt_1x1": "A Chinese heroine leaving a quiet family lounge.",
            },
            {
                **shared,
                "selected_moment": "孩子主动回到母亲身边",
                "interaction_angle": "这次团聚是否值得相信",
                "main_action": "children embrace their mother",
                "key_prop": "none",
                "composition": "warm centered reunion",
                "copy": "The children choose to welcome their mother home.",
                "image_prompt_1x1": "Chinese children embrace their mother at home.",
            },
        ]

        issues = CANONICAL.validate_post(
            {"results": results},
            {"video_id": "v", "community_output_version": 2, "community_count": 2},
            {},
        )

        self.assertNotIn("post_internal_plan_collision_1_2", issues)


if __name__ == "__main__":
    unittest.main()
