import importlib.util
import re
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "deterministic_batch.py"
sys.path.insert(0, str(SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("deterministic_batch_title_contract_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class TitleGenerationContractTests(unittest.TestCase):
    def test_generation_targets_95_unicode_codepoints_to_leave_validation_margin(self):
        directive = MODULE.STAGE_DIRECTIVES["xy-title"]

        self.assertIn("95 Unicode code points", directive)
        self.assertIn("Do not trust or merely copy your own char_count", directive)
        self.assertIn("core_story_promise must explicitly name", directive)

    def test_title_generation_uses_declarative_double_explosion_not_open_questions(self):
        prompt = MODULE.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "测试剧"},
                "channel_theme_contract": {
                    "channel_direction": "豪门婚恋",
                    "plot_supported": True,
                },
            },
            [],
        )

        self.assertIn("A creates an immediate emotional debt", prompt)
        self.assertIn("B directly repays the emotional debt created by A", prompt)
        self.assertIn("Both A and B must be declarative", prompt)
        self.assertIn("Never use questions", prompt)
        self.assertNotIn("must NOT reveal the real identity", prompt)
        self.assertNotIn("withhold the real answer", prompt)

    def test_title_generation_optimizes_clickbait_payoff_without_literal_plot_matching(self):
        prompt = MODULE.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "测试剧"},
                "channel_theme_contract": {
                    "channel_direction": "复仇逆袭",
                    "plot_supported": True,
                },
            },
            [],
        )

        self.assertIn("minimum relationship or conflict connection", prompt)
        self.assertIn("does not need to be a literal plot event or ending", prompt)
        self.assertIn("concrete public_payoff_anchor", prompt)
        self.assertIn("must appear verbatim inside the Chinese B beat", prompt)

    def test_title_generation_applies_cold_viewer_rewrite_to_internal_terms(self):
        prompt = MODULE.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "测试剧"},
                "channel_theme_contract": {
                    "channel_direction": "豪门婚恋",
                    "plot_supported": True,
                },
            },
            [],
        )

        self.assertIn("cold viewer", prompt.lower())
        self.assertIn("bare story-internal proper noun", prompt)
        self.assertIn("current relationship, event, or position change", prompt)

    def test_title_retry_feedback_is_actionable_for_abstract_payoff_and_internal_terms(self):
        prompt = MODULE.build_prompt(
            "xy-title",
            "title rules",
            {"task": {"drama_name": "测试剧"}},
            [
                "title_1_public_payoff_anchor_abstract",
                "title_2_cold_viewer_internal_term",
            ],
        )

        self.assertIn("directly responds to the preceding conflict", prompt)
        self.assertIn("concrete, perceptible position change", prompt)
        self.assertIn("Replace the internal proper noun", prompt)
        self.assertIn("Do not ask the viewer to know the plot first", prompt)

    def test_first_person_requirement_is_semantic_not_a_fixed_phrase_list(self):
        prompt = MODULE.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "测试剧"},
                "channel_theme_contract": {
                    "channel_direction": "豪门婚恋",
                    "plot_supported": True,
                },
            },
            [],
        )

        self.assertIn("narrator must be directly involved in the explosive event", prompt)
        self.assertIn("Do not enforce a fixed first-person vocabulary", prompt)
        self.assertNotIn("First-person POV includes I, my husband", prompt)
        self.assertNotIn("Valid openings include", prompt)

    def test_cover_generation_leaves_style_and_typography_to_controller(self):
        directive = MODULE.STAGE_DIRECTIVES["xy-cover"]

        self.assertIn("Return scene_prompt_4_5", directive)
        self.assertIn("controller owns and appends those exactly once", directive)
        self.assertIn("Do not include global style boilerplate", directive)
        self.assertIn("Return outpaint_environment", directive)

    def test_cover_generation_hard_forbids_door_and_vehicle_door_as_primary_staging(self):
        prompt = MODULE.build_prompt(
            "xy-cover",
            "cover rules",
            {
                "task": {"drama_name": "测试剧", "workflow_contract_version": 2},
                "cover_rule_contract": MODULE.load_cover_rule_bundle(),
                "title_payload": {
                    "results": [{
                        "titles": [{
                            "index": 1,
                            "title": "测试标题",
                            "translation": "Test title",
                            "visual_thesis": "The heroine discovers the returning heir.",
                        }]
                    }]
                },
            },
            [],
        )

        self.assertIn("Do not use doors or vehicle doors as primary scene devices", prompt)
        self.assertIn("This is a hard generation and validation requirement", prompt)
        self.assertNotIn("only when the verified plot moment cannot be represented truthfully without it", prompt)
        self.assertNotIn("This is a generation preference, not a validation rejection", prompt)
        acceptance = prompt.split(
            "Generation acceptance specification (owned by the same controller as validation):\n", 1
        )[1].split("\n\nAuthoritative Skill contract:", 1)[0]
        self.assertIn('"door_and_vehicle_door_negative_constraints":', acceptance)
        self.assertIn('"enforcement": "hard_generation_and_validation"', acceptance)

    def test_child_channel_cannot_override_find_angles(self):
        prompt = MODULE.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "舒秘书辞职后总裁气疯了"},
                "channel_theme_contract": {
                    "channel_direction": "萌宝家庭",
                    "plot_supported": True,
                },
            },
            ["title_2_child_safe_cover_scene_missing"],
        )

        self.assertIn("only child fact is not yet born", prompt)
        self.assertIn("Channel direction, drama name, and child wording must never force all three directions", prompt)
        self.assertIn("never use split screen, inset memory, separate memory regions, collage, or temporal montage", prompt)
        self.assertIn("A deceased, absent, or earlier-life child does not require child_angle=true", prompt)
        self.assertIn("Never select, copy, or translate a fixed channel-theme candidate phrase", prompt)
        self.assertNotIn("localized_theme_phrases", prompt)

    def test_v14_title_schema_has_no_fixed_theme_phrase_fields(self):
        schema = MODULE.schema_for("xy-title", {"workflow_contract_version": 2})
        direction = schema["properties"]["results"]["items"]["properties"]["directions"]["items"]

        self.assertNotIn("localized_theme_phrase", direction["properties"])
        self.assertNotIn("localized_theme_phrase_translation", direction["properties"])
        self.assertIn("visual_thesis", direction["properties"])
        self.assertIn("public_payoff_anchor", direction["properties"])
        self.assertIn("public_payoff_anchor", direction["required"])

    def test_v14_cover_model_schema_returns_scene_and_environment_not_final_prompts(self):
        schema = MODULE.schema_for("xy-cover", {"workflow_contract_version": 2})
        row = schema["properties"]["results"]["items"]["properties"]["titles"]["items"]

        self.assertIn("visual_thesis", row["properties"])
        self.assertIn("scene_prompt_4_5", row["properties"])
        self.assertIn("outpaint_environment", row["properties"])
        self.assertNotIn("prompt_4_5", row["properties"])
        self.assertNotIn("prompt_16_9", row["properties"])

    def test_final_cover_skill_json_example_matches_response_schema(self):
        rules = MODULE.SIMULATED_SKILLS["xy-cover"].read_text(encoding="utf-8")
        prompt = MODULE.build_prompt(
            "xy-cover",
            rules,
            {"task": {"drama_name": "测试剧", "workflow_contract_version": 2}},
            [],
            MODULE.STAGE_DIRECTIVES["xy-cover"],
        )
        skill = prompt.split("Authoritative Skill contract:\n", 1)[1].split(
            "\n\nNormalized immutable input JSON:", 1
        )[0]
        declared_json_fields = set(re.findall(r'^\s*"([A-Za-z0-9_]+)"\s*:', skill, re.MULTILINE))
        schema = MODULE.schema_for("xy-cover", {"workflow_contract_version": 2})

        def schema_fields(node):
            fields = set((node.get("properties") or {}).keys()) if isinstance(node, dict) else set()
            if isinstance(node, dict):
                for child in (node.get("properties") or {}).values():
                    fields.update(schema_fields(child))
                fields.update(schema_fields(node.get("items")))
            return fields

        self.assertTrue(declared_json_fields)
        self.assertEqual(declared_json_fields - schema_fields(schema), set())
        self.assertIn('"scene_prompt_4_5":', skill)
        self.assertIn('"outpaint_environment":', skill)
        self.assertNotIn('"prompt_4_5":', skill)
        self.assertNotIn('"prompt_16_9":', skill)
        self.assertIn("Never return prompt_4_5 or prompt_16_9", prompt)

    def test_v14_contract_explicitly_disables_fixed_localized_title_candidates(self):
        import tempfile

        with tempfile.TemporaryDirectory() as folder:
            contract = MODULE.ContractBundle(Path(folder), persist_if_missing=False).semantic()

        self.assertFalse(contract["fixed_localized_title_candidates"])
        self.assertTrue(contract["dynamic_channel_theme_grounding_required"])

    def test_cover_retry_does_not_translate_audit_only_quality_signals_into_rewrites(self):
        prompt = MODULE.build_prompt(
            "xy-cover",
            "cover rules",
            {"task": {"drama_name": "星河若无声灯火有归期"}},
            [
                "cover_1_quality_observation_only",
                "cover_2_prompt_4_5_core_words_diegetic_placement",
                "cover_3_quality_observation_only",
            ],
        )

        self.assertNotIn("Rewrite each failed scene_prompt_4_5", prompt)
        self.assertIn("controller alone adds the non-diegetic editorial Typography block", prompt)
        self.assertNotIn("wife, husband, mother, father", prompt)

    def test_stage_directives_do_not_merge_packaging_ack_into_broken_sentences(self):
        combined = "\n".join(MODULE.STAGE_DIRECTIVES.values())

        self.assertNotIn("scenes Copy packaging_brief", combined)
        self.assertNotIn("Reinforce that Copy packaging_brief", combined)
        self.assertNotIn("distinct In every result copy packaging_brief", combined)


if __name__ == "__main__":
    unittest.main()
