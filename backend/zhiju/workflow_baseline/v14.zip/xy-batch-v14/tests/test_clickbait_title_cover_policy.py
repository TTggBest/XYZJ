import importlib.util
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts" / "canonical_outputs.py"
SPEC = importlib.util.spec_from_file_location("canonical_outputs_clickbait_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class ClickbaitTitlePolicyTests(unittest.TestCase):
    @staticmethod
    def _title_payload(*, first_b: str, first_anchor: str, first_translation: str):
        rows = []
        values = (
            (first_b, first_anchor, first_translation, "betrayal", "villain_cost", 96),
            ("我当众收回前夫公司的控制权", "前夫公司的控制权", "我被丈夫赶出家门！我当众收回前夫公司的控制权！", "humiliation", "power_reversal", 88),
            ("我公开三份股权书让豪门继承权易主", "豪门继承权易主", "继妹偷走我的身份！我公开三份股权书让豪门继承权易主！", "theft", "wealth_reveal", 79),
        )
        for index, (hook_b, payoff_anchor, translation, hook_a_type, hook_b_type, score) in enumerate(values, 1):
            rows.append({
                "index": index,
                "recommendation_score": score,
                "direction": f"方向{index}",
                "hook_a_type": hook_a_type,
                "hook_a_fact": "丈夫把我赶出家门",
                "hook_a_evidence": "营销冲突入口",
                "hook_b_type": hook_b_type,
                "hook_b_fact": hook_b,
                "hook_b_evidence": "营销放大结果",
                "specificity_anchor": f"独立锚点{index}",
                "public_payoff_anchor": payoff_anchor,
                "visual_thesis": "女主在众人面前完成权力反杀",
                "child_angle": False,
                "safe_cover_scene": "",
                "child_role": "",
                "title": translation,
                "translation": translation,
                "char_count": len(translation),
            })
        return {"results": [{"directions": rows, "direct_titles": [row["title"] for row in rows]}]}

    def test_title_validator_rejects_abstract_payoff_even_when_marketing_may_exaggerate(self):
        payload = self._title_payload(
            first_b="我让他们全部付出代价",
            first_anchor="让他们付出代价",
            first_translation="他们六年前害惨了我！我让他们全部付出代价！",
        )

        issues = MODULE.validate_title(payload, {}, {
            "title_rule_contract": {"require_public_payoff_anchor": True},
            "plot_payload": {"results": []},
        })

        self.assertIn("title_1_public_payoff_anchor_abstract", issues)

    def test_title_validator_allows_concrete_clickbait_payoff_without_plot_fact_matching(self):
        payload = self._title_payload(
            first_b="我一通电话取消继妹的百亿合同",
            first_anchor="继妹的百亿合同",
            first_translation="继妹六年前害惨了我！我一通电话取消继妹的百亿合同！",
        )

        issues = MODULE.validate_title(payload, {}, {
            "title_rule_contract": {"require_public_payoff_anchor": True},
            "plot_payload": {"results": []},
        })

        self.assertFalse(any("public_payoff_anchor" in issue for issue in issues))
        self.assertFalse(any("cold_viewer_internal_term" in issue for issue in issues))

    def test_title_validator_rejects_bare_internal_family_name_for_cold_viewers(self):
        payload = self._title_payload(
            first_b="我一通电话取消江氏协议",
            first_anchor="江氏协议",
            first_translation="继妹六年前害惨了我！我一通电话取消江氏协议！",
        )

        issues = MODULE.validate_title(
            payload,
            {},
            {
                "title_rule_contract": {"require_public_payoff_anchor": True},
                "plot_payload": {"results": [{"plot_fields": {"内容概述": "女主终止江氏协议。"}}]},
            },
        )

        self.assertIn("title_1_cold_viewer_internal_term", issues)

    def test_title_validator_accepts_relationship_amount_or_consequence_rewrite(self):
        payload = self._title_payload(
            first_b="我一通电话取消继妹的百亿合同",
            first_anchor="继妹的百亿合同",
            first_translation="继妹六年前害惨了我！我一通电话取消继妹的百亿合同！",
        )

        issues = MODULE.validate_title(
            payload,
            {},
            {
                "title_rule_contract": {"require_public_payoff_anchor": True},
                "plot_payload": {"results": [{"plot_fields": {"内容概述": "女主终止江氏协议。"}}]},
            },
        )

        self.assertFalse(any("cold_viewer_internal_term" in issue for issue in issues))

    def test_title_validator_rejects_bare_internal_project_name(self):
        payload = self._title_payload(
            first_b="我当众叫停天衡计划",
            first_anchor="天衡计划",
            first_translation="继妹六年前害惨了我！我当众叫停天衡计划！",
        )

        issues = MODULE.validate_title(
            payload,
            {},
            {
                "title_rule_contract": {"require_public_payoff_anchor": True},
                "plot_payload": {"results": [{"plot_fields": {"内容概述": "女主叫停天衡计划。"}}]},
            },
        )

        self.assertIn("title_1_cold_viewer_internal_term", issues)

    def test_title_validator_does_not_mistake_universal_agreement_for_internal_name(self):
        payload = self._title_payload(
            first_b="我让前夫的离婚协议当场作废",
            first_anchor="离婚协议当场作废",
            first_translation="前夫逼我净身出户！我让前夫的离婚协议当场作废！",
        )

        issues = MODULE.validate_title(
            payload,
            {},
            {
                "title_rule_contract": {"require_public_payoff_anchor": True},
                "plot_payload": {"results": [{"plot_fields": {"内容概述": "她签下离婚协议。"}}]},
            },
        )

        self.assertNotIn("title_1_cold_viewer_internal_term", issues)

    def test_pre_change_frozen_title_contract_does_not_gain_new_required_field(self):
        payload = self._title_payload(
            first_b="我让他们全部付出代价",
            first_anchor="让他们付出代价",
            first_translation="他们六年前害惨了我！我让他们全部付出代价！",
        )
        for row in payload["results"][0]["directions"]:
            row.pop("public_payoff_anchor")

        issues = MODULE.validate_title(
            payload,
            {},
            {
                "title_rule_contract": {"require_public_payoff_anchor": False},
                "plot_payload": {"results": []},
            },
        )

        self.assertFalse(any("public_payoff_anchor" in issue for issue in issues))
        self.assertFalse(any("cold_viewer_internal_term" in issue for issue in issues))

    def test_title_length_gate_uses_batch_frozen_limit(self):
        frozen = {"max_visible_characters": 120}

        self.assertEqual(MODULE.title_length_issues("A" * 110, 1, frozen), [])
        self.assertIn(
            "title_1_over_100_chars",
            MODULE.title_length_issues("A" * 110, 1, {"max_visible_characters": 100}),
        )

    def test_controller_orders_highest_recommendation_score_first(self):
        payload = {"results": [{"directions": [
            {"index": 1, "recommendation_score": 72, "title": "普通标题"},
            {"index": 2, "recommendation_score": 96, "title": "最强标题"},
            {"index": 3, "recommendation_score": 81, "title": "次强标题"},
        ], "direct_titles": ["普通标题", "最强标题", "次强标题"]}]}

        MODULE.normalize_title_recommendation_order(payload)

        rows = payload["results"][0]["directions"]
        self.assertEqual([row["title"] for row in rows], ["最强标题", "次强标题", "普通标题"])
        self.assertEqual([row["index"] for row in rows], [1, 2, 3])
        self.assertEqual(payload["results"][0]["direct_titles"], ["最强标题", "次强标题", "普通标题"])

    @staticmethod
    def _market_sort_context(*source_types):
        return {
            "market_packaging": {
                "final_angles": [
                    {"angle_id": angle_id, "source_type": source_type}
                    for angle_id, source_type in zip(("A", "B", "C"), source_types)
                ]
            }
        }

    @staticmethod
    def _market_sort_payload():
        return {"results": [{"directions": [
            {"index": 1, "recommendation_score": 72, "title": "A方向"},
            {"index": 2, "recommendation_score": 96, "title": "B方向"},
            {"index": 3, "recommendation_score": 81, "title": "C方向"},
        ], "direct_titles": ["A方向", "B方向", "C方向"]}]}

    def test_controller_places_the_only_market_verified_direction_first(self):
        payload = self._market_sort_payload()
        context = self._market_sort_context(
            "external_market_verified", "story_derived", "story_derived"
        )

        MODULE.normalize_title_recommendation_order(payload, context)

        self.assertEqual(
            [row["title"] for row in payload["results"][0]["directions"]],
            ["A方向", "B方向", "C方向"],
        )

    def test_validator_accepts_market_first_when_only_one_direction_has_market_evidence(self):
        payload = self._title_payload(
            first_b="我让他们全部付出代价",
            first_anchor="让他们付出代价",
            first_translation="他们六年前害惨了我！我让他们全部付出代价！",
        )
        payload["results"][0]["directions"][0]["recommendation_score"] = 72
        payload["results"][0]["directions"][1]["recommendation_score"] = 96
        payload["results"][0]["directions"][2]["recommendation_score"] = 81
        context = self._market_sort_context(
            "external_market_verified", "story_derived", "story_derived"
        )
        context["plot_payload"] = {"results": []}

        MODULE.normalize_title_recommendation_order(payload, context)
        issues = MODULE.validate_title(payload, {}, context)

        self.assertNotIn("title_strongest_recommendation_not_first", issues)

    def test_controller_places_two_market_verified_directions_before_story_fallback(self):
        payload = self._market_sort_payload()
        context = self._market_sort_context(
            "external_market_verified", "external_market_verified", "story_derived"
        )

        MODULE.normalize_title_recommendation_order(payload, context)

        self.assertEqual(
            [row["title"] for row in payload["results"][0]["directions"]],
            ["B方向", "A方向", "C方向"],
        )

    def test_controller_orders_three_market_verified_directions_by_score(self):
        payload = self._market_sort_payload()
        context = self._market_sort_context(
            "external_market_verified", "external_market_verified", "external_market_verified"
        )

        MODULE.normalize_title_recommendation_order(payload, context)

        self.assertEqual(
            [row["title"] for row in payload["results"][0]["directions"]],
            ["B方向", "C方向", "A方向"],
        )

    def test_controller_orders_three_story_derived_directions_by_score(self):
        payload = self._market_sort_payload()
        context = self._market_sort_context(
            "story_derived", "story_derived", "story_derived"
        )

        MODULE.normalize_title_recommendation_order(payload, context)

        self.assertEqual(
            [row["title"] for row in payload["results"][0]["directions"]],
            ["B方向", "C方向", "A方向"],
        )

    def test_child_angle_title_requires_safe_cover_scene_before_cover_stage(self):
        row = {
            "child_angle": True,
            "safe_cover_scene": "",
            "child_role": "",
        }

        issues = MODULE.title_child_cover_safety_issues(1, row)

        self.assertIn("title_1_child_safe_cover_scene_missing", issues)
        self.assertIn("title_1_child_role_missing", issues)

    def test_child_angle_title_accepts_safe_supervised_visual_plan(self):
        row = {
            "child_angle": True,
            "safe_cover_scene": "An ordinary family living room with two healthy cheerful twins safely supervised by their mother.",
            "child_role": "The fully clothed twins hold a plush toy beside their caring mother and do not carry evidence.",
        }

        self.assertEqual(MODULE.title_child_cover_safety_issues(1, row), [])

    def test_child_angle_title_does_not_reject_explicit_no_threat_language(self):
        row = {
            "child_angle": True,
            "safe_cover_scene": "两个健康开心的中国男孩由母亲陪伴玩积木，与成人冲突分开，无威胁、无危险。",
            "child_role": "双胞胎只负责制造相貌悬念，不承担受害或举证任务。",
        }

        self.assertEqual(MODULE.title_child_cover_safety_issues(1, row), [])

    def test_cover_does_not_treat_restrained_adult_emotion_as_restrained_child(self):
        prompt = (
            "Two healthy cheerful Chinese twin boys play safely beside their mother. "
            "The mother watches the father with restrained, unreadable emotion, knowing he once denied her unborn child."
        )

        self.assertEqual(MODULE.cover_policy_issues(prompt, 1, True, True), [])

    def test_cover_still_rejects_an_actually_restrained_child(self):
        prompt = "A restrained Chinese child sits alone while angry adults surround him."

        self.assertIn("cover_1_child_safety_violation", MODULE.cover_policy_issues(prompt, 1, True, True))

    def test_channel_theme_does_not_force_child_plan_onto_unrelated_direction(self):
        row = {
            "child_angle": False,
            "safe_cover_scene": "",
            "child_role": "",
            "title": "丈夫离婚后五个男人突然上门",
            "translation": "丈夫离婚后五个男人突然上门",
        }

        issues = MODULE.title_direction_child_policy_issues(
            1,
            row,
            global_child_required=True,
        )

        self.assertEqual(issues, [])

    def test_generic_channel_snapshot_rules_do_not_force_child_angle(self):
        context = {
            "task": {"drama_name": "春迟海棠"},
            "channel_snapshot": "通用规则：如果标题有孩子则必须保证儿童安全。",
            "channel_theme_contract": {
                "channel_direction": "豪门婚姻",
                "plot_supported": True,
            },
        }

        self.assertFalse(MODULE.global_child_plan_required({}, context))

    def test_supported_child_channel_does_not_override_find_angle(self):
        context = {
            "task": {"drama_name": "普通剧名"},
            "channel_theme_contract": {
                "channel_direction": "萌宝家庭",
                "plot_supported": True,
            },
        }

        self.assertFalse(MODULE.global_child_plan_required({}, context))

    def test_pregnancy_only_find_angle_does_not_require_visible_born_child(self):
        row = {
            "title": "我怀孕时继母诬陷我！孩子父亲当众维护我！",
            "translation": "我怀孕时继母诬陷我！孩子父亲当众维护我！",
            "hook_a_fact": "我怀孕时，继母当众诬陷我。",
            "hook_b_fact": "孩子父亲当众维护我。",
            "specificity_anchor": "孕期得到孩子父亲公开保护",
            "child_angle": False,
            "safe_cover_scene": "",
            "child_role": "",
        }

        self.assertFalse(MODULE.title_row_requires_minor_child(row, False))
        self.assertEqual(MODULE.title_direction_child_policy_issues(1, row, False), [])

    def test_visible_baby_terms_are_recognized_in_safe_cover_plan(self):
        row = {
            "child_angle": True,
            "safe_cover_scene": "中国女婴穿着完整婴儿服，由母亲安全抱在怀中。",
            "child_role": "女婴健康平静，由父母共同照护。",
        }

        self.assertEqual(MODULE.title_child_cover_safety_issues(1, row), [])

    def test_cover_child_requirement_is_group_scoped_for_non_child_drama(self):
        context = {
            "task": {"drama_name": "好一个龙凤呈祥"},
            "channel_theme_contract": {"channel_direction": "复仇逆袭", "plot_supported": True},
        }
        titles = [
            {"title": "我没有放弃女儿", "translation": "我没有放弃女儿", "child_angle": True},
            {"title": "他们毁了我的工厂", "translation": "他们毁了我的工厂", "child_angle": False},
            {"title": "他们叫停婚礼", "translation": "他们叫停婚礼", "child_angle": False},
        ]

        self.assertEqual(
            MODULE.cover_group_child_requirements({}, context, titles),
            [True, False, False],
        )

    def test_cover_child_requirement_is_all_groups_for_twin_drama(self):
        context = {
            "task": {"drama_name": "一胎双宝，夫人拒不复婚"},
            "channel_theme_contract": {"channel_direction": "豪门婚恋", "plot_supported": True},
        }
        titles = [
            {"title": "离婚突袭", "translation": "离婚突袭", "child_angle": True},
            {"title": "回到豪宅", "translation": "回到豪宅", "child_angle": True},
            {"title": "拒绝复婚", "translation": "拒绝复婚", "child_angle": True},
        ]

        self.assertEqual(
            MODULE.cover_group_child_requirements({}, context, titles),
            [True, True, True],
        )

    def test_title_theme_does_not_require_authoritative_localized_pair(self):
        payload = {"results": [{
            "packaging_brief": {"core_story_promise": "萌宝亲子团聚"},
            "directions": [{
                "hook_a_fact": "萌宝寻找母亲",
                "hook_b_fact": "亲子团聚仍有秘密",
                "specificity_anchor": "萌宝",
                "translation": "萌宝回家",
                "title": "मेरे बेटे ने वह रिपोर्ट खोल दी! अब कौन सच छिपाएगा?",
            }],
        }]}
        context = {"channel_theme_contract": {
            "plot_supported": True,
            "channel_direction": "萌宝家庭",
            "required_output_signals": ["萌宝", "亲子"],
        }, "semantic_contract": {"version": 7}}

        issues = MODULE.channel_theme_alignment_issues("xy-title", payload, context)

        self.assertFalse(any("localized_theme_phrase" in issue for issue in issues))

    def test_title_validator_rejects_when_highest_score_is_not_first(self):
        rows = []
        for index, score in enumerate((70, 99, 80), 1):
            rows.append({
                "index": index,
                "recommendation_score": score,
                "direction": f"方向{index}",
                "hook_a_type": "betrayal" if index < 3 else "theft",
                "hook_a_fact": "她被丈夫赶出家门",
                "hook_a_evidence": "她被丈夫赶出家门",
                "hook_b_type": "arrival_mystery" if index != 2 else "public_shock",
                "hook_b_fact": f"第{index}个神秘人带着证据出现",
                "hook_b_evidence": "营销放大但不揭晓答案",
                "specificity_anchor": f"独立锚点{index}",
                "child_angle": False,
                "safe_cover_scene": "",
                "child_role": "",
                "title": f"标题{index}",
                "translation": f"翻译标题{index}",
                "char_count": 3,
            })
        payload = {"results": [{"directions": rows, "direct_titles": [row["title"] for row in rows]}]}
        context = {"plot_payload": {"results": [{"plot_fields": {"内容概述": "她被丈夫赶出家门"}}]}}

        issues = MODULE.validate_title(payload, {}, context)

        self.assertIn("title_strongest_recommendation_not_first", issues)

    def test_one_exact_plot_anchor_is_enough(self):
        issues = MODULE.title_marketing_issues(
            1,
            "她被丈夫赶出家门",
            "看到五个男人带来的东西，前夫当场跪下了",
            "丈夫刚提出离婚，五个男人就同时来抢我",
            "看到他们带来的东西，前夫当场跪下了",
            "她被丈夫赶出家门，五个堂哥赶来保护她。",
        )
        self.assertNotIn("title_1_minimum_plot_anchor_missing", issues)

    def test_marketing_title_does_not_require_a_verbatim_plot_anchor(self):
        issues = MODULE.title_marketing_issues(1, "完全虚构甲", "完全虚构乙", "A钩子足够长", "B钩子足够长", "原剧情只有被赶出家门")
        self.assertNotIn("title_1_minimum_plot_anchor_missing", issues)

    def test_b_hook_may_directly_deliver_identity_reversal_or_payoff(self):
        issues = MODULE.title_marketing_issues(
            1, "她被丈夫赶出家门", "营销放大", "丈夫刚提出离婚，五个男人来抢我", "所有人才知道她是他们最宠爱的妹妹", "她被丈夫赶出家门"
        )
        self.assertNotIn("title_1_b_hook_reveals_answer", issues)

    def test_ab_hooks_reject_questions_instead_of_using_them_as_click_gaps(self):
        issues = MODULE.title_marketing_issues(
            1,
            "她被丈夫赶出家门",
            "营销放大",
            "丈夫刚提出离婚，五个哥哥就出现了",
            "为什么五个哥哥都来保护我？",
            "她被丈夫赶出家门",
        )

        self.assertIn("title_1_question_not_allowed", issues)

    def test_title_rejects_humiliation_when_it_targets_a_minor(self):
        row = {
            "title": "他们当众羞辱我五岁的女儿！我让整个家族付出代价！",
            "translation": "他们当众羞辱我五岁的女儿！我让整个家族付出代价！",
            "hook_a_fact": "他们当众羞辱我五岁的女儿",
            "hook_b_fact": "我让整个家族付出代价",
            "specificity_anchor": "五岁女儿",
            "child_angle": True,
            "safe_cover_scene": "五岁女孩健康安全地站在母亲身边，由母亲照看。",
            "child_role": "五岁女孩清晰出镜，但不承担成人冲突。",
        }

        issues = MODULE.title_direction_child_policy_issues(1, row, global_child_required=False)

        self.assertIn("title_1_minor_humiliation_or_age_inappropriate", issues)

    def test_title_allows_the_same_humiliation_words_for_an_adult_daughter(self):
        row = {
            "title": "他们当众羞辱我成年的女儿！我让整个家族付出代价！",
            "translation": "他们当众羞辱我成年的女儿！我让整个家族付出代价！",
            "hook_a_fact": "他们当众羞辱我成年的女儿",
            "hook_b_fact": "我让整个家族付出代价",
            "specificity_anchor": "成年女儿",
            "child_angle": False,
            "safe_cover_scene": "",
            "child_role": "",
        }

        issues = MODULE.title_direction_child_policy_issues(1, row, global_child_required=False)

        self.assertNotIn("title_1_minor_humiliation_or_age_inappropriate", issues)

    def test_title_does_not_join_separate_fields_into_a_minor_marriage_claim(self):
        row = {
            "title": "丈夫把我秘密送上直播！我带着儿子拿下冠军与3000万奖金！",
            "translation": "丈夫把我秘密送上直播！我带着儿子拿下冠军与3000万奖金！",
            "hook_a_fact": "丈夫为争夺抚养权秘密直播我",
            "hook_b_fact": "我陪儿子赢得冠军与3000万奖金",
            "specificity_anchor": "母子冠军",
            "child_angle": True,
            "safe_cover_scene": "健康安全的中国男孩站在母亲身边，由母亲照看。",
            "child_role": "男孩是母亲赢得亲子比赛的安全伙伴。",
        }

        issues = MODULE.title_direction_child_policy_issues(1, row, global_child_required=True)

        self.assertNotIn("title_1_minor_humiliation_or_age_inappropriate", issues)

    def test_title_does_not_assign_the_adult_speaker_wife_role_to_her_daughter(self):
        row = {
            "title": "我找回被宣告夭折的女儿！我当众成为继承人妻子！",
            "translation": "我找回被宣告夭折的女儿！我当众成为继承人妻子！",
            "hook_a_fact": "我找回失散女儿",
            "hook_b_fact": "我成为继承人妻子",
            "specificity_anchor": "母女重聚",
            "child_angle": True,
            "safe_cover_scene": "健康安全的中国女孩站在母亲身边，由母亲照看。",
            "child_role": "女孩与成年母亲安全重聚。",
        }

        issues = MODULE.title_direction_child_policy_issues(1, row, global_child_required=True)

        self.assertNotIn("title_1_minor_humiliation_or_age_inappropriate", issues)

    def test_title_still_rejects_a_minor_forced_into_an_adult_marriage_role(self):
        row = {
            "title": "他们逼五岁女儿成为新娘！我让所有成年人付出代价！",
            "translation": "他们逼五岁女儿成为新娘！我让所有成年人付出代价！",
            "hook_a_fact": "他们逼五岁女儿成为新娘",
            "hook_b_fact": "我惩罚所有成年人",
            "specificity_anchor": "五岁女儿",
            "child_angle": True,
            "safe_cover_scene": "健康安全的五岁女孩站在母亲身边，由母亲照看。",
            "child_role": "五岁女孩只作为被保护的儿童出现。",
        }

        issues = MODULE.title_direction_child_policy_issues(1, row, global_child_required=True)

        self.assertIn("title_1_minor_humiliation_or_age_inappropriate", issues)

    def test_open_loop_b_hook_passes(self):
        issues = MODULE.title_marketing_issues(
            1, "她被丈夫赶出家门", "营销放大", "丈夫刚提出离婚，五个男人来抢我", "看到他们带来的东西，前夫当场跪下了", "她被丈夫赶出家门"
        )
        self.assertNotIn("title_1_b_hook_reveals_answer", issues)

    def test_one_reused_cross_channel_title_is_already_a_collision(self):
        current = {"directions": [{
            "hook_a_type": "marriage_trap", "hook_b_type": "arrival_mystery",
            "specificity_anchor": "五个男人同时出现",
            "translation": "丈夫刚提出离婚，五个男人就同时来抢我！看到他们带来的东西，前夫当场跪下了！",
        }]}
        old = {"directions": [{
            "hook_a_type": "marriage_trap", "hook_b_type": "arrival_mystery",
            "specificity_anchor": "五个男人同时出现",
            "translation": "丈夫刚提出离婚，五个男人就同时来抢我！看到他们带来的东西，前夫当场跪下了！",
        }]}
        issues = MODULE.creative_collision_issues(
            "xy-title", {"results": [current]}, {"creative_history": [{"title_payload": {"results": [old]}}]}
        )
        self.assertIn("title_cross_channel_package_collision", issues)


class CoverPolicyTests(unittest.TestCase):
    def test_cover_normalizer_uses_adaptive_salience_without_fixed_geometry(self):
        payload = {"results": [{"titles": [{
            "core_words": "秘密",
            "scene_prompt_4_5": "A wife turns toward her husband in a family doorway.",
            "outpaint_environment": "Continue the apartment corridor walls and practical ceiling lights.",
        }]}]}
        frozen = {"prompt_audit": {"typography_salience_rule": {
            "fixed_geometry_requirements": False,
            "forbid_fixed_width_height_font_size_or_canvas_ratio": True,
            "containment_area_4_5": "centered_1728x2160",
        }}}

        MODULE.normalize_cover_prompt_contract(payload, frozen)

        row = payload["results"][0]["titles"][0]
        self.assertIn("visually prominent, highly legible", row["prompt_4_5"])
        self.assertIn("use no fixed width, height, font size, or canvas ratio", row["prompt_4_5"])
        self.assertIn("inside the centered 1728x2160 4:5 image area", row["prompt_4_5"])
        self.assertNotRegex(row["prompt_4_5"], r"\b(?:50|75|9|22)%")
        self.assertIn("pixel-for-pixel", row["prompt_16_9"])

    def test_cover_quality_gate_ignores_legacy_numeric_thresholds(self):
        prompt = (
            "live-action Chinese family drama still with natural skin texture, ordinary clothing wrinkles, "
            "realistic lens rendering, believable lighting, and slightly softer environmental detail. "
            "A wife turns toward her husband in an apartment doorway with controlled shock."
        )
        frozen = {"prompt_audit": {
            "prompt_word_count_mode": "audit_only",
            "maximum_story_evidence_props": 4,
            "minimum_real_drama_score_audit": 0,
            "hard_forbidden_ai_poster_terms": ["hologram"],
            "image_style": {
                "forbidden_overprocessed_terms": [],
                "required_natural_signals": [],
                "minimum_required_natural_signals": 0,
            },
        }}

        issues = MODULE.cover_prompt_quality_issues(prompt, 1, frozen)

        self.assertEqual(issues, [])

    def test_core_words_are_normalized_as_non_diegetic_cover_typography(self):
        payload = {"results": [{"titles": [{
            "core_words": "REDDEDİLDİ",
            "scene_prompt_4_5": "A wife closes a divorce folder while her husband blocks the apartment doorway.",
            "outpaint_environment": "Continue the apartment entryway and warm practical ceiling light.",
        }]}]}

        MODULE.normalize_cover_prompt_contract(payload)

        row = payload["results"][0]["titles"][0]
        self.assertIn("non-diegetic cover typography", row["prompt_4_5"])
        self.assertIn("visually prominent, highly legible", row["prompt_4_5"])
        self.assertNotIn("primary thumbnail focal text", row["prompt_4_5"])
        self.assertNotIn("50-75%", row["prompt_4_5"])
        self.assertIn("never place text on physical surfaces or props", row["prompt_4_5"])
        self.assertIn("faces and event remain primary", row["prompt_4_5"])
        self.assertIn("faces, critical hands, story objects", row["prompt_4_5"])
        self.assertNotIn("never printed, painted, written, engraved, projected, or attached", row["prompt_4_5"])
        self.assertNotIn("visually prominent, highly legible", row["prompt_16_9"])
        self.assertNotIn("REDDEDİLDİ", row["prompt_16_9"])
        self.assertIn("Preserve the entire center pixel-for-pixel", row["prompt_16_9"])
        self.assertIn("do not resize, move, restyle, recolor, re-outline, re-shadow, or reflow it", row["prompt_16_9"])

    def test_4x5_prompt_excludes_all_wide_generation_instructions(self):
        payload = {"results": [{"titles": [{
            "core_words": "秘密",
            "scene_prompt_4_5": "A Chinese wife closes a divorce folder in a realistic apartment living room.",
            "outpaint_environment": "Continue the apartment walls and warm practical lighting.",
        }]}]}

        MODULE.normalize_cover_prompt_contract(payload)

        row = payload["results"][0]["titles"][0]
        prompt_4_5 = row["prompt_4_5"].casefold()
        for forbidden in (
            "16:9",
            "16x9",
            "outpaint",
            "locked center",
            "side band",
            "3840x2160",
            "1056px",
            "pixel-for-pixel",
        ):
            with self.subTest(forbidden=forbidden):
                self.assertNotIn(forbidden, prompt_4_5)
        self.assertIn("3840x2160", row["prompt_16_9"])
        self.assertIn("outpaint", row["prompt_16_9"].casefold())

    def test_4x5_prompt_validator_rejects_wide_generation_vocabulary(self):
        row = {
            "scene_prompt_4_5": "A Chinese couple argues in a living room; preserve this locked center for 16:9 outpainting.",
            "prompt_4_5": (
                "A Chinese couple argues in a living room; preserve this locked center for 16:9 outpainting. "
                + MODULE.COVER_STYLE_BLOCK + " " + MODULE.core_words_typography_clause("秘密")
            ),
        }

        issues = MODULE.cover_prompt_structure_issues(row, 2)

        self.assertIn("cover_2_scene_prompt_contains_wide_generation_instruction", issues)
        self.assertIn("cover_2_final_prompt_contains_wide_generation_instruction", issues)

    def test_validator_rejects_core_words_placed_on_a_wall_without_painted_verb(self):
        self.assertTrue(MODULE.has_diegetic_core_word_placement(
            'Place the prominent Bengali core word "গোপন" on the upper cream wall.',
            "গোপন",
        ))

    def test_validator_rejects_core_words_painted_on_a_wall(self):
        title_rows = [
            {"title": f"title {index}", "translation": f"translation {index}"}
            for index in range(1, 4)
        ]
        cover_rows = []
        for index in range(1, 4):
            core = "REDDEDİLDİ" if index == 1 else f"CORE{index}"
            placement = "painted directly on the living-room wall" if index == 1 else "as a cover-title overlay"
            cover_rows.append({
                "title_index": index,
                "title": f"title {index}",
                "title_translation": f"translation {index}",
                "core_words": core,
                "story_hook": f"distinct story hook {index}",
                "scene_family": f"scene family {index}",
                "scene": f"scene {index}",
                "main_action": f"main action {index}",
                "key_prop": f"prop {index}",
                "composition": f"composition {index}",
                "palette": f"palette {index}",
                "lighting": f"lighting {index}",
                "prompt_4_5": (
                    "Chinese actors, Chinese facial features, East Asian appearance. "
                    f"Render the exact core words {core} {placement}."
                ),
                "prompt_16_9": (
                    f"Extend the approved center and preserve {core}. "
                    "Chinese actors, Chinese facial features, East Asian appearance."
                ),
            })
        payload = {"results": [{"titles": cover_rows}]}
        context = {"title_payload": {"results": [{"directions": title_rows}]}}

        issues = MODULE.validate_cover(payload, {}, context)

        self.assertIn("cover_1_prompt_4_5_core_words_diegetic_placement", issues)

    def test_female_frequency_special_effects_are_rejected(self):
        issues = MODULE.cover_policy_issues("A Chinese woman stands in a lobby with a magical aura, lightning particles and glowing eyes.", 1, True, False)
        self.assertIn("cover_1_female_frequency_special_effects_forbidden", issues)

    def test_natural_sunlight_is_not_a_special_effect(self):
        issues = MODULE.cover_policy_issues("A Chinese woman stands at a doorway in natural sunset light with restrained rim light.", 1, True, False)
        self.assertNotIn("cover_1_female_frequency_special_effects_forbidden", issues)

    def test_primary_door_and_vehicle_door_staging_is_rejected(self):
        cases = (
            {"scene": "apartment doorway confrontation", "main_action": "the husband blocks the doorway"},
            {"scene": "hotel entrance", "main_action": "the heroine opens the door"},
            {"scene": "curbside arrival", "main_action": "the CEO steps out through an open car door"},
            {"scene": "parking garage", "main_action": "the wife grips the vehicle door during the confrontation"},
        )

        for index, row in enumerate(cases, 1):
            with self.subTest(row=row):
                issues = MODULE.cover_primary_door_device_issues(
                    row,
                    index,
                    MODULE.load_cover_rule_bundle(),
                )
                self.assertEqual(issues, [f"cover_{index}_door_or_vehicle_door_primary_staging_forbidden"])

    def test_distant_incidental_background_door_is_not_rejected(self):
        row = {
            "scene_family": "family dining room",
            "scene": "a couple confronts each other across a dining table",
            "main_action": "the wife places a sealed report on the table",
            "composition": "eye-level table-side medium close-up",
            "scene_prompt_4_5": (
                "A Chinese couple confront each other across a dining table. "
                "A closed door remains distant and incidental in the soft background; nobody touches or approaches it."
            ),
        }

        issues = MODULE.cover_primary_door_device_issues(
            row,
            1,
            MODULE.load_cover_rule_bundle(),
        )

        self.assertEqual(issues, [])

    def test_child_angle_requires_visible_child(self):
        issues = MODULE.cover_policy_issues("Two Chinese adults argue at a family doorway.", 2, True, True)
        self.assertIn("cover_2_child_angle_missing_visible_child", issues)

    def test_safe_supervised_child_passes(self):
        issues = MODULE.cover_policy_issues("A healthy cheerful five-year-old Chinese girl, fully clothed and safely beside her attentive mother, watches two adults block a doorway.", 2, True, True)
        self.assertNotIn("cover_2_child_angle_missing_visible_child", issues)
        self.assertNotIn("cover_2_child_safety_violation", issues)

    def test_three_safe_visible_triplets_count_as_visible_children(self):
        prompt = (
            "A Chinese mother stands beside her three visible, healthy, fully clothed Chinese triplets "
            "under both parents' supervision in a bright family room."
        )

        issues = MODULE.cover_policy_issues(prompt, 2, True, True)

        self.assertNotIn("cover_2_child_angle_missing_visible_child", issues)
        self.assertNotIn("cover_2_child_safety_violation", issues)

    def test_controller_outpaint_prompt_does_not_reuse_model_wide_prompt(self):
        payload = {"results": [{"titles": [{
            "scene_prompt_4_5": "A wife turns away from her husband in an apartment doorway.",
            "outpaint_environment": "Continue the corridor walls and practical ceiling lights.",
        }]}]}
        MODULE.normalize_cover_prompt_contract(payload)
        wide = payload["results"][0]["titles"][0]["prompt_16_9"]
        self.assertFalse(MODULE.has_blanket_background_text_ban(wide))
        self.assertIn("Environmental extension only", wide)
        self.assertNotIn("Chinese facial features", wide)

    def test_safe_child_may_appear_in_normal_hospital_environment(self):
        row = {
            "child_angle": True,
            "safe_cover_scene": "A healthy Chinese girl waits safely beside her attentive mother in a bright hospital waiting area.",
            "child_role": "The fully clothed girl is safe, calm, and supervised during a normal follow-up visit.",
        }

        self.assertEqual(MODULE.title_child_cover_safety_issues(1, row), [])

    def test_painful_invasive_child_medical_procedure_is_rejected(self):
        row = {
            "child_angle": True,
            "safe_cover_scene": "A Chinese child undergoes an invasive medical procedure.",
            "child_role": "The child is shown during the procedure.",
        }

        self.assertIn("title_1_child_safe_cover_scene_unsafe", MODULE.title_child_cover_safety_issues(1, row))

    def test_scene_prompt_with_controller_typography_is_rejected_not_cleaned(self):
        row = {
            "scene_prompt_4_5": "A wife turns at a doorway. Add non-diegetic cover typography spanning 50-75% canvas width.",
            "prompt_4_5": (
                "A wife turns at a doorway. Add non-diegetic cover typography spanning 50-75% canvas width. "
                + MODULE.COVER_STYLE_BLOCK + " " + MODULE.core_words_typography_clause("秘密")
            ),
        }

        issues = MODULE.cover_prompt_structure_issues(row, 1)

        self.assertIn("cover_1_scene_prompt_contains_controller_owned_typography", issues)

    def test_child_distress_is_rejected(self):
        issues = MODULE.cover_policy_issues("A frightened crying Chinese child is restrained while angry adults surround her.", 3, True, True)
        self.assertIn("cover_3_child_safety_violation", issues)

    def test_adult_hospital_context_does_not_poison_separate_safe_child_scene(self):
        prompt = (
            "In the background hospital boardroom, two Chinese adults confront each other over a medical file. "
            "In a separate ordinary family lounge, two healthy cheerful Chinese twins sit safely beside their attentive mother."
        )

        issues = MODULE.cover_policy_issues(prompt, 1, True, True)

        self.assertNotIn("cover_1_child_safety_violation", issues)

    def test_explicit_separation_from_adult_hospital_scene_is_safe(self):
        prompt = (
            "The two healthy, cheerful Chinese twin boys are safely playing with wooden blocks in a sunlit "
            "residential garden under a gentle nanny's close supervision, entirely separate from this adult "
            "hospital scene."
        )

        issues = MODULE.cover_policy_issues(prompt, 2, True, True)

        self.assertNotIn("cover_2_child_safety_violation", issues)

    def test_child_inside_hospital_context_is_still_rejected(self):
        prompt = "A frightened Chinese child waits alone inside a hospital corridor while hostile adults argue around her."

        issues = MODULE.cover_policy_issues(prompt, 1, True, True)

        self.assertIn("cover_1_child_safety_violation", issues)

    def test_beating_and_about_to_hit_are_rejected(self):
        for prompt in ("A man is about to slap a woman.", "A woman raises her fist to punch her rival."):
            self.assertIn("cover_1_physical_violence_forbidden", MODULE.cover_policy_issues(prompt, 1, False, False))

    def test_blood_type_report_is_not_physical_violence(self):
        for prompt in (
            "A Chinese woman raises a blood-type report revealing a biological mismatch.",
            "A Chinese woman displays a blood type report during a family confrontation.",
        ):
            self.assertNotIn(
                "cover_2_physical_violence_forbidden",
                MODULE.cover_policy_issues(prompt, 2, False, False),
            )

    def test_visible_blood_is_still_rejected(self):
        prompt = "Visible blood stains the man's shirt after the confrontation."

        self.assertIn(
            "cover_1_physical_violence_forbidden",
            MODULE.cover_policy_issues(prompt, 1, False, False),
        )


if __name__ == "__main__":
    unittest.main()
