import importlib.util
import sys
import unittest
from pathlib import Path
from unittest import mock


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "export_daily_tasks.py"
SPEC = importlib.util.spec_from_file_location("export_daily_tasks_under_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class ExportSlotTests(unittest.TestCase):
    def setUp(self):
        self.item = {
            "slot": "2026080910",
            "slot_label": "46243.416666666664",
            "channel": "Pag-ibig ng Tagapagmana",
            "nickname": "channel nickname",
            "drama_name": "偏爱你星辰为证",
            "video_id": "wx94hVpG134",
            "url": "https://youtu.be/wx94hVpG134",
            "need_community": 1,
            "package_path": "/nonexistent/package",
            "status": "PACKAGE_READY",
        }

    def test_build_rows_exports_normalized_slot_instead_of_raw_excel_serial(self):
        rows = MODULE.build_rows({"items": [self.item]}, "2026-08-09", completed_only=True)
        self.assertEqual(rows[1][6], "2026080910")

    def test_append_output_base_row_writes_normalized_slot(self):
        captured = []
        original_put_values = MODULE.put_values
        original_read_row = MODULE.read_row
        MODULE.put_values = lambda *args: captured.append(args)
        MODULE.read_row = lambda *args: captured[-1][-1]
        try:
            columns = {name: index for index, name in enumerate(MODULE.HEADERS)}
            row_number = MODULE.append_output_base_row(
                "token", "spreadsheet", "sheet", [MODULE.HEADERS], columns, self.item
            )
        finally:
            MODULE.put_values = original_put_values
            MODULE.read_row = original_read_row

        self.assertEqual(row_number, 2)
        written_row = captured[0][-1][0]
        self.assertEqual(written_row[6], "2026080910")

    def test_empty_output_sheet_initializes_standard_header_before_matching(self):
        writes = []
        with (
            mock.patch.object(MODULE, "put_values", side_effect=lambda *args: writes.append(args)),
            mock.patch.object(MODULE, "read_row", return_value=[MODULE.HEADERS]),
        ):
            header, initialized = MODULE.ensure_output_base_headers(
                "token", "spreadsheet", "sheet", [None] * 52
            )
        self.assertTrue(initialized)
        self.assertEqual(header[: len(MODULE.HEADERS)], MODULE.HEADERS)
        self.assertEqual(writes[0][2], "sheet!A1:Q1")
        self.assertEqual(writes[0][3], [MODULE.HEADERS])

    def test_partial_wrong_header_is_not_silently_overwritten(self):
        with self.assertRaisesRegex(RuntimeError, "任务表缺少基础列"):
            MODULE.ensure_output_base_headers(
                "token", "spreadsheet", "sheet", ["日期", "错误列"]
            )

    def test_missing_hashtags_gets_only_cdrama_not_a_default_set(self):
        description = "🔥 剧情说明\n\n==测试剧=="

        result = MODULE.ensure_description_hashtags(description, Path("/tmp/package"))

        self.assertIn("\n\n#cdrama\n\n==测试剧==", result)
        self.assertNotIn("#ChineseDrama", result)
        self.assertNotIn("#ShortDrama", result)
        self.assertNotIn("#RomanceDrama", result)

    def test_existing_hashtag_line_with_cdrama_is_unchanged(self):
        description = "🔥 Story hook\n\n#romance #cdrama #家庭秘密\n\n==测试剧=="

        result = MODULE.ensure_description_hashtags(description, Path("/tmp/package"))

        self.assertIn("#romance #cdrama #家庭秘密", result)
        self.assertNotIn("#ChineseDrama", result)
        self.assertNotIn("#ShortDrama", result)
        self.assertEqual(result.lower().count("#cdrama"), 1)

    def test_hashtag_validation_requires_three_base_tags_but_does_not_reject_other_scripts(self):
        description = "\n".join([
            "🔥 Story hook",
            "#cdrama #ChineseDrama #ShortDrama #家庭秘密 #PolskiDramat",
            "==测试剧==",
        ])
        contract = {
            "contract": {
                "mandatory_hashtags": ["#cdrama", "#ChineseDrama", "#ShortDrama"],
            }
        }

        issues = MODULE.description_format_issues(description, contract)

        self.assertNotIn("说明缺少 #cdrama", issues)
        self.assertNotIn("说明缺少 #ChineseDrama", issues)
        self.assertNotIn("说明缺少 #ShortDrama", issues)
        self.assertNotIn("说明正文含中文字符", issues)

        missing = MODULE.description_format_issues(
            description.replace(" #ShortDrama", ""), contract
        )
        self.assertIn("说明缺少 #ShortDrama", missing)


if __name__ == "__main__":
    unittest.main()
