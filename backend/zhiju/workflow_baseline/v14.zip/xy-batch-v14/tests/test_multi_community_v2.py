import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


BATCH_SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
PACK_SCRIPTS = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts"
for path in (BATCH_SCRIPTS, PACK_SCRIPTS):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


init_batch = load("init_batch_multi_test", BATCH_SCRIPTS / "init_batch.py")
canonical = load("canonical_multi_test", PACK_SCRIPTS / "canonical_outputs.py")
deterministic = load("deterministic_multi_test", BATCH_SCRIPTS / "deterministic_batch.py")
exporter = load("export_multi_test", BATCH_SCRIPTS / "export_daily_tasks.py")


class MultiCommunityV2Tests(unittest.TestCase):
    def test_feishu_rich_url_readback_matches_plain_url(self):
        rich = [{"type": "url", "text": "https://youtu.be/abc", "link": "https://youtu.be/abc"}]
        self.assertEqual(exporter.normalize_match(rich), exporter.normalize_match("https://youtu.be/abc"))

    def test_claim_failure_does_not_stop_later_queue_items(self):
        first = {"row_number": 2, "drama_name": "失败行", "video_id": "bad"}
        second = {"row_number": 3, "drama_name": "正常行", "video_id": "good"}

        class Controller:
            def claim(self, item):
                if item is first:
                    raise deterministic.WritebackPendingError("writeback failed")

            def finish(self, item, status, error):
                item["status"] = status
                item["error"] = error

        claim_next = getattr(
            deterministic,
            "claim_next_item",
            lambda queue, start_index, controller, results: (None, len(queue)),
        )
        results = []
        item, next_index = claim_next([first, second], 0, Controller(), results)
        self.assertIs(item, second)
        self.assertEqual(next_index, 2)
        self.assertEqual(results[0]["status"], "WRITEBACK_PENDING")

    def test_channel_theme_contract_uses_registry_fields_and_keeps_three_distinct_layers(self):
        item = {
            "channel": "萌宝频道",
            "language": "孟加拉",
            "gender": "女频",
            "direction": "萌宝家庭",
            "nickname": "🎀萌宝频道-孟加拉-女频-萌宝家庭",
        }

        contract = deterministic.channel_theme_contract(item)

        self.assertEqual(contract["channel_direction"], "萌宝家庭")
        self.assertEqual(contract["channel_gender"], "女频")
        self.assertEqual(contract["same_channel_rule"], "theme_consistent_creative_distinct")
        self.assertEqual(contract["cross_channel_rule"], "channel_direction_must_change_packaging_angle")

    def test_title_schema_carries_one_packaging_brief_into_downstream_modules(self):
        result_properties = canonical.SCHEMAS["xy-title"]["properties"]["results"]["items"]["properties"]
        brief = result_properties["packaging_brief"]

        self.assertEqual(brief["type"], "object")
        self.assertIn("creative_slot_id", brief["properties"])
        self.assertIn("channel_direction", brief["properties"])
        self.assertIn("core_story_promise", brief["properties"])
        self.assertIn("thumbnail_role", brief["properties"])
        self.assertEqual(set(brief["required"]), set(brief["properties"]))

    def test_fixed_full_video_cta_rejects_same_channel_paraphrase(self):
        footer = {"full_video_cta": "সম্পূর্ণ গল্প দেখতে এখানে ক্লিক করুন"}
        link = "https://youtu.be/abc123"

        issues = canonical.community_opening_cta_issues(
            f"🔥 পুরো গল্পটি এখানে দেখুন 👉 {link}\n剧情正文",
            link,
            footer,
        )

        self.assertIn("copy_full_video_cta_mismatch", issues)

    def test_fixed_full_video_cta_accepts_exact_channel_phrase(self):
        footer = {"full_video_cta": "সম্পূর্ণ গল্প দেখতে এখানে ক্লিক করুন"}
        link = "https://youtu.be/abc123"

        issues = canonical.community_opening_cta_issues(
            f"🔥 সম্পূর্ণ গল্প দেখতে এখানে ক্লিক করুন 👉 {link}\n剧情正文",
            link,
            footer,
        )

        self.assertEqual(issues, [])

    def test_text_generation_finishes_as_text_ready_not_package_ready(self):
        self.assertEqual(deterministic.completion_status_for_images("pending"), "TEXT_READY")
        self.assertEqual(deterministic.completion_status_for_images("partial"), "TEXT_READY")
        self.assertEqual(deterministic.completion_status_for_images("validated"), "TEXT_READY")

    def test_batch_export_fails_closed_when_any_stage_writeback_fails(self):
        ensure_no_errors = getattr(exporter, "ensure_no_stage_errors", lambda _errors: None)
        with self.assertRaises(RuntimeError):
            ensure_no_errors([{"stage": "xy-cover", "drama_name": "测试剧", "error": "readback mismatch"}])

    def test_read_only_contract_preflight_does_not_create_snapshot(self):
        with tempfile.TemporaryDirectory() as temp_name:
            batch_dir = Path(temp_name)
            loader = getattr(
                deterministic,
                "load_contract_bundle",
                lambda path, persist_if_missing=True: deterministic.ContractBundle(path),
            )
            loader(batch_dir, persist_if_missing=False)
            self.assertFalse((batch_dir / "生产契约快照.json").exists())

    def test_supported_channel_theme_is_a_generation_and_validation_requirement(self):
        context = {"channel_theme_contract": {
            "channel_direction": "萌宝家庭",
            "plot_supported": True,
        }}
        off_theme = {"results": [{"directions": [{
            "hook_a_fact": "总裁在董事会公开身份",
            "hook_b_fact": "所有股东震惊",
            "specificity_anchor": "继承权争夺",
            "translation": "豪门身份曝光",
        }]}]}
        on_theme = {"results": [{"directions": [{
            "hook_a_fact": "两个孩子认出了父亲",
            "hook_b_fact": "母亲带着双宝离开",
            "specificity_anchor": "双宝亲子关系",
            "translation": "孩子让这个家庭再次相认",
        }]}]}

        self.assertIn(
            "title_channel_theme_not_prominent",
            canonical.channel_theme_alignment_issues("xy-title", off_theme, context),
        )
        self.assertEqual(canonical.channel_theme_alignment_issues("xy-title", on_theme, context), [])

    def test_baby_theme_is_not_supported_by_generic_parent_words_alone(self):
        item = {"direction": "萌宝家庭", "gender": "女频"}
        plot = {"results": [{"plot_fields": {
            "内容概述": "成年女主与父亲争夺公司控制权，全剧没有儿童。",
        }}]}

        contract = deterministic.channel_theme_contract(item, plot)

        self.assertFalse(contract["plot_supported"])
        self.assertEqual(contract["plot_support_signals"], [])

    def test_theme_must_be_prominent_in_each_title_direction(self):
        context = {"channel_theme_contract": {
            "channel_direction": "萌宝家庭",
            "plot_supported": True,
            "plot_support_signals": ["孩子"],
        }}
        payload = {"results": [{"directions": [
            {"hook_a_fact": "孩子回家", "hook_b_fact": "", "specificity_anchor": "", "translation": ""},
            {"hook_a_fact": "父亲赶到公司", "hook_b_fact": "", "specificity_anchor": "", "translation": ""},
            {"hook_a_fact": "旧爱归来", "hook_b_fact": "", "specificity_anchor": "", "translation": ""},
        ]}]}

        issues = canonical.channel_theme_alignment_issues("xy-title", payload, context)

        self.assertIn("title_2_channel_theme_not_prominent", issues)
        self.assertIn("title_3_channel_theme_not_prominent", issues)

    def test_title_theme_does_not_require_a_fixed_localized_phrase_field(self):
        context = {"channel_theme_contract": {
            "channel_direction": "萌宝家庭",
            "plot_supported": True,
            "required_output_signals": ["孩子", "萌宝", "宝宝"],
        }}
        payload = {"results": [{"directions": [{
            "title": "Una mujer vuelve y todos callan",
            "hook_a_fact": "孩子回家",
            "hook_b_fact": "萌宝见证",
            "specificity_anchor": "孩子",
            "translation": "孩子让家庭重新选择",
        }]}]}

        issues = canonical.channel_theme_alignment_issues("xy-title", payload, context)

        self.assertFalse(any("localized_theme_phrase" in issue for issue in issues))

    def test_packaging_brief_promise_must_express_the_supported_channel_theme(self):
        context = {
            "semantic_contract": {"version": 6},
            "channel_theme_contract": {
                "channel_direction": "萌宝家庭",
                "plot_supported": True,
                "required_output_signals": ["孩子", "萌宝", "宝宝"],
            },
        }
        payload = {"results": [{
            "packaging_brief": {"core_story_promise": "一个女人公开反击所有敌人"},
            "directions": [{
                "title": "Los gemelos regresan y todos callan",
                "hook_a_fact": "孩子回家",
                "hook_b_fact": "萌宝见证",
                "specificity_anchor": "孩子",
                "translation": "孩子让家庭重新选择",
            }],
        }]}

        issues = canonical.channel_theme_alignment_issues("xy-title", payload, context)

        self.assertIn("packaging_brief_core_story_promise_not_channel_theme", issues)

    def test_theme_phrase_stays_grounded_in_description_but_not_verbatim_in_community(self):
        context = {"channel_theme_contract": {
            "channel_direction": "萌宝家庭",
            "plot_supported": True,
            "required_output_signals": ["孩子", "萌宝", "宝宝"],
        }}
        place = {"results": [{
            "description": "Una historia de amor y traición.",
            "channel_theme_phrase": "los niños",
            "channel_theme_phrase_translation": "孩子",
            "editorial_anchor": "孩子回家",
            "translation": "萌宝家庭故事",
        }]}
        post = {"results": [{
            "copy": "Mira la historia completa.",
            "channel_theme_phrase": "los niños",
            "channel_theme_phrase_translation": "孩子",
            "selected_moment": "孩子回家",
            "interaction_angle": "萌宝选择",
            "copy_translation": "宝宝家庭",
        }]}

        self.assertIn(
            "place_localized_theme_phrase_missing_from_publication",
            canonical.channel_theme_alignment_issues("xy-place", place, context),
        )
        self.assertNotIn(
            "post_1_localized_theme_phrase_missing_from_publication",
            canonical.channel_theme_alignment_issues("xy-post", post, context),
        )

    def test_sweet_romance_channel_has_a_real_theme_profile(self):
        item = {"direction": "甜宠", "gender": "女频"}
        plot = {"results": [{"plot_fields": {"内容概述": "两人在相处中逐渐心动并确认恋爱关系。"}}]}

        contract = deterministic.channel_theme_contract(item, plot)

        self.assertTrue(contract["plot_supported"])
        self.assertIn("恋爱", contract["plot_support_signals"])

    def test_legacy_batch_without_machine_contract_is_not_blocked_by_new_preflight(self):
        issues = deterministic.stage_preflight_issues(
            "xy-title",
            {"task": {"workflow_contract_version": 1}},
            {},
        )

        self.assertEqual(issues, [])

    def test_downstream_outputs_acknowledge_the_exact_packaging_brief(self):
        brief = {
            "creative_slot_id": "slot-123",
            "channel_direction": "萌宝家庭",
            "core_story_promise": "孩子促成家庭关系重新选择",
        }
        aligned = {
            "packaging_brief_id": "slot-123",
            "channel_direction": "萌宝家庭",
            "core_story_promise": "孩子促成家庭关系重新选择",
        }
        drifted = {**aligned, "core_story_promise": "豪门继承争夺"}

        self.assertEqual(canonical.packaging_brief_alignment_issues("cover", aligned, brief), [])
        self.assertIn(
            "cover_packaging_brief_core_story_promise_mismatch",
            canonical.packaging_brief_alignment_issues("cover", drifted, brief),
        )

    def test_post_preflight_blocks_before_model_when_fixed_cta_contract_is_incomplete(self):
        context = {
            "task": {"workflow_contract_version": 2},
            "plot_payload": {"results": [{"plot_fields": {"内容概述": "孩子回家"}}]},
            "title_payload": {"results": [{"packaging_brief": {"channel_direction": "萌宝家庭"}}]},
            "channel_theme_contract": {"channel_direction": "萌宝家庭"},
            "community_footer_cta": {"full_video_cta": "Watch here"},
        }

        issues = deterministic.stage_preflight_issues(
            "xy-post", context, {"version": 3}
        )

        self.assertIn("preflight_community_fixed_cta_incomplete", issues)

    def test_workflow_events_are_append_only(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)

            deterministic.append_workflow_event(package, {"event": "text_ready", "status": "text_ready"})
            deterministic.append_workflow_event(package, {"event": "image_pending", "status": "pending"})

            rows = [
                __import__("json").loads(line)
                for line in (package / "workflow_events.jsonl").read_text(encoding="utf-8").splitlines()
            ]
            self.assertEqual([row["event"] for row in rows], ["text_ready", "image_pending"])
            self.assertTrue(all(row.get("created_at") for row in rows))

    def test_same_drama_channels_receive_distinct_pre_generation_creative_slots(self):
        index = {"items": [
            {"workflow_contract_version": 2, "drama_name": "同一部剧", "channel": "频道甲", "direction": "萌宝家庭"},
            {"workflow_contract_version": 2, "drama_name": "同一部剧", "channel": "频道乙", "direction": "萌宝家庭"},
            {"workflow_contract_version": 2, "drama_name": "同一部剧", "channel": "频道丙", "direction": "豪门婚恋"},
        ]}

        deterministic.allocate_creative_slots(index)

        slots = [item["creative_slot"] for item in index["items"]]
        self.assertEqual(len({slot["creative_slot_id"] for slot in slots}), 3)
        self.assertTrue(all("title_hook_preference" not in slot for slot in slots))
        self.assertTrue(all("thumbnail_layout_preference" not in slot for slot in slots))
        self.assertTrue(all(slot["creative_answer_policy"] == "fresh_model_creation_no_candidate_library" for slot in slots))

    def test_same_channel_different_dramas_receive_distinct_visual_slots(self):
        index = {"items": [
            {"workflow_contract_version": 2, "drama_name": "剧甲", "channel": "频道甲", "direction": "萌宝家庭"},
            {"workflow_contract_version": 2, "drama_name": "剧乙", "channel": "频道甲", "direction": "萌宝家庭"},
            {"workflow_contract_version": 2, "drama_name": "剧丙", "channel": "频道甲", "direction": "萌宝家庭"},
        ]}

        deterministic.allocate_creative_slots(index)

        slots = [item["creative_slot"] for item in index["items"]]
        self.assertEqual(len({slot["creative_slot_id"] for slot in slots}), 3)
        self.assertTrue(all("title_hook_preference" not in slot for slot in slots))
        self.assertTrue(all("thumbnail_layout_preference" not in slot for slot in slots))

    def test_new_batch_avoids_same_channel_slots_reserved_by_history(self):
        previous = {"items": [{
            "workflow_contract_version": 2,
            "drama_name": "旧剧",
            "channel": "频道甲",
            "creative_slot": {
                "title_hook_preference": "public_exposure",
                "thumbnail_layout_preference": "foreground_reaction_background_witness",
            },
        }]}
        current = {"items": [{
            "workflow_contract_version": 2,
            "drama_name": "新剧",
            "channel": "频道甲",
            "direction": "萌宝家庭",
        }]}

        deterministic.allocate_creative_slots(current, historical_indices=[previous])

        slot = current["items"][0]["creative_slot"]
        self.assertNotIn("title_hook_preference", slot)
        self.assertNotIn("thumbnail_layout_preference", slot)
        self.assertEqual(slot["creative_answer_policy"], "fresh_model_creation_no_candidate_library")

    def test_resumed_exact_task_keeps_its_frozen_creative_slot(self):
        frozen = {
            "creative_slot_id": "slot-stable",
            "allocation_ordinal": 2,
            "channel_direction": "豪门婚恋",
            "title_hook_preference": "public_exposure",
            "thumbnail_layout_preference": "protective_triangle_blocking",
            "truth_rule": "preference_only_use_verified_plot_facts",
        }
        previous = {"items": [{
            "workflow_contract_version": 2,
            "drama_name": "星河若无声灯火有归期",
            "channel": "频道甲",
            "slot": "2026081820",
            "creative_slot": frozen,
        }]}
        current = {"items": [{
            "workflow_contract_version": 2,
            "drama_name": "星河若无声灯火有归期",
            "channel": "频道甲",
            "slot": "2026081820",
            "direction": "豪门婚恋",
        }]}

        deterministic.allocate_creative_slots(current, historical_indices=[previous])

        self.assertEqual(current["items"][0]["creative_slot"], frozen)

    def test_stage_context_loads_only_the_history_that_stage_can_use(self):
        self.assertEqual(deterministic.history_requirements_for_stage("xy-find"), (False, False))
        self.assertEqual(deterministic.history_requirements_for_stage("xy-title"), (False, True))
        self.assertEqual(deterministic.history_requirements_for_stage("xy-cover"), (True, True))
        self.assertEqual(deterministic.history_requirements_for_stage("xy-place"), (False, True))
        self.assertEqual(deterministic.history_requirements_for_stage("xy-post"), (False, True))

    def test_generation_prompt_receives_the_same_frozen_contract_as_validation(self):
        cover_contract = {"version": 81, "prompt_audit": {"prompt_word_count_mode": "audit_only"}}
        post_contract = {"version": 31, "min_non_empty_lines": 9}

        cover = deterministic.stage_context("xy-cover", {"cover_rule_contract": cover_contract})
        post = deterministic.stage_context("xy-post", {"community_rule_contract": post_contract})

        self.assertEqual(cover["cover_rule_contract"], cover_contract)
        self.assertEqual(post["community_rule_contract"], post_contract)

    def assert_openai_strict_objects(self, schema, path="$"):
        if not isinstance(schema, dict):
            return
        if schema.get("type") == "object":
            properties = schema.get("properties", {})
            self.assertEqual(
                set(schema.get("required", [])), set(properties),
                f"strict object required/properties mismatch at {path}",
            )
            self.assertIs(schema.get("additionalProperties"), False)
        for key, value in schema.items():
            if isinstance(value, dict):
                self.assert_openai_strict_objects(value, f"{path}.{key}")

    def test_every_runtime_schema_is_openai_strict_and_post_count_is_exact(self):
        for stage in canonical.SCHEMAS:
            with self.subTest(stage=stage):
                item = {"community_output_version": 2, "community_count": 2, "need_community": 1}
                schema = canonical.schema_for(stage, item)
                self.assert_openai_strict_objects(schema)
        post = canonical.schema_for(
            "xy-post", {"community_output_version": 2, "community_count": 2, "need_community": 1}
        )
        self.assertEqual(post["properties"]["results"]["minItems"], 2)
        self.assertEqual(post["properties"]["results"]["maxItems"], 2)
        required = set(post["properties"]["results"]["items"]["required"])
        self.assertIn("plan_index", required)
        self.assertIn("scene_family", required)
        self.assertIn("palette", required)

    def test_legacy_post_schema_is_separate_and_has_no_v2_only_fields(self):
        schema = canonical.schema_for("xy-post", {"need_community": 1})
        properties = schema["properties"]["results"]["items"]["properties"]
        self.assertNotIn("plan_index", properties)
        self.assertNotIn("scene_family", properties)
        self.assert_openai_strict_objects(schema)

    def test_interrupted_running_item_with_exhausted_stage_is_retry_candidate(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            state = {
                "steps": {
                    "xy-post": {
                        "status": "retrying",
                        "attempts": 3,
                        "attempts_total": 3,
                        "retry_cycle": 1,
                        "errors": ["old strict schema 400"],
                    }
                }
            }
            (package / "workflow_state.json").write_text(__import__("json").dumps(state), encoding="utf-8")
            item = {
                "status": "running",
                "current_stage": "xy-post",
                "package_path": str(package),
                "video_id": "pending_probe",
            }
            self.assertTrue(deterministic.needs_retry_approval(item))
            self.assertTrue(deterministic.approve_retry_cycle(item))
            updated = __import__("json").loads((package / "workflow_state.json").read_text())
            self.assertEqual(updated["steps"]["xy-post"]["status"], "approved_retry")
            self.assertEqual(updated["steps"]["xy-post"]["attempts"], 0)
            self.assertEqual(updated["steps"]["xy-post"]["retry_cycle"], 2)
            self.assertEqual(updated["steps"]["xy-post"]["errors"], ["old strict schema 400"])
            self.assertEqual(item["resume_from_stage"], "xy-post")

    def test_new_index_detects_exhausted_package_stage_without_empty_first_run(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            state = {"steps": {
                "xy-title": {"status": "done", "attempts": 1},
                "xy-cover": {
                    "status": "needs_user_review",
                    "attempts": 3,
                    "errors": ["cover_2_content_failure"],
                },
            }}
            (package / "workflow_state.json").write_text(__import__("json").dumps(state), encoding="utf-8")
            item = {
                "status": "INITIALIZED",
                "current_stage": "xy-title",
                "package_path": str(package),
                "video_id": "new_index_probe",
            }

            self.assertTrue(deterministic.needs_retry_approval(item))
            self.assertTrue(deterministic.approve_retry_cycle(item))

            updated = __import__("json").loads((package / "workflow_state.json").read_text())
            self.assertEqual(item["current_stage"], "xy-cover")
            self.assertEqual(
                updated["steps"]["xy-cover"]["errors"],
                ["cover_2_content_failure"],
            )
            self.assertEqual(item["resume_from_stage"], "xy-cover")

    def test_retry_approval_uses_actual_unfinished_stage_when_index_stage_is_stale(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            state = {
                "steps": {
                    "xy-title": {"status": "done", "attempts": 1, "retry_cycle": 1},
                    "xy-cover": {
                        "status": "needs_user_review",
                        "attempts": 3,
                        "attempts_total": 3,
                        "retry_cycle": 1,
                        "errors": ["cover failed"],
                    },
                }
            }
            (package / "workflow_state.json").write_text(__import__("json").dumps(state), encoding="utf-8")
            item = {
                "status": "NEEDS_USER_REVIEW",
                "current_stage": "xy-title",
                "package_path": str(package),
                "video_id": "stale_stage_probe",
            }

            self.assertTrue(deterministic.approve_retry_cycle(item))

            updated = __import__("json").loads((package / "workflow_state.json").read_text())
            self.assertEqual(item["current_stage"], "xy-cover")
            self.assertEqual(updated["steps"]["xy-cover"]["status"], "approved_retry")
            self.assertEqual(updated["steps"]["xy-cover"]["retry_cycle"], 2)
            self.assertEqual(item["resume_from_stage"], "xy-cover")

    def test_failed_task_never_retires_worker_slot(self):
        for status in ("done", "failed", "needs_user_review"):
            with self.subTest(status=status):
                self.assertTrue(deterministic.should_refill_worker(status))

    def test_writeback_failure_is_resumable_without_content_retry_approval(self):
        result = deterministic.failure_result_for_exception(
            deterministic.WritebackPendingError("Feishu暂时不可用")
        )

        self.assertEqual(result["status"], "WRITEBACK_PENDING")
        self.assertEqual(result["error_type"], "SYSTEM_ERROR")
        self.assertIn("Feishu暂时不可用", result["error"])
        queue = deterministic.runnable_items(
            {"items": [{"status": "writeback_pending", "output_row_number": 2}]},
            retry_failed=False,
            max_output_row=0,
        )
        self.assertEqual(len(queue), 1)

    def test_writeback_pending_claim_preserves_resume_stage_without_rewriting_base_fields(self):
        with tempfile.TemporaryDirectory() as temp_name:
            index_path = Path(temp_name) / "index.json"
            item = {
                "status": "writeback_pending",
                "current_stage": "xy-cover",
                "output_row_number": 9,
            }
            controller = deterministic.BatchController(index_path, {"items": [item]}, skip_export=False)

            with mock.patch.object(deterministic, "ensure_output_base_row") as ensure:
                controller.claim(item)

            ensure.assert_not_called()
            self.assertEqual(item["resume_from_stage"], "xy-cover")
            self.assertEqual(item["status"], "CLAIMED")

    def test_system_error_claim_resumes_failed_stage_without_rewriting_base_fields(self):
        with tempfile.TemporaryDirectory() as temp_name:
            index_path = Path(temp_name) / "index.json"
            item = {
                "status": "SYSTEM_ERROR",
                "current_stage": "xy-cover",
                "output_row_number": 9,
            }
            controller = deterministic.BatchController(index_path, {"items": [item]}, skip_export=False)

            with mock.patch.object(deterministic, "ensure_output_base_row") as ensure:
                controller.claim(item)

            ensure.assert_not_called()
            self.assertEqual(item["resume_from_stage"], "xy-cover")
            self.assertEqual(item["status"], "CLAIMED")

    def test_identity_corrected_clean_recreate_claim_reuses_exact_output_row(self):
        with tempfile.TemporaryDirectory() as temp_name:
            index_path = Path(temp_name) / "index.json"
            item = {
                "status": "INITIALIZED",
                "output_row_number": 97,
                "video_id": "video-a",
                "clean_recreate": {
                    "source_drama_name": "简称",
                    "target_drama_name": "权威完整名",
                },
            }
            controller = deterministic.BatchController(index_path, {"items": [item]}, skip_export=False)

            with mock.patch.object(deterministic, "ensure_output_base_row") as append_row, mock.patch.object(
                deterministic, "rewrite_output_base_row"
            ) as rewrite_row:
                rewrite_row.return_value = {
                    "row_number": 97, "updated": True, "readback_verified": True,
                }
                controller.claim(item)

            append_row.assert_not_called()
            rewrite_row.assert_called_once_with(item, 97, "简称")
            self.assertEqual(item["output_row_number"], 97)
            self.assertEqual(item["status"], "CLAIMED")

    def test_clean_recreate_record_restores_intended_output_row_after_interruption(self):
        index = {
            "clean_recreate": {
                "records": [
                    {"video_id": "video-a", "output_row_number": 97},
                    {"video_id": "video-b", "output_row_number": 131},
                ]
            },
            "items": [
                {"video_id": "video-a", "output_row_number": 287},
                {"video_id": "video-b", "output_row_number": 288},
            ],
        }

        changed = deterministic.restore_clean_recreate_output_rows(index)

        self.assertEqual(changed, 2)
        self.assertEqual([item["output_row_number"] for item in index["items"]], [97, 131])


    def test_writeback_resume_skips_stages_before_the_failed_checkpoint(self):
        self.assertEqual(
            deterministic.content_stages_for_resume("xy-cover"),
            ("xy-cover", "xy-place", "xy-post"),
        )
        self.assertEqual(
            deterministic.content_stages_for_resume(""),
            deterministic.CONTENT_STAGES,
        )

    def test_orphan_running_labels_are_normalized_before_claiming(self):
        index = {"items": [{"status": "running", "video_id": "old"}, {"status": "initialized", "video_id": "new"}]}
        self.assertEqual(deterministic.normalize_interrupted_items(index), 1)
        self.assertEqual(index["items"][0]["status"], "INTERRUPTED")
        self.assertEqual(index["items"][1]["status"], "initialized")

    def test_community_count_contract(self):
        cases = {
            "": 0,
            "  ": 0,
            "0": 0,
            "1": 1,
            "2": 2,
            "9": 9,
            "-1": 1,
            "1.5": 1,
            "yes": 1,
            "★": 1,
        }
        for raw, expected in cases.items():
            with self.subTest(raw=raw):
                self.assertEqual(init_batch.parse_community_count(raw), expected)

    def test_missing_video_link_gets_stable_placeholder_identity(self):
        first = init_batch.normalize_video_id("", "", "剧名", "频道", "2026081412")
        second = init_batch.normalize_video_id("", "", "剧名", "频道", "2026081412")
        self.assertEqual(first, second)
        self.assertTrue(first.startswith("pending_"))
        self.assertEqual(init_batch.normalize_url(first, ""), "【视频链接待补】")

    def test_existing_batch_keeps_legacy_workflow_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            batch_dir = Path(tmp)
            snapshot = batch_dir / "生产契约快照.json"
            snapshot.write_text(json.dumps({"version": 3}), encoding="utf-8")
            self.assertEqual(init_batch.workflow_contract_version_for_batch(batch_dir, True), 1)

            snapshot.write_text(json.dumps({"version": 4}), encoding="utf-8")
            self.assertEqual(init_batch.workflow_contract_version_for_batch(batch_dir, True), 2)

        self.assertEqual(init_batch.workflow_contract_version_for_batch(Path(tmp), False), 2)

    def test_only_asset_complete_items_are_terminal_for_batch_continuation(self):
        self.assertTrue(init_batch.has_unfinished_items({"items": [{"status": "package_ready"}]}))
        self.assertFalse(init_batch.has_unfinished_items({"items": [{"status": "DELIVERED"}]}))
        self.assertTrue(init_batch.has_unfinished_items({"items": [{"status": "text_ready"}]}))

    def test_completed_only_export_excludes_dry_run_and_skipped_items(self):
        self.assertFalse(exporter.should_export_item({"status": "dry_run"}, True))
        self.assertFalse(exporter.should_export_item({"status": "skipped"}, True))
        self.assertFalse(exporter.should_export_item({"status": "text_ready"}, True))
        self.assertTrue(exporter.should_export_item({"status": "PACKAGE_READY"}, True))
        self.assertFalse(exporter.should_export_item({"status": "TEXT_READY"}, False))
        self.assertTrue(exporter.should_export_item({"status": "DELIVERED"}, False))

    def test_existing_feishu_row_base_fields_are_fully_compared(self):
        item = {
            "slot": "2026081712", "channel": "频道", "nickname": "昵称",
            "drama_name": "剧名", "video_id": "video-new", "url": "https://youtu.be/new",
            "community_count": 2,
        }
        columns = {name: index for index, name in enumerate(exporter.HEADERS)}
        row = [
            "2026-08-17", "频道", "旧昵称", "剧名", "video-old",
            "https://youtu.be/old", "2026081712", "1",
        ]

        differences = exporter.base_row_differences(row, columns, item)

        self.assertEqual(
            set(differences), {"频道昵称", "剧id", "剧目地址", "是否需要社区"}
        )

    def test_export_audit_can_use_batch_frozen_community_contract(self):
        contract = {
            "normalize_markdown_links_before_validation": False,
            "forbid_markdown_links": True,
            "require_single_short_url": True,
            "min_non_empty_lines": 1,
            "fixed_emojis": [],
        }
        copy = "🔥 Watch 👉 https://youtu.be/abc123\n🤔 Question?\n👇 Answer\n🔔 Subscribe\n🙏 Share"

        with mock.patch.object(exporter, "load_community_rule_bundle", side_effect=AssertionError("live contract used")):
            issues = exporter.community_copy_issues(copy, contract=contract)

        self.assertNotIn("社群文案短链数量不是1: 0", issues)

    def test_export_loads_machine_rules_from_the_batch_snapshot(self):
        with tempfile.TemporaryDirectory() as temp_name:
            batch = Path(temp_name)
            (batch / "生产契约快照.json").write_text(json.dumps({
                "machine_contracts": {
                    "xy-cover": {"content": {"version": 81}},
                    "xy-post": {"content": {"version": 31}},
                }
            }), encoding="utf-8")

            contracts = exporter.load_batch_machine_contracts(batch)

        self.assertEqual(contracts["xy-cover"]["version"], 81)
        self.assertEqual(contracts["xy-post"]["version"], 31)

    def test_channel_fixed_asset_overrides_are_frozen_inside_new_package(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            channel = root / "channel"
            package = root / "package"
            channel.mkdir()
            package.mkdir()
            (channel / "description_fixed_assets.json").write_text(
                json.dumps({"subscribe_line": "fixed description"}), encoding="utf-8"
            )
            (channel / "community_footer_cta.json").write_text(
                json.dumps({"share_cta": "fixed share"}), encoding="utf-8"
            )

            path = init_batch.write_channel_asset_snapshot(package, channel)
            frozen = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(frozen["description_fixed_assets"]["subscribe_line"], "fixed description")
        self.assertEqual(frozen["community_footer_cta"]["share_cta"], "fixed share")

    def test_post_validator_accepts_exact_two_distinct_results_with_placeholder(self):
        item = {
            "drama_name": "测试剧",
            "video_id": "pending_abc",
            "url": "【视频链接待补】",
            "slot": "2026081412",
            "community_count": 2,
            "need_community": 1,
        }
        identity = {
            "search_result_index": 1,
            "source_block_label": "搜索资料1",
            "result_id": "pending_abc_1",
            "video_id": "pending_abc",
            "drama_name": "测试剧",
        }
        def result(index, moment, angle, hook, copy):
            return {
                **identity,
                "plan_index": index,
                "community_hook_type": hook,
                "selected_moment": moment,
                "interaction_angle": angle,
                "scene_family": f"scene-{index}",
                "main_action": f"action-{index}",
                "key_prop": f"prop-{index}",
                "composition": f"composition-{index}",
                "palette": f"palette-{index}",
                "image_prompt_1x1": (
                    f"Create plan {index}. Chinese facial features, contemporary Chinese short-drama cast appearance."
                ),
                "copy": copy,
                "copy_translation": f"第{index}套中文审阅翻译，内容彼此不同。",
            }
        payload = {
            "section": "community",
            "results": [
                result(1, "董事会公开揭穿冒名者", "观众是否会当场反击", "public_exposure",
                       "🔥 Full story 👉 【视频链接待补】\nA\nB\nC\n🤔 Q1\n👇 C1\n🔔 S1\n🙏 Share1"),
                result(2, "母亲在旧宅认出信物", "观众会选择亲情还是真相", "identity_reveal",
                       "🔥 Watch now 👉 【视频链接待补】\nD\nE\nF\n🤔 Q2\n👇 C2\n🔔 S2\n🙏 Share2"),
            ],
        }
        issues = canonical.validate_payload("xy-post", payload, item, {"community_footer_cta": {}, "creative_history": []})
        self.assertEqual(issues, [])

    def test_manifest_contains_one_image_per_community_plan(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            payload = {
                "section": "community",
                "results": [
                    {"plan_index": 1, "image_prompt_1x1": "prompt one"},
                    {"plan_index": 2, "image_prompt_1x1": "prompt two"},
                ],
            }
            (package / "06_社群方案.json").write_text(__import__("json").dumps(payload), encoding="utf-8")
            cover = {"results": [{"titles": []}]}
            (package / "04_封面提示词.json").write_text(__import__("json").dumps(cover), encoding="utf-8")
            item = {"video_id": "pending_abc", "community_count": 2, "need_community": 1}
            deterministic.build_prompt_manifest(package, item)
            manifest = __import__("json").loads((package / "images/prompts/出图任务清单.json").read_text())
            community = [task for task in manifest["tasks"] if task["slug"].startswith("community")]
            self.assertEqual([task["slug"] for task in community], ["community1", "community2"])
            self.assertEqual(manifest["community_count"], 2)
            self.assertEqual(manifest["required_asset_manifest"]["required_count"], len(manifest["tasks"]))
            self.assertEqual(
                manifest["required_asset_manifest"]["required_task_ids"],
                [task["task_id"] for task in manifest["tasks"]],
            )

    def test_cover_manifest_requires_real_outpaint_dependency_and_center_restore(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            cover = {"results": [{"titles": [{
                "title_index": 1,
                "prompt_4_5": "Generate the approved 4:5 source image.",
                "prompt_16_9": canonical.canonical_outpaint_prompt("Continue the apartment corridor walls."),
            }]}]}
            (package / "04_封面提示词.json").write_text(__import__("json").dumps(cover), encoding="utf-8")
            (package / "06_社群方案.json").write_text('{"results": []}', encoding="utf-8")

            deterministic.build_prompt_manifest(package, {"video_id": "vid", "need_community": 0})

            manifest = __import__("json").loads((package / "images/prompts/出图任务清单.json").read_text())
            portrait, wide = manifest["tasks"]
            self.assertEqual(wide["generation_mode"], "image_to_image_outpaint")
            self.assertEqual(wide["depends_on_task_id"], portrait["task_id"])
            self.assertEqual(wide["source_image_task_id"], portrait["task_id"])
            self.assertEqual(wide["mask_policy"], "side_bands_only")
            self.assertTrue(wide["center_restore_required"])
            wide_prompt = Path(wide["prompt_file"]).read_text(encoding="utf-8")
            self.assertIn("Do not run this as standalone text-to-image", wide_prompt)
            self.assertEqual(wide_prompt.count("Image-to-image environmental outpainting only"), 1)
            self.assertIn("side-only outpaint mask", wide_prompt)
            self.assertIn("composite the approved 4:5 source pixels back", wide_prompt)

    def test_cover_manifest_reads_wide_execution_mode_from_versioned_contract(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            cover = {"results": [{"titles": [{
                "title_index": 1,
                "prompt_4_5": "portrait",
                "prompt_16_9": "wide",
            }]}]}
            (package / "04_封面提示词.json").write_text(__import__("json").dumps(cover), encoding="utf-8")
            (package / "06_社群方案.json").write_text('{"results": []}', encoding="utf-8")
            contract = {"prompt_audit": {"wide_generation_execution": {
                "mode": "contract_outpaint_mode",
                "mask_policy": "contract_side_mask",
                "center_restore_required": True,
            }}}

            with mock.patch.object(deterministic, "load_cover_rule_bundle", return_value=contract):
                deterministic.build_prompt_manifest(package, {"video_id": "vid", "need_community": 0})

            manifest = __import__("json").loads((package / "images/prompts/出图任务清单.json").read_text())
            wide = manifest["tasks"][1]
            self.assertEqual(wide["generation_mode"], "contract_outpaint_mode")
            self.assertEqual(wide["mask_policy"], "contract_side_mask")

    def test_cover_manifest_prefers_batch_frozen_contract_over_live_disk_rules(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            cover = {"results": [{"titles": [{
                "title_index": 1,
                "prompt_4_5": "portrait",
                "prompt_16_9": "wide",
            }]}]}
            (package / "04_封面提示词.json").write_text(__import__("json").dumps(cover), encoding="utf-8")
            (package / "06_社群方案.json").write_text('{"results": []}', encoding="utf-8")
            frozen = {"prompt_audit": {"wide_generation_execution": {
                "mode": "frozen_outpaint_mode",
                "mask_policy": "frozen_side_mask",
                "center_restore_required": True,
            }}}
            live = {"prompt_audit": {"wide_generation_execution": {
                "mode": "drifted_live_mode",
                "mask_policy": "drifted_live_mask",
                "center_restore_required": False,
            }}}

            with mock.patch.object(deterministic, "load_cover_rule_bundle", return_value=live):
                deterministic.build_prompt_manifest(
                    package, {"video_id": "vid", "need_community": 0}, cover_rule_contract=frozen
                )

            manifest = __import__("json").loads((package / "images/prompts/出图任务清单.json").read_text())
            wide = manifest["tasks"][1]
            self.assertEqual(wide["generation_mode"], "frozen_outpaint_mode")
            self.assertEqual(wide["mask_policy"], "frozen_side_mask")
            self.assertTrue(wide["center_restore_required"])

    def test_post_stage_writes_numbered_column_pairs(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            payload = {
                "results": [
                    {"plan_index": 1, "copy": "copy1", "image_prompt_1x1": "image1"},
                    {"plan_index": 2, "copy": "copy2", "image_prompt_1x1": "image2"},
                ]
            }
            (package / "06_社群方案.json").write_text(__import__("json").dumps(payload), encoding="utf-8")
            headers, values = exporter.stage_output_values(package, "xy-post", {"community_count": 2})
            self.assertEqual(headers, ["社群文案1", "社群图描述1", "社群文案2", "社群图描述2"])
            self.assertEqual(values, ["copy1", "image1", "copy2", "image2"])

    def test_post_stage_narrow_writes_noncontiguous_numbered_columns(self):
        with tempfile.TemporaryDirectory() as temp_name:
            package = Path(temp_name)
            payload = {
                "results": [
                    {"plan_index": 1, "copy": "copy1", "image_prompt_1x1": "image1"},
                    {"plan_index": 2, "copy": "copy2", "image_prompt_1x1": "image2"},
                ]
            }
            (package / "06_社群方案.json").write_text(__import__("json").dumps(payload), encoding="utf-8")
            header = [
                "日期", "频道", "频道昵称", "剧名", "剧id", "剧目地址", "档期", "是否需要社区",
                "标题", "社群文案1", "说明", "社群图描述1", "社群文案2", "播放列表", "社群图描述2",
            ]
            columns = {name: index for index, name in enumerate(header)}
            calls = []
            with (
                mock.patch.object(exporter, "load_config", return_value={}),
                mock.patch.object(exporter, "get_token", return_value="token"),
                mock.patch.object(exporter, "get_wiki_sheet_token", return_value="spreadsheet"),
                mock.patch.object(exporter, "find_output_sheet_id", return_value="sheet"),
                mock.patch.object(exporter, "read_output_table", return_value=[header, []]),
                mock.patch.object(exporter, "match_task_row", return_value=(2, columns)),
                mock.patch.object(exporter, "ensure_matched_base_row", return_value=False),
                mock.patch.object(exporter, "put_values", side_effect=lambda *args: calls.append(args)),
                mock.patch.object(exporter, "read_row", side_effect=lambda *args: calls[-1][-1]),
            ):
                result = exporter.write_stage_back(
                    {"community_count": 2, "community_output_version": 2},
                    package,
                    "xy-post",
                    "dummy-config.json",
                )
            self.assertTrue(result["updated"])
            self.assertEqual(
                [(args[2], args[3]) for args in calls],
                [
                    ("sheet!J2:J2", [["copy1"]]),
                    ("sheet!L2:M2", [["image1", "copy2"]]),
                    ("sheet!O2:O2", [["image2"]]),
                ],
            )

    def test_v2_header_plan_renames_legacy_pair_and_appends_after_last_real_header(self):
        header = ["日期", "频道", "社群文案", "社群图描述"] + [""] * 48
        required = ["社群文案1", "社群图描述1", "社群文案2", "社群图描述2"]
        planned, writes = exporter.plan_v2_community_headers(header, required)
        self.assertEqual(planned[:6], ["日期", "频道", *required])
        self.assertEqual(
            writes,
            [(2, "社群文案1"), (3, "社群图描述1"), (4, "社群文案2"), (5, "社群图描述2")],
        )


if __name__ == "__main__":
    unittest.main()
