import importlib.util
import json
import sys
import unittest
from pathlib import Path

from channel_context_fixture import structured_channel_snapshot


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "deterministic_batch.py"
sys.path.insert(0, str(SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("v14_title_local_language_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class V14TitleLocalLanguageRealizationTests(unittest.TestCase):
    def prompt(self):
        rules = json.loads(MODULE.MACHINE_RULE_PATHS["xy-title"].read_text(encoding="utf-8"))
        context = {
            "task": {
                "drama_name": "动态剧目",
                "channel": "动态孟加拉频道",
                "language": "孟加拉语",
            },
            "identity": {"video_id": "dynamic-video"},
            "channel_snapshot": structured_channel_snapshot(
                global_body="目标市场：孟加拉；自然口语"
            ),
            "channel_theme_contract": {"channel_direction": "动态频道方向"},
            "semantic_contract": {},
            "creative_slot": {},
            "title_rule_contract": rules["title_contract"],
            "plot_payload": {"results": [{"plot_fields": {"内容概述": "动态真实剧情"}}]},
            "creative_history": [],
        }
        static_prompt = MODULE.SIMULATED_SKILLS["xy-title"].read_text(encoding="utf-8")
        return rules, MODULE.build_prompt("xy-title", static_prompt, context, [])

    def test_marketing_semantics_precede_local_language_realization(self):
        rules, prompt = self.prompt()
        contract = rules["title_contract"]["target_language_realization"]
        self.assertEqual(
            contract["stage_order"],
            ["finalize marketing semantics and the A-to-B causal line", "realize them naturally in the target language"],
        )
        self.assertLess(prompt.index("Finalize the marketing semantics"), prompt.index("Then realize that unchanged meaning naturally"))

    def test_naturalization_preserves_click_strength_and_facts(self):
        _, prompt = self.prompt()
        self.assertIn("must not weaken the conflict, reversal, payoff, or position change", prompt)
        self.assertIn("must not change facts or invent identities, amounts, assets, power, or relationships", prompt)
        self.assertIn("may reorganize grammar, clause order, pronouns, punctuation, time placement", prompt)
        self.assertIn("locally natural forms of address", prompt)

    def test_realization_is_abstract_model_only_not_a_new_gate_or_template_library(self):
        rules, prompt = self.prompt()
        contract = rules["title_contract"]["target_language_realization"]
        self.assertFalse(contract["validator_gate"])
        self.assertFalse(contract["schema_change"])
        self.assertFalse(contract["controller_semantic_detection"])
        self.assertTrue(contract["prebuilt_sentence_templates_forbidden"])
        self.assertIn("model-only native-language self-check", prompt)
        self.assertIn("Do not create or use a fixed sentence-pattern library", prompt)

    def test_dynamic_language_and_market_context_remain_visible(self):
        _, prompt = self.prompt()
        for value in ("孟加拉语", "动态孟加拉频道", "目标市场：孟加拉；自然口语", "动态真实剧情"):
            self.assertIn(value, prompt)

    def test_native_language_self_check_keeps_relationship_action_and_result_clear(self):
        rules, prompt = self.prompt()
        checks = rules["title_contract"]["target_language_realization"][
            "model_only_native_language_self_check"
        ]

        self.assertIn(
            "the relationship, action, and result remain immediately clear",
            checks,
        )
        self.assertIn(
            "the relationship, action, and result should remain immediately clear",
            prompt,
        )

    def test_localization_reduces_comprehension_cost_without_narrative_expansion(self):
        rules, prompt = self.prompt()
        contract = rules["title_contract"]["target_language_realization"]

        self.assertEqual(
            contract["clarity_priority"],
            [
                "relationship clarity",
                "action clarity",
                "result clarity",
                "natural word order",
                "conciseness",
            ],
        )
        self.assertIn("reduce first-read comprehension cost", contract["purpose"])
        self.assertIn("expand the title with background or narrative detail", contract["must_not"])
        self.assertIn("reduce first-read comprehension cost", prompt)
        self.assertIn("not to make the title more literary", prompt)


if __name__ == "__main__":
    unittest.main()
