import importlib.util
import sys
import unittest
from pathlib import Path


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
PACK_SCRIPTS = SKILLS / "xy-pack-v14/scripts"
if str(PACK_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(PACK_SCRIPTS))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


CANONICAL = load_module(
    "v14_validator_semantic_boundary_test",
    PACK_SCRIPTS / "canonical_outputs.py",
)


def current_v14_context():
    return {
        "semantic_contract": {
            "version": 14,
            "fixed_localized_title_candidates": False,
        },
        "channel_theme_contract": {
            "channel_direction": "复仇逆袭",
            "plot_supported": True,
            "required_output_signals": ["复仇", "逆袭", "羞辱", "反击"],
        },
    }


class ValidatorSemanticBoundaryTests(unittest.TestCase):
    def test_place_theme_meaning_is_not_a_mechanical_validator_gate(self):
        payload = {
            "results": [
                {
                    "editorial_anchor": "她公开揭穿骗局并重新掌握人生",
                    "channel_theme_phrase": "Da traição à virada",
                    "description": "A traição virou contra-ataque e ela retomou a própria vida.",
                }
            ]
        }

        issues = CANONICAL.channel_theme_alignment_issues(
            "xy-place", payload, current_v14_context()
        )

        self.assertEqual(issues, [])

    def test_post_theme_meaning_is_not_a_mechanical_validator_gate(self):
        payload = {
            "results": [
                {
                    "selected_moment": "她揭穿冒名者并夺回家族位置",
                    "interaction_angle": "观众判断家人是否值得原谅",
                    "channel_theme_phrase": "Her comeback starts when the lie ends.",
                    "copy": "She exposes the impostor and takes back her place in the family.",
                    "image_prompt_1x1": "A Chinese heroine confronts the impostor before her family.",
                }
            ]
        }

        issues = CANONICAL.channel_theme_alignment_issues(
            "xy-post", payload, current_v14_context()
        )

        self.assertEqual(issues, [])

    def test_objective_packaging_brief_mismatches_remain_rejected(self):
        issues = CANONICAL.packaging_brief_alignment_issues(
            "place",
            {
                "packaging_brief_id": "wrong-slot",
                "channel_direction": "复仇逆袭",
                "core_story_promise": "她夺回人生",
            },
            {
                "creative_slot_id": "slot-1",
                "channel_direction": "复仇逆袭",
                "core_story_promise": "她夺回人生",
            },
        )

        self.assertEqual(issues, ["place_packaging_brief_packaging_brief_id_mismatch"])


if __name__ == "__main__":
    unittest.main()
