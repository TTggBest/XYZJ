import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

from channel_context_fixture import structured_channel_snapshot


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
SCRIPTS = SKILLS / "xy-batch-v14" / "scripts"
sys.path.insert(0, str(SCRIPTS))

SPEC = importlib.util.spec_from_file_location(
    "title_negative_term_frequency_batch", SCRIPTS / "deterministic_batch.py"
)
BATCH = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = BATCH
SPEC.loader.exec_module(BATCH)


def write_title(package: Path, translations: list[str]) -> None:
    package.mkdir(parents=True, exist_ok=True)
    (package / "04_标题方案.json").write_text(
        json.dumps(
            {
                "results": [
                    {
                        "directions": [
                            {"index": index, "translation": value}
                            for index, value in enumerate(translations, 1)
                        ]
                    }
                ]
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )


class TitleNegativeTermFrequencyGuidanceTests(unittest.TestCase):
    def test_counts_only_current_channel_prior_seven_day_title_candidates(self):
        with tempfile.TemporaryDirectory() as temp_name:
            channel = Path(temp_name) / "印地" / "测试频道"
            current = channel / "剧目" / "当前剧_2026082412"
            current.mkdir(parents=True)
            write_title(channel / "剧目" / "近期开包_2026082312", ["我遭到背叛后归来！", "这场复仇刚开始！", "小三偷走一切！"])
            write_title(channel / "剧目" / "窗口边界_2026081713", ["背叛让我反击！", "骗局被揭开！", "普通标题"])
            write_title(channel / "剧目" / "过期包_2026081612", ["复仇！", "背叛！", "骗局！"])
            other = Path(temp_name) / "印地" / "其他频道" / "剧目" / "其他剧_2026082312"
            write_title(other, ["复仇！", "背叛！", "骗局！"])

            policy = {
                "terms": {
                    "复仇": {"aliases": ["复仇"], "max_uses_7d": 2},
                    "背叛": {"aliases": ["背叛"], "max_uses_7d": 2},
                    "骗局": {"aliases": ["骗局"], "max_uses_7d": 1},
                    "情人/小三": {"aliases": ["情人", "小三"], "max_uses_7d": 1},
                }
            }
            usage = BATCH.recent_channel_title_term_usage_7d(
                current,
                {"slot": "2026082412", "channel": "测试频道"},
                policy,
            )

            self.assertEqual(usage["window_start"], "2026081712")
            self.assertEqual(usage["window_end"], "2026082412")
            self.assertEqual(usage["counts"], {"复仇": 1, "背叛": 2, "骗局": 1, "情人/小三": 1})
            self.assertEqual(usage["count_basis"], "accepted_generated_title_candidates")

    def test_title_prompt_uses_usage_as_soft_generation_guidance(self):
        prompt = BATCH.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "测试剧", "language": "印地", "workflow_contract_version": 2},
                "channel_theme_contract": {"channel_direction": "复仇逆袭", "plot_supported": True},
                "channel_snapshot": structured_channel_snapshot(),
                "recent_channel_title_usage_7d": {
                    "counts": {"复仇": 2, "背叛": 1},
                    "limits": {"复仇": 2, "背叛": 2},
                    "window_start": "2026081712",
                    "window_end": "2026082412",
                    "count_basis": "accepted_generated_title_candidates",
                },
            },
            [],
        )

        self.assertIn("Seven-day negative-term usage is soft generation guidance", prompt)
        self.assertIn('"复仇": 2', prompt)
        self.assertIn("At or above a numeric preference, choose another hard expression", prompt)
        self.assertIn("Never fail, retry, or block production solely for this frequency guidance", prompt)

    def test_policy_is_explicitly_not_a_validator_gate(self):
        rules = json.loads((SKILLS / "xy-title-v14/rules/title_rules.json").read_text())
        policy = rules["title_contract"]["negative_term_frequency_guidance"]
        self.assertEqual(policy["enforcement"], "soft_generation_guidance_only")
        self.assertFalse(policy["validator_gate"])
        self.assertFalse(policy["missing_history_blocks_generation"])


if __name__ == "__main__":
    unittest.main()
