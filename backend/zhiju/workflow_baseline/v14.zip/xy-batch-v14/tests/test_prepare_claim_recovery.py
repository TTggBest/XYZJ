import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "prepare_claim_recovery.py"
SPEC = importlib.util.spec_from_file_location("prepare_claim_recovery_under_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class PrepareClaimRecoveryTests(unittest.TestCase):
    def test_builds_exact_scope_with_cadence_counts(self):
        with tempfile.TemporaryDirectory() as name:
            index = Path(name) / "今日任务索引.json"
            items = []
            for row_number, channel in ((2, "单更"), (3, "双更"), (4, "双更")):
                items.append({
                    "row_number": row_number,
                    "video_id": f"video-{row_number}",
                    "channel": channel,
                    "slot": f"20260819{row_number:02d}",
                    "community_count": 1,
                    "status": "WRITEBACK_PENDING",
                    "current_stage": "claim",
                    "error": "领取任务失败: Feishu基础字段回写失败: 任务表为空",
                })
            index.write_text(json.dumps({"items": items}), encoding="utf-8")
            scope = MODULE.build_claim_recovery_scope(
                index,
                batch_id="V2-19-RECOVERY-R2",
                target_contract_id="xy-v14-0123456789abcdefabcd",
            )
            self.assertEqual([row["output_row_number"] for row in scope["items"]], [2, 3, 4])
            self.assertEqual([row["target_community_count"] for row in scope["items"]], [2, 1, 1])
            self.assertTrue(all(row["expected_source_status"] == "WRITEBACK_PENDING" for row in scope["items"]))

    def test_rejects_non_claim_failure(self):
        with tempfile.TemporaryDirectory() as name:
            index = Path(name) / "今日任务索引.json"
            index.write_text(json.dumps({"items": [{
                "row_number": 2, "video_id": "video", "channel": "A", "slot": "2026081906",
                "community_count": 1, "status": "WRITEBACK_PENDING", "current_stage": "xy-title",
                "error": "some later failure",
            }]}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "current_stage不是claim"):
                MODULE.build_claim_recovery_scope(
                    index,
                    batch_id="V2-19-RECOVERY-R2",
                    target_contract_id="xy-v14-0123456789abcdefabcd",
                )

if __name__ == "__main__":
    unittest.main()
