import importlib.util
import json
import sys
import unittest
from pathlib import Path


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
BATCH_SCRIPTS = SKILLS / "xy-batch-v14/scripts"
PACK_SCRIPTS = SKILLS / "xy-pack-v14/scripts"
for path in (BATCH_SCRIPTS, PACK_SCRIPTS):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


BATCH = load_module("v14_peripheral_batch_test", BATCH_SCRIPTS / "deterministic_batch.py")
CANONICAL = load_module("v14_peripheral_canonical_test", PACK_SCRIPTS / "canonical_outputs.py")

WHITELISTS = SKILLS / "xy-place-v14/rules/channel_hashtag_whitelists.json"
CURATION_EVIDENCE = SKILLS / "xy-place-v14/rules/channel_hashtag_curation_evidence.json"
PLACE_SKILL = SKILLS / "xy-place-v14/SKILL.md"
PLACE_PROMPT = SKILLS / "xy-place-v14/references/model_prompt.md"
POST_SKILL = SKILLS / "xy-post-v14/SKILL.md"
POST_PROMPT = SKILLS / "xy-post-v14/references/model_prompt.md"


class V14PeripheralGenerationPolicyTests(unittest.TestCase):
    def test_description_prompt_prioritizes_drama_specific_free_body_material(self):
        prompt = BATCH.build_prompt(
            "xy-place",
            "description skill",
            {
                "task": {"channel": "测试频道", "language": "英语"},
                "identity": {},
                "channel_snapshot": "",
                "channel_theme_contract": {},
                "semantic_contract": {},
                "title_payload": {},
                "plot_payload": {},
                "creative_history": [],
                "description_fixed_assets": {},
                "channel_hashtag_whitelist": {},
            },
            [],
        )

        self.assertIn("Use exactly one concrete mid-story event as the escalation", prompt)
        self.assertIn("two to four natural paragraphs", prompt)
        self.assertIn("any sentence whose removal would not reduce comprehension or suspense", prompt)
        self.assertIn("Do not stack several betrayals, props, or consequences into the opening sentence", prompt)
        self.assertIn("Name the relevant character instead of using a vague stranger", prompt)
        self.assertIn("Never place a blunt standalone genre declaration after the suspense", prompt)

    def test_description_prompt_performs_single_call_anchor_scoped_native_edit(self):
        prompt = BATCH.build_prompt(
            "xy-place",
            "description skill",
            {
                "task": {"channel": "测试频道", "language": "印地"},
                "identity": {},
                "channel_snapshot": "",
                "channel_theme_contract": {},
                "semantic_contract": {},
                "title_payload": {},
                "plot_payload": {},
                "creative_history": [],
                "description_fixed_assets": {},
                "channel_hashtag_whitelist": {},
            },
            [],
        )

        self.assertIn("Use editorial_anchor as the sole sentence-selection center", prompt)
        self.assertIn("delete it when removing it does not reduce understanding of that anchor", prompt)
        self.assertIn("The final suspense must directly close the loop with the opening misunderstanding", prompt)
        self.assertIn("silently reread and rewrite the body inside this same model call", prompt)
        self.assertIn("one spelling throughout", prompt)
        self.assertIn("narrator knowledge", prompt)
        self.assertIn("native collocation", prompt)
        self.assertNotIn("xy-place-editor", prompt)

    def test_description_viewing_expectation_stays_drama_specific(self):
        for path in (PLACE_SKILL, PLACE_PROMPT):
            text = path.read_text(encoding="utf-8")
            with self.subTest(path=path.name):
                self.assertIn(
                    "Leave at most one plot-specific unresolved question or a non-question suspense statement",
                    text,
                )

    def test_description_refinement_is_not_a_new_validator_rule(self):
        for path in (PLACE_SKILL, PLACE_PROMPT):
            text = path.read_text(encoding="utf-8")
            with self.subTest(path=path.name):
                self.assertIn(
                    "This remains a free-body generation and self-check preference, not a new Validator rule",
                    text,
                )

    def test_community_prompt_keeps_theme_as_context_and_shortens_image_hook_role(self):
        prompt = BATCH.build_prompt(
            "xy-post",
            "community skill",
            {
                "task": {"channel": "测试频道", "language": "英语", "community_count": 1},
                "identity": {},
                "channel_snapshot": "",
                "channel_theme_contract": {"channel_direction": "萌宝家庭", "plot_supported": True},
                "semantic_contract": {},
                "title_payload": {},
                "cover_payload": {},
                "plot_payload": {},
                "creative_history": [],
                "community_footer_cta": {},
            },
            [],
        )

        self.assertIn("Treat the channel theme as existing context for angle selection", prompt)
        self.assertIn(
            "image hook expresses one core conflict, choice, or relationship change",
            prompt,
        )
        self.assertIn("keep the full interaction question in the public copy", prompt)
        self.assertNotIn("include it naturally in both the public copy and image hook", prompt)

    def test_community_theme_phrase_is_not_required_verbatim_in_publication(self):
        context = {
            "semantic_contract": {"version": 6},
            "channel_theme_contract": {
                "channel_direction": "萌宝家庭",
                "plot_supported": True,
                "required_output_signals": ["孩子"],
            },
        }
        payload = {
            "results": [
                {
                    "selected_moment": "孩子主动坐到母亲身边",
                    "interaction_angle": "母亲是否接受这次团聚",
                    "copy_translation": "孩子选择重新靠近母亲。",
                    "channel_theme_phrase": "Family begins with a choice.",
                    "channel_theme_phrase_translation": "孩子让家庭重新靠近",
                    "copy": "The family must decide whether to begin again.",
                    "image_prompt_1x1": "A Chinese mother and children share one quiet decision.",
                }
            ]
        }

        issues = CANONICAL.channel_theme_alignment_issues("xy-post", payload, context)

        self.assertNotIn("post_1_localized_theme_phrase_missing_from_publication", issues)
        self.assertFalse(any(issue.endswith("localized_theme_phrase_missing") for issue in issues))

    def test_community_generation_uses_one_primary_audience_decision(self):
        for path in (POST_SKILL, POST_PROMPT):
            text = path.read_text(encoding="utf-8")
            with self.subTest(path=path.name):
                self.assertIn("one primary audience decision", text)
                self.assertIn(
                    "only the minimum background needed to understand that decision",
                    text,
                )
                self.assertIn(
                    "Do not introduce a second competing interaction goal",
                    text,
                )

    def test_community_single_goal_is_not_a_mechanical_text_gate(self):
        for path in (POST_SKILL, POST_PROMPT):
            text = path.read_text(encoding="utf-8")
            with self.subTest(path=path.name):
                self.assertIn(
                    "This is a generation priority, not a question-mark count, word limit, character limit, or Validator rule",
                    text,
                )

    def test_community_body_does_not_ask_before_the_single_formal_interaction_cta(self):
        for path in (POST_SKILL, POST_PROMPT):
            text = path.read_text(encoding="utf-8")
            with self.subTest(path=path.name):
                self.assertIn(
                    "The Community body before the formal interaction CTA must establish only scene, conflict, and choice background; it must not ask the audience any question",
                    text,
                )
                self.assertIn(
                    "Put the one audience-facing question only in the formal `🤔` interaction CTA",
                    text,
                )

    def test_curated_hashtag_assets_are_traceable_and_support_multiple_selections(self):
        whitelist = json.loads(WHITELISTS.read_text(encoding="utf-8"))
        evidence = json.loads(CURATION_EVIDENCE.read_text(encoding="utf-8"))

        self.assertEqual(set(whitelist["channels"]), set(evidence["channels"]))
        output_count = int(whitelist["additional_selection_count"])
        for channel, row in whitelist["channels"].items():
            with self.subTest(channel=channel):
                candidates = row["additional_whitelist"]
                channel_evidence = evidence["channels"][channel]["candidates"]
                self.assertGreater(len(candidates), output_count)
                self.assertEqual(set(candidates), set(channel_evidence))
                for tag in candidates:
                    sources = channel_evidence[tag]
                    self.assertTrue(
                        int(sources.get("historical_occurrences") or 0) >= 2
                        or bool(sources.get("public_ecology_evidence")),
                        tag,
                    )

    def test_hashtag_generation_uses_soft_supply_priority_without_fixed_quota(self):
        for path in (PLACE_SKILL, PLACE_PROMPT):
            text = path.read_text(encoding="utf-8")
            with self.subTest(path=path.name):
                self.assertIn(
                    "target-market audience-entry candidates first, then channel-history candidates, then current-drama-specific candidates, and finally cross-market generic candidates",
                    text,
                )
                self.assertIn("This is a soft supply and selection priority, not a fixed quota", text)
                self.assertIn(
                    "Cross-market generic tags are fallback coverage and must not dominate when eligible market-, channel-, or drama-specific candidates fit the current drama",
                    text,
                )

    def test_hashtag_generation_keeps_one_local_market_signal_when_relevant(self):
        rules = json.loads(BATCH.MACHINE_RULE_PATHS["xy-place"].read_text(encoding="utf-8"))
        contract = rules["description_contract"]["hashtag_local_market_coverage"]
        context = {
            "task": {"channel": "动态孟加拉频道", "language": "孟加拉"},
            "identity": {"video_id": "dynamic-video"},
            "channel_snapshot": "目标市场：孟加拉",
            "channel_theme_contract": {"channel_direction": "复仇逆袭"},
            "semantic_contract": {},
            "title_payload": {},
            "plot_payload": {"results": [{"plot_fields": {"内容概述": "动态真实剧情"}}]},
            "creative_history": [],
            "description_fixed_assets": {},
            "description_rule_contract": rules["description_contract"],
            "channel_hashtag_whitelist": {
                "channel_name": "动态孟加拉频道",
                "additional_candidates": ["#BanglaDrama", "#FamilyDrama"],
                "target_language_tags": ["#BanglaDrama"],
            },
        }
        prompt = BATCH.build_prompt(
            "xy-place",
            BATCH.SIMULATED_SKILLS["xy-place"].read_text(encoding="utf-8"),
            context,
            [],
        )

        self.assertEqual(contract["minimum_when_eligible"], 1)
        self.assertEqual(contract["preferred_when_highly_relevant"], "two_or_more")
        self.assertFalse(contract["fixed_quota"])
        self.assertFalse(contract["validator_gate"])
        self.assertIn("At least one of positions 1 and 2", prompt)
        self.assertIn("pre-registered exact-channel asset", prompt)
        self.assertIn("the model must not infer", prompt)

    def test_vetted_market_entry_tags_are_available_to_each_matching_channel(self):
        whitelist = json.loads(WHITELISTS.read_text(encoding="utf-8"))
        evidence = json.loads(CURATION_EVIDENCE.read_text(encoding="utf-8"))
        expected_by_language = {
            "俄语": {"#дорама", "#КитайскаяДорама", "#минидрама"},
            "印地": {"#HindiDubbed", "#CdramaHindiDubbed", "#chinesedramahindidubbed", "#chinesedramahindi", "#ChineseDramaInHindi"},
            "印尼": {"#dracin", "#filmcina"},
            "巴葡": {"#SérieCurta", "#dramachinês"},
            "菲律宾": {"#filipinodrama"},
            "西班牙": {"#dramachino"},
            "阿拉伯语": {"#دراما", "#مسلسل"},
        }

        for channel, row in evidence["channels"].items():
            expected = expected_by_language.get(row["language"], set())
            if not expected:
                continue
            with self.subTest(channel=channel):
                candidates = set(whitelist["channels"][channel]["additional_whitelist"])
                self.assertTrue(expected.issubset(candidates))
                for tag in expected:
                    self.assertTrue(row["candidates"][tag]["public_ecology_evidence"])


if __name__ == "__main__":
    unittest.main()
