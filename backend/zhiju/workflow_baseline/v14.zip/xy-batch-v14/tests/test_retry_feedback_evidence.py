import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
SCRIPT = SCRIPTS / "reconcile_retry_feedback_evidence.py"
SPEC = importlib.util.spec_from_file_location("retry_feedback_evidence_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class RetryFeedbackEvidenceTests(unittest.TestCase):
    def make_scope(self, root: Path):
        package = root / "印地" / "频道" / "剧目" / "剧_2026081812"
        package.mkdir(parents=True)
        old = "cover_1_visual_collision_with_history_1_fields_main_action_source_old"
        transient = "cover_2_visual_collision_with_history_2_fields_composition_source_transient"
        final = "cover_3_visual_collision_with_history_3_fields_palette_source_final"
        state = {
            "contract_id": "xy-v14-1234567890abcdef1234",
            "steps": {"xy-cover": {
                "status": "done", "retry_cycle": 3, "attempts": 1,
                "retry_history": [
                    {"retry_cycle": 1, "errors": [old]},
                    {"retry_cycle": 2, "errors": [final]},
                ],
            }},
        }
        state_path = package / "workflow_state.json"
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        seed = [old, transient, final]
        item = {
            "output_row_number": 2, "video_id": "video-a", "status": "TEXT_READY",
            "package_path": str(package), "retry_feedback_seed": seed,
        }
        index_path = root / "批量任务" / "batch" / "今日任务索引.json"
        index_path.parent.mkdir(parents=True)
        index_path.write_text(json.dumps({"items": [item]}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        scope = {
            "scope_version": 1, "mode": "retry_feedback_evidence",
            "source_index": str(index_path.relative_to(root)),
            "expected_source_index_sha256": digest(index_path),
            "expected_workflow_state_sha256": digest(state_path),
            "expected_contract_id": state["contract_id"],
            "output_row_number": 2, "video_id": "video-a", "stage": "xy-cover",
            "current_collision_feedback_history": seed,
            "cycle_feedback_history": {"1": [old], "2": [transient, final]},
        }
        scope_path = root / "scope.json"
        scope_path.write_text(json.dumps(scope, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return package, state_path, index_path, scope_path, seed

    def test_dry_run_is_read_only(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, state_path, index_path, scope_path, _ = self.make_scope(root)
            before = (digest(state_path), digest(index_path))
            result = MODULE.reconcile(root, scope_path, apply=False)
            self.assertTrue(result["dry_run"])
            self.assertEqual(result["content_generation_calls"], 0)
            self.assertEqual(result["feishu_writes"], 0)
            self.assertEqual(before, (digest(state_path), digest(index_path)))
            self.assertFalse((package / "workflow_events.jsonl").exists())

    def test_apply_only_reconciles_state_evidence(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            package, state_path, index_path, scope_path, seed = self.make_scope(root)
            index_sha = digest(index_path)
            result = MODULE.reconcile(root, scope_path, apply=True)
            state = json.loads(state_path.read_text())
            step = state["steps"]["xy-cover"]
            self.assertEqual(step["collision_feedback_history"], seed)
            self.assertEqual(step["retry_history"][0]["collision_feedback_history"], [seed[0]])
            self.assertEqual(step["retry_history"][1]["collision_feedback_history"], seed[1:])
            self.assertEqual(digest(index_path), index_sha)
            self.assertTrue((package / "workflow_events.jsonl").is_file())
            self.assertTrue(result["applied"])

    def test_stale_state_hash_fails_closed(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            _, state_path, _, scope_path, _ = self.make_scope(root)
            state_path.write_text("{}\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "workflow_state SHA不符"):
                MODULE.reconcile(root, scope_path, apply=True)


if __name__ == "__main__":
    unittest.main()
