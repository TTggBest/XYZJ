import importlib.util
import sys
import unittest
from pathlib import Path


PACK_SCRIPTS = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts"
SCRIPT = PACK_SCRIPTS / "canonical_outputs.py"
SPEC = importlib.util.spec_from_file_location("canonical_outputs_drama_still_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def natural_prompt(extra: str = "") -> str:
    base = """
Create a 1728x2160 vertical 4:5 realistic live-action Chinese short-drama thumbnail,
photographed like a candid television drama still. In a rain-wet apartment parking
garage, a Chinese wife has just discovered her husband with another woman. She stands
beside an open car door holding a smartphone with one clear surveillance image. Her
face is shocked but controlled. Her husband turns toward her in panic while the other
woman remains slightly behind him. Keep the scene focused on the three adults and their
emotional relationship. Their bodies overlap naturally and nobody poses directly for
the camera. Use an eye-level medium close-up with a natural 50mm photography feel and
asymmetrical actor blocking. Ordinary parked cars and wet concrete remain softly visible
behind them. Use realistic garage lighting mixed with soft post-rain daylight. Preserve
natural Chinese skin texture, normal facial shadows, clothing wrinkles, loose hair, and
slightly softer background detail. Add the exact Portuguese cover word “Traição” once in
available negative space. Premium live-action Chinese short-drama photography with
believable actors, accurate anatomy, expressive faces, and authentic location detail.
Chinese actors, Chinese facial features, East Asian appearance. No CGI look, no
futuristic interface, no holograms, no invented technology, no plastic skin, no beauty
filter, no floating props, no symmetrical poster layout, no excessive glow, no heavy
haze, no distorted hands, no extra fingers, and no text except the requested cover word.
"""
    return " ".join((base + " " + extra).split())


class CoverDramaStillQualityTests(unittest.TestCase):
    def test_controller_quality_floor_is_natural_tv_still_not_premium_ad_copy(self):
        payload = {"results": [{"titles": [{
            "core_words": "秘密",
            "scene_prompt_4_5": "A wife turns toward her husband in an apartment.",
            "outpaint_environment": "Continue the apartment walls and window light.",
        }]}]}

        MODULE.normalize_cover_prompt_contract(payload)

        prompt = payload["results"][0]["titles"][0]["prompt_4_5"]
        self.assertIn("Natural live-action Chinese television drama still", prompt)
        self.assertIn("ordinary clothing wrinkles", prompt)
        self.assertNotIn("Premium", prompt)
        self.assertNotIn("cinematic but realistic", prompt)

    def test_ai_poster_risk_rejects_futuristic_devices_and_named_geometry(self):
        prompt = (
            natural_prompt()
            + " A holographic display and glowing DNA device form a lightning-bolt composition."
        )

        audit = MODULE.audit_cover_prompt(prompt)

        self.assertGreaterEqual(audit["ai_poster_risk"], 7)
        self.assertIn("holographic display", audit["forbidden_terms"])
        self.assertIn("lightning-bolt composition", audit["forbidden_terms"])

    def test_one_invented_device_is_already_a_hard_rejection(self):
        prompt = natural_prompt() + " A holographic display floats between the actors."

        issues = MODULE.cover_prompt_quality_issues(prompt, 2)

        self.assertIn("cover_2_ai_poster_hard_forbidden", issues)

    def test_natural_drama_still_prompt_passes_quality_audit(self):
        audit = MODULE.audit_cover_prompt(natural_prompt())

        self.assertLessEqual(audit["ai_poster_risk"], 3)
        self.assertGreaterEqual(audit["real_drama_score"], 10)
        self.assertEqual(audit["forbidden_terms"], [])
        self.assertLessEqual(audit["word_count"], 320)

    def test_overprocessed_advertising_style_is_audit_only(self):
        prompt = natural_prompt(
            "Ultra sharp focus, crisp facial details, high micro-contrast, clean edges, and mobile readability."
        )

        issues = MODULE.cover_prompt_quality_issues(prompt, 2)
        evidence = MODULE.cover_prompt_quality_observations(prompt, 2)

        self.assertEqual(issues, [])
        self.assertIn("cover_2_overprocessed_advertising_style", evidence["observations"])

    def test_natural_live_action_style_contract_passes(self):
        issues = MODULE.image_prompt_style_issues(natural_prompt(), "cover_1")

        self.assertEqual(issues, [])

    def test_prompt_word_count_is_audit_only_without_upper_gate(self):
        prompt = natural_prompt("ordinary detail " * 180)

        issues = MODULE.cover_prompt_quality_issues(prompt, 1)
        evidence = MODULE.cover_prompt_quality_observations(prompt, 1)

        self.assertEqual(issues, [])
        self.assertGreater(evidence["word_count"], 320)

    def test_more_than_two_story_evidence_props_is_audit_only(self):
        prompt = natural_prompt(
            "She also presents a printed medical report, a wedding ring, and an ID card to explain the plot."
        )

        issues = MODULE.cover_prompt_quality_issues(prompt, 1)
        evidence = MODULE.cover_prompt_quality_observations(prompt, 1)

        self.assertEqual(issues, [])
        self.assertIn("cover_1_prop_density", evidence["observations"])

    def test_quality_normalization_does_not_add_ai_poster_styling(self):
        payload = {"results": [{"titles": [{
            "core_words": "秘密",
            "scene_prompt_4_5": "A wife closes a folder as her husband blocks the apartment doorway under window light.",
            "outpaint_environment": "Continue the apartment walls and window light.",
        }]}]}

        MODULE.normalize_cover_prompt_contract(payload)
        prompt = payload["results"][0]["titles"][0]["prompt_4_5"]

        self.assertNotIn("strong micro-contrast", prompt)
        self.assertNotIn("sharp facial highlights", prompt)
        self.assertNotIn("clean edges", prompt)
        self.assertIn("natural skin texture", prompt)
        self.assertIn("Realistic lens rendering", prompt)
        self.assertIn("ordinary clothing wrinkles", prompt)

    def test_quality_normalization_appends_one_canonical_style_block(self):
        scene = "A wife closes a folder as her husband blocks the apartment doorway under window light."
        payload = {"results": [{"titles": [{
            "core_words": "秘密",
            "scene_prompt_4_5": scene,
            "outpaint_environment": "Continue the apartment walls and window light.",
        }]}]}

        MODULE.normalize_cover_prompt_contract(payload)

        prompt = payload["results"][0]["titles"][0]["prompt_4_5"]
        self.assertTrue(prompt.startswith(scene))
        self.assertEqual(prompt.count(MODULE.COVER_STYLE_MARKER), 1)
        self.assertEqual(prompt.count(MODULE.COVER_IDENTITY_MARKER), 1)

    def test_controller_clauses_are_measured_without_a_hard_word_limit(self):
        prompt = " ".join(["ordinary"] * 170)
        payload = {"results": [{"titles": [{
            "core_words": "秘密",
            "scene_prompt_4_5": prompt,
            "outpaint_environment": "Continue the ordinary room walls and light.",
        }]}]}

        MODULE.normalize_cover_prompt_contract(payload)

        audit = MODULE.audit_cover_prompt(payload["results"][0]["titles"][0]["prompt_4_5"])
        self.assertGreater(audit["word_count"], 170)

    def test_supporting_style_metadata_alone_does_not_trigger_history_collision(self):
        current = [{
            "story_hook": "wife discovers a hidden child at a school gate",
            "scene_family": "school gate reunion",
            "main_action": "mother lowers herself and opens her arms",
            "key_prop": "phone",
            "composition": "eye-level foreground reaction",
            "palette": "natural daylight with one blue accent",
            "lighting": "soft window daylight",
        }]
        history = [{
            "story_hook": "executive exposes forged accounts during a meeting",
            "scene_family": "company boardroom exposure",
            "main_action": "chairwoman closes the ledger and points to the exit",
            "key_prop": "phone",
            "composition": "over-the-shoulder witness view",
            "palette": "natural daylight with one blue accent",
            "lighting": "soft window daylight",
        }]

        self.assertEqual(MODULE.visual_history_collision_issues(current, history), [])


if __name__ == "__main__":
    unittest.main()
