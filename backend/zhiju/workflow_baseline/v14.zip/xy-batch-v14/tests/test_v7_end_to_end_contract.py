import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


SKILLS = Path(__file__).resolve().parents[2]
BATCH_SCRIPTS = SKILLS / "xy-batch-v14" / "scripts"
SORT_SCRIPTS = SKILLS / "xy-sort-v14" / "scripts"
LOGO_SCRIPTS = SKILLS / "xy-logo-v14" / "scripts"
for folder in (BATCH_SCRIPTS, SORT_SCRIPTS, LOGO_SCRIPTS):
    if str(folder) not in sys.path:
        sys.path.insert(0, str(folder))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


BATCH = load("v7_e2e_batch", BATCH_SCRIPTS / "deterministic_batch.py")
CONTRACT = load("v7_e2e_contract", BATCH_SCRIPTS / "workflow_contract.py")
SORT = load("v7_e2e_sort", SORT_SCRIPTS / "sort_images.py")
LOGO = load("v7_e2e_logo", LOGO_SCRIPTS / "apply_logos_from_sort.py")


class V7EndToEndContractTests(unittest.TestCase):
    def test_sort_and_logo_are_file_operations_outside_generation_contract(self):
        with tempfile.TemporaryDirectory() as temp_name:
            root = Path(temp_name)
            batch_dir = root / "批量任务" / "canary"
            package = root / "西班牙" / "频道" / "剧目" / "测试剧_2026081700"
            batch_dir.mkdir(parents=True)
            package.mkdir(parents=True)
            contracts = BATCH.ContractBundle(batch_dir)
            item = {
                "package_path": str(package), "video_id": "video", "drama_name": "测试剧",
                "channel": "频道", "language": "西班牙", "slot": "2026081700",
                "community_count": 0, "need_community": 0,
                "writeback_readback_stages": ["xy-title", "xy-cover", "xy-place"],
            }
            covers = {"results": [{"titles": [
                {"title_index": index, "prompt_4_5": f"portrait {index}", "prompt_16_9": f"wide {index}"}
                for index in (1, 2, 3)
            ]}]}
            (package / "04_封面提示词.json").write_text(json.dumps(covers), encoding="utf-8")
            (package / "06_社群方案.json").write_text('{"results":[]}', encoding="utf-8")
            BATCH.build_prompt_manifest(
                package, item, contracts.machine("xy-cover"), contracts.contract_id
            )
            manifest_path = package / "images" / "prompts" / "出图任务清单.json"
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertEqual(manifest["contract_id"], contracts.contract_id)
            self.assertTrue(all(task["contract_id"] == contracts.contract_id for task in manifest["tasks"]))

            (package / "workflow_state.json").write_text(json.dumps({
                "status": "TEXT_READY", "contract_id": contracts.contract_id,
            }), encoding="utf-8")
            source = root / "source"
            source.mkdir()
            for sequence in (1, 2, 3):
                (source / f"video{sequence}.png").write_bytes(f"image-{sequence}".encode())
            item["image_tasks"] = manifest["tasks"]

            routing = SORT.route_images(source, {"items": [item]}, move=False, dry_run=False)
            queue = LOGO.logo_queue_from_sort_report({"items": routing["items"]})

            self.assertEqual(routing["matched_count"], 3)
            self.assertEqual(len(queue[str(package.resolve())]), 3)
            final_state = json.loads((package / "workflow_state.json").read_text(encoding="utf-8"))
            self.assertEqual(final_state["status"], "TEXT_READY")
            self.assertEqual(final_state["contract_id"], contracts.contract_id)


if __name__ == "__main__":
    unittest.main()
