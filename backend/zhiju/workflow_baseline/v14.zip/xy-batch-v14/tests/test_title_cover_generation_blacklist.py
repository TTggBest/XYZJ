import importlib.util
import json
import sys
import unittest
from pathlib import Path

from channel_context_fixture import structured_channel_snapshot


SKILLS = Path("/Volumes/TTggg_mini01_2T/CodexData/.codex/skills")
SCRIPTS = SKILLS / "xy-batch-v14" / "scripts"
sys.path.insert(0, str(SCRIPTS))

SPEC = importlib.util.spec_from_file_location(
    "title_cover_generation_blacklist_batch", SCRIPTS / "deterministic_batch.py"
)
BATCH = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = BATCH
SPEC.loader.exec_module(BATCH)


HARD_CONCEPTS = (
    "rape",
    "sexual assault",
    "molestation",
    "drugged",
    "date rape or drugging",
    "sold a person",
    "human trafficking",
    "kill",
    "murder",
    "shooting or killing",
    "suicide",
    "self-harm",
    "corpse or dead body",
    "bloody or gory",
    "torture",
    "poisoning to death",
    "brutal killing",
)

SOFT_CONCEPTS = (
    "domestic violence",
    "abuse",
    "kidnapping",
    "death threat",
)


class TitleCoverGenerationBlacklistTests(unittest.TestCase):
    def _title_prompt(self):
        return BATCH.build_prompt(
            "xy-title",
            "title rules",
            {
                "task": {"drama_name": "测试剧", "language": "印地", "workflow_contract_version": 2},
                "channel_theme_contract": {"channel_direction": "复仇逆袭", "plot_supported": True},
                "channel_snapshot": structured_channel_snapshot(),
            },
            ["title_1_format_mismatch"],
        )

    def _cover_prompt(self):
        return BATCH.build_prompt(
            "xy-cover",
            "cover rules",
            {
                "task": {"drama_name": "测试剧", "language": "印地", "workflow_contract_version": 2},
                "cover_rule_contract": BATCH.load_cover_rule_bundle(),
                "title_payload": {"results": [{"titles": [
                    {
                        "index": index,
                        "title": f"标题{index}",
                        "translation": f"翻译{index}",
                        "visual_thesis": f"视觉方向{index}",
                        "child_angle": False,
                        "child_role": "",
                        "safe_cover_scene": "",
                    }
                    for index in range(1, 4)
                ]}]},
            },
            ["cover_1_core_words_duplicate"],
        )

    def test_title_initial_and_retry_generation_carry_blacklist(self):
        prompt = self._title_prompt()
        self.assertIn("Strictly forbidden semantic concepts", prompt)
        self.assertIn("Prefer not to use these semantic concepts", prompt)
        for concept in HARD_CONCEPTS + SOFT_CONCEPTS:
            with self.subTest(concept=concept):
                self.assertIn(concept, prompt)

    def test_cover_initial_and_retry_generation_carry_same_blacklist(self):
        prompt = self._cover_prompt()
        self.assertIn("Strictly forbidden semantic concepts", prompt)
        self.assertIn("Prefer not to use these semantic concepts", prompt)
        for concept in HARD_CONCEPTS + SOFT_CONCEPTS:
            with self.subTest(concept=concept):
                self.assertIn(concept, prompt)

    def test_rule_sources_mark_blacklist_as_generation_only(self):
        title = json.loads((SKILLS / "xy-title-v14/rules/title_rules.json").read_text())
        cover = json.loads((SKILLS / "xy-cover-v14/rules/cover_rules.json").read_text())

        for rules in (title["title_contract"], cover["prompt_audit"]):
            blacklist = rules["generation_language_blacklist"]
            self.assertEqual(blacklist["enforcement"], "generation_instruction_only")
            self.assertEqual(blacklist["hard_forbidden_semantic_concepts"], list(HARD_CONCEPTS))
            self.assertEqual(blacklist["prefer_avoid_semantic_concepts"], list(SOFT_CONCEPTS))
        self.assertNotIn("generation_language_blacklist", cover.get("validator", {}))


if __name__ == "__main__":
    unittest.main()
