import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import drama_library as library


class DramaLibraryPagingTests(unittest.TestCase):
    def test_large_library_keeps_physical_rows_and_exact_plot_fields(self):
        header = ['作品名称', '内容概述', '剧情档案', '剧情套路', '核心人设']
        rows = {1: header, 102: ['边界剧', '概述', '档案', '套路', '人设']}

        def request(method, url, **kwargs):
            if '/wiki/' in url:
                return {'data': {'node': {'obj_type': 'sheet', 'obj_token': 'book'}}}
            import re
            match = re.search(r'!A(\d+):AZ(\d+)$', url)
            start, end = map(int, match.groups())
            if end - start + 1 > 100:
                raise RuntimeError('data exceeded 10485760 bytes')
            values = [rows.get(i, []) for i in range(start, end+1)]
            while values and not values[-1]:
                values.pop()
            return {'data': {'valueRange': {'values': values}}}

        with patch.object(library, 'load_config', return_value={}), \
             patch.object(library, 'get_token', return_value='test'), \
             patch.object(library, 'list_sheets', return_value=[{'title': '总库表', 'sheet_id': 'sid'}]), \
             patch.object(library, 'request_json', side_effect=request):
            client = library.DramaLibraryClient()
            client.preflight()
            result = client.exact_match('边界剧')['results'][0]
        self.assertEqual(result['source_row_number'], 102)
        self.assertEqual(result['plot_fields'], {'内容概述': '概述', '剧情档案': '档案', '剧情套路': '套路', '核心人设': '人设'})


if __name__ == '__main__':
    unittest.main()
