import importlib.util
import sys
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
PACK_SCRIPT = Path(__file__).resolve().parents[2] / "xy-pack-v14" / "scripts" / "canonical_outputs.py"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

CANONICAL_SPEC = importlib.util.spec_from_file_location("localized_core_words_canonical_test", PACK_SCRIPT)
CANONICAL = importlib.util.module_from_spec(CANONICAL_SPEC)
sys.modules[CANONICAL_SPEC.name] = CANONICAL
CANONICAL_SPEC.loader.exec_module(CANONICAL)

BATCH_SPEC = importlib.util.spec_from_file_location("localized_core_words_batch_test", SCRIPTS / "deterministic_batch.py")
BATCH = importlib.util.module_from_spec(BATCH_SPEC)
sys.modules[BATCH_SPEC.name] = BATCH
BATCH_SPEC.loader.exec_module(BATCH)


HINDI_RULES = {
    "prompt_audit": {"localized_core_words": {
        "require_idiomatic_native_phrase": True,
        "selection_priority": ["single_word", "natural_modifier_plus_head"],
        "language_rules": {
            "印地": {
                "relational_heads": ["प्यार", "प्रेम", "मोहब्बत"],
                "role_noun_modifiers": ["वारिस", "चेयरमैन", "अध्यक्ष", "मालिक", "सीईओ"],
                "measure_modifiers": ["करोड़", "करोड़ों", "लाख", "लाखों", "हजार", "हजारों"],
                "evidence_heads": ["रसीद", "रिपोर्ट", "करार", "सबूत"],
                "literal_impairment_modifiers": ["अंधा", "बहरा", "गूंगा"],
                "abstract_truth_heads": ["सच", "सच्चाई", "राज़"],
            }
        },
    }}
}


def test_real_hindi_mechanical_phrases_are_rejected_before_writeback():
    expected = {
        "वारिस प्रेम": "cover_1_core_words_unidiomatic_missing_linker",
        "चेयरमैन प्यार": "cover_1_core_words_unidiomatic_missing_linker",
        "करोड़ रसीद": "cover_1_core_words_unidiomatic_measure_compound",
        "अंधा सच": "cover_1_core_words_unidiomatic_semantic_pair",
    }
    for phrase, issue in expected.items():
        assert issue in CANONICAL.localized_core_words_issues(phrase, "印地", 1, HINDI_RULES)


def test_natural_hindi_one_or_two_word_alternatives_pass():
    for phrase in ("वारिस", "शाही प्यार", "महंगी रसीद", "कड़वा सच", "नकली वारिस", "आखिरी कॉल", "लौटी याद"):
        assert CANONICAL.localized_core_words_issues(phrase, "印地", 1, HINDI_RULES) == []


def test_core_word_naturalness_retry_has_actionable_generation_feedback():
    context = {
        "task": {"drama_name": "春迟海棠", "language": "印地", "gender": "女频"},
        "identity": {},
        "channel_snapshot": "",
        "channel_theme_contract": {},
        "cover_rule_contract": HINDI_RULES,
        "title_payload": {"results": [{"directions": [
            {"index": 1, "title": "T1", "translation": "译1"},
            {"index": 2, "title": "T2", "translation": "译2"},
            {"index": 3, "title": "T3", "translation": "译3"},
        ]}]},
    }
    prompt = BATCH.build_prompt(
        "xy-cover", "rules", context, ["cover_2_core_words_unidiomatic_missing_linker"]
    )
    feedback = prompt.split("Controller-owned actionable correction instructions:\n", 1)[1]
    assert "one idiomatic native word" in feedback
    assert "natural two-word modifier-plus-head phrase" in feedback
    assert "do not omit a required linker" in feedback
    persistent = prompt.split("Persistent generation requirements", 1)[1]
    assert "Never mechanically concatenate two plot nouns" in persistent
